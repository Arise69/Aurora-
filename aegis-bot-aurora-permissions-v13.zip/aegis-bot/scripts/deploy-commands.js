'use strict';
/**
 * Registers slash commands with Discord.
 *   npm run deploy            -> global (takes up to ~1 hour to propagate)
 *   DEV_GUILD_ID=<id> npm run deploy -> one guild, instant
 *   npm run deploy:clear      -> removes all commands (global, or from DEV_GUILD_ID)
 */
const { REST, Routes } = require('discord.js');
const env = require('../src/config/env');
const logger = require('../src/utils/logger');

async function deploy(commands, { clear = false } = {}) {
  env.validate({ needToken: true, needClientId: true });
  const rest = new REST({ version: '10' }).setToken(env.token);
  const body = clear ? [] : [...commands.values()].map((c) => c.data.toJSON());
  if (body.length > 100) throw new Error(`Too many top-level commands (${body.length}); Discord allows 100.`);
  const route = env.devGuildId ? Routes.applicationGuildCommands(env.clientId, env.devGuildId) : Routes.applicationCommands(env.clientId);
  await rest.put(route, { body });
  logger.info(`${clear ? 'Cleared' : `Registered ${body.length}`} command(s) ${env.devGuildId ? `in guild ${env.devGuildId}` : 'globally'}.`);
}

module.exports = { deploy };

if (require.main === module) {
  const { loadCommands } = require('../src/utils/loaders');
  deploy(loadCommands(), { clear: process.argv.includes('--clear') }).catch((err) => {
    logger.error('Command deployment failed', err);
    process.exit(1);
  });
}
