'use strict';
/** Applies pending database migrations and exits. (The bot also does this automatically on start.) */
const db = require('../src/database');
const logger = require('../src/utils/logger');

db.init()
  .then(() => db.close())
  .then(() => logger.info('Migrations complete.'))
  .catch((err) => { logger.error('Migration failed', err); process.exit(1); });
