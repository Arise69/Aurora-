'use strict';
const { Events } = require('discord.js');
const logger = require('../utils/logger');

const safe = async (label, fn) => { try { return await fn(); } catch (err) { logger.error(`messageCreate/${label} failed`, err); return false; } };

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (!message.guild) return;
    const client = message.client;
    if (message.system) return safe('boost', () => require('../services/greetings').onSystemMessage(message));
    if (message.author.id === client.user.id) return;

    // Feeds from bots/webhooks: only announcement auto-publish applies.
    if (message.author.bot || message.webhookId) return safe('autopublish', () => require('../services/utility').handleAutopublish(message));
    if (message.partial) return;
    // `message.member` is a read-only getter that resolves from the member cache; fetching populates that cache.
    if (!message.member) await message.guild.members.fetch(message.author.id).catch(() => null);
    if (!message.member) return;

    // Order matters: security first, then convenience features.
    if (await safe('antinuke-mention-spam', () => require('../services/antinuke').onMessage(message))) return;
    if (await safe('antispam', () => require('../services/antispam').process(message))) return;
    if (await safe('automod', () => require('../services/automod').process(message))) return;

    const utility = require('../services/utility');
    await Promise.all([safe('afk', () => utility.handleAfk(message)), safe('autopublish', () => utility.handleAutopublish(message))]);
    if (await safe('prefix', () => require('../prefix').handle(message))) return;
    await safe('autoresponder', () => require('../services/autoresponder').process(message));
    await safe('sticky', () => utility.handleSticky(message));
  },
};
