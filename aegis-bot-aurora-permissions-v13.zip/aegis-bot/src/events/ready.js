'use strict';
const { Events, ActivityType } = require('discord.js');
const logger = require('../utils/logger');
const env = require('../config/env');
const scheduler = require('../services/scheduler');
const voicemaster = require('../services/voicemaster');

module.exports = {
  name: Events.ClientReady ?? 'ready', // discord.js renamed 'ready' -> 'clientReady' in newer 14.x releases
  once: true,
  async execute(client) {
    logger.info(`Logged in as ${client.user.tag} — serving ${client.guilds.cache.size} guild(s), ${client.commands.size} top-level commands.`);
    client.user.setPresence({ activities: [{ name: 'custom', state: '/help • protecting servers', type: ActivityType.Custom }], status: 'online' });
    await voicemaster.reconcile().catch((err) => logger.warn(`Voice Master reconcile failed: ${err.message}`));
    scheduler.start(); // also ends giveaways / lockdowns that expired while the bot was offline
    if (env.autoDeploy) await require('../../scripts/deploy-commands').deploy(client.commands).catch((err) => logger.error('Auto-deploy failed', err));
  },
};
