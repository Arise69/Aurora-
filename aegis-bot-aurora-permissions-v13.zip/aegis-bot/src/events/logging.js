'use strict';
/** Server activity logging: messages, channels, roles, server settings and audit-log driven moderation events. */
const { Events, AuditLogEvent: A, ChannelType, PermissionsBitField } = require('discord.js');
const logging = require('../services/logging');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser, modEmbed, clip } = require('../utils/embeds');
const { discordTime } = require('../utils/duration');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const code = (s, n = 900) => `\`\`\`${clip(String(s).replace(/`/g, "'"), n)}\`\`\``;

// ── Recent audit-log entries, so channel/role events can name the executor ──
const recentAudit = new Map();
function rememberAudit(entry) {
  recentAudit.set(`${entry.action}:${entry.targetId}`, { entry, at: Date.now() });
  if (recentAudit.size > 300) for (const [k, v] of recentAudit) if (Date.now() - v.at > 30_000) recentAudit.delete(k);
}
async function findExecutor(actions, targetId) {
  await sleep(900); // audit-log entries arrive slightly after the gateway event
  for (const a of actions) {
    const hit = recentAudit.get(`${a}:${targetId}`);
    if (hit && Date.now() - hit.at < 15_000) return hit.entry.executor ?? (hit.entry.executorId ? { id: hit.entry.executorId, username: 'unknown' } : null);
  }
  return null;
}
const by = (executor) => ({ name: 'Changed by', value: executor ? describeUser(executor) : 'Unknown', inline: true });
const changed = (label, a, b) => (a === b ? null : { name: label, value: `${clip(a ?? '—', 400)} → ${clip(b ?? '—', 400)}` });
const overwriteSig = (ch) => [...(ch.permissionOverwrites?.cache?.values() ?? [])].map((o) => `${o.id}:${o.allow.bitfield}:${o.deny.bitfield}`).sort().join('|');

module.exports = [
  // ───────── Messages ─────────
  {
    name: Events.MessageDelete,
    async execute(message) {
      if (!message.guildId || message.author?.id === getClient().user.id) return;
      const guild = message.guild ?? getClient().guilds.cache.get(message.guildId);
      if (!guild) return;
      const files = message.attachments?.size ? [...message.attachments.values()].map((a) => a.name).join(', ') : null;
      await logging.send(guild, 'messages', makeEmbed({
        title: '🗑️ Message deleted', color: COLORS.error,
        fields: [
          { name: 'Author', value: message.author ? describeUser(message.author) : 'Unknown (message not cached)', inline: true },
          { name: 'Channel', value: `<#${message.channelId}>`, inline: true },
          { name: 'Content', value: message.content ? code(message.content) : message.partial ? '_Not cached_' : '_No text content_' },
          files ? { name: 'Attachments', value: clip(files, 1000) } : null,
        ].filter(Boolean),
        footer: `Message ID: ${message.id}${message.author ? ` • User ID: ${message.author.id}` : ''}`,
      }));
    },
  },
  {
    name: Events.MessageUpdate,
    async execute(oldMessage, newMessage) {
      if (!newMessage.guildId || newMessage.author?.bot || oldMessage.partial) return;
      if (oldMessage.content === newMessage.content) return;
      await logging.send(newMessage.guild, 'messages', makeEmbed({
        title: '✏️ Message edited', color: COLORS.warning, description: `[Jump to message](${newMessage.url})`,
        fields: [
          { name: 'Author', value: describeUser(newMessage.author), inline: true },
          { name: 'Channel', value: `<#${newMessage.channelId}>`, inline: true },
          { name: 'Before', value: oldMessage.content ? code(oldMessage.content, 1000) : '_empty_' },
          { name: 'After', value: newMessage.content ? code(newMessage.content, 1000) : '_empty_' },
        ],
        footer: `Message ID: ${newMessage.id}`,
      }));
    },
  },
  {
    name: Events.MessageBulkDelete,
    async execute(messages, channel) {
      await logging.send(channel.guild, 'messages', makeEmbed({
        title: '🗑️ Bulk message delete', color: COLORS.error,
        fields: [{ name: 'Channel', value: `<#${channel.id}>`, inline: true }, { name: 'Messages', value: String(messages.size), inline: true }],
      }));
    },
  },

  // ───────── Channels ─────────
  {
    name: Events.ChannelCreate,
    async execute(channel) {
      if (!channel.guild) return;
      require('../services/antinuke').captureChannel(channel).catch(() => {});
      const who = await findExecutor([A.ChannelCreate], channel.id);
      await logging.send(channel.guild, 'channels', makeEmbed({
        title: '📁 Channel created', color: COLORS.success,
        fields: [{ name: 'Channel', value: `<#${channel.id}> (\`${channel.name}\`)`, inline: true }, { name: 'Type', value: ChannelType[channel.type] ?? String(channel.type), inline: true }, by(who)],
        footer: `Channel ID: ${channel.id}`,
      }));
    },
  },
  {
    name: Events.ChannelDelete,
    async execute(channel) {
      if (!channel.guild) return;
      // The deleted channel object is still available during this event; snapshot it before recovery logic runs.
      require('../services/antinuke').captureChannel(channel).catch(() => {});
      const who = await findExecutor([A.ChannelDelete], channel.id);
      await logging.send(channel.guild, 'channels', makeEmbed({
        title: '🗑️ Channel deleted', color: COLORS.error,
        fields: [{ name: 'Channel', value: `\`${channel.name}\``, inline: true }, { name: 'Type', value: ChannelType[channel.type] ?? String(channel.type), inline: true }, by(who)],
        footer: `Channel ID: ${channel.id}`,
      }));
    },
  },
  {
    name: Events.ChannelUpdate,
    async execute(oldCh, newCh) {
      if (!newCh.guild) return;
      require('../services/antinuke').captureChannel(newCh).catch(() => {});
      const fields = [
        changed('Name', oldCh.name, newCh.name), changed('Topic', oldCh.topic, newCh.topic),
        changed('NSFW', oldCh.nsfw, newCh.nsfw), changed('Slowmode (s)', oldCh.rateLimitPerUser, newCh.rateLimitPerUser),
        changed('User limit', oldCh.userLimit, newCh.userLimit), changed('Category', oldCh.parentId ? `<#${oldCh.parentId}>` : null, newCh.parentId ? `<#${newCh.parentId}>` : null),
        overwriteSig(oldCh) !== overwriteSig(newCh) ? { name: 'Permissions', value: 'Permission overwrites were changed' } : null,
      ].filter(Boolean);
      if (!fields.length) return;
      const who = await findExecutor([A.ChannelUpdate, A.ChannelOverwriteCreate, A.ChannelOverwriteUpdate, A.ChannelOverwriteDelete], newCh.id);
      await logging.send(newCh.guild, 'channels', makeEmbed({
        title: '🛠️ Channel updated', color: COLORS.info, description: `<#${newCh.id}>`, fields: [...fields, by(who)], footer: `Channel ID: ${newCh.id}`,
      }));
    },
  },

  // ───────── Roles ─────────
  {
    name: Events.GuildRoleCreate,
    async execute(role) {
      require('../services/antinuke').captureRole(role).catch(() => {});
      const who = await findExecutor([A.RoleCreate], role.id);
      await logging.send(role.guild, 'roles', makeEmbed({ title: '🏷️ Role created', color: COLORS.success, fields: [{ name: 'Role', value: `<@&${role.id}> (\`${role.name}\`)`, inline: true }, by(who)], footer: `Role ID: ${role.id}` }));
    },
  },
  {
    name: Events.GuildRoleDelete,
    async execute(role) {
      require('../services/antinuke').captureRole(role).catch(() => {});
      const who = await findExecutor([A.RoleDelete], role.id);
      await logging.send(role.guild, 'roles', makeEmbed({ title: '🗑️ Role deleted', color: COLORS.error, fields: [{ name: 'Role', value: `\`${role.name}\``, inline: true }, by(who)], footer: `Role ID: ${role.id}` }));
    },
  },
  {
    name: Events.GuildRoleUpdate,
    async execute(oldRole, newRole) {
      require('../services/antinuke').captureRole(newRole).catch(() => {});
      const added = new PermissionsBitField(oldRole.permissions).missing(newRole.permissions.bitfield);
      const removed = new PermissionsBitField(newRole.permissions).missing(oldRole.permissions.bitfield);
      const fields = [
        changed('Name', oldRole.name, newRole.name), changed('Color', oldRole.hexColor, newRole.hexColor),
        changed('Hoisted', oldRole.hoist, newRole.hoist), changed('Mentionable', oldRole.mentionable, newRole.mentionable),
        added.length ? { name: 'Permissions granted', value: clip(added.join(', '), 1000) } : null,
        removed.length ? { name: 'Permissions revoked', value: clip(removed.join(', '), 1000) } : null,
      ].filter(Boolean);
      if (!fields.length) return;
      const who = await findExecutor([A.RoleUpdate], newRole.id);
      await logging.send(newRole.guild, 'roles', makeEmbed({ title: '🛠️ Role updated', color: COLORS.info, description: `<@&${newRole.id}>`, fields: [...fields, by(who)], footer: `Role ID: ${newRole.id}` }));
    },
  },

  // ───────── Server ─────────
  {
    name: Events.GuildUpdate,
    async execute(oldG, newG) {
      const fields = [
        changed('Name', oldG.name, newG.name), changed('Description', oldG.description, newG.description),
        changed('Icon', oldG.icon, newG.icon), changed('Verification level', oldG.verificationLevel, newG.verificationLevel),
        changed('Content filter', oldG.explicitContentFilter, newG.explicitContentFilter), changed('2FA requirement', oldG.mfaLevel, newG.mfaLevel),
        changed('Owner', oldG.ownerId ? `<@${oldG.ownerId}>` : null, newG.ownerId ? `<@${newG.ownerId}>` : null),
        changed('AFK channel', oldG.afkChannelId, newG.afkChannelId), changed('System channel', oldG.systemChannelId, newG.systemChannelId),
        changed('Vanity URL', oldG.vanityURLCode, newG.vanityURLCode),
      ].filter(Boolean);
      if (!fields.length) return;
      const who = await findExecutor([A.GuildUpdate], newG.id);
      await logging.send(newG, 'server', makeEmbed({ title: '🏰 Server settings changed', color: COLORS.info, fields: [...fields, by(who)] }));
    },
  },

  // ───────── Audit-log driven: bans, kicks, timeouts, member role changes ─────────
  {
    name: Events.GuildAuditLogEntryCreate,
    async execute(entry, guild) {
      rememberAudit(entry);
      require('../services/antinuke').onAuditEntry(entry, guild).catch((err) => logger.warn(`Anti-nuke failed: ${err.message}`));
      const client = getClient();
      if (entry.executorId === client.user.id) return; // the bot's own actions are logged by the service that performed them

      const target = entry.target && entry.target.id ? entry.target : { id: entry.targetId };
      const executor = entry.executor ?? (entry.executorId ? { id: entry.executorId } : null);
      const reason = entry.reason ?? undefined;

      switch (entry.action) {
        case A.MemberBanAdd:
          return logging.logModeration(guild, { action: '🔨 Member Banned', color: COLORS.error, target, moderator: executor, reason, ids: { 'User ID': target.id } });
        case A.MemberBanRemove:
          return logging.logModeration(guild, { action: '🔓 Member Unbanned', color: COLORS.success, target, moderator: executor, reason, ids: { 'User ID': target.id } });
        case A.MemberKick:
          return logging.logModeration(guild, { action: '👢 Member Kicked', color: COLORS.mod, target, moderator: executor, reason, ids: { 'User ID': target.id } });
        case A.MemberUpdate: {
          const change = entry.changes?.find((c) => c.key === 'communication_disabled_until');
          if (!change) return undefined;
          const until = change.new ? new Date(change.new).getTime() : null;
          return logging.send(guild, 'moderation', modEmbed({
            action: until ? '🔇 Member Timed Out' : '🔊 Timeout Removed', color: until ? COLORS.mod : COLORS.success, target, moderator: executor, reason,
            fields: until ? [{ name: 'Ends', value: discordTime(until, 'R'), inline: true }] : [], ids: { 'User ID': target.id },
          }));
        }
        case A.MemberRoleUpdate: {
          const add = entry.changes?.find((c) => c.key === '$add')?.new ?? [];
          const rem = entry.changes?.find((c) => c.key === '$remove')?.new ?? [];
          if (!add.length && !rem.length) return undefined;
          return logging.send(guild, 'roles', makeEmbed({
            title: '👥 Member roles changed', color: COLORS.info,
            fields: [
              { name: 'Member', value: describeUser(target), inline: true }, by(executor),
              add.length ? { name: 'Added', value: add.map((r) => `<@&${r.id}>`).join(' ') } : null,
              rem.length ? { name: 'Removed', value: rem.map((r) => `<@&${r.id}>`).join(' ') } : null,
            ].filter(Boolean),
            footer: `User ID: ${target.id}`,
          }));
        }
        default: return undefined;
      }
    },
  },
];
