'use strict';
const { Events, PermissionFlagsBits: P } = require('discord.js');
const { runCommand, handleError, checkRateLimit } = require('../middleware/guard');
const { fail } = require('../utils/reply');

const builtIn = {
  gw: (i) => require('../services/giveaways').handleComponent(i),
  verify: (i) => require('../services/verification').handleComponent(i),
  ticket: (i) => require('../services/tickets').handleComponent(i),
  help: (i) => require('../services/help').handleComponent(i),
  antinuke: (i) => require('../prefix/security').handleComponent(i),
  fp: (i) => require('../prefix/permissions').handleComponent(i),
  am: (i) => require('../prefix/automod').handleComponent(i),
  amw: (i) => require('../prefix/automod').handleWhitelistComponent(i),
  amh: (i) => require('../prefix/automod').handleHeatModal(i),
  ig: (i) => require('../prefix/ignore').handleComponent(i),
  igc: (i) => require('../prefix/ignore').handleChannelComponent(i),
  igm: (i) => require('../prefix/ignore').handleCommandComponent(i),
  igr: (i) => require('../prefix/ignore').handleRoleComponent(i),
};
let handlers = null;

/** Merges built-in component handlers with any `components` exported by command modules. */
function getHandlers(client) {
  if (handlers) return handlers;
  handlers = new Map(Object.entries(builtIn));
  for (const cmd of client.commands.values()) {
    for (const [prefix, fn] of Object.entries(cmd.components ?? {})) handlers.set(prefix, fn);
  }
  return handlers;
}

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    const client = interaction.client;

    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return fail(interaction, 'That command is no longer available.');
      return runCommand(interaction, command);
    }

    if (interaction.isAutocomplete()) {
      const command = client.commands.get(interaction.commandName);
      if (!command?.autocomplete || !interaction.inGuild()) return interaction.respond([]).catch(() => {});
      try {
        if (!interaction.memberPermissions?.has(command.autocompletePermission ?? P.ManageGuild)) return await interaction.respond([]);
        await command.autocomplete(interaction);
      } catch { await interaction.respond([]).catch(() => {}); }
      return undefined;
    }

    if (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isModalSubmit()) {
      const prefix = interaction.customId.split(':')[0];
      const handler = getHandlers(client).get(prefix);
      if (!handler) return undefined;
      const limited = checkRateLimit(interaction.user.id, `component:${prefix}`, 1);
      if (limited) return fail(interaction, limited);
      try { await handler(interaction); } catch (err) { await handleError(interaction, err, `in component ${prefix}`); }
    }
    return undefined;
  },
};
