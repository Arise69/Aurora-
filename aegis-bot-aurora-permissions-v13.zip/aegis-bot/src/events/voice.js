'use strict';
const { Events } = require('discord.js');
const logging = require('../services/logging');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser } = require('../utils/embeds');

module.exports = {
  name: Events.VoiceStateUpdate,
  async execute(oldState, newState) {
    await require('../services/voicemaster').onVoiceStateUpdate(oldState, newState);
    require('../services/music').onVoiceStateUpdate(oldState, newState);

    if (!newState.member || newState.channelId === oldState.channelId) return;
    const [title, color, desc] = !oldState.channelId
      ? ['🔊 Joined voice', COLORS.success, `Joined <#${newState.channelId}>`]
      : !newState.channelId
        ? ['🔇 Left voice', COLORS.neutral, `Left <#${oldState.channelId}>`]
        : ['🔀 Moved voice channel', COLORS.info, `<#${oldState.channelId}> → <#${newState.channelId}>`];
    await logging.send(newState.guild, 'voice', makeEmbed({
      title, color, description: desc, fields: [{ name: 'User', value: describeUser(newState.member.user) }], footer: `User ID: ${newState.member.id}`,
    }));
  },
};
