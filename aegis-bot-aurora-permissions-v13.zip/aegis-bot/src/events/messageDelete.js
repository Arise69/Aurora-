'use strict';
const { Events } = require('discord.js');
const snipe = require('../services/snipe');

module.exports = {
  name: Events.MessageDelete,
  async execute(message) {
    try { if (message.guild && !message.author?.bot) snipe.remember(message); } catch {}
  },
};
