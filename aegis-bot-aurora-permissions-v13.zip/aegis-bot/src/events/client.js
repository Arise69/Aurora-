'use strict';
const { Events } = require('discord.js');
const logger = require('../utils/logger');

module.exports = [
  { name: Events.Error, execute: (err) => logger.error('Discord client error', err) },
  { name: Events.Warn, execute: (msg) => logger.warn(`Discord warning: ${msg}`) },
  { name: Events.ShardDisconnect, execute: (ev, id) => logger.warn(`Shard ${id} disconnected (code ${ev.code}); discord.js will reconnect.`) },
  { name: Events.ShardReconnecting, execute: (id) => logger.info(`Shard ${id} reconnecting…`) },
  { name: Events.ShardResume, execute: (id, replayed) => logger.info(`Shard ${id} resumed (${replayed} events replayed).`) },
  { name: Events.GuildCreate, execute: (guild) => logger.info(`Joined guild ${guild.name} (${guild.id}) — ${guild.memberCount} members.`) },
  { name: Events.GuildDelete, execute: (guild) => { if (guild.available !== false) logger.info(`Removed from guild ${guild.id}. Data is kept in case the bot is re-invited.`); } },
];
