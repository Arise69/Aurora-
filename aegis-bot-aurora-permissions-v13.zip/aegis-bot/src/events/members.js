'use strict';
const { Events } = require('discord.js');
const logger = require('../utils/logger');
const logging = require('../services/logging');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser } = require('../utils/embeds');
const { discordTime, formatDuration } = require('../utils/duration');

const safe = async (label, fn) => { try { return await fn(); } catch (err) { logger.warn(`member handler ${label} failed: ${err.message}`); return null; } };

module.exports = [
  {
    name: Events.GuildMemberAdd,
    async execute(member) {
      const removed = await safe('antiraid', () => require('../services/antiraid').onMemberJoin(member));
      await logging.send(member.guild, 'members', makeEmbed({
        title: removed ? '📥 Member joined (removed by lockdown)' : '📥 Member joined', color: COLORS.success, thumbnail: member.user.displayAvatarURL(),
        fields: [
          { name: 'User', value: describeUser(member.user), inline: true },
          { name: 'Account created', value: `${discordTime(member.user.createdTimestamp, 'R')} (${formatDuration(Date.now() - member.user.createdTimestamp)} old)`, inline: true },
          { name: 'Member count', value: String(member.guild.memberCount), inline: true },
        ],
        footer: `User ID: ${member.id}`,
      }));
      if (removed) return;
      await safe('verification', () => require('../services/verification').onMemberJoin(member));
      await safe('autorole', () => require('../services/utility').applyAutorole(member));
      await safe('welcome', () => require('../services/greetings').sendGreeting('welcome', member));
    },
  },
  {
    name: Events.GuildMemberRemove,
    async execute(member) {
      await logging.send(member.guild, 'members', makeEmbed({
        title: '📤 Member left', color: COLORS.neutral, thumbnail: member.user?.displayAvatarURL?.(),
        fields: [
          { name: 'User', value: describeUser(member.user), inline: true },
          member.joinedTimestamp ? { name: 'Joined', value: discordTime(member.joinedTimestamp, 'R'), inline: true } : null,
          { name: 'Roles', value: member.roles?.cache?.filter((r) => r.id !== member.guild.id).map((r) => `<@&${r.id}>`).join(' ') || 'None (or not cached)' },
        ].filter(Boolean),
        footer: `User ID: ${member.id}`,
      }));
      if (member.partial) return;
      await safe('leave', () => require('../services/greetings').sendGreeting('leave', member));
      await safe('customrole', () => require('../services/customroles').onMemberLeave(member));
    },
  },
  { name: Events.PresenceUpdate, execute: (o, n) => require('../services/vanity').onPresence(o, n) },
  { name: Events.GuildRoleDelete, execute: (role) => require('../services/customroles').onRoleDelete(role) },
];
