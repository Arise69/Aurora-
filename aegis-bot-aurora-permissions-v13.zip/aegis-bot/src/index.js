'use strict';
const { Client, GatewayIntentBits: I, Partials, Options } = require('discord.js');
const env = require('./config/env');
const logger = require('./utils/logger');
const db = require('./database');
const { setClient } = require('./utils/context');
const { loadCommands, registerEvents } = require('./utils/loaders');

let client = null;
let shuttingDown = false;

function buildClient() {
  const flags = env.intents;
  const intents = [I.Guilds, I.GuildModeration, I.GuildMessages, I.GuildVoiceStates];
  if (flags.members) intents.push(I.GuildMembers);
  if (flags.messageContent) intents.push(I.MessageContent);
  if (flags.presences) intents.push(I.GuildPresences);
  if (!flags.members) logger.warn('ENABLE_GUILD_MEMBERS=false: join/leave logging, anti-raid, autorole and greetings will not work.');
  if (!flags.messageContent) logger.warn('ENABLE_MESSAGE_CONTENT=false: anti-spam, AutoMod, autoresponders and prefix commands cannot read message text.');

  return new Client({
    intents,
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
    allowedMentions: { parse: [], repliedUser: false }, // nothing pings unless a message explicitly opts in
    makeCache: Options.cacheWithLimits({ ...Options.DefaultMakeCacheSettings, MessageManager: 200, ReactionManager: 0 }),
    sweepers: { ...Options.DefaultSweeperSettings, messages: { interval: 300, lifetime: 3600 } },
  });
}

async function shutdown(signal, code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info(`${signal} received — shutting down gracefully…`);
  const force = setTimeout(() => { logger.error('Forced exit after shutdown timeout.'); process.exit(1); }, 12_000);
  force.unref();
  try {
    require('./services/scheduler').stop();
    require('./services/music').shutdownAll();
    await client?.destroy();
    await db.close();
  } catch (err) { logger.error('Error during shutdown', err); }
  process.exit(code);
}

async function main() {
  env.validate({ needToken: true });
  await db.init();
  client = buildClient();
  setClient(client);
  client.commands = loadCommands();
  registerEvents(client);
  await client.login(env.token);
}

process.on('unhandledRejection', (reason) => logger.error('Unhandled promise rejection', reason));
process.on('uncaughtException', (err) => { logger.error('Uncaught exception — exiting so the process manager can restart cleanly', err); shutdown('uncaughtException', 1); });
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

main().catch((err) => {
  logger.error('Fatal startup error', err);
  process.exit(1);
});
