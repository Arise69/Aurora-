'use strict';
const tags = require('../services/tags');
const utility = require('../services/utility');
const { AppError } = require('../utils/errors');
const { reply } = require('./helpers');

module.exports = [
  {
    name: 'afk', category: 'Utility', description: 'Set your AFK status. Usage: afk [reason]',
    async execute(message, args) {
      await utility.setAfk(message.guild.id, message.author.id, args.join(' ').slice(0, 200) || null);
      return reply(message, '💤 You are now AFK.');
    },
  },
  {
    name: 'tag', aliases: ['t'], category: 'Vanity & Tags', description: 'Show a tag. Usage: tag <name>',
    async execute(message, args) {
      if (!args[0]) throw new AppError('Usage: `tag <name>`');
      const tag = await tags.use(message.guild.id, args[0]);
      return reply(message, tag.content);
    },
  },
];
