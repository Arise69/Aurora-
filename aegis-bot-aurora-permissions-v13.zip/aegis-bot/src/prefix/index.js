'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const config = require('../services/guildConfig');
const { checkRateLimit } = require('../middleware/guard');
const { toUserMessage, reportUnexpected } = require('../utils/errors');
const { missingBotPermissions, permNames } = require('../utils/permissions');
const { reply } = require('./helpers');
const fakePermissions = require('../services/fakePermissions');
const ignoreList = require('../services/ignoreList');

const registry = [];
const byName = new Map();
for (const file of ['general', 'moderation', 'modbasic', 'music', 'utility', 'fun', 'security', 'owner', 'permissions', 'ignore', 'automod']) {
  for (const cmd of require(`./${file}`)) registry.push(cmd);
}
for (const cmd of require('./catalog').build(registry)) registry.push(cmd);
for (const cmd of registry) {
  for (const n of [cmd.name, ...(cmd.aliases ?? [])]) byName.set(n.toLowerCase(), cmd);
}
const maxCommandWords = Math.max(1, ...[...byName.keys()].map((n) => n.trim().split(/\s+/).length));

/** Handles "<prefix>command args". Returns true when the message was a prefix command. */
async function handle(message) {
  const { prefix } = await config.get(message.guild.id, 'general');
  const hasPrefix = message.content.startsWith(prefix);
  const noPrefix = !hasPrefix && await require('../services/botOwner').hasNoPrefixAccess(message.author.id);
  if (!hasPrefix && !noPrefix) return false;
  const tokens = (hasPrefix ? message.content.slice(prefix.length) : message.content).trim().split(/\s+/).filter(Boolean);
  if (!tokens.length) return false;
  let cmd = null;
  let consumed = 1;
  const limit = Math.min(maxCommandWords, tokens.length);
  for (let n = limit; n >= 1; n -= 1) {
    const candidate = tokens.slice(0, n).join(' ').toLowerCase();
    const hit = byName.get(candidate);
    if (hit) { cmd = hit; consumed = n; break; }
  }
  const args = tokens.slice(consumed);
  if (!cmd) return false;
  if (!message.channel.permissionsFor(message.guild.members.me)?.has(P.SendMessages)) return true;

  // Server ignore list: ignored commands are silently skipped for everyone except bypass users.
  if (await ignoreList.isCommandIgnored(message.guild.id, message.author.id, cmd)) return true;

  const limited = checkRateLimit(message.author.id, `prefix:${cmd.name}`, cmd.cooldown ?? 3);
  if (limited) { await reply(message, `❌ ${limited}`).catch(() => {}); return true; }
  if (cmd.userPermissions?.length && !(await fakePermissions.satisfies(message.member, cmd.userPermissions, { fakeable: cmd.fakePermissions !== false }))) {
    await reply(message, `❌ You don't have permission to use this command. Required: **${permNames(cmd.userPermissions).join(', ')}**.`).catch(() => {});
    return true;
  }
  const missing = missingBotPermissions(message.guild, cmd.botPermissions ?? [], message.channel);
  if (missing.length) { await reply(message, `❌ I'm missing: **${missing.join(', ')}**.`).catch(() => {}); return true; }

  try {
    await cmd.execute(message, args, { prefix });
  } catch (err) {
    const { message: text, silent } = toUserMessage(err);
    if (!silent) {
      const out = text ?? `Something went wrong on my side. (ref: \`${reportUnexpected(err, `in prefix command ${cmd.name}`)}\`)`;
      await reply(message, `❌ ${out}`).catch(() => {});
    }
  }
  return true;
}

/** Exact command name or alias (case-insensitive, may be several words) -> command, or undefined. */
const resolve = (name) => byName.get(String(name).trim().toLowerCase().replace(/\s+/g, ' '));

module.exports = { handle, registry, resolve };
