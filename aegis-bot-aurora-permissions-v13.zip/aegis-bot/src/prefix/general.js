'use strict';
const { makeEmbed } = require('../utils/embeds');
const { discordTime } = require('../utils/duration');
const { reply, resolveMember } = require('./helpers');

module.exports = [
  {
    name: 'prefix',
    aliases: ['getprefix'],
    category: 'Bot Settings',
    description: 'Show the current server prefix',
    async execute(message, args, { prefix }) {
      return reply(message, `My prefix for this server is \`${prefix}\`. Use \`${prefix}setprefix <new prefix>\` to change it.`);
    },
  },
  {
    name: 'setprefix',
    aliases: ['prefixset'],
    category: 'Bot Settings',
    description: 'Change the server prefix. Usage: setprefix <prefix>',
    userPermissions: [require('discord.js').PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      const next = String(args[0] ?? '').trim();
      if (!next) return reply(message, '❌ Usage: `setprefix <prefix>`');
      if (next.length > 5 || /\s/.test(next)) {
        return reply(message, '❌ The prefix must be 1–5 characters and cannot contain spaces.');
      }
      const config = require('../services/guildConfig');
      await config.update(message.guild.id, 'general', (draft) => {
        draft.prefix = next;
      }, { actorId: message.author.id, summary: `Prefix changed to ${next}` });
      return reply(message, `✅ Server prefix changed to \`${next}\`.`);
    },
  },
  {
    name: 'help', aliases: ['h'], category: 'General', description: 'Show commands. Usage: help [category|command]',
    async execute(message, args, { prefix }) {
      const view = require('../services/help').resolve(args.join(' '), prefix, message.guild);
      return reply(message, view ?? '❌ No category or command with that name. Try `,help`.');
    },
  },
  {
    name: 'ping', category: 'General', description: 'Show bot latency',
    async execute(message) {
      const sent = await reply(message, '🏓 Pinging…');
      return sent.edit({ content: `🏓 Pong! Round-trip **${sent.createdTimestamp - message.createdTimestamp}ms** • API **${Math.round(message.client.ws.ping)}ms**`, allowedMentions: { parse: [] } });
    },
  },
  {
    name: 'avatar', aliases: ['av'], category: 'General', description: 'Show a member avatar. Usage: avatar [@user]',
    async execute(message, args) {
      const member = (await resolveMember(message, args[0])) ?? message.member;
      return reply(message, { embeds: [makeEmbed({ title: `${member.user.username}'s avatar`, timestamp: false }).setImage(member.displayAvatarURL({ size: 1024 }))] });
    },
  },
  {
    name: 'userinfo', aliases: ['ui', 'whois'], category: 'General', description: 'Show member info. Usage: userinfo [@user]',
    async execute(message, args) {
      const m = (await resolveMember(message, args[0])) ?? message.member;
      return reply(message, { embeds: [makeEmbed({
        title: m.user.username, thumbnail: m.displayAvatarURL(),
        fields: [
          { name: 'ID', value: m.id, inline: true }, { name: 'Created', value: discordTime(m.user.createdTimestamp, 'R'), inline: true },
          { name: 'Joined', value: m.joinedTimestamp ? discordTime(m.joinedTimestamp, 'R') : 'Unknown', inline: true },
          { name: 'Top role', value: `${m.roles.highest}`, inline: true },
        ],
      })] });
    },
  },
];
