'use strict';
/**
 * Moderation > basic commands: `.ban` (alias `.hackban`) and `.softban`.
 * Flow: usage -> pre-checks (red "Process Denied !") -> 10s confirmation (Confirm / Remove) -> result embed.
 */
const { PermissionFlagsBits: P, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const moderation = require('../services/moderation');
const permsUtil = require('../utils/permissions');
const { AppError } = require('../utils/errors');
const { reply, requireUserId } = require('./helpers');
const ui = require('./ui');

const { ARROW, CHECK, CROSS } = ui;
const REASON = '<:reason:1556690309768024185>';
const MEMBERS = '<:members:1543490027777036381>';
const WHITECHECK = '<:whitecheck:1556694996835508294>';
const WICKARROW = '<:wickarrow:1556694640634241087>';
const CONFIRM_MS = 10_000;
const BOT_HIERARCHY = 'I cannot ban someone with a higher or equal role to me!';

const KINDS = {
  ban: {
    title: 'User have been banned!',
    usage: ['.ban <user> [reason] [delete_messages=False]', 'Ban a user from the server.', ['hackban']],
    run: ({ guild, user, member, moderator, reason, deleteDays }) => moderation.ban({ guild, targetUser: user, targetMember: member, moderator, reason, deleteDays }),
  },
  softban: {
    title: 'User have been soft banned!',
    usage: ['.softban <member> [reason]', 'Ban and unban a member to purge messages.', null],
    run: ({ guild, user, member, moderator, reason }) => moderation.softban({ guild, targetUser: user, targetMember: member, moderator, reason }),
  },
};

const deniedPayload = (text) => ({ embeds: [ui.deniedEmbed(text)] });
const inline = (s) => String(s).replace(/`/g, "'").replace(/\s+/g, ' ').trim().slice(0, 300);

/** `[reason...] [delete_messages=true|false]` — the flag is the last word, either `delete_messages=…` or a bare true/false/yes/no. */
function parseBanArgs(rest) {
  const words = [...rest];
  let deleteMessages = false;
  const last = words[words.length - 1];
  const m = last ? /^(?:(?:delete_messages|delete)=)?(true|false|yes|no|on|off|1|0)$/i.exec(last) : null;
  const prefixed = last && /=/.test(last);
  if (m && (prefixed || /^(true|false|yes|no)$/i.test(last))) {
    deleteMessages = /^(true|yes|on|1)$/i.test(m[1]);
    words.pop();
  }
  return { reason: words.join(' '), deleteMessages };
}

/** Everything that can be checked before asking for confirmation. Throws AppError(text) -> red denied embed. */
async function preflight(message, userId) {
  const { guild } = message;
  permsUtil.assertBotPermissions(guild, P.BanMembers);
  const user = await message.client.users.fetch(userId).catch(() => null);
  if (!user) throw new AppError('I could not find that user.');
  const member = await guild.members.fetch(userId).catch(() => null);
  if (member) {
    const problem = permsUtil.hierarchyProblem(guild, message.member, member, { needBot: false }); // yourself / me / owner / your role
    if (problem) throw new AppError(problem);
    const me = guild.members.me;
    if (!me || me.roles.highest.comparePositionTo(member.roles.highest) <= 0 || member.bannable === false) throw new AppError(BOT_HIERARCHY);
  } else if (await guild.bans.fetch({ user: userId, force: true }).catch(() => null)) {
    throw new AppError('That user is already banned.'); // also stops `softban` from unbanning someone
  }
  return { user, member };
}

const confirmPayload = (moderatorName) => ({
  embeds: [ui.plainEmbed(`### Do you want to continue? ${REASON}\n${ARROW}  Are you sure **${moderatorName}** ? You have \`10s\` to decide.`)],
  components: [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('modc:yes').setLabel('Confirm').setStyle(ButtonStyle.Success).setEmoji({ id: '1551675781527380011' }),
    new ButtonBuilder().setCustomId('modc:no').setLabel('Remove').setStyle(ButtonStyle.Danger).setEmoji({ id: '1551836362402177056' }),
  )],
  allowedMentions: { parse: [] },
});

/** Pure text of the result embed (unit-tested). */
function resultText({ title, nickname, moderatorName, dmSent, reason }) {
  return [
    `**${CHECK}  ${title}**`,
    `${MEMBERS}  \`${inline(nickname)}\``,
    `${WHITECHECK} **Moderator :** \`${inline(moderatorName)}\``,
    '',
    REASON,
    `${WICKARROW} Dm Done ? ${dmSent ? CHECK : CROSS} `,
    `${WICKARROW} **Reason :** \`${reason ? inline(reason) : 'Reason not provided'}\``,
  ].join('\n');
}

/** Waits (max 10s) for the moderator to press a button; other people get a private notice. Resolves 'yes' | 'no' | null (timeout). */
async function waitForChoice(prompt, moderatorId) {
  const deadline = Date.now() + CONFIRM_MS;
  for (;;) {
    const remaining = deadline - Date.now();
    if (remaining <= 0) return { choice: null };
    let i;
    try { i = await prompt.awaitMessageComponent({ componentType: ComponentType.Button, time: remaining }); } catch { return { choice: null }; }
    if (i.user.id !== moderatorId) {
      await i.reply({ content: '❌ Only the person who ran this command can use these buttons.', flags: MessageFlags.Ephemeral }).catch(() => {});
      continue;
    }
    await i.deferUpdate().catch(() => {});
    return { choice: i.customId === 'modc:yes' ? 'yes' : 'no', interaction: i };
  }
}

async function runBan(message, args, kind, prefix) {
  const def = KINDS[kind];
  if (!args.length) {
    const [command, text, aliases] = def.usage;
    return reply(message, { embeds: [ui.usageEmbed(`${prefix}${command.slice(1)}`, text, aliases, { space: false })] });
  }

  let target;
  let parsed;
  try {
    const userId = requireUserId(args[0]);
    parsed = kind === 'ban' ? parseBanArgs(args.slice(1)) : { reason: args.slice(1).join(' '), deleteMessages: false };
    target = await preflight(message, userId);
  } catch (err) {
    if (err instanceof AppError) return reply(message, deniedPayload(err.message));
    throw err;
  }

  const prompt = await reply(message, confirmPayload(message.author.username));
  const { choice } = await waitForChoice(prompt, message.author.id);
  if (choice !== 'yes') { await prompt.delete().catch(() => {}); return undefined; } // Remove pressed, or no answer in 10s: nothing happens

  const { user, member } = target;
  try {
    const { dmSent } = await def.run({
      guild: message.guild, user, member, moderator: message.member, reason: parsed.reason, deleteDays: parsed.deleteMessages ? 7 : 0,
    });
    const nickname = member?.displayName ?? user.globalName ?? user.username;
    return await prompt.edit({
      embeds: [ui.plainEmbed(resultText({ title: def.title, nickname, moderatorName: message.author.username, dmSent, reason: parsed.reason }))],
      components: [], allowedMentions: { parse: [] },
    });
  } catch (err) {
    const text = err instanceof AppError ? err.message : 'Discord refused the request. Check my permissions and role position.';
    await prompt.edit({ embeds: [ui.deniedEmbed(text)], components: [] }).catch(() => {});
    if (!(err instanceof AppError)) throw err;
    return undefined;
  }
}

module.exports = [
  {
    name: 'ban', aliases: ['hackban'], category: 'Moderation', description: 'Ban a user from the server.',
    userPermissions: [P.BanMembers],
    execute: (message, args, ctx = {}) => runBan(message, args, 'ban', ctx.prefix || '.'),
  },
  {
    name: 'softban', category: 'Moderation', description: 'Ban and unban a member to purge messages.',
    userPermissions: [P.BanMembers],
    execute: (message, args, ctx = {}) => runBan(message, args, 'softban', ctx.prefix || '.'),
  },
];
module.exports.parseBanArgs = parseBanArgs;
module.exports.resultText = resultText;
module.exports.BOT_HIERARCHY = BOT_HIERARCHY;
