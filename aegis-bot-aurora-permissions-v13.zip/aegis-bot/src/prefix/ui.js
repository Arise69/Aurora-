'use strict';
/** Shared look & feel for Aurora-style prefix replies (embed colours, emojis, usage / denied embeds, pager buttons). */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { makeEmbed } = require('../utils/embeds');

const COLOR = 0x2c2c2c;
const RED = 0xed4245;
const SPACE = '<a:space:1551669674213908510>';
const ARROW = '<:whitearrow:1551669900622172161>';
const CHECK = '<:wccheckmark:1551675781527380011>';
const CROSS = '<:wccrossmar:1551676376313237504>';
const ARROW_LIST = '<:arrow:1556670011232227368>'; // bullet used in the automod panels (the help pages use ARROW)
const YML = ['```yml', '<..> <required> | [..] [optional]', '```'];

/** "```yml legend``` > **`command`**  → Aliases / description" */
function usageEmbed(command, text, aliases, { space = true } = {}) {
  const lines = [...YML, `> **\`${command}\`**`, ''];
  if (aliases?.length) lines.push(`${space ? `${SPACE} ` : ''}${ARROW}  **Aliases :** ${aliases.map((a) => `\`${a}\``).join(', ')}`);
  lines.push(`${space ? `${SPACE} ` : ''}${ARROW}  ${text}`);
  return makeEmbed({ description: lines.join('\n'), color: COLOR, timestamp: false });
}

/**
 * Help page: "### Title [n]" + legend + one block per [command, text] + page footer.
 * Entries are split into pages of `perPage`; [n] is always the total number of entries.
 */
function helpPage(title, entries, nickname, { page = 0, perPage = entries.length || 1 } = {}) {
  const pages = Math.max(1, Math.ceil(entries.length / perPage));
  const i = Math.min(Math.max(page, 0), pages - 1);
  const lines = [`### ${title} [${entries.length}]`, ...YML, ''];
  for (const [command, text] of entries.slice(i * perPage, (i + 1) * perPage)) lines.push(`> **\`${command}\`**`, `${SPACE} ${ARROW}  ${text}`, '');
  lines.pop();
  lines.push(`-# Page ${i + 1}/${pages} | Requested by ${nickname}`);
  return makeEmbed({ description: lines.join('\n'), color: COLOR, timestamp: false });
}
const helpPageCount = (entries, perPage) => Math.max(1, Math.ceil(entries.length / perPage));

const deniedEmbed = (text) => makeEmbed({ description: `**Process Denied !**\n${CROSS}  ${text}`, color: RED, timestamp: false });
const plainEmbed = (description, color = COLOR) => makeEmbed({ description, color, timestamp: false });

// « ‹ and › » are text characters (labels); only the trash can is a real emoji.
const PAGER = { first: { label: '«' }, prev: { label: '‹' }, del: { emoji: '🗑️' }, next: { label: '›' }, last: { label: '»' } };
const PAGER_ACTIONS = Object.keys(PAGER);

/** Pager row; customId = `<idPrefix>:<action>:<userId>:<targetPage>` */
function pagerRow(idPrefix, userId, page, total) {
  const b = (action, target, disabled = false) => {
    const btn = new ButtonBuilder().setCustomId(`${idPrefix}:${action}:${userId}:${target}`).setStyle(ButtonStyle.Secondary).setDisabled(disabled);
    if (PAGER[action].label) btn.setLabel(PAGER[action].label); else btn.setEmoji(PAGER[action].emoji);
    return btn;
  };
  return new ActionRowBuilder().addComponents(
    b('first', 0, page === 0), b('prev', page - 1, page === 0), b('del', page),
    b('next', page + 1, page >= total - 1), b('last', total - 1, page >= total - 1),
  );
}

/** Configuring bot systems needs the REAL Manage Server permission (or the owner) - never a fake one. */
const hasRealManage = (guild, userId, permissions) => userId === guild.ownerId || !!permissions?.has(require('discord.js').PermissionFlagsBits.ManageGuild);

module.exports = { hasRealManage, helpPageCount, COLOR, RED, SPACE, ARROW, ARROW_LIST, CHECK, CROSS, usageEmbed, helpPage, deniedEmbed, plainEmbed, pagerRow, PAGER_ACTIONS };
