'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const moderation = require('../services/moderation');
const tools = require('../services/channelTools');
const { AppError } = require('../utils/errors');
const { parseDuration, formatDuration, discordTime } = require('../utils/duration');
const { makeEmbed } = require('../utils/embeds');
const { reply, requireMember, requireUserId } = require('./helpers');

const rest = (args, from) => args.slice(from).join(' ');

module.exports = [
  {
    name: 'warn', category: 'Moderation', description: 'Warn a member. Usage: warn @user <reason>', userPermissions: [P.ModerateMembers],
    async execute(message, args) {
      const target = await requireMember(message, args[0]);
      if (!rest(args, 1)) throw new AppError('Please provide a reason.');
      const r = await moderation.warn({ guild: message.guild, target, moderator: message.member, reason: rest(args, 1) });
      return reply(message, `✅ Warned ${target.user.username} (ID \`${r.id}\`, ${r.total} total).`);
    },
  },
  {
    name: 'warnings', aliases: ['warns'], category: 'Moderation', description: 'List warnings. Usage: warnings @user', userPermissions: [P.ModerateMembers],
    async execute(message, args) {
      const userId = requireUserId(args[0]);
      const rows = await moderation.listWarnings(message.guild.id, userId);
      if (!rows.length) return reply(message, 'ℹ️ That user has no warnings.');
      return reply(message, { embeds: [makeEmbed({ title: `Warnings (${rows.length})`, description: rows.slice(0, 10).map((w) => `\`${w.id}\` ${discordTime(Number(w.created_at), 'd')} — ${w.reason.slice(0, 120)}`).join('\n') })] });
    },
  },
  {
    name: 'kick', category: 'Moderation', description: 'Kick a member. Usage: kick @user [reason]', userPermissions: [P.KickMembers],
    async execute(message, args) {
      const target = await requireMember(message, args[0]);
      await moderation.kick({ guild: message.guild, target, moderator: message.member, reason: rest(args, 1) });
      return reply(message, `✅ Kicked ${target.user.username}.`);
    },
  },
  {
    name: 'unban', category: 'Moderation', description: 'Unban a user by ID. Usage: unban <id> [reason]', userPermissions: [P.BanMembers],
    async execute(message, args) {
      const user = await moderation.unban({ guild: message.guild, userId: requireUserId(args[0]), moderator: message.member, reason: rest(args, 1) });
      return reply(message, `✅ Unbanned ${user.username}.`);
    },
  },
  {
    name: 'mute', aliases: ['timeout'], category: 'Moderation', description: 'Timeout a member. Usage: mute @user <duration e.g. 10m> [reason]', userPermissions: [P.ModerateMembers],
    async execute(message, args) {
      const target = await requireMember(message, args[0]);
      const ms = parseDuration(args[1]);
      if (!ms) throw new AppError('Invalid duration. Examples: `10m`, `2h`, `1d`.');
      const applied = await moderation.timeout({ guild: message.guild, target, moderator: message.member, durationMs: ms, reason: rest(args, 2) });
      return reply(message, `✅ Timed out ${target.user.username} for ${formatDuration(applied)}.`);
    },
  },
  {
    name: 'unmute', aliases: ['untimeout'], category: 'Moderation', description: 'Remove a timeout. Usage: unmute @user', userPermissions: [P.ModerateMembers],
    async execute(message, args) {
      const target = await requireMember(message, args[0]);
      await moderation.untimeout({ guild: message.guild, target, moderator: message.member, reason: rest(args, 1) });
      return reply(message, `✅ Removed the timeout from ${target.user.username}.`);
    },
  },
  {
    name: 'purge', aliases: ['clear'], category: 'Moderation', description: 'Delete recent messages. Usage: purge <1-100>', userPermissions: [P.ManageMessages],
    async execute(message, args) {
      const amount = Number.parseInt(args[0], 10);
      const n = await tools.purge({ guild: message.guild, channel: message.channel, amount, moderator: message.member });
      const note = await message.channel.send({ content: `🧹 Deleted ${n} message(s).`, allowedMentions: { parse: [] } });
      setTimeout(() => note.delete().catch(() => {}), 4000).unref?.();
    },
  },
  {
    name: 'lock', category: 'Moderation', description: 'Lock this channel for @everyone', userPermissions: [P.ManageChannels],
    async execute(message, args) {
      await tools.setLocked({ guild: message.guild, channel: message.channel, locked: true, moderator: message.member, reason: rest(args, 0) || undefined });
      return reply(message, '🔒 Channel locked.');
    },
  },
  {
    name: 'unlock', category: 'Moderation', description: 'Unlock this channel', userPermissions: [P.ManageChannels],
    async execute(message, args) {
      await tools.setLocked({ guild: message.guild, channel: message.channel, locked: false, moderator: message.member, reason: rest(args, 0) || undefined });
      return reply(message, '🔓 Channel unlocked.');
    },
  },
];
