'use strict';
const music = require('../services/music');
const { AppError } = require('../utils/errors');
const { reply } = require('./helpers');

const ctl = async (message) => music.assertController(message.guild, message.member);

module.exports = [
  {
    name: 'play', aliases: ['p'], category: 'Music', description: 'Play a song. Usage: play <search | YouTube URL | audio URL>', cooldown: 3,
    async execute(message, args) {
      if (!args.length) throw new AppError('Tell me what to play: `play <search or URL>`.');
      const { track, position } = await music.play({ guild: message.guild, member: message.member, textChannel: message.channel, query: args.join(' ') });
      if (position > 0) return reply(message, `✅ Queued **${track.title.slice(0, 100)}** (position ${position}).`);
      return null;
    },
  },
  { name: 'skip', aliases: ['s'], category: 'Music', description: 'Skip the current track', async execute(m) { (await ctl(m)).player.stop(); return reply(m, '⏭️ Skipped.'); } },
  { name: 'stop', aliases: ['leave', 'dc'], category: 'Music', description: 'Stop and leave', async execute(m) { (await ctl(m)).destroy(); return reply(m, '⏹️ Stopped.'); } },
  { name: 'pause', category: 'Music', description: 'Pause playback', async execute(m) { (await ctl(m)).player.pause(); return reply(m, '⏸️ Paused.'); } },
  { name: 'resume', category: 'Music', description: 'Resume playback', async execute(m) { (await ctl(m)).player.unpause(); return reply(m, '▶️ Resumed.'); } },
  {
    name: 'queue', aliases: ['q'], category: 'Music', description: 'Show the queue',
    async execute(m) {
      const session = music.sessionFor(m.guild.id);
      if (!session) throw new AppError('Nothing is playing.');
      return reply(m, { embeds: [music.queueEmbed(session)] });
    },
  },
  {
    name: 'loop', category: 'Music', description: 'Cycle loop mode: off → track → queue',
    async execute(m) {
      const s = await ctl(m);
      s.loop = { off: 'track', track: 'queue', queue: 'off' }[s.loop];
      return reply(m, `🔁 Loop: **${s.loop}**`);
    },
  },
];
