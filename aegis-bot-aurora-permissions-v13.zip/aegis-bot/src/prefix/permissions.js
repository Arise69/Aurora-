'use strict';

const {
  PermissionFlagsBits: P, MessageFlags,
  ContainerBuilder, SectionBuilder, TextDisplayBuilder, ThumbnailBuilder, SeparatorBuilder, SeparatorSpacingSize,
  ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle,
} = require('discord.js');
const config = require('../services/guildConfig');
const fake = require('../services/fakePermissions');
const { makeEmbed } = require('../utils/embeds');
const { getClient } = require('../utils/context');
const { fail } = require('../utils/reply');
const { reply } = require('./helpers');
const ui = require('./ui');
const { AppError } = require('../utils/errors');

const { COLOR, SPACE, ARROW, CHECK, CROSS, deniedEmbed } = ui;
const OFF = '<:off:1551693996059787356>';
const ON = '<:on:1551833384131498014>';
const BTN_ALL_EMOJI = { id: '1551675781527380011' };
const BTN_RESET_EMOJI = { id: '1551836362402177056' };

const ID_PREFIX = 'fp';

/** Configuring fake permissions needs the REAL Manage Server permission (never a fake one). */
function hasRealManage(guild, userId, permissions) {
  return userId === guild.ownerId || !!permissions?.has(P.ManageGuild);
}
function requireManage(message) {
  if (!hasRealManage(message.guild, message.author.id, message.member.permissions)) {
    throw new AppError('You need **Manage Server** to manage fake permissions.');
  }
}

function roleFrom(message, args) {
  const mentioned = message.mentions.roles.first();
  if (mentioned) return mentioned;
  const raw = String(args[0] || '').replace(/[<@&>]/g, '');
  if (/^\d{17,20}$/.test(raw)) return message.guild.roles.cache.get(raw) || null;
  const name = args.join(' ').trim().toLowerCase();
  return name ? message.guild.roles.cache.find((r) => r.name.toLowerCase() === name) || null : null;
}

function assertConfigurable(guild, role) {
  if (!role || role.id === guild.id || role.managed) throw new AppError('That role cannot be configured for fake permissions.');
}

const cleanName = (s) => String(s ?? '').replace(/`/g, '');

// ───────────────────────── Panel ─────────────────────────

/** Pure text pieces of the panel (kept separate so they can be unit-tested without discord.js). */
const toggleList = (keys) => {
  const on = new Set(keys);
  return fake.CATEGORIES.map((c) => `> ${on.has(c.key) ? ON : OFF} » **\`${c.label}\`**`).join('\n');
};

function panelText(keys, roleMention, user) {
  return {
    head: `### Permissions Setup\n\n${toggleList(keys)}`,
    role: `${ARROW} **Role** » ${roleMention}`,
    foot: `-# Requested by <@${user.id}> (\`${cleanName(user.username)}\`)`,
  };
}

const cid = (action, userId, roleId) => `${ID_PREFIX}:${action}:${userId}:${roleId}`;

function buildPanel({ role, keys, user }) {
  const t = panelText(keys, `<@&${role.id}>`, user);
  const avatar = getClient()?.user?.displayAvatarURL?.() ?? null;

  const head = new SectionBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent(t.head));
  if (avatar) head.setThumbnailAccessory(new ThumbnailBuilder().setURL(avatar));

  const select = new StringSelectMenuBuilder()
    .setCustomId(cid('sel', user.id, role.id))
    .setPlaceholder('↳ Select permissions to toggle')
    .setMinValues(1)
    .setMaxValues(fake.CATEGORIES.length)
    .addOptions(fake.CATEGORIES.map((c) => ({ label: c.label, value: c.key })));
  const buttons = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('all', user.id, role.id)).setLabel('All Perms').setStyle(ButtonStyle.Success).setEmoji(BTN_ALL_EMOJI),
    new ButtonBuilder().setCustomId(cid('reset', user.id, role.id)).setLabel('Reset').setStyle(ButtonStyle.Danger).setEmoji(BTN_RESET_EMOJI),
  );

  const container = new ContainerBuilder()
    .setAccentColor(COLOR)
    .addSectionComponents(head)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.role))
    .addActionRowComponents(new ActionRowBuilder().addComponents(select), buttons)
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.foot));
  return { components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } };
}

async function handleListClick(interaction, action, page) {
  if (action === 'del') return interaction.message.delete().catch(() => {});
  const rows = await configuredRoles(interaction.guild);
  if (!rows.length) return interaction.update({ embeds: [emptyListEmbed()], components: [], allowedMentions: { parse: [] } });
  const nickname = interaction.member?.displayName ?? interaction.user.username;
  return interaction.update(buildListPage({ rows, page, user: interaction.user, nickname }));
}

/** Button / select handler (customId `fp:<sel|all|reset>:<requesterId>:<roleId>`). Registered in events/interactionCreate. */
async function handleComponent(interaction) {
  const [, action, userId, roleId] = interaction.customId.split(':');
  if (!interaction.inGuild() || !interaction.guild) return undefined;
  if (interaction.user.id !== userId) return fail(interaction, 'Only the person who opened this panel can use it.');
  if (ui.PAGER_ACTIONS.includes(action)) return handleListClick(interaction, action, Number.parseInt(roleId, 10) || 0);
  // Re-checked on every click: the panel may have been opened before the person lost the permission.
  if (!hasRealManage(interaction.guild, interaction.user.id, interaction.memberPermissions)) {
    return fail(interaction, 'You need **Manage Server** to manage fake permissions.');
  }
  const role = interaction.guild.roles.cache.get(roleId);
  if (!role || role.id === interaction.guild.id || role.managed) return fail(interaction, 'That role no longer exists or cannot be configured.');

  const audit = { actorId: interaction.user.id };
  let keys;
  if (action === 'sel') {
    const picked = fake.normalizeKeys(interaction.values ?? []);
    keys = await fake.updateRole(interaction.guild.id, role.id, (cur) => {
      for (const k of picked) { if (cur.has(k)) cur.delete(k); else cur.add(k); }
      return cur;
    }, { ...audit, summary: `Fake permissions toggled for ${role.name}: ${picked.join(', ')}` });
  } else if (action === 'all') {
    keys = await fake.updateRole(interaction.guild.id, role.id, () => fake.KEYS, { ...audit, summary: `All fake permissions granted to ${role.name}` });
  } else if (action === 'reset') {
    keys = await fake.updateRole(interaction.guild.id, role.id, () => [], { ...audit, summary: `Fake permissions reset for ${role.name}` });
  } else return undefined;

  return interaction.update(buildPanel({ role, keys, user: interaction.user }));
}

// ───────────────────────── List (paged) ─────────────────────────

/** Configured roles that still exist, highest role first (stable order across page clicks). */
async function configuredRoles(guild) {
  const cfg = await config.get(guild.id, 'permissions');
  return Object.entries(cfg.roles || {})
    .map(([id, data]) => ({ role: guild.roles.cache.get(id), keys: fake.normalizeKeys(data?.permissions) }))
    .filter((x) => x.role && x.keys.length)
    .sort((a, b) => b.role.position - a.role.position);
}

const emptyListEmbed = () => deniedEmbed('There are no fake permission roles configured on this server.');

/** Pure text of one page (unit-tested). */
function listPageText({ keys, roleMention, page, total, nickname }) {
  return [
    `### Fake Permission Roles [${total}]`,
    toggleList(keys),
    '',
    `${ARROW} **Role :** ${roleMention}`,
    `-# Page ${page + 1}/${total} | Requested by ${nickname}`,
  ].join('\n');
}

function buildListPage({ rows, page, user, nickname }) {
  const i = Math.min(Math.max(page, 0), rows.length - 1);
  const embed = makeEmbed({
    description: listPageText({ keys: rows[i].keys, roleMention: `<@&${rows[i].role.id}>`, page: i, total: rows.length, nickname }),
    color: COLOR, timestamp: false,
  });
  const payload = { embeds: [embed], allowedMentions: { parse: [] } };
  if (rows.length > 1) payload.components = [ui.pagerRow(ID_PREFIX, user.id, i, rows.length)];
  return payload;
}

// ───────────────────────── Text commands ─────────────────────────

function helpEmbed(message) {
  return makeEmbed({
    title: 'Aurora permissions [5]',
    description: [
      '```yml',
      '<..> <required> | [..] [optional]',
      '```',
      '',
      '> **`.permissions grant`**',
      `${SPACE} ${ARROW} Grant or setup fake permissions for a role.`,
      '',
      '> **`.permissions list`**',
      `${ARROW} ${SPACE} List all fake permission roles in the server.`,
      '',
      '> **`.permissions manage`**',
      `${SPACE} ${ARROW} Manage already configured fake permission roles.`,
      '',
      '> **`.permissions resetall`**',
      `${SPACE} ${ARROW} Revoke all fake permissions from every role.`,
      '',
      '> **`.permissions revoke`**',
      `${SPACE} ${ARROW} Revoke all fake permissions from role.`,
      `-# Page 1/1 | Requested by ${message.member?.displayName || message.author.username}`,
    ].join('\n'),
    color: COLOR, timestamp: false,
  });
}

const usageEmbed = (prefix, sub, text, aliases, opts) => ui.usageEmbed(`${prefix}permissions ${sub}`, text, aliases, opts);

async function grant(message, args, prefix) {
  requireManage(message);
  const role = roleFrom(message, args);
  if (!role) {
    return reply(message, { embeds: [usageEmbed(prefix, 'grant <role>', 'Grant or setup fake permissions for a role.', ['setup'])] });
  }
  return openPanel(message, role);
}

/** The toggle panel shown by both `grant` and `manage`. */
async function openPanel(message, role) {
  assertConfigurable(message.guild, role);
  const keys = await fake.keysOfRole(message.guild.id, role.id);
  return reply(message, buildPanel({ role, keys, user: message.author }));
}

async function list(message) {
  const rows = await configuredRoles(message.guild);
  if (!rows.length) return reply(message, { embeds: [emptyListEmbed()] });
  return reply(message, buildListPage({ rows, page: 0, user: message.author, nickname: message.member?.displayName || message.author.username }));
}

async function manage(message, args, prefix) {
  requireManage(message);
  const role = roleFrom(message, args);
  if (!role) {
    return reply(message, { embeds: [usageEmbed(prefix, 'manage <role>', 'Manage already configured fake permission roles.', null, { space: false })] });
  }
  if (!(await configuredRoles(message.guild)).length) {
    return reply(message, { embeds: [deniedEmbed('There are no fake permission roles configured to manage.')] });
  }
  return openPanel(message, role);
}


async function revoke(message, args, prefix) {
  requireManage(message);
  const role = roleFrom(message, args);
  if (!role) return reply(message, { embeds: [usageEmbed(prefix, 'revoke <role>', 'Revoke all fake permissions from role.', ['remove'])] });
  if (!(await fake.keysOfRole(message.guild.id, role.id)).length) {
    return reply(message, { embeds: [deniedEmbed(`${role} does not have any fake permissions configured.`)] });
  }
  await fake.updateRole(message.guild.id, role.id, () => [], { actorId: message.author.id, summary: `Fake permissions revoked from ${role.name}` });
  return reply(message, { embeds: [makeEmbed({
    description: `**${CHECK} Permissions Revoked**\n${ARROW}  Successfully revoked all fake permissions for ${role}.`,
    color: COLOR, timestamp: false,
  })] });
}

async function resetAll(message) {
  requireManage(message);
  const rows = await configuredRoles(message.guild);
  await config.update(message.guild.id, 'permissions', (d) => { d.roles = {}; }, { actorId: message.author.id, summary: `All fake permissions reset (${rows.length} role(s))` });
  return reply(message, { embeds: [makeEmbed({
    title: `${CHECK} Fake Permissions Reset`,
    description: rows.length
      ? `${ARROW} All fake permissions have been revoked from **${rows.length}** role(s).`
      : `${SPACE} ${ARROW} No fake permission roles were configured.`,
    color: COLOR, timestamp: false,
  })] });
}

module.exports = [{
  name: 'permissions',
  aliases: ['setup', 'perms', 'permission'],
  category: 'Permit Commands',
  description: 'Manage Aurora fake permissions',
  userPermissions: [P.ManageGuild],
  fakePermissions: false, // a fake permission can never be used to edit fake permissions
  async execute(message, args, ctx = {}) {
    const prefix = ctx.prefix || '.';
    const action = String(args.shift() || 'help').toLowerCase();
    if (action === 'help' || action === 'show') return reply(message, { embeds: [helpEmbed(message)] });
    if (action === 'grant') return grant(message, args, prefix);
    if (action === 'list' || action === 'ls') return list(message);
    if (action === 'manage' || action === 'edit') return manage(message, args, prefix);
    if (action === 'revoke' || action === 'remove') return revoke(message, args, prefix);
    if (action === 'resetall' || action === 'reset' || action === 'clear') return resetAll(message);
    throw new AppError('Use `.permissions show`, `grant`, `list`, `manage`, `resetall` or `revoke`.');
  },
}];

module.exports.handleComponent = handleComponent;
module.exports.panelText = panelText;
module.exports.listPageText = listPageText;
module.exports.command = module.exports[0];
module.exports.handleListClick = handleListClick;
