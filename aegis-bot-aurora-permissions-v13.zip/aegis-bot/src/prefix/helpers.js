'use strict';
const { AppError } = require('../utils/errors');

const reply = (message, content) =>
  message.reply(typeof content === 'string' ? { content, allowedMentions: { parse: [], repliedUser: false } } : { allowedMentions: { parse: [], repliedUser: false }, ...content });

/** <@id>, <@!id> or raw id -> GuildMember (or null). */
async function resolveMember(message, arg) {
  const id = String(arg ?? '').match(/^<@!?(\d{17,20})>$|^(\d{17,20})$/);
  if (!id) return null;
  return message.guild.members.fetch(id[1] ?? id[2]).catch(() => null);
}

async function requireMember(message, arg) {
  const m = await resolveMember(message, arg);
  if (!m) throw new AppError('Please mention a member of this server (or give their ID).');
  return m;
}

const requireUserId = (arg) => {
  const id = String(arg ?? '').match(/^<@!?(\d{17,20})>$|^(\d{17,20})$/);
  if (!id) throw new AppError('Please mention a user or provide a user ID.');
  return id[1] ?? id[2];
};

module.exports = { reply, resolveMember, requireMember, requireUserId };
