'use strict';
const { PermissionFlagsBits: P, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const config = require('../services/guildConfig');
const DEFAULTS = require('../config/defaults');
const { reply } = require('./helpers');
const { permNames } = require('../utils/permissions');
const { COLORS } = require('../config/constants');
const { makeEmbed } = require('../utils/embeds');
const antinuke = require('../services/antinuke');
const permit = require('../services/permit');

async function needManage(message, c = null) {
  const extraOwner = await permit.isPermitted(message.guild.id, message.member, 'antinuke');
  if (extraOwner) return true;
  if (!(await require('../services/fakePermissions').satisfies(message.member, P.ManageGuild))) throw new Error(`You need **${permNames([P.ManageGuild])[0]}** to use this command.`);
  return true;
}
function parseBool(v) {
  const s = String(v ?? '').toLowerCase();
  return ['on','true','yes','enable','enabled'].includes(s) ? true : ['off','false','no','disable','disabled'].includes(s) ? false : null;
}
async function ownerGuard(message, c) {
  if (!c.ownerOnly || message.author.id === message.guild.ownerId) return true;
  const extraOwner = await permit.isPermitted(message.guild.id, message.member, 'antinuke');
  if (!extraOwner) throw new Error('Anti-nuke settings are restricted to the server owner and Extra Owners.');
  return true;
}

const MODULES = new Map([
  ['channel-create','channelCreate'], ['channel-delete','channelDelete'], ['channel-update','channelUpdate'],
  ['role-create','roleCreate'], ['role-delete','roleDelete'], ['role-update','roleUpdate'], ['role-position','rolePosition'],
  ['ban','ban'], ['kick','kick'], ['bot-add','botAdd'],
  ['webhook-create','webhookCreate'], ['webhook-delete','webhookDelete'], ['webhook-update','webhookUpdate'],
  ['guild-update','guildUpdate'], ['vanity-update','vanityUpdate'], ['onboarding-safeguard','onboardingSafeguard'], ['linkrole-protection','linkroleProtection'], ['invite-role-protection','inviteRoleProtection'], ['mainrole-protection','mainroleProtection'], ['integration','integration'], ['prune','prune'], ['emoji-delete','emojiDelete'], ['sticker-delete','stickerDelete'],
  ['member-role-update','memberRoleUpdate'], ['permission-escalation','permissionEscalation'], ['mention-spam','mentionSpam'],
]);
const MODULE_LABELS = Object.fromEntries([...MODULES].map(([name, key]) => [key, name]));

const MANAGE_FILTERS = [
  ['ban', 'Ban', 'ban'],
  ['kick', 'Kick', 'kick'],
  ['memberRoleUpdate', 'Member Update', 'member-role-update'],
  ['roleCreate', 'Role Create', 'role-create'],
  ['roleDelete', 'Role Delete', 'role-delete'],
  ['roleUpdate', 'Role Update', 'role-update'],
  ['channelCreate', 'Channel Create', 'channel-create'],
  ['channelDelete', 'Channel Delete', 'channel-delete'],
  ['channelUpdate', 'Channel Update', 'channel-update'],
  ['webhookCreate', 'Webhook Create', 'webhook-create'],
  ['webhookDelete', 'Webhook Delete', 'webhook-delete'],
  ['webhookUpdate', 'Webhook Update', 'webhook-update'],
  ['botAdd', 'Bot Add', 'bot-add'],
  ['guildUpdate', 'Guild Update', 'guild-update'],
  ['vanityUpdate', 'Vanity Update', 'vanity-update'],
  ['onboardingSafeguard', 'Onboarding Safeguard', 'onboarding-safeguard'],
  ['linkroleProtection', 'Linkrole Protection', 'linkrole-protection'],
  ['inviteRoleProtection', 'Invite Role Protection', 'invite-role-protection'],
  ['mainroleProtection', 'Mainrole Protection', 'mainrole-protection'],
  ['integration', 'Integration', 'integration'],
  ['prune', 'Prune', 'prune'],
  ['emojiDelete', 'Emoji Delete', 'emoji-delete'],
  ['stickerDelete', 'Sticker Delete', 'sticker-delete'],
  ['rolePosition', 'Role Position', 'role-position'],
  ['permissionEscalation', 'Permission Escalation', 'permission-escalation'],
  ['mentionSpam', 'Mention Spam', 'mention-spam'],
];
const MANAGE_ON = '<:on:1551833384131498014>';
const MANAGE_OFF = '<:off:1551693996059787356>';
const MANAGE_FAKE = '1551834754775523378';
const MANAGE_ENABLE = '1551675781527380011';
const MANAGE_DISABLE = '1551836362402177056';
const managePending = new Map();
const whitelistPending = new Map();

const ANTINUKE_HELP = [
  [
    ['autorecovery', 'Manage server autorecovery settings.'],
    ['betrayalguard', 'Enable or disable betrayal guard for whitelisted users.'],
    ['config', 'Shows the current antinuke configuration.'],
    ['disable', 'Disable and reset antinuke on the server.'],
    ['enable', 'Enable and configure antinuke on the server.'],
    ['logging', 'Set the channel for antinuke logs.'],
  ],
  [
    ['manage', 'Manage and toggle specific antinuke modules.'],
    ['owneronly', 'Toggle owner only mode for all security commands.'],
    ['whitelist', 'Manage whitelisting for antinuke filters.'],
    ['whitelisted', 'Show the list of whitelisted users.'],
    ['wizard', 'One-click setup for a powerful antinuke configuration.'],
  ],
];

const ANTINUKE_SPACE = '<a:space:1551669674213908510>';
const ANTINUKE_ARROW = '<:whitearrow:1551669900622172161>';
const ANTINUKE_CROSS = '<:wccrossmar:1551676376313237504>';
const ANTINUKE_SPACE_UI = '<a:space:1551669674213908510>';
const ANTINUKE_ARROW_UI = '<:whitearrow:1551669900622172161>';
const ANTINUKE_CHECK = '<:wccheckmark:1551675781527380011>';
const ANTINUKE_CROSS_UI = '<:wccrossmar:1551676376313237504>';
const ANTINUKE_WICKTRI = '<:wicktri:1551832699508097057>';
const ANTINUKE_DISABLE_CHECK = '<:wccheckmark:1551675781527380011>';
const ANTINUKE_DISABLE_ARROW = '<:whitearrow:1551669900622172161>';
const ANTINUKE_DISABLE_SPACE = '<a:space:1551669674213908510>';
const ANTINUKE_DISABLE_CROSS = '<:wccrossmar:1551676376313237504>';
const ANTINUKE_LIGHT_RED = 0xB91C1C;
const BARRIER_ROLE_NAME = 'Aurora Barrier [A+]';
const ANTINUKE_SETUP_COLOR = 0x2c2c2c;
const DEFAULT_MAINROLE_ID = '1492911522324680754';

function antinukeHelp(message, page = 0) {
  const safePage = page === 1 ? 1 : 0;
  const lines = ANTINUKE_HELP[safePage].map(([command, description]) =>
    `> **\`.antinuke ${command}\`**\n${ANTINUKE_SPACE} ${ANTINUKE_ARROW} ${description}`
  );
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`antinuke:prev:${safePage}`).setLabel('‹').setStyle(ButtonStyle.Secondary).setDisabled(safePage === 0),
    new ButtonBuilder().setCustomId(`antinuke:page:${safePage}`).setLabel(`${safePage + 1}/2`).setStyle(ButtonStyle.Secondary).setDisabled(true),
    new ButtonBuilder().setCustomId(`antinuke:next:${safePage}`).setLabel('›').setStyle(ButtonStyle.Secondary).setDisabled(safePage === 1),
  );
  return {
    embeds: [makeEmbed({
      title: 'Aurora antinuke [11]',
      description: '```yml\n<..> <required> | [..] [optional]\n```\n\n' + lines.join('\n\n'),
      color: ANTINUKE_SETUP_COLOR,
      footer: `Page ${safePage + 1}/2 | Requested by ${message.author?.username ?? message.author?.tag ?? 'Unknown User'}`,
      timestamp: false,
    })],
    components: [row],
    allowedMentions: { parse: [], repliedUser: false },
  };
}

function setupEmbed(lines, footer) {
  return { embeds: [makeEmbed({ title: 'Setting up Antinuke!', description: lines.join('\n'), color: ANTINUKE_SETUP_COLOR, footer, timestamp: false })], allowedMentions: { parse: [], repliedUser: false } };
}

async function findOrCreateLogChannel(guild) {
  const existing = guild.channels.cache.find((ch) => ch.isTextBased?.() && ch.name === 'antinuke-logs');
  if (existing) return existing;
  if (!guild.members.me.permissions.has(P.ManageChannels)) return null;
  const everyone = guild.roles.everyone;
  return guild.channels.create({
    name: 'antinuke-logs',
    type: 0,
    permissionOverwrites: [
      { id: everyone.id, deny: [P.ViewChannel] },
      { id: guild.members.me.id, allow: [P.ViewChannel, P.SendMessages, P.EmbedLinks] },
    ],
    reason: 'Anti-nuke security logging',
  }).catch(() => null);
}


async function ensureBarrierRole(guild) {
  const security = await config.get(guild.id, 'security');
  let role = security.barrierRoleId ? guild.roles.cache.get(security.barrierRoleId) : null;
  if (!role) role = guild.roles.cache.find((r) => r.name === BARRIER_ROLE_NAME && !r.managed) ?? null;
  if (!role) {
    const botMember = guild.members.me ?? await guild.members.fetchMe();
    role = await guild.roles.create({ name: BARRIER_ROLE_NAME, permissions: [], reason: 'Aurora AntiNuke barrier role' });

    // Keep Aurora Barrier immediately below the highest role that has Administrator.
    // Discord only allows the bot to move roles below its own highest role.
    const adminRole = guild.roles.cache
      .filter((r) => !r.managed && r.id !== guild.id && r.permissions.has(P.Administrator))
      .sort((a, b) => b.position - a.position)
      .first();
    const targetPosition = adminRole
      ? Math.max(1, adminRole.position - 1)
      : Math.max(1, botMember.roles.highest.position - 1);
    if (role.position !== targetPosition && targetPosition < botMember.roles.highest.position) {
      await role.setPosition(targetPosition).catch(() => {});
    }
  }
  for (const channel of guild.channels.cache.values()) {
    if (channel.isThread?.() || !channel.permissionOverwrites?.edit) continue;
    await channel.permissionOverwrites.edit(role, {
      ViewChannel: false,
      SendMessages: false,
      AddReactions: false,
      CreatePublicThreads: false,
      CreatePrivateThreads: false,
      SendMessagesInThreads: false,
      Connect: false,
      Speak: false,
      Stream: false,
    }, { reason: 'Aurora AntiNuke Barrier isolation' }).catch(() => {});
  }
  await config.update(guild.id, 'security', (d) => { d.barrierRoleId = role.id; d.quarantineRoleId = role.id; }, { summary: 'Aurora Barrier role configured' });
  return role;
}

function securitySetupDoneEmbed(guild, user, botUser) {
  const on = '<:on:1551833384131498014>';
  const anti = (label) => `> ${on} » **\`${label}\`**`;
  const description = [
    '-# The server is now completely secured by the {ping bot} core security infrastructure. All unauthorized administrative actions or rogue behavior will be immediately neutralized.',
    '',
    '**__Active Security Filters__**',
    anti('Anti Ban'),
    anti('Anti Kick'),
    anti('Anti Member Update'),
    anti('Anti Role Create'),
    anti('Anti Role Delete'),
    anti('Anti Role Update'),
    anti('Anti Channel Create'),
    anti('Anti Channel Delete'),
    anti('Anti Channel Update'),
    anti('Anti Webhook Create'),
    anti('Anti Webhook Delete'),
    anti('Anti Webhook Update'),
    anti('Anti Guild Update'),
    anti('Anti Mention Spam'),
    '',
    '**__Special Security Filters__**',
    anti('Anti Bot Add'),
    anti('Anti Prune'),
    anti('Anti Integration'),
    anti('Anti Vanity Update'),
    anti('Onboarding Safeguard'),
    anti('Linkrole Protection'),
    anti('Invite Role Protection'),
    anti('Mainrole Protection'),
    '',
    '**__Notes__**',
    `-# ${ANTINUKE_ARROW}  Please ensure the bot's barrier role is placed as high as possible for absolute protection.`,
    `-# ${ANTINUKE_ARROW}   Use \`/antinuke whitelist\` to carefully manage and monitor your trusted users.`,
    `-# ${guild.name.replace(/[\\*_~`|>]/g, '\\$&')}`,
  ].join('\n');

  const pingBot = botUser?.id ? `<@${botUser.id}>` : 'Aurora';
  return {
    embeds: [makeEmbed({
      description: `### Security Setup Done\n${description.replace('{ping bot}', pingBot)}`,
      color: ANTINUKE_SETUP_COLOR,
      thumbnail: botUser?.displayAvatarURL?.({ size: 256 }) ?? undefined,
      timestamp: false,
    })],
    allowedMentions: { parse: [], repliedUser: false },
  };
}

function disableConfirmEmbed() {
  return {
    embeds: [makeEmbed({
      title: 'Disable Antinuke !',
      description: '_Are you sure you want to disable antinuke for this server? It is a **destructive step** as it will delete all data related to antinuke in this server._',
      color: ANTINUKE_LIGHT_RED,
      timestamp: false,
    })],
  };
}

function antinukeDisabledEmbed() {
  return {
    embeds: [makeEmbed({
      description: `${ANTINUKE_DISABLE_CHECK} Antinuke Disabled\n${ANTINUKE_DISABLE_ARROW} Antinuke has been disabled and all data has been reset for this server.`,
      color: ANTINUKE_LIGHT_RED,
      timestamp: false,
    })],
    allowedMentions: { parse: [], repliedUser: false },
  };
}

function antinukeProcessDeniedEmbed() {
  return {
    embeds: [makeEmbed({
      title: 'Process Denied !',
      description: `${ANTINUKE_DISABLE_SPACE}${ANTINUKE_DISABLE_CROSS} Antinuke is not enabled in this server. Use \`/antinuke enable\` to enable it.`,
      color: ANTINUKE_LIGHT_RED,
      timestamp: false,
    })],
    allowedMentions: { parse: [], repliedUser: false },
  };
}

async function runAntinukeSetup(message, { wizard = false } = {}) {
  const guild = message.guild;
  const botMember = guild.members.me ?? await guild.members.fetchMe();
  const botRole = botMember.roles.highest;
  const security = await config.get(guild.id, 'security');
  const configuredRoleId = security.mainroleId || DEFAULT_MAINROLE_ID;
  const configuredRole = guild.roles.cache.get(configuredRoleId);
  const lines = ['Loaded server configs !', 'Checking permission and position for my role...'];
  const requiredPerms = [P.ViewAuditLog, P.ManageChannels, P.ManageRoles, P.BanMembers, P.KickMembers, P.ModerateMembers, P.ManageWebhooks];
  const missing = requiredPerms.filter((perm) => !botMember.permissions.has(perm));
  const roleTooLow = configuredRole && botRole.position <= configuredRole.position;

  if (roleTooLow) {
    lines.push(`${ANTINUKE_CROSS} My role is too low in the hierarchy! Please move my role higher ...`);
    lines.push('```Move the role high above that I can protect the server```');
    return setupEmbed(lines, 'Antinuke setup failed');
  }
  if (missing.length) {
    lines.push(`${ANTINUKE_CROSS} My role is missing required permissions! Please grant the required permissions ...`);
    lines.push('```text\n' + permNames(missing).join(', ') + '\n```');
    return setupEmbed(lines, 'Antinuke setup failed');
  }

  const barrierRole = await ensureBarrierRole(guild).catch(() => null);
  const logChannel = guild.channels.cache.get((await config.get(guild.id, 'antinuke')).loggingChannelId) ?? await findOrCreateLogChannel(guild);
  const defaults = DEFAULTS.antinuke();
  lines.push(`${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Bot's role and position check passed ...`);
  lines.push(`${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Enabling server Antinuke ...`);
  if (configuredRole) lines.push(`${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Configured <@&${configuredRole.id}> as the main security role ...`);
  else lines.push(`${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Main security role is not set; using owner/bot trust only ...`);
  lines.push(barrierRole ? `${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Configured <@&${barrierRole.id}> as Aurora Barrier [A+] ...` : `${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Aurora Barrier [A+] could not be created ...`);
  lines.push(logChannel ? `${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Configured <#${logChannel.id}> channel for logging ...` : `${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Dedicated logging channel could not be created; using Aurora security logs ...`);
  lines.push(`${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Set default trust limits...`);
  lines.push(`${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Secured channels for abuse protection...`);
  lines.push(`${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Saving changes...`);

  await config.update(guild.id, 'antinuke', (d) => {
    d.enabled = true;
    d.loggingChannelId = logChannel?.id ?? d.loggingChannelId ?? null;
    d.windowSec = 30;
    d.limits = structuredClone(defaults.limits);
    d.betrayalLimits = structuredClone(defaults.betrayalLimits);
    d.modules = structuredClone(defaults.modules);
    d.betrayalGuard = true;
    d.punishment = wizard ? 'strip' : d.punishment;
    d.autoRecovery = wizard ? true : Boolean(d.autoRecovery);
    d.recovery = structuredClone(defaults.recovery);
  }, { actorId: message.author.id, summary: `Anti-nuke ${wizard ? 'wizard' : 'setup'} completed` });

  if (configuredRole) await config.update(guild.id, 'security', (d) => { if (!d.mainroleId) d.mainroleId = configuredRole.id; }, { actorId: message.author.id, summary: 'Anti-nuke main role linked' });
  await antinuke.primeSnapshots(guild).catch(() => {});
  lines.push(`${ANTINUKE_SPACE} ${ANTINUKE_ARROW} Antinuke Setup Complete!`);
  return {
    embeds: [makeEmbed({ title: 'Setting up Antinuke!', description: lines.join('\n'), color: ANTINUKE_SETUP_COLOR, timestamp: false })],
    allowedMentions: { parse: [], repliedUser: false },
    __followup: securitySetupDoneEmbed(guild, message.author, botMember.user),
  };
}

function formatConfig(c) {
  const normal = Object.entries(c.limits ?? {}).map(([k, v]) => `${MODULE_LABELS[k] ?? k}=${v}`).join(' • ');
  const betrayal = Object.entries(c.betrayalLimits ?? {}).map(([k, v]) => `${MODULE_LABELS[k] ?? k}=${v}`).join(' • ');
  const modules = Object.entries(c.modules ?? {}).map(([k, v]) => `${MODULE_LABELS[k] ?? k}:${v ? 'on' : 'off'}`).join(' • ');
  return { normal, betrayal, modules };
}

function moduleKey(raw) { return MODULES.get(String(raw ?? '').toLowerCase()); }

const WHITELIST_FILTERS = [
  ['ban', 'Ban', 'ban'], ['kick', 'Kick', 'kick'], ['memberRoleUpdate', 'Member Update', 'member-role-update'],
  ['roleCreate', 'Role Create', 'role-create'], ['roleDelete', 'Role Delete', 'role-delete'], ['roleUpdate', 'Role Update', 'role-update'],
  ['channelCreate', 'Channel Create', 'channel-create'], ['channelDelete', 'Channel Delete', 'channel-delete'], ['channelUpdate', 'Channel Update', 'channel-update'],
  ['webhookCreate', 'Webhook Create', 'webhook-create'], ['webhookDelete', 'Webhook Delete', 'webhook-delete'], ['webhookUpdate', 'Webhook Update', 'webhook-update'],
  ['guildUpdate', 'Guild Update', 'guild-update'], ['mentionSpam', 'Mention Spam', 'mention-spam'],
];
const WL_ON = '<:on:1551833384131498014>';
const WL_OFF = '<:off:1551693996059787356>';
const WL_FAKE = '1551834754775523378';
const WL_CHECK = '1551675781527380011';
const WL_TRASH = '1551836362402177056';

function whitelistState(c, userId) {
  const raw = c.whitelist ?? {};
  if (Array.isArray(raw)) return Object.fromEntries(WHITELIST_FILTERS.map(([key]) => [key, raw.includes(userId)]));
  const entry = raw?.[userId] ?? {};
  return Object.fromEntries(WHITELIST_FILTERS.map(([key]) => [key, Boolean(entry.all || entry[key])]));
}

function whitelistEmbed(guild, user, requester, filters) {
  const lines = WHITELIST_FILTERS.map(([key, label]) => `> ${filters[key] ? WL_ON : WL_OFF}  » **\`${label}\`**`);
  return makeEmbed({
    title: 'Antinuke Whitelist',
    description: [
      '-# Select the filters below to configure whitelist.', '', ...lines, '',
      `<:FakeNitroEmoji:1551834754775523378> **Member**`,
      `<:FakeNitroEmoji:1551834754775523378> ${user}`, '',
      `Requested by <@${requester.id}>`,
    ].join('\n'),
    color: ANTINUKE_SETUP_COLOR,
    thumbnail: user.displayAvatarURL?.({ size: 128 }),
    timestamp: false,
  });
}


function whitelistedUsers(c, guild) {
  const raw = c.whitelist ?? {};
  const entries = Array.isArray(raw)
    ? raw.map((id) => [String(id), { all: true }])
    : Object.entries(raw);

  return entries
    .map(([id, entry]) => {
      if (!id || !entry) return null;
      const state = entry === true || entry.all === true
        ? Object.fromEntries(WHITELIST_FILTERS.map(([key]) => [key, true]))
        : Object.fromEntries(WHITELIST_FILTERS.map(([key]) => [key, Boolean(entry[key])])) ;
      if (!Object.values(state).some(Boolean)) return null;
      const member = guild.members.cache.get(id);
      if (!member) return null;
      const selected = WHITELIST_FILTERS.filter(([key]) => state[key]).map(([, label]) => label);
      return {
        id,
        member,
        filters: selected.length === WHITELIST_FILTERS.length ? 'All Whitelistable Filters' : selected.join(', '),
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.member.displayName.localeCompare(b.member.displayName, undefined, { sensitivity: 'base' }));
}

function whitelistedUsersEmbed(guild, requester, users, page = 0) {
  const perPage = 10;
  const totalPages = Math.max(1, Math.ceil(users.length / perPage));
  const safePage = Math.min(Math.max(0, page), totalPages - 1);
  const start = safePage * perPage;
  const current = users.slice(start, start + perPage);
  const description = current.map((entry, index) => {
    const number = String(start + index + 1).padStart(2, '0');
    return `**[\`${number}\`]** ${entry.member} - **${entry.filters}**`;
  }).join('\n');

  return makeEmbed({
    title: 'Whitelisted Users',
    description: `${description}\n\n-# Page ${safePage + 1}/${totalPages} | Requested by ${requester.member?.displayName ?? requester.displayName ?? requester.username}`,
    color: ANTINUKE_SETUP_COLOR,
    timestamp: false,
  });
}

function whitelistedUsersComponents(ownerId, page, totalPages) {
  if (totalPages <= 1) return [];
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`antinuke:whitelisted:prev:${ownerId}:${page}`)
      .setLabel('Previous')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 0),
    new ButtonBuilder()
      .setCustomId(`antinuke:whitelisted:next:${ownerId}:${page}`)
      .setLabel('Next')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages - 1),
  )];
}

function whitelistComponents(ownerId, filters, mode = null) {
  const rows = [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`antinuke:whitelist:category:${ownerId}:add`).setEmoji({ id: WL_FAKE, name: 'FakeNitroEmoji' }).setLabel('Select Filters To Add To Whitelist').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`antinuke:whitelist:category:${ownerId}:remove`).setEmoji({ id: WL_FAKE, name: 'FakeNitroEmoji' }).setLabel('Select Filters To Remove From Whitelist').setStyle(ButtonStyle.Secondary),
  )];
  if (mode) {
    const available = WHITELIST_FILTERS.filter(([key]) => mode === 'add' ? !filters[key] : Boolean(filters[key]));
    const select = new StringSelectMenuBuilder().setCustomId(`antinuke:whitelist:filters:${ownerId}:${mode}`).setPlaceholder(mode === 'add' ? 'Select filters to add' : 'Select filters to remove').setMinValues(1).setMaxValues(Math.max(1, Math.min(available.length, 15)));
    if (!available.length) select.setDisabled(true).addOptions({ label: mode === 'add' ? 'All filters are whitelisted' : 'No filters are whitelisted', value: 'none' });
    else select.addOptions(available.map(([, label, value]) => ({ label, value })));
    rows.push(new ActionRowBuilder().addComponents(select));
  }
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`antinuke:whitelist:all:${ownerId}`).setEmoji({ id: WL_CHECK, name: 'wccheckmark' }).setLabel('Whitelist All').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`antinuke:whitelist:clear:${ownerId}`).setEmoji({ id: WL_TRASH, name: 'redtrash' }).setLabel('Clear All').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`antinuke:whitelist:save:${ownerId}`).setLabel('Save').setStyle(ButtonStyle.Success),
  ));
  return rows;
}

function manageDescription(guild, user, modules) {
  const lines = MANAGE_FILTERS.map(([key, label]) =>
    `> ${modules[key] ? MANAGE_ON : MANAGE_OFF} » **\`${label}\`**`
  );
  const serverName = String(guild.name ?? 'Server').replace(/[\\*_~`|>]/g, '\\$&');
  const serverUrl = `https://discord.com/channels/${guild.id}`;
  return [
    '-# Select the filters below to enable or disable them.',
    '',
    ...lines,
    '',
    `<:anti_308:1551623253653594132> **Server Name**`,
    `<:FakeNitroEmoji:1551834754775523378> [${serverName}](${serverUrl})`,
    '',
    `Requested by <@${user.id}>`,
  ].join('\n');
}

function manageEmbed(guild, user, modules) {
  return makeEmbed({
    title: 'Antinuke Management',
    description: manageDescription(guild, user, modules),
    color: ANTINUKE_SETUP_COLOR,
    thumbnail: user.displayAvatarURL?.({ size: 128 }),
    timestamp: false,
  });
}

function manageCategoryRows(ownerId) {
  const disable = new ButtonBuilder()
    .setCustomId(`antinuke:manage:category:${ownerId}:disable`)
    .setEmoji({ id: MANAGE_FAKE, name: 'FakeNitroEmoji' })
    .setLabel('Select Filters To Disable')
    .setStyle(ButtonStyle.Primary);
  const enable = new ButtonBuilder()
    .setCustomId(`antinuke:manage:category:${ownerId}:enable`)
    .setEmoji({ id: MANAGE_FAKE, name: 'FakeNitroEmoji' })
    .setLabel('Select Filters To Enable')
    .setStyle(ButtonStyle.Primary);
  return new ActionRowBuilder().addComponents(disable, enable);
}

function manageActionRows(ownerId) {
  const enableAll = new ButtonBuilder()
    .setCustomId(`antinuke:manage:all:${ownerId}:enable`)
    .setEmoji({ id: MANAGE_ENABLE, name: 'wccheckmark' })
    .setLabel('Enable All')
    .setStyle(ButtonStyle.Success);
  const disableAll = new ButtonBuilder()
    .setCustomId(`antinuke:manage:all:${ownerId}:disable`)
    .setEmoji({ id: MANAGE_DISABLE, name: 'redtrash' })
    .setLabel('Disable All')
    .setStyle(ButtonStyle.Danger);
  const save = new ButtonBuilder()
    .setCustomId(`antinuke:manage:save:${ownerId}`)
    .setLabel('Save')
    .setStyle(ButtonStyle.Success);
  return new ActionRowBuilder().addComponents(enableAll, disableAll, save);
}

function manageSelectRow(ownerId, mode, modules) {
  const available = MANAGE_FILTERS.filter(([key]) => mode === 'enable' ? !modules[key] : Boolean(modules[key]));
  const select = new StringSelectMenuBuilder()
    .setCustomId(`antinuke:manage:filters:${ownerId}:${mode}`)
    .setPlaceholder(mode === 'enable' ? 'Select filters to enable' : 'Select filters to disable')
    .setMinValues(1)
    .setMaxValues(Math.max(1, Math.min(available.length, 15)));
  if (!available.length) {
    select.setDisabled(true).addOptions({ label: mode === 'enable' ? 'All filters are already enabled' : 'All filters are already disabled', value: 'none' });
  } else {
    // Keep select option payloads API-safe; the ON/OFF emojis are rendered in the embed.
    select.addOptions(available.map(([, label, value]) => ({ label, value })));
  }
  return new ActionRowBuilder().addComponents(select);
}

function manageComponents(ownerId, modules, mode = null) {
  const rows = [manageCategoryRows(ownerId)];
  if (mode) rows.push(manageSelectRow(ownerId, mode, modules));
  rows.push(manageActionRows(ownerId));
  return rows;
}

async function handleComponent(interaction) {
  const parts = String(interaction.customId).split(':');
  if (parts[1] === 'manage') {
    const kind = parts[2];
    const ownerId = parts[3];
    if (interaction.user.id !== ownerId) return interaction.reply({ content: '❌ Only the user who ran the manage command can use these controls.', ephemeral: true });
    const key = `${interaction.guild.id}:${ownerId}`;
    const pending = managePending.get(key);
    if (!pending) return interaction.reply({ content: '❌ This AntiNuke management session has expired. Run `,an manage` again.', ephemeral: true });

    if (kind === 'category') {
      const mode = parts[4] === 'disable' ? 'disable' : 'enable';
      return interaction.update({ embeds: [manageEmbed(interaction.guild, interaction.user, pending.modules)], components: manageComponents(ownerId, pending.modules, mode) });
    }
    if (kind === 'filters') {
      const mode = parts[4] === 'disable' ? 'disable' : 'enable';
      if (interaction.values?.includes('none')) return interaction.update({ embeds: [manageEmbed(interaction.guild, interaction.user, pending.modules)], components: manageComponents(ownerId, pending.modules, mode) });
      for (const value of interaction.values ?? []) {
        const entry = MANAGE_FILTERS.find(([, , v]) => v === value);
        if (entry) pending.modules[entry[0]] = mode === 'enable';
      }
      return interaction.update({ embeds: [manageEmbed(interaction.guild, interaction.user, pending.modules)], components: manageComponents(ownerId, pending.modules, mode) });
    }
    if (kind === 'all') {
      const enabled = parts[4] === 'enable';
      for (const [key] of MANAGE_FILTERS) pending.modules[key] = enabled;
      return interaction.update({ embeds: [manageEmbed(interaction.guild, interaction.user, pending.modules)], components: manageComponents(ownerId, pending.modules) });
    }
    if (kind === 'save') {
      await config.update(interaction.guild.id, 'antinuke', (d) => {
        d.modules = { ...d.modules, ...pending.modules };
      }, { actorId: interaction.user.id, summary: 'Anti-nuke modules saved from management panel' });
      managePending.delete(key);
      return interaction.update({ embeds: [makeEmbed({ title: 'Antinuke Management', description: `${ANTINUKE_CHECK} **Filters Saved**\n${ANTINUKE_ARROW} The AntiNuke filter configuration has been saved successfully.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })], components: [] });
    }
    return;
  }
  if (parts[1] === 'whitelist') {
    const kind = parts[2];
    const ownerId = parts[3];
    if (interaction.user.id !== ownerId) return interaction.reply({ content: '❌ Only the user who ran the whitelist command can use these controls.', ephemeral: true });
    const key = `${interaction.guild.id}:${ownerId}`;
    const pending = whitelistPending.get(key);
    if (!pending) return interaction.reply({ content: '❌ This AntiNuke whitelist session has expired. Run `,an whitelist @user` again.', ephemeral: true });
    if (kind === 'category') {
      const mode = parts[4] === 'remove' ? 'remove' : 'add';
      return interaction.update({ embeds: [whitelistEmbed(interaction.guild, pending.target.user, interaction.user, pending.filters)], components: whitelistComponents(ownerId, pending.filters, mode) });
    }
    if (kind === 'filters') {
      const mode = parts[4] === 'remove' ? 'remove' : 'add';
      for (const value of interaction.values ?? []) {
        const entry = WHITELIST_FILTERS.find(([, , v]) => v === value);
        if (entry) pending.filters[entry[0]] = mode === 'add';
      }
      return interaction.update({ embeds: [whitelistEmbed(interaction.guild, pending.target.user, interaction.user, pending.filters)], components: whitelistComponents(ownerId, pending.filters) });
    }
    if (kind === 'all') {
      for (const [key] of WHITELIST_FILTERS) pending.filters[key] = true;
      return interaction.update({ embeds: [whitelistEmbed(interaction.guild, pending.target.user, interaction.user, pending.filters)], components: whitelistComponents(ownerId, pending.filters) });
    }
    if (kind === 'clear') {
      for (const [key] of WHITELIST_FILTERS) pending.filters[key] = false;
      return interaction.update({ embeds: [whitelistEmbed(interaction.guild, pending.target.user, interaction.user, pending.filters)], components: whitelistComponents(ownerId, pending.filters) });
    }
    if (kind === 'save') {
      const targetId = pending.target.id;
      const filters = { ...pending.filters };
      await config.update(interaction.guild.id, 'antinuke', (d) => {
        const raw = d.whitelist ?? {};
        const current = Array.isArray(raw) ? Object.fromEntries(raw.map((id) => [id, { all: true }])) : { ...raw };
        const entry = {};
        for (const [key] of WHITELIST_FILTERS) if (filters[key]) entry[key] = true;
        if (Object.keys(entry).length) current[targetId] = entry;
        else delete current[targetId];
        d.whitelist = current;
      }, { actorId: interaction.user.id, summary: `Anti-nuke whitelist filters saved for ${targetId}` });
      whitelistPending.delete(key);
      return interaction.update({ embeds: [makeEmbed({ title: 'Antinuke Whitelist', description: `${ANTINUKE_CHECK} **Whitelist Saved**\n${ANTINUKE_ARROW} Whitelist filters for <@${targetId}> have been updated successfully.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })], components: [] });
    }
    return;
  }
  if (parts[1] === 'whitelisted') {
    const kind = parts[2];
    const ownerId = parts[3];
    const oldPage = Number(parts[4]);
    if (interaction.user.id !== ownerId) return interaction.reply({ content: '❌ Only the user who ran the whitelisted command can use these controls.', ephemeral: true });
    if (kind !== 'prev' && kind !== 'next') return;

    const c = await config.get(interaction.guild.id, 'antinuke');
    const users = whitelistedUsers(c, interaction.guild);
    if (!users.length) {
      return interaction.update({ embeds: [makeEmbed({
        title: 'Process Denied !',
        description: `${ANTINUKE_SPACE_UI} ${ANTINUKE_CROSS_UI}  There are no whitelisted users in this server.`,
        color: ANTINUKE_SETUP_COLOR,
        timestamp: false,
      })], components: [] });
    }
    const totalPages = Math.max(1, Math.ceil(users.length / 10));
    const page = kind === 'prev' ? Math.max(0, oldPage - 1) : Math.min(totalPages - 1, oldPage + 1);
    return interaction.update({
      embeds: [whitelistedUsersEmbed(interaction.guild, interaction.member ?? interaction.user, users, page)],
      components: whitelistedUsersComponents(ownerId, page, totalPages),
      allowedMentions: { parse: [], repliedUser: false },
    });
  }
  if (parts[1] === 'disable') {
    const choice = parts[2];
    const ownerId = parts[3];
    if (interaction.user.id !== ownerId) return interaction.reply({ content: '❌ Only the user who ran the disable command can use these buttons.', ephemeral: true });
    if (choice === 'no') {
      await interaction.message.delete().catch(() => interaction.update({ content: '', embeds: [], components: [] }));
      return;
    }

    const current = await config.get(interaction.guild.id, 'antinuke');
    if (!current.enabled) return interaction.update(antinukeProcessDeniedEmbed());

    await config.update(interaction.guild.id, 'antinuke', () => structuredClone(DEFAULTS.antinuke()), { actorId: interaction.user.id, summary: 'Anti-nuke disabled and reset' });
    await antinuke.clearData(interaction.guild.id);
    return interaction.update({ ...antinukeDisabledEmbed(), components: [] });
  }
  const [, action, currentRaw] = parts;
  const current = Number(currentRaw);
  const page = Number.isInteger(current) && current >= 0 && current <= 1 ? current : 0;
  if (action !== 'prev' && action !== 'next') return;
  const next = action === 'prev' ? Math.max(0, page - 1) : Math.min(1, page + 1);
  return interaction.update(antinukeHelp({ author: interaction.user }, next));
}

module.exports = [
  {
    name: 'antinuke', aliases: ['an'], category: 'Security', description: 'Configure anti-nuke. Usage: antinuke <enable|disable|whitelist|manage|logging|config|autorecovery|owneronly|betrayalguard|wizard>',
    async execute(message, args, { prefix = ',' } = {}) {
      let action = (args.shift() ?? '').toLowerCase();
      const actionAliases = { ac: 'autorecovery', ar: 'autorecovery', bg: 'betrayalguard', betrayal: 'betrayalguard', oo: 'owneronly', wl: 'whitelist' };
      action = actionAliases[action] ?? action;
      if (!action) return reply(message, antinukeHelp(message));

      // Unknown/invalid AntiNuke actions should behave exactly like `,an`
      // instead of falling through to the status/config output.
      const validActions = new Set([
        'autorecovery', 'betrayalguard', 'config', 'disable', 'enable',
        'logging', 'manage', 'owneronly', 'whitelist', 'whitelisted', 'wizard',
      ]);
      if (!validActions.has(action)) return reply(message, antinukeHelp(message));

      let c = await config.get(message.guild.id, 'antinuke');
      await needManage(message, c);
      await ownerGuard(message, c);

      if (action === 'wizard') {
        const setup = await runAntinukeSetup(message, { wizard: true });
        const followup = setup.__followup;
        delete setup.__followup;
        const sent = await reply(message, setup);
        if (followup) await message.channel.send(followup).catch(() => {});
        return sent;
      }
      if (action === 'enable') {
        const setup = await runAntinukeSetup(message);
        const followup = setup.__followup;
        delete setup.__followup;
        const sent = await reply(message, setup);
        if (followup) await message.channel.send(followup).catch(() => {});
        return sent;
      }

      if (action === 'disable') {
        if (!c.enabled) return reply(message, antinukeProcessDeniedEmbed());
        const yes = new ButtonBuilder().setCustomId(`antinuke:disable:yes:${message.author.id}`).setLabel('Yes').setStyle(ButtonStyle.Success);
        const no = new ButtonBuilder().setCustomId(`antinuke:disable:no:${message.author.id}`).setLabel('No').setStyle(ButtonStyle.Danger);
        return reply(message, {
          ...disableConfirmEmbed(),
          components: [new ActionRowBuilder().addComponents(yes, no)],
        });
      }

      // All operational AntiNuke subcommands require the engine to be enabled.
      // Enable/disable/wizard are intentionally handled above so they can change the engine state.
      if (!c.enabled && ['owneronly', 'betrayalguard', 'autorecovery', 'manage', 'whitelist', 'whitelisted', 'logging', 'config'].includes(action)) {
        return reply(message, antinukeProcessDeniedEmbed());
      }

      if (action === 'owneronly' || action === 'betrayalguard' || action === 'autorecovery') {
        const v = parseBool(args[0]);
        if (v === null) {
          if (action === 'autorecovery') return reply(message, { embeds: [makeEmbed({ description: '```yml\n<..> <required> | [..] [optional]\n```\n> **`.antinuke autorecovery <action>`**\n\n' + `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} **Aliases :** \`ar\`\n` + `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} Manage server autorecovery settings.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
          if (action === 'betrayalguard') return reply(message, { embeds: [makeEmbed({ description: '```yml\n<..> <required> | [..] [optional]\n```\n> **`.antinuke betrayalguard <action>`**\n\n' + `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} **Aliases :** \`bg\` , \`betrayal\`\n` + `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} Enable or disable betrayal guard for whitelisted users.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
          if (action === 'owneronly') return reply(message, { embeds: [makeEmbed({ description: '```yml\n<..> <required> | [..] [optional]\n```\n> **`.antinuke owneronly <action>`**\n\n' + `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} **Aliases :** \`oo\`\n` + `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} Toggle owner only mode for all security commands.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
          return reply(message, `❌ Usage: \`${prefix}antinuke ${action} <on|off>\`.`);
        }
        if (action === 'owneronly' && message.author.id !== message.guild.ownerId) throw new Error('Only the server owner can change Owner Only mode.');
        if (action === 'autorecovery' && v && !message.guild.members.me.permissions.has([P.ManageChannels, P.ManageRoles])) throw new Error('Auto-recovery needs **Manage Channels** and **Manage Roles**.');
        if (action !== 'owneronly') await ownerGuard(message, c);
        const key = action === 'owneronly' ? 'ownerOnly' : action === 'betrayalguard' ? 'betrayalGuard' : 'autoRecovery';
        await config.update(message.guild.id, 'antinuke', (d) => { d[key] = v; }, { actorId: message.author.id, summary: `Anti-nuke ${key}: ${v}` });
        if (action === 'owneronly') {
          return reply(message, { embeds: [makeEmbed({ description: v ? `${ANTINUKE_CHECK}  **Owner Only Enabled**\n${ANTINUKE_ARROW} Security commands are now accessible to Extra Owners as well.` : `${ANTINUKE_CROSS_UI}  **Owner Only Disabled**\n${ANTINUKE_ARROW} Security commands are now accessible to Extra Owners as well.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
        }
        if (action === 'autorecovery') {
          return reply(message, {
            embeds: [makeEmbed({
              description: v
                ? `${ANTINUKE_CHECK} **Autorecovery Enabled**\n${ANTINUKE_ARROW} The bot will now attempt to recover from nuke events.`
                : `${ANTINUKE_CROSS_UI} **Autorecovery Disabled**\n${ANTINUKE_ARROW} The bot will no longer attempt to recover from nuke events.`,
              color: ANTINUKE_SETUP_COLOR,
              timestamp: false,
            })],
            allowedMentions: { parse: [], repliedUser: false },
          });
        }
        if (action === 'betrayalguard') {
          return reply(message, {
            embeds: [makeEmbed({
              description: `> **Betrayalguard Status** ${ANTINUKE_ARROW} ${v ? ANTINUKE_CHECK : ANTINUKE_CROSS_UI}`,
              color: ANTINUKE_SETUP_COLOR,
              timestamp: false,
            })],
            allowedMentions: { parse: [], repliedUser: false },
          });
        }
        return reply(message, `✅ **${action}** is now **${v ? 'enabled' : 'disabled'}.`);
      }

      if (action === 'manage') {
        const current = await config.get(message.guild.id, 'antinuke');
        const modules = Object.fromEntries(MANAGE_FILTERS.map(([key]) => [key, Boolean(current.modules?.[key]) ]));
        const key = `${message.guild.id}:${message.author.id}`;
        managePending.set(key, { modules });
        return reply(message, {
          embeds: [manageEmbed(message.guild, message.author, modules)],
          components: manageComponents(message.author.id, modules),
          allowedMentions: { parse: [], repliedUser: false },
        });
      }

      if (action === 'whitelisted') {
        const users = whitelistedUsers(c, message.guild);
        if (!users.length) {
          return reply(message, { embeds: [makeEmbed({
            title: 'Process Denied !',
            description: `${ANTINUKE_SPACE_UI} ${ANTINUKE_CROSS_UI}  There are no whitelisted users in this server.`,
            color: ANTINUKE_SETUP_COLOR,
            timestamp: false,
          })] });
        }
        const perPage = 10;
        const totalPages = Math.max(1, Math.ceil(users.length / perPage));
        const page = 0;
        return reply(message, {
          embeds: [whitelistedUsersEmbed(message.guild, message.member, users, page)],
          components: whitelistedUsersComponents(message.author.id, page, totalPages),
          allowedMentions: { parse: [], repliedUser: false },
        });
      }

      if (action === 'whitelist') {
        const raw = args[0];
        const id = raw?.match(/^<@!?(\d{17,20})>$|^(\d{17,20})$/)?.[1] ?? raw?.match(/\d{17,20}/)?.[0];
        if (!id) {
          return reply(message, { embeds: [makeEmbed({ description: '```yml\n<..> <required> | [..] [optional]\n```\n> **`.antinuke whitelist <user>`**\n\n' + `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} **Aliases :** \`wl\`\n` + `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} Manage whitelisting for antinuke filters.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
        }
        const target = await message.guild.members.fetch(id).catch(() => null);
        if (!target) return reply(message, { embeds: [makeEmbed({ description: `${ANTINUKE_CROSS_UI} User not found in this server.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
        if (id === message.guild.ownerId || id === message.client.user.id) return reply(message, { embeds: [makeEmbed({ description: `${ANTINUKE_CROSS_UI} The server owner and Aurora are already trusted and cannot be configured here.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
        const filters = whitelistState(c, id);
        const key = `${message.guild.id}:${message.author.id}`;
        whitelistPending.set(key, { target, filters });
        return reply(message, { embeds: [whitelistEmbed(message.guild, target.user, message.author, filters)], components: whitelistComponents(message.author.id, filters), allowedMentions: { parse: [], repliedUser: false } });
      }

      if (action === 'logging') {
        const ch = message.mentions.channels.first() ?? message.guild.channels.cache.get(args[0]);
        const help = makeEmbed({
          description: '```yml\n<..> <required> | [..] [optional]\n```\n> **`.antinuke logging <channel>`**\n\n' +
            `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} Set the channel for antinuke logs.`,
          color: ANTINUKE_SETUP_COLOR,
          timestamp: false,
        });
        if (!ch) return reply(message, { embeds: [help], allowedMentions: { parse: [], repliedUser: false } });
        if (!ch.isTextBased?.() || !('send' in ch)) return reply(message, { embeds: [makeEmbed({ description: '❌ Please choose a text-based channel that Aurora can send messages to.', color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
        const botMember = message.guild.members.me ?? await message.guild.members.fetchMe();
        const perms = ch.permissionsFor(botMember);
        if (!perms?.has([P.ViewChannel, P.SendMessages, P.EmbedLinks])) {
          return reply(message, { embeds: [makeEmbed({ description: '❌ I need **View Channel**, **Send Messages**, and **Embed Links** in that channel before I can use it for AntiNuke logs.', color: ANTINUKE_SETUP_COLOR, timestamp: false })] });
        }
        await config.update(message.guild.id, 'antinuke', (d) => { d.loggingChannelId = ch.id; }, { actorId: message.author.id, summary: `Anti-nuke logging channel: ${ch.id}` });
        return reply(message, { embeds: [makeEmbed({ description: `${ANTINUKE_SPACE_UI} ${ANTINUKE_ARROW_UI} AntiNuke logs will now be sent to <#${ch.id}>.`, color: ANTINUKE_SETUP_COLOR, timestamp: false })], allowedMentions: { parse: [], repliedUser: false } });
      }

      if (action === 'config') {
        c = await config.get(message.guild.id, 'antinuke');
        const security = await config.get(message.guild.id, 'security');
        const barrierId = security.barrierRoleId ?? security.quarantineRoleId ?? null;
        const barrier = barrierId ? message.guild.roles.cache.get(barrierId) : null;
        const logChannel = c.loggingChannelId ? message.guild.channels.cache.get(c.loggingChannelId) : null;
        const status = (v) => v ? ANTINUKE_CHECK : ANTINUKE_CROSS_UI;
        return reply(message, { embeds: [makeEmbed({
          title: 'Antinuke Configuration',
          description: `> **\`Engine Status\`** → ${status(c.enabled)}\n> **\`Auto Recovery\`** → ${status(c.autoRecovery)}\n> **\`Betrayal Guard\`** → ${status(c.betrayalGuard)}\n> **\`Owner Only\`** → ${status(c.ownerOnly)}\n**__Channels & Roles__**\n${ANTINUKE_SPACE} ${ANTINUKE_ARROW} **Barrier Role :** ${barrier ? `<@&${barrier.id}>` : '`Not configured`'}\n${ANTINUKE_SPACE} ${ANTINUKE_ARROW} **Log Channel :** ${logChannel ? `<#${logChannel.id}>` : '`Not configured`'}\n-# Requested by <@${message.author.id}> (\`${message.author.username}\`)`,
          color: ANTINUKE_SETUP_COLOR,
          timestamp: false,
        })] });
      }

      const f = formatConfig(c);
      return reply(message, { embeds: [makeEmbed({ title: '🛡️ Anti-nuke', color: COLORS.security, description: `${c.enabled ? '✅ Enabled' : '❌ Disabled'}\nWindow: **${c.windowSec}s**\nPunishment: **${c.punishment}**\nOwner-only: **${c.ownerOnly ? 'On' : 'Off'}**\nBetrayal guard: **${c.betrayalGuard ? 'On' : 'Off'}**\nAuto-recovery: **${c.autoRecovery ? 'On' : 'Off'}**\n\n${f.normal}` })] });
    },
  },
  {
    name: 'mainrole', category: 'Security', description: 'Manage the security main role', userPermissions: [P.ManageGuild],
    async execute(message, args) {
      needManage(message);
      const anti = await config.get(message.guild.id, 'antinuke');
      await ownerGuard(message, anti);
      const action = (args.shift() ?? 'show').toLowerCase();
      const role = message.mentions.roles.first() ?? message.guild.roles.cache.get(args[0]);
      if (action === 'show') { const c = await config.get(message.guild.id, 'security'); return reply(message, c.mainroleId ? `🛡️ Main role: <@&${c.mainroleId}>` : '🛡️ No main role is configured.'); }
      if (action === 'remove' || action === 'reset') { await config.update(message.guild.id, 'security', (d) => { d.mainroleId = null; }); return reply(message, '✅ Main role cleared.'); }
      if (action === 'add') {
        if (!role || role.managed || role.id === message.guild.id) return reply(message, '❌ Mention a normal, non-managed role.');
        if (role.position >= message.guild.members.me.roles.highest.position) return reply(message, '❌ Move my bot role above that role first.');
        await config.update(message.guild.id, 'security', (d) => { d.mainroleId = role.id; }, { actorId: message.author.id, summary: `Security main role set: ${role.id}` });
        return reply(message, `✅ Main role set to <@&${role.id}>.`);
      }
      return reply(message, '❌ Usage: `mainrole <show|add|remove|reset> [@role]`');
    },
  },
];

module.exports.handleComponent = handleComponent;
