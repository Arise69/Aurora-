'use strict';
const crypto = require('node:crypto');
const { reply } = require('./helpers');
const { EIGHT_BALL } = require('../utils/fun');

module.exports = [
  { name: '8ball', category: 'Fun Commands', description: 'Ask the magic 8-ball. Usage: 8ball <question>', execute: (m, args) => reply(m, args.length ? `🎱 ${EIGHT_BALL[crypto.randomInt(EIGHT_BALL.length)]}` : '🎱 Ask me a question first!') },
  { name: 'coinflip', aliases: ['flip'], category: 'Fun Commands', description: 'Flip a coin', execute: (m) => reply(m, `🪙 **${crypto.randomInt(2) ? 'Heads' : 'Tails'}**`) },
  { name: 'roll', category: 'Fun Commands', description: 'Roll a die. Usage: roll [sides]', execute: (m, args) => { const s = Math.min(Math.max(Number.parseInt(args[0], 10) || 6, 2), 1000); return reply(m, `🎲 You rolled **${crypto.randomInt(s) + 1}** (d${s})`); } },
];
