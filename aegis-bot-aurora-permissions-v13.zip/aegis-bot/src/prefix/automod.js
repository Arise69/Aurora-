'use strict';
/**
 * `.automod` — help, enable / disable, logging, manage (filter panel), settings (heat), whitelist, wlshow, reset.
 */
const {
  PermissionFlagsBits: P, ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const config = require('../services/guildConfig');
const DEFAULTS = require('../config/defaults');
const { AppError } = require('../utils/errors');
const { fail } = require('../utils/reply');
const { reply } = require('./helpers');
const ui = require('./ui');

const { ARROW, ARROW_LIST, CHECK, CROSS } = ui;
const ID_PREFIX = 'am';
const HELP_PER_PAGE = 7;

/** Panel order = display order. `key` is the rule name in the guild's automod config. */
const FILTERS = [
  { key: 'spam',        label: 'Anti spam' },
  { key: 'caps',        label: 'Anti caps' },
  { key: 'links',       label: 'Anti link' },
  { key: 'invites',     label: 'Anti invites' },
  { key: 'mentions',    label: 'Anti mass mention' },
  { key: 'emojis',      label: 'Anti emoji spam' },
  { key: 'nsfw',        label: 'Anti NSFW link' },
  { key: 'attachments', label: 'Anti attachment spam' },
  { key: 'zalgo',       label: 'Anti zalgo spam' },
  { key: 'similar',     label: 'Similar message spam' },
  { key: 'charlimit',   label: 'Character limit spam' },
  { key: 'newlines',    label: 'New line spam' },
  { key: 'words',       label: 'Blacklist word' },
];

/** `nsfw` can't be whitelisted; `nsfw` and `words` always punish at 100 heat ("100 (Max)"). */
const WL_FILTERS = FILTERS.filter((f) => f.key !== 'nsfw');
const HEAT_FIXED = new Set(['nsfw', 'words']);
const HEAT_FILTERS = FILTERS.filter((f) => !HEAT_FIXED.has(f.key));
const labelOf = (key) => FILTERS.find((f) => f.key === key)?.label ?? key;
const WL_LISTS = { u: 'users', r: 'roles', c: 'channels' };
const mentionOf = (type, id) => ({ u: `<@${id}>`, r: `<@&${id}>`, c: `<#${id}>` })[type];

const HELP = [
  ['.automod disable', 'Disables the automod system.'],
  ['.automod enable', 'Enable automod on the server.'],
  ['.automod logging', 'Sets the logging channel for automod events.'],
  ['.automod manage', 'Manage automod filters.'],
  ['.automod reset', 'Resets (deletes) the automod configuration.'],
  ['.automod settings', 'Master panel to configure all automod filters.'],
  ['.automod whitelist', 'Manage per-filter whitelists for a specific target.'],
  ['.automod wlshow', 'Show whitelisted items per filter.'],
];

const nicknameOf = (message) => message.member?.displayName || message.author.username;
const helpPayload = (nickname, userId, page) => {
  const payload = { embeds: [ui.helpPage('Aurora automod', HELP, nickname, { page, perPage: HELP_PER_PAGE })] };
  const pages = ui.helpPageCount(HELP, HELP_PER_PAGE);
  if (pages > 1) payload.components = [ui.pagerRow(ID_PREFIX, userId, Math.min(Math.max(page, 0), pages - 1), pages)];
  return payload;
};

// ───────────────────────── filter panels ─────────────────────────

/** Select menu whose chips show what is currently on (`defaults`), like the original: picking sets the new state. */
function filterSelect(customId, placeholder, filters, defaults, { min = 0, max = filters.length } = {}) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder(placeholder)
      .setMinValues(min)
      .setMaxValues(max)
      .addOptions(filters.map((f) => ({ label: f.label, value: f.key, default: defaults.has(f.key) }))),
  );
}

const fmtHeat = (key, value) => (HEAT_FIXED.has(key) ? '100 (Max)' : String(Number(value ?? 100)));

/** Pure texts of the panels (unit-tested). */
function panelText(rules) {
  return ['### Setup Automod !', ...FILTERS.map((f) => `${ARROW_LIST} **${f.label}** → ${rules?.[f.key]?.enabled ? CHECK : CROSS}`)].join('\n');
}
function settingsText(rules) {
  return ['### Automod Master Settings', ...FILTERS.map((f) => `${ARROW_LIST} **${f.label}** → Punishment: \`Auto Mute\` | Heat: \`${fmtHeat(f.key, rules?.[f.key]?.heat)}\``)].join('\n');
}
function whitelistText(cfg, type, id) {
  const on = new Set(whitelistedKeys(cfg, type, id));
  return [`### Automod Whitelist - ${mentionOf(type, id)}`, ...WL_FILTERS.map((f) => `${ARROW_LIST}  **${f.label}** → ${on.has(f.key) ? CHECK : CROSS}`)].join('\n');
}
function overviewText(cfg) {
  const blocks = [];
  for (const f of WL_FILTERS) {
    const t = cfg.whitelist?.[f.key];
    const rows = [['Users', t?.users, 'u'], ['Roles', t?.roles, 'r'], ['Channels', t?.channels, 'c']]
      .filter(([, list]) => list?.length)
      .map(([name, list, type]) => `${ARROW_LIST}  **${name}:** ${list.slice(0, 10).map((id) => mentionOf(type, id)).join(', ')}${list.length > 10 ? ` +${list.length - 10} more` : ''}`);
    if (rows.length) blocks.push([`**${f.label}**`, ...rows].join('\n'));
  }
  return blocks.length ? ['### Automod Whitelist Overview', ...blocks].join('\n') : null;
}

const whitelistedKeys = (cfg, type, id) => WL_FILTERS.map((f) => f.key).filter((k) => cfg.whitelist?.[k]?.[WL_LISTS[type]]?.includes(id));

const panelPayload = (cfg, userId) => ({
  embeds: [ui.plainEmbed(panelText(cfg.rules))],
  components: [filterSelect(`${ID_PREFIX}:sel:${userId}:0`, '↳ Select Filters To Toggle', FILTERS, new Set(FILTERS.filter((f) => cfg.rules[f.key]?.enabled).map((f) => f.key)))],
  allowedMentions: { parse: [] },
});
const settingsPayload = (cfg, userId) => ({
  embeds: [ui.plainEmbed(settingsText(cfg.rules))],
  components: [filterSelect(`${ID_PREFIX}:heat:${userId}:0`, '↳ Select filter to change heat', HEAT_FILTERS, new Set(), { min: 1, max: 1 })],
  allowedMentions: { parse: [] },
});
const whitelistPayload = (cfg, userId, type, id) => ({
  embeds: [ui.plainEmbed(whitelistText(cfg, type, id))],
  components: [filterSelect(`amw:sel:${userId}:${type}${id}`, '↳ Select Filters To Whitelist', WL_FILTERS, new Set(whitelistedKeys(cfg, type, id)))],
  allowedMentions: { parse: [] },
});

/** Shared guard for every panel interaction: only the requester, and they still need the real Manage Server permission. */
async function guardInteraction(interaction, userId) {
  if (!interaction.inGuild() || !interaction.guild) return false;
  if (interaction.user.id !== userId) { await fail(interaction, 'Only the person who ran this command can use this.'); return false; }
  if (!ui.hasRealManage(interaction.guild, interaction.user.id, interaction.memberPermissions)) {
    await fail(interaction, 'You need **Manage Server** to manage automod.');
    return false;
  }
  return true;
}

/** Pager (`am:<first|prev|del|next|last>:<userId>:<page>`), filter select (`am:sel:…`) and heat select (`am:heat:…`). */
async function handleComponent(interaction) {
  const [, action, userId, target] = interaction.customId.split(':');
  if (!interaction.inGuild() || !interaction.guild) return undefined;

  if (ui.PAGER_ACTIONS.includes(action)) {
    if (interaction.user.id !== userId) return fail(interaction, 'Only the person who ran this command can use this.');
    if (action === 'del') return interaction.message.delete().catch(() => {});
    const nickname = interaction.member?.displayName ?? interaction.user.username;
    return interaction.update(helpPayload(nickname, interaction.user.id, Number.parseInt(target, 10) || 0));
  }

  if (action === 'sel') {
    if (!(await guardInteraction(interaction, userId))) return undefined;
    const valid = new Set(FILTERS.map((f) => f.key));
    const picked = new Set((interaction.values ?? []).filter((k) => valid.has(k)));
    const cfg = await config.update(interaction.guild.id, 'automod', (d) => {
      for (const k of valid) d.rules[k].enabled = picked.has(k);
    }, { actorId: interaction.user.id, summary: `Automod filters enabled: ${[...picked].join(', ') || 'none'}` });
    return interaction.update(panelPayload(cfg, interaction.user.id));
  }

  if (action === 'heat') {
    if (!(await guardInteraction(interaction, userId))) return undefined;
    const key = HEAT_FILTERS.find((f) => f.key === interaction.values?.[0])?.key;
    if (!key) return undefined;
    const current = (await config.get(interaction.guild.id, 'automod')).rules[key].heat;
    const modal = new ModalBuilder().setCustomId(`amh:${userId}:${key}`).setTitle(`Heat - ${labelOf(key)}`.slice(0, 45)).addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('heat').setLabel('Heat per violation (0 - 100)').setStyle(TextInputStyle.Short)
          .setRequired(true).setMaxLength(6).setValue(String(Number(current))),
      ),
    );
    return interaction.showModal(modal);
  }
  return undefined;
}

/** Heat modal (`amh:<userId>:<filterKey>`): a violation of the filter adds this much heat per unit; 100 = Auto Mute. */
async function handleHeatModal(interaction) {
  const [, userId, key] = interaction.customId.split(':');
  if (!(await guardInteraction(interaction, userId))) return undefined;
  if (!HEAT_FILTERS.some((f) => f.key === key)) return fail(interaction, 'That filter has a fixed heat.');
  const raw = String(interaction.fields.getTextInputValue('heat') ?? '').trim().replace(',', '.');
  const value = raw === '' ? Number.NaN : Number(raw);
  if (!Number.isFinite(value) || value < 0 || value > 100) return fail(interaction, 'Heat must be a number between 0 and 100.');
  const heat = Math.round(value * 100) / 100;
  const cfg = await config.update(interaction.guild.id, 'automod', (d) => { d.rules[key].heat = heat; },
    { actorId: interaction.user.id, summary: `Automod heat for ${key} set to ${heat}` });
  const payload = settingsPayload(cfg, interaction.user.id);
  return interaction.isFromMessage?.() ? interaction.update(payload) : interaction.reply(payload);
}

/** Whitelist filter select (`amw:sel:<userId>:<u|r|c><targetId>`): picking sets exactly which filters the target is whitelisted for. */
async function handleWhitelistComponent(interaction) {
  const [, action, userId, targetRaw] = interaction.customId.split(':');
  if (action !== 'sel') return undefined;
  if (!(await guardInteraction(interaction, userId))) return undefined;
  const type = targetRaw?.[0];
  const id = targetRaw?.slice(1);
  if (!WL_LISTS[type] || !/^\d{17,20}$/.test(id ?? '')) return undefined;
  const valid = new Set(WL_FILTERS.map((f) => f.key));
  const picked = new Set((interaction.values ?? []).filter((k) => valid.has(k)));
  const list = WL_LISTS[type];
  const cfg = await config.update(interaction.guild.id, 'automod', (d) => {
    d.whitelist ??= {};
    for (const k of valid) {
      const t = (d.whitelist[k] ??= { users: [], roles: [], channels: [] });
      t[list] ??= [];
      const has = t[list].includes(id);
      if (picked.has(k) && !has) t[list].push(id);
      if (!picked.has(k) && has) t[list] = t[list].filter((x) => x !== id);
      if (!t.users?.length && !t.roles?.length && !t.channels?.length) delete d.whitelist[k];
    }
  }, { actorId: interaction.user.id, summary: `Automod whitelist for ${mentionOf(type, id)}: ${[...picked].join(', ') || 'none'}` });
  return interaction.update(whitelistPayload(cfg, interaction.user.id, type, id));
}

// ───────────────────────── subcommands ─────────────────────────

const parseChannelId = (args, message) => message.mentions.channels.first()?.id || String(args.find((x) => /^\d{17,20}$/.test(x)) ?? '');

/** User / role / channel from a mention or a raw ID. */
async function parseTarget(message, args) {
  const user = message.mentions.users.first(); if (user) return { type: 'u', id: user.id };
  const role = message.mentions.roles.first(); if (role) return { type: 'r', id: role.id };
  const channel = message.mentions.channels.first(); if (channel) return { type: 'c', id: channel.id };
  const raw = String(args.find((x) => /^\d{17,20}$/.test(String(x).replace(/[<@&#!>]/g, ''))) ?? '').replace(/[<@&#!>]/g, '');
  if (!raw) return null;
  if (message.guild.roles?.cache?.has(raw)) return { type: 'r', id: raw };
  if (message.guild.channels.cache.has(raw)) return { type: 'c', id: raw };
  if (await message.client?.users?.fetch(raw).catch(() => null)) return { type: 'u', id: raw };
  throw new AppError('I could not find that user, role or channel.');
}

async function whitelist(message, args) {
  const target = await parseTarget(message, args);
  if (!target) return reply(message, { embeds: [ui.deniedEmbed('You must provide a User, Role, or Channel to whitelist.')] });
  return reply(message, whitelistPayload(await config.get(message.guild.id, 'automod'), message.author.id, target.type, target.id));
}

async function wlshow(message) {
  const text = overviewText(await config.get(message.guild.id, 'automod'));
  if (!text) return reply(message, { embeds: [ui.deniedEmbed('There is nothing whitelisted in this server.')] });
  return reply(message, { embeds: [ui.plainEmbed(text)], allowedMentions: { parse: [] } });
}

async function enable(message) {
  const cfg = await config.get(message.guild.id, 'automod');
  if (cfg.enabled) return reply(message, { embeds: [ui.deniedEmbed('Automod is already enabled. Use `/automod manage` to configure filters.')] });
  const now = await config.update(message.guild.id, 'automod', (d) => { d.enabled = true; }, { actorId: message.author.id, summary: 'Automod enabled' });
  return reply(message, panelPayload(now, message.author.id));
}

async function disable(message) {
  const cfg = await config.get(message.guild.id, 'automod');
  if (!cfg.enabled) return reply(message, { embeds: [ui.deniedEmbed('The automod system is already disabled.')] });
  await config.update(message.guild.id, 'automod', (d) => { d.enabled = false; }, { actorId: message.author.id, summary: 'Automod disabled' });
  return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Automod Disabled**\n${ARROW}  The automod system has been disabled.`)] });
}

async function logging(message, args, prefix) {
  const id = parseChannelId(args, message);
  if (!id) return reply(message, { embeds: [ui.usageEmbed(`${prefix}automod logging <channel>`, 'Sets the logging channel for automod events.', null, { space: false })] });
  if (!message.guild.channels.cache.has(id)) throw new AppError('I could not find that channel in this server.');
  await config.update(message.guild.id, 'logging', (d) => { d.channels.automod = id; }, { actorId: message.author.id, summary: `Automod logging channel set to ${id}` });
  return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Automod Logging**\n${ARROW}  Automod logging channel has been set to <#${id}>.`)] });
}

/** Back to defaults and switched off. The ignore / bypass lists (managed with `.ignore`) are kept. */
async function reset(message) {
  const fresh = DEFAULTS.automod();
  await config.update(message.guild.id, 'automod', (d) => {
    d.enabled = false;
    d.rules = fresh.rules;
    d.timeoutSec = fresh.timeoutSec;
    d.exemptStaff = fresh.exemptStaff;
    d.ignoredUsers = []; // the old global automod whitelist
    d.whitelist = {};
  }, { actorId: message.author.id, summary: 'Automod configuration reset' });
  await config.update(message.guild.id, 'logging', (d) => { delete d.channels.automod; });
  return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Automod Reset**\n${ARROW} The automod configuration has been successfully reset.`)] });
}

module.exports = [{
  name: 'automod',
  aliases: ['am'],
  category: 'Automod',
  description: 'Configure the Aurora automod system',
  userPermissions: [P.ManageGuild],
  fakePermissions: false,
  async execute(message, args, ctx = {}) {
    const prefix = ctx.prefix || '.';
    // Also guards the catalog's `automod <sub>` entries, which delegate here without the dispatcher's permission check.
    if (!ui.hasRealManage(message.guild, message.author.id, message.member?.permissions)) {
      throw new AppError('You need **Manage Server** to manage automod.');
    }
    const sub = String(args[0] || '').toLowerCase();
    if (!sub || sub === 'help' || sub === 'show') return reply(message, helpPayload(nicknameOf(message), message.author.id, 0));
    args.shift();
    if (sub === 'enable') return enable(message);
    if (sub === 'disable') return disable(message);
    if (sub === 'logging') return logging(message, args, prefix);
    if (sub === 'manage') return reply(message, panelPayload(await config.get(message.guild.id, 'automod'), message.author.id));
    if (sub === 'reset') return reset(message);
    if (sub === 'settings') return reply(message, settingsPayload(await config.get(message.guild.id, 'automod'), message.author.id));
    if (sub === 'whitelist') return whitelist(message, args);
    if (sub === 'wlshow') return wlshow(message);
    return reply(message, helpPayload(nicknameOf(message), message.author.id, 0));
  },
}];

module.exports.handleComponent = handleComponent;
module.exports.handleHeatModal = handleHeatModal;
module.exports.handleWhitelistComponent = handleWhitelistComponent;
module.exports.panelText = panelText;
module.exports.settingsText = settingsText;
module.exports.whitelistText = whitelistText;
module.exports.overviewText = overviewText;
module.exports.FILTERS = FILTERS;
module.exports.WL_FILTERS = WL_FILTERS;
