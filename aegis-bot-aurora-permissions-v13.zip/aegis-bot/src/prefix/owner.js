'use strict';

const { makeEmbed } = require('../utils/embeds');
const { reply, resolveMember } = require('./helpers');
const { AppError } = require('../utils/errors');
const owners = require('../services/botOwner');
const env = require('../config/env');
const { formatDuration } = require('../utils/duration');
const { version: djsVersion } = require('discord.js');

const COLOR = 0x2c2c2c;
const pad = (n) => String(n).padStart(2, '0');

async function requireOwner(message) {
  if (!(await owners.isOwner(message.author.id))) throw new AppError('This command is restricted to Aurora bot owners.');
}

function statsEmbed(client) {
  const members = client.guilds.cache.reduce((n, g) => n + (g.memberCount || 0), 0);
  const m = process.memoryUsage();
  return makeEmbed({
    title: 'Aurora Owner Panel', color: COLOR, thumbnail: client.user.displayAvatarURL({ size: 256 }), timestamp: false,
    description: 'Bot statistics visible to Aurora owners only.',
    fields: [
      { name: 'Guilds', value: String(client.guilds.cache.size), inline: true },
      { name: 'Users', value: String(members), inline: true },
      { name: 'Uptime', value: formatDuration(client.uptime || 0), inline: true },
      { name: 'Memory', value: `RSS: **${(m.rss / 1048576).toFixed(1)} MB**\nHeap: **${(m.heapUsed / 1048576).toFixed(1)} / ${(m.heapTotal / 1048576).toFixed(1)} MB**`, inline: true },
      { name: 'Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true },
      { name: 'Node.js', value: process.version, inline: true },
      { name: 'discord.js', value: `v${djsVersion}`, inline: true },
      { name: 'Commands', value: String(client.commands?.size || 0), inline: true },
    ],
  });
}

function listEmbed(title, ids, description) {
  return makeEmbed({
    title, color: COLOR, timestamp: false,
    description: ids.length ? ids.map((id, i) => `**[\`${pad(i + 1)}\`]** <@${id}>`).join('\n') : description,
  });
}

async function target(message, args) {
  const member = await resolveMember(message, args[0]);
  if (member) return member.user;
  const id = message.mentions.users.first()?.id || String(args[0] || '').match(/^\d{17,20}$/)?.[0];
  if (!id) throw new AppError('Mention a valid user or provide their user ID.');
  return message.client.users.fetch(id);
}

module.exports = [{
  name: 'owner', aliases: ['botowner', 'bo'], category: 'Bot Settings', description: 'Aurora owner controls',
  async execute(message, args) {
    await requireOwner(message);
    const action = (args.shift() || 'help').toLowerCase();
    if (action === 'stats' || action === 'status' || action === 'info') return reply(message, { embeds: [statsEmbed(message.client)] });
    if (action === 'list' || action === 'owners') {
      const d = await owners.get();
      const ids = [...new Set([...env.ownerIds, ...d.owners])];
      return reply(message, { embeds: [listEmbed('Aurora Owners', ids, 'No owners are configured.')] });
    }
    if (action === 'add' || action === 'remove') {
      const user = await target(message, args);
      if (action === 'add') {
        await owners.addOwner(user.id);
        return reply(message, `✅ Added ${user} as an Aurora bot owner.`);
      }
      if (env.ownerIds.includes(user.id)) throw new AppError('That owner is defined in OWNER_IDS and must be removed from the .env file.');
      const current = await owners.get();
      const allOwners = new Set([...env.ownerIds, ...current.owners]);
      if (allOwners.size <= 1 && allOwners.has(user.id)) throw new AppError('You cannot remove the last Aurora bot owner.');
      await owners.removeOwner(user.id);
      return reply(message, `✅ Removed ${user} from Aurora bot owners.`);
    }
    if (action === 'noprefix' || action === 'np') {
      const op = (args.shift() || 'list').toLowerCase();
      if (op === 'list' || op === 'show') {
        const d = await owners.get();
        return reply(message, { embeds: [listEmbed('Aurora No-Prefix Users', d.noPrefix, 'No users have no-prefix access.')] });
      }
      const user = await target(message, args);
      if (op === 'add' || op === 'grant' || op === 'on') {
        await owners.grantNoPrefix(user.id);
        return reply(message, `✅ Granted no-prefix access to ${user}. They can now use commands without the \`.\` prefix.`);
      }
      if (op === 'remove' || op === 'revoke' || op === 'off') {
        await owners.revokeNoPrefix(user.id);
        return reply(message, `✅ Removed no-prefix access from ${user}.`);
      }
    }
    return reply(message, [
      '**Aurora Owner Controls**',
      '`owner stats` — guild count, users, uptime, memory and more',
      '`owner list` — list bot owners',
      '`owner add @user` — add a bot owner',
      '`owner remove @user` — remove a bot owner',
      '`owner noprefix add @user` — grant no-prefix access',
      '`owner noprefix remove @user` — remove no-prefix access',
      '`owner noprefix list` — list no-prefix users',
    ].join('\n'));
  },
}];
