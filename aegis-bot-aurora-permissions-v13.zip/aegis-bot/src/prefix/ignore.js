'use strict';
/**
 * `.ignore` — overview + the `bypass`, `channel`, `role` and `command` list UIs.
 * Only a bare `ignore show` still uses the original implementation in catalog.js (ignoreCommand).
 *
 * NOTE: the lists live in the guild's `automod` config (ignoredChannels, ignoredRoles, ignoredCommands,
 * ignoredBypassUsers). Today only ignoredChannels / ignoredRoles / ignoredUsers are read (by services/exemptions.js,
 * for automod exemptions; channels and roles are NOT yet enforced for commands). ignoredCommands + ignoredBypassUsers are enforced by the prefix dispatcher (services/ignoreList.js).
 */
const { PermissionFlagsBits: P } = require('discord.js');
const config = require('../services/guildConfig');
const { AppError } = require('../utils/errors');
const { fail } = require('../utils/reply');
const { reply } = require('./helpers');
const ui = require('./ui');
const ignoreList = require('../services/ignoreList');

const { ARROW, CHECK, CROSS, COLOR, RED } = ui;
const PAGE_SIZE = 10;

/** Real Manage Server (or the owner) — a fake permission can never edit the ignore lists. */
const canManage = (guild, userId, permissions) => userId === guild.ownerId || !!permissions?.has(P.ManageGuild);

const parseUserId = (args, message) => message.mentions.users.first()?.id || String(args.find((x) => /^\d{17,20}$/.test(x)) ?? '');
const cleanName = (s) => String(s ?? '').replace(/`/g, '');
const nicknameOf = (message) => message.member?.displayName || message.author.username;

// ───────────────────────── help pages ─────────────────────────

const ignoreHelp = (nickname) => ui.helpPage('Aurora ignore', [
  ['.ignore bypass', 'Manage users that can bypass the ignore list for this server.'],
  ['.ignore channel', 'Manage ignored channels for this server.'],
  ['.ignore command', 'Manage ignored commands for this server.'],
  ['.ignore role', 'Manage ignored roles for this server.'],
], nickname);

const bypassHelp = (nickname) => ui.helpPage('Aurora bypass', [
  ['.ignore bypass add', 'Add a bypass user for this server.'],
  ['.ignore bypass remove', 'Remove a bypass user for this server.'],
  ['.ignore bypass reset', 'Reset the bypass users list for this server.'],
  ['.ignore bypass show', 'Show all bypass users for this server.'],
], nickname);

const channelHelp = (nickname) => ui.helpPage('Aurora channel', [
  ['.ignore channel add', "Add a channel to the server's ignore list."],
  ['.ignore channel remove', "Remove a channel from the server's ignore list."],
  ['.ignore channel reset', 'Reset the ignored channels list for this server.'],
  ['.ignore channel show', 'Show all ignored channels for this server.'],
], nickname);

const roleHelp = (nickname) => ui.helpPage('Aurora role', [
  ['.ignore role add', "Add a role to the server's ignore list."],
  ['.ignore role remove', "Remove a role from the server's ignore list."],
  ['.ignore role reset', 'Reset the ignored roles list for this server.'],
  ['.ignore role show', 'Show all ignored roles for this server.'],
], nickname);

const commandHelp = (nickname) => ui.helpPage('Aurora command', [
  ['.ignore command add', "Add a command to the server's ignore list."],
  ['.ignore command remove', "Remove a command from the server's ignore list."],
  ['.ignore command reset', 'Reset the ignored commands list for this server.'],
  ['.ignore command show', 'Show all ignored commands for this server.'],
], nickname);

// ───────────────────────── paged list views ─────────────────────────

const pageLabel = (n) => `**[\`${String(n).padStart(2, '0')}\`]**`;

/** Pure text of one page (unit-tested). `rows` = [{ id, username }] for this page only. */
function bypassPageText({ rows, offset, totalUsers, page, pages, nickname }) {
  const lines = rows.map((r, i) => `${pageLabel(offset + i + 1)} <@${r.id}> → [\`${cleanName(r.username)}\`](https://discord.com/users/${r.id})`);
  return [`### Ignored Bypass users [${totalUsers}]`, ...lines, `-# Page ${page + 1}/${pages} | Requested by ${nickname}`].join('\n');
}

function channelPageText({ ids, offset, total, page, pages, nickname }) {
  const lines = ids.map((id, i) => `${pageLabel(offset + i + 1)} <#${id}>`);
  return [`### Ignored Channels [${total}]`, ...lines, `-# Page ${page + 1}/${pages} | Requested by ${nickname}`].join('\n');
}

function rolePageText({ ids, offset, total, page, pages, nickname }) {
  const lines = ids.map((id, i) => `${pageLabel(offset + i + 1)} <@&${id}>`);
  return [`### Ignored Roles [${total}]`, ...lines, `-# Page ${page + 1}/${pages} | Requested by ${nickname}`].join('\n');
}

function commandPageText({ names, offset, total, page, pages, nickname }) {
  const lines = names.map((n, i) => `${pageLabel(offset + i + 1)} \`${n}\``);
  return [`### Ignored Commands [${total}]`, ...lines, `-# Page ${page + 1}/${pages} | Requested by ${nickname}`].join('\n');
}

async function usernameOf(client, id) {
  const cached = client.users.cache.get(id);
  if (cached) return cached.username;
  return (await client.users.fetch(id).catch(() => null))?.username ?? id;
}

/** Each paged list: where it is stored, its button customId prefix (registered in events/interactionCreate), page text and empty message. */
const LISTS = {
  bypass: {
    prefix: 'ig', key: 'ignoredBypassUsers',
    empty: 'There are no bypass users configured for this server.',
    async text({ client, slice, offset, total, page, pages, nickname }) {
      const rows = await Promise.all(slice.map(async (id) => ({ id, username: await usernameOf(client, id) })));
      return bypassPageText({ rows, offset, totalUsers: total, page, pages, nickname });
    },
  },
  channel: {
    prefix: 'igc', key: 'ignoredChannels',
    empty: 'There are no ignored channels in this server.',
    async text({ slice, offset, total, page, pages, nickname }) { return channelPageText({ ids: slice, offset, total, page, pages, nickname }); },
  },
  role: {
    prefix: 'igr', key: 'ignoredRoles',
    empty: 'There are no ignored roles in this server.',
    emptyColor: ui.COLOR, // requested: this empty state uses the normal embed colour, not red
    async text({ slice, offset, total, page, pages, nickname }) { return rolePageText({ ids: slice, offset, total, page, pages, nickname }); },
  },
  command: {
    prefix: 'igm', key: 'ignoredCommands',
    empty: 'There are no ignored commands in this server.',
    async text({ slice, offset, total, page, pages, nickname }) { return commandPageText({ names: slice, offset, total, page, pages, nickname }); },
  },
};

const emptyEmbed = (list) => (list.emptyColor
  ? ui.plainEmbed(`**Process Denied !**\n${CROSS}  ${list.empty}`, list.emptyColor)
  : ui.deniedEmbed(list.empty));

async function buildListPage(list, { client, ids, page, user, nickname }) {
  const pages = Math.max(1, Math.ceil(ids.length / PAGE_SIZE));
  const i = Math.min(Math.max(page, 0), pages - 1);
  const slice = ids.slice(i * PAGE_SIZE, (i + 1) * PAGE_SIZE);
  const description = await list.text({ client, slice, offset: i * PAGE_SIZE, total: ids.length, page: i, pages, nickname });
  const payload = { embeds: [ui.plainEmbed(description)], allowedMentions: { parse: [] } };
  if (pages > 1) payload.components = [ui.pagerRow(list.prefix, user.id, i, pages)];
  return payload;
}

/** Pager buttons (`<prefix>:<action>:<requesterId>:<page>`). */
function listHandler(list) {
  return async function handleComponent(interaction) {
    const [, action, userId, target] = interaction.customId.split(':');
    if (!interaction.inGuild() || !interaction.guild) return undefined;
    if (interaction.user.id !== userId) return fail(interaction, 'Only the person who ran this command can use these buttons.');
    if (action === 'del') return interaction.message.delete().catch(() => {});
    if (!ui.PAGER_ACTIONS.includes(action)) return undefined;
    const ids = (await config.get(interaction.guild.id, 'automod'))[list.key] ?? [];
    if (!ids.length) return interaction.update({ embeds: [emptyEmbed(list)], components: [], allowedMentions: { parse: [] } });
    const nickname = interaction.member?.displayName ?? interaction.user.username;
    return interaction.update(await buildListPage(list, { client: interaction.client, ids, page: Number.parseInt(target, 10) || 0, user: interaction.user, nickname }));
  };
}
const handleComponent = listHandler(LISTS.bypass);
const handleChannelComponent = listHandler(LISTS.channel);
const handleCommandComponent = listHandler(LISTS.command);
const handleRoleComponent = listHandler(LISTS.role);

// ───────────────────────── bypass subcommands ─────────────────────────

async function bypass(message, args, prefix) {
  const sub = String(args.shift() || '').toLowerCase();
  if (!sub) return reply(message, { embeds: [bypassHelp(nicknameOf(message))] });

  const guildId = message.guild.id;
  const audit = (summary) => ({ actorId: message.author.id, summary });
  const current = async () => [...((await config.get(guildId, 'automod')).ignoredBypassUsers ?? [])];

  if (sub === 'add' || sub === 'remove' || sub === 'delete') {
    const isAdd = sub === 'add';
    const id = parseUserId(args, message);
    if (!id) {
      return reply(message, { embeds: [isAdd
        ? ui.usageEmbed(`${prefix}ignore bypass add <user>`, 'Add a bypass user for this server.')
        : ui.usageEmbed(`${prefix}ignore bypass remove <user>`, 'Remove a bypass user for this server.')] });
    }
    const listed = (await current()).includes(id);
    if (isAdd) {
      if (listed) return reply(message, { embeds: [ui.deniedEmbed(`User <@${id}> is already in the bypass list.`)] });
      if (!(await message.client.users.fetch(id).catch(() => null))) throw new AppError('I could not find that user.');
      await config.update(guildId, 'automod', (d) => { d.ignoredBypassUsers ??= []; if (!d.ignoredBypassUsers.includes(id)) d.ignoredBypassUsers.push(id); }, audit(`Ignore bypass user added: ${id}`));
      return reply(message, { embeds: [ui.plainEmbed(`${CHECK} **Bypass User Added**\n${ARROW} User <@${id}> can now bypass the ignore list.`)] });
    }
    if (!listed) {
      // Text exactly as requested (cross emoji + "Bypass User Removed"), shown in red.
      return reply(message, { embeds: [ui.plainEmbed(`**${CROSS}  Bypass User Removed**\n${ARROW}  User <@${id}> can no longer bypass the ignore list.`, RED)] });
    }
    await config.update(guildId, 'automod', (d) => { d.ignoredBypassUsers = (d.ignoredBypassUsers ?? []).filter((x) => x !== id); }, audit(`Ignore bypass user removed: ${id}`));
    return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Bypass User Removed**\n${ARROW}  User <@${id}> can no longer bypass the ignore list.`)] });
  }

  if (sub === 'reset' || sub === 'clear') {
    await config.update(guildId, 'automod', (d) => { d.ignoredBypassUsers = []; }, audit('Ignore bypass list reset'));
    return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Bypass User Reset**\n${ARROW}  The bypass users list has been reset.`)] });
  }

  if (sub === 'show' || sub === 'list') {
    const ids = await current();
    if (!ids.length) return reply(message, { embeds: [emptyEmbed(LISTS.bypass)] });
    return reply(message, await buildListPage(LISTS.bypass, { client: message.client, ids, page: 0, user: message.author, nickname: nicknameOf(message) }));
  }

  return reply(message, { embeds: [bypassHelp(nicknameOf(message))] });
}

// ───────────────────────── channel subcommands ─────────────────────────

const parseChannelId = (args, message) => message.mentions.channels.first()?.id || String(args.find((x) => /^\d{17,20}$/.test(x)) ?? '');

async function channel(message, args, prefix) {
  const sub = String(args.shift() || '').toLowerCase();
  if (!sub) return reply(message, { embeds: [channelHelp(nicknameOf(message))] });

  const guildId = message.guild.id;
  const audit = (summary) => ({ actorId: message.author.id, summary });
  const current = async () => [...((await config.get(guildId, 'automod')).ignoredChannels ?? [])];

  if (sub === 'add' || sub === 'remove' || sub === 'delete') {
    const isAdd = sub === 'add';
    const id = parseChannelId(args, message);
    if (!id) {
      return reply(message, { embeds: [isAdd
        ? ui.usageEmbed(`${prefix}ignore channel add <channel>`, "Add a channel to the server's ignore list.")
        : ui.usageEmbed(`${prefix}ignore channel remove <channel>`, "Remove a channel from the server's ignore list.")] });
    }
    const listed = (await current()).includes(id);
    if (isAdd) {
      if (listed) {
        // Text exactly as requested (white arrow instead of the cross emoji).
        return reply(message, { embeds: [ui.plainEmbed(`**Process Denied !**\n${ARROW}  Channel <#${id}> is already in the ignore list.`, RED)] });
      }
      if (!message.guild.channels.cache.has(id)) throw new AppError('I could not find that channel in this server.');
      await config.update(guildId, 'automod', (d) => { d.ignoredChannels ??= []; if (!d.ignoredChannels.includes(id)) d.ignoredChannels.push(id); }, audit(`Ignored channel added: ${id}`));
      return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Channel Added**\n${ARROW}  Channel <#${id}> has been added to the ignore list.`)] });
    }
    if (!listed) return reply(message, { embeds: [ui.deniedEmbed(`Channel <#${id}> is not in the ignore list.`)] });
    await config.update(guildId, 'automod', (d) => { d.ignoredChannels = (d.ignoredChannels ?? []).filter((x) => x !== id); }, audit(`Ignored channel removed: ${id}`));
    return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Channel Removed**\n${ARROW}  Channel <#${id}> has been removed from the ignore list.`)] });
  }

  if (sub === 'reset' || sub === 'clear') {
    await config.update(guildId, 'automod', (d) => { d.ignoredChannels = []; }, audit('Ignored channels reset'));
    return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Channel Reset**\n${ARROW}  The ignored channels list has been reset.`)] });
  }

  if (sub === 'show' || sub === 'list') {
    const ids = await current();
    if (!ids.length) return reply(message, { embeds: [emptyEmbed(LISTS.channel)] });
    return reply(message, await buildListPage(LISTS.channel, { client: message.client, ids, page: 0, user: message.author, nickname: nicknameOf(message) }));
  }

  return reply(message, { embeds: [channelHelp(nicknameOf(message))] });
}

// ───────────────────────── role subcommands ─────────────────────────

const parseRoleId = (args, message) => message.mentions.roles.first()?.id || String(args.find((x) => /^\d{17,20}$/.test(x)) ?? '');

async function roleScope(message, args, prefix) {
  const sub = String(args.shift() || '').toLowerCase();
  if (!sub) return reply(message, { embeds: [roleHelp(nicknameOf(message))] });

  const guildId = message.guild.id;
  const audit = (summary) => ({ actorId: message.author.id, summary });
  const current = async () => [...((await config.get(guildId, 'automod')).ignoredRoles ?? [])];

  if (sub === 'add' || sub === 'remove' || sub === 'delete') {
    const isAdd = sub === 'add';
    const id = parseRoleId(args, message);
    if (!id) {
      return reply(message, { embeds: [isAdd
        ? ui.usageEmbed(`${prefix}ignore role add <role>`, "Add a role to the server's ignore list.", null, { space: false })
        : ui.usageEmbed(`${prefix}ignore role remove <role>`, "Remove a role from the server's ignore list.", null, { space: false })] });
    }
    const listed = (await current()).includes(id);
    if (isAdd) {
      // @everyone would match every member (and exempt everyone from automod / antispam).
      if (id === guildId) return reply(message, { embeds: [ui.deniedEmbed('The @everyone role cannot be added to the ignore list.')] });
      if (listed) return reply(message, { embeds: [ui.deniedEmbed(`Role <@&${id}> is already in the ignore list.`)] });
      if (!message.guild.roles.cache.has(id)) throw new AppError('I could not find that role in this server.');
      await config.update(guildId, 'automod', (d) => { d.ignoredRoles ??= []; if (!d.ignoredRoles.includes(id)) d.ignoredRoles.push(id); }, audit(`Ignored role added: ${id}`));
      return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Role Added**\n${ARROW}  Role <@&${id}> has been added to the ignore list.`)] });
    }
    if (!listed) return reply(message, { embeds: [ui.deniedEmbed(`Role <@&${id}> is not in the ignore list.`)] });
    await config.update(guildId, 'automod', (d) => { d.ignoredRoles = (d.ignoredRoles ?? []).filter((x) => x !== id); }, audit(`Ignored role removed: ${id}`));
    return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Role Removed**\n${ARROW}  Role <@&${id}> has been removed from the ignore list.`)] });
  }

  if (sub === 'reset' || sub === 'clear') {
    await config.update(guildId, 'automod', (d) => { d.ignoredRoles = []; }, audit('Ignored roles reset'));
    return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Role Reset**\n${ARROW}  The ignored roles list has been reset.`)] });
  }

  if (sub === 'show' || sub === 'list') {
    const ids = await current();
    if (!ids.length) return reply(message, { embeds: [emptyEmbed(LISTS.role)] });
    return reply(message, await buildListPage(LISTS.role, { client: message.client, ids, page: 0, user: message.author, nickname: nicknameOf(message) }));
  }

  return reply(message, { embeds: [roleHelp(nicknameOf(message))] });
}

// ───────────────────────── command subcommands ─────────────────────────

const commandName = (args) => args.join(' ').trim().toLowerCase().replace(/\s+/g, ' ');

async function commandScope(message, args, prefix) {
  const sub = String(args.shift() || '').toLowerCase();
  if (!sub) return reply(message, { embeds: [commandHelp(nicknameOf(message))] });

  const guildId = message.guild.id;
  const audit = (summary) => ({ actorId: message.author.id, summary });
  const current = async () => [...((await config.get(guildId, 'automod')).ignoredCommands ?? [])];

  if (sub === 'add' || sub === 'remove' || sub === 'delete') {
    const isAdd = sub === 'add';
    const typed = commandName(args);
    if (!typed) {
      return reply(message, { embeds: [isAdd
        ? ui.usageEmbed(`${prefix}ignore command add <command>`, "Add a command to the server's ignore list.", null, { space: false })
        : ui.usageEmbed(`${prefix}ignore command remove <command>`, "Remove a command from the server's ignore list.", null, { space: false })] });
    }
    // Aliases resolve to the real command name, so `clear` and `purge` are the same entry.
    const found = require('./index').resolve(typed);
    const name = found?.name ?? typed;
    const list = await current();
    const listed = list.includes(name);

    if (isAdd) {
      if (!found) return reply(message, { embeds: [ui.deniedEmbed(`Command \`${typed}\` does not exist.`)] });
      if (ignoreList.isIgnoreCommand(found)) return reply(message, { embeds: [ui.deniedEmbed('The ignore command itself cannot be ignored.')] });
      if (listed) return reply(message, { embeds: [ui.deniedEmbed(`Command \`${name}\` is already in the ignore list.`)] });
      await config.update(guildId, 'automod', (d) => { d.ignoredCommands ??= []; if (!d.ignoredCommands.includes(name)) d.ignoredCommands.push(name); }, audit(`Ignored command added: ${name}`));
      return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Command Added**\n${ARROW}  Command \`${name}\` has been added to the ignore list.`)] });
    }
    if (!listed) return reply(message, { embeds: [ui.deniedEmbed(`Command \`${name}\` is not in the ignore list.`)] });
    await config.update(guildId, 'automod', (d) => { d.ignoredCommands = (d.ignoredCommands ?? []).filter((x) => x !== name); }, audit(`Ignored command removed: ${name}`));
    return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Command Removed**\n${ARROW}  Command \`${name}\` has been removed from the ignore list.`)] });
  }

  if (sub === 'reset' || sub === 'clear') {
    await config.update(guildId, 'automod', (d) => { d.ignoredCommands = []; }, audit('Ignored commands reset'));
    return reply(message, { embeds: [ui.plainEmbed(`**${CHECK}  Ignore Command Reset**\n${ARROW}  The ignored commands list has been reset.`)] });
  }

  if (sub === 'show' || sub === 'list') {
    const ids = await current();
    if (!ids.length) return reply(message, { embeds: [emptyEmbed(LISTS.command)] });
    return reply(message, await buildListPage(LISTS.command, { client: message.client, ids, page: 0, user: message.author, nickname: nicknameOf(message) }));
  }

  return reply(message, { embeds: [commandHelp(nicknameOf(message))] });
}

module.exports = [{
  name: 'ignore',
  category: 'Ignore',
  description: 'Manage Aurora ignore lists',
  userPermissions: [P.ManageGuild],
  fakePermissions: false,
  async execute(message, args, ctx = {}) {
    const prefix = ctx.prefix || '.';
    // Also guards the catalog's `ignore <scope> <op>` entries, which delegate here without the dispatcher's permission check.
    if (!canManage(message.guild, message.author.id, message.member?.permissions)) {
      throw new AppError('You need **Manage Server** to manage the ignore lists.');
    }
    const scope = String(args[0] || '').toLowerCase();
    if (!scope) return reply(message, { embeds: [ignoreHelp(nicknameOf(message))] });
    if (scope === 'bypass') { args.shift(); return bypass(message, args, prefix); }
    if (scope === 'channel' || scope === 'channels') { args.shift(); return channel(message, args, prefix); }
    if (scope === 'role' || scope === 'roles') { args.shift(); return roleScope(message, args, prefix); }
    if (scope === 'command' || scope === 'commands') { args.shift(); return commandScope(message, args, prefix); }
    return require('./catalog').ignoreCommand(message, args); // bare `show`
  },
}];

module.exports.handleComponent = handleComponent;
module.exports.handleChannelComponent = handleChannelComponent;
module.exports.handleCommandComponent = handleCommandComponent;
module.exports.handleRoleComponent = handleRoleComponent;
module.exports.rolePageText = rolePageText;
module.exports.channelPageText = channelPageText;
module.exports.commandPageText = commandPageText;
module.exports.bypassPageText = bypassPageText;
