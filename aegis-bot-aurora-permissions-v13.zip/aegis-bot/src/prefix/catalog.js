'use strict';

const {
  ChannelType,
  PermissionFlagsBits: P,
  OverwriteType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const crypto = require('node:crypto');
const { PAGES } = require('../services/help');
const config = require('../services/guildConfig');
const permit = require('../services/permit');
const fakePermissions = require('../services/fakePermissions');
const { permNames, hierarchyProblem, isDangerousRole } = require('../utils/permissions');
const automod = require('../services/automod');
const moderation = require('../services/moderation');
const tools = require('../services/channelTools');
const utility = require('../services/utility');
const giveaway = require('../services/giveaways');
const verification = require('../services/verification');
const autoresponder = require('../services/autoresponder');
const tags = require('../services/tags');
const greetings = require('../services/greetings');
const customroles = require('../services/customroles');
const tickets = require('../services/tickets');
const webhooks = require('../services/webhooks');
const music = require('../services/music');
const { reply, resolveMember, requireMember, requireUserId } = require('./helpers');
const { makeEmbed, clip } = require('../utils/embeds');
const { parseDuration, formatDuration, discordTime } = require('../utils/duration');
const { AppError } = require('../utils/errors');

const ROLE_PERMS = [P.Administrator, P.ManageGuild, P.ManageChannels, P.ManageMessages, P.ModerateMembers];
const GENERIC_FUN = {
  airkiss: '💨💋', angrystare: '😠👀', bite: '🦷', bonk: '🔨', brofist: '👊', cuddle: '🫂',
  handhold: '🤝', hug: '🫂', kiss: '💋', lick: '😛', nom: '🍽️', nuzzle: '😊', pat: '🫳',
  pinch: '🤏', poke: '👉', punch: '🥊', slap: '🖐️', smack: '💥', stare: '👀', tickle: '😂',
  wave: '👋', bleh: '😛', blush: '😊', celebrate: '🎉', cheers: '🥂', clap: '👏', confused: '😵‍💫',
  cool: '😎', cry: '😢', dance: '💃', drool: '🤤', evillaugh: '😈', facepalm: '🤦', happy: '😄',
  headbang: '🤘', huh: '❓', laugh: '😂', love: '❤️', mad: '😡', nervous: '😬', no: '🙅',
  nosebleed: '🫣', nyah: '😺', peek: '👀', pout: '😗', run: '🏃', sad: '😔', scared: '😨',
  shout: '📣', shrug: '🤷', shy: '🫣', sigh: '😮‍💨', sing: '🎤', sip: '🥤', sleep: '😴',
  slowclap: '👏', smile: '🙂', smug: '😏', sneeze: '🤧', sorry: '🙏', stop: '🛑', surprised: '😲',
  sweat: '😅', thumbsup: '👍', tired: '🥱', wink: '😉', yawn: '🥱', yay: '🙌', yes: '✅',
};

function rootOf(command) { return command.split(' ')[0]; }
function categoryFor(command) {
  for (const [category, sections] of PAGES) {
    if (sections.some(([, commands]) => commands.includes(command))) return category;
  }
  return 'General';
}
function usage(command) { return `\`,${command}\` ${command.includes(' ') ? '[args]' : '[args]'}`; }
function cleanText(s, max = 1800) { return clip(String(s ?? '').replace(/@everyone|@here/g, '@ everyone'), max); }
function memberArg(message, arg) { return resolveMember(message, arg).then((m) => m ?? null); }
/** Throws when the invoking member may not act on `target` (self / owner / equal-or-higher role, for the member AND the bot). */
function checkTarget(message, target) {
  const problem = hierarchyProblem(message.guild, message.member, target);
  if (problem) throw new AppError(problem);
}

/**
 * A role the invoker may touch: not @everyone / integration-managed, below the invoker's highest role and below the bot.
 * Someone acting through a FAKE Manage Roles grant also cannot hand out roles with powerful permissions.
 */
function checkRole(message, role) {
  if (!role) throw new AppError('Mention a role.');
  if (role.id === message.guild.id || role.managed) throw new AppError('That role cannot be managed with this command.');
  const me = message.guild.members.me;
  const actor = message.member;
  if (actor.id !== message.guild.ownerId && actor.roles.highest.comparePositionTo(role) <= 0) throw new AppError('You can only manage roles below your highest role.');
  if (!me || me.roles.highest.comparePositionTo(role) <= 0) throw new AppError("I can't manage that role — it is above (or equal to) my highest role.");
  if (!actor.permissions.has(P.ManageRoles) && isDangerousRole(role)) throw new AppError('That role has powerful permissions and cannot be handed out through fake permissions.');
}

async function ensureManage(message, perm = P.ManageGuild) {
  // Real permission or a fake one (see services/fakePermissions). Administrator is always real-only.
  if (await fakePermissions.satisfies(message.member, perm)) return;
  throw new AppError(`You need **${permNames([perm]).join(', ')}** to use this command.`);
}
function boolArg(v) {
  if (['on','true','yes','enable','enabled'].includes(String(v).toLowerCase())) return true;
  if (['off','false','no','disable','disabled'].includes(String(v).toLowerCase())) return false;
  return null;
}
function parseKeyValue(args) {
  const out = {};
  for (const a of args) {
    const m = a.match(/^([a-z][\w-]*)=(.*)$/i);
    if (m) out[m[1].toLowerCase()] = m[2];
  }
  return out;
}
function parseChannelId(args, message) {
  return message.mentions.channels.first()?.id || String(args.find((x) => /^\d{17,20}$/.test(x)) ?? '');
}
function parseRoleId(args, message) {
  return message.mentions.roles.first()?.id || String(args.find((x) => /^\d{17,20}$/.test(x)) ?? '');
}
function parseUserId(args, message) {
  return message.mentions.users.first()?.id || String(args.find((x) => /^\d{17,20}$/.test(x)) ?? '');
}

async function setListConfig(guildId, module, key, op, values) {
  return config.update(guildId, module, (d) => {
    d[key] ??= [];
    if (op === 'reset' || op === 'clear') d[key] = [];
    else if (op === 'add') { for (const v of values) { if (v && !d[key].includes(v)) d[key].push(v); } }
    else if (op === 'remove') d[key] = d[key].filter((x) => !values.includes(x));
  });
}

async function ignoreCommand(message, args) {
  await ensureManage(message);
  const scope = (args.shift() || 'show').toLowerCase();
  const op = (args.shift() || 'show').toLowerCase();
  const c = await config.get(message.guild.id, 'automod');
  if (scope === 'show') {
    return reply(message, [
      `Channels: ${c.ignoredChannels.map(id => `<#${id}>`).join(' ') || 'none'}`,
      `Roles: ${c.ignoredRoles.map(id => `<@&${id}>`).join(' ') || 'none'}`,
      `Commands: ${c.ignoredCommands.map(x => `\`${x}\``).join(', ') || 'none'}`,
      `Bypass users: ${c.ignoredBypassUsers.map(id => `<@${id}>`).join(' ') || 'none'}`,
    ].join('\n'));
  }
  if (scope === 'channel' || scope === 'role') {
    const key = scope === 'channel' ? 'ignoredChannels' : 'ignoredRoles';
    const id = scope === 'channel' ? parseChannelId(args, message) : parseRoleId(args, message);
    if (op === 'show') return reply(message, c[key].length ? c[key].map(x => scope === 'channel' ? `<#${x}>` : `<@&${x}>`).join(' ') : `ℹ️ No ignored ${scope}s.`);
    if (op === 'reset' || op === 'clear') { await config.update(message.guild.id,'automod',d=>{d[key]=[]}); return reply(message, `✅ Ignored ${scope}s reset.`); }
    if (!id) throw new AppError(`Mention a ${scope}.`);
    await setListConfig(message.guild.id,'automod',key,op,[id]);
    return reply(message, `✅ Ignored ${scope} ${op} complete.`);
  }
  if (scope === 'command') {
    if (op === 'show') return reply(message, c.ignoredCommands.length ? c.ignoredCommands.map(x => `\`${x}\``).join(', ') : 'ℹ️ No ignored commands.');
    if (op === 'reset' || op === 'clear') { await config.update(message.guild.id,'automod',d=>{d.ignoredCommands=[]}); return reply(message,'✅ Ignored commands reset.'); }
    const name = args.join(' ').trim().toLowerCase(); if (!name) throw new AppError('Provide a command name.');
    await setListConfig(message.guild.id,'automod','ignoredCommands',op,[name]);
    return reply(message, `✅ Ignored command ${op} complete for \`${name}\`.`);
  }
  if (scope === 'bypass') {
    const id = parseUserId(args, message);
    if (op === 'show') return reply(message, c.ignoredBypassUsers.length ? c.ignoredBypassUsers.map(x => `<@${x}>`).join(' ') : 'ℹ️ No bypass users.');
    if (op === 'reset' || op === 'clear') { await config.update(message.guild.id,'automod',d=>{d.ignoredBypassUsers=[]}); return reply(message,'✅ Bypass list reset.'); }
    if (!id) throw new AppError('Mention a user.');
    await setListConfig(message.guild.id,'automod','ignoredBypassUsers',op,[id]);
    return reply(message, `✅ Bypass ${op} complete.`);
  }
  return reply(message, 'ℹ️ Use ignore channel/role/command/bypass with add, remove, show or reset.');
}

async function permitCommand(message, root, args) {
  const SPACE = '<a:space:1551669674213908510>';
  const ARROW = '<:whitearrow:1551669900622172161>';
  // Trusted users are a separate server trust layer. Build the command surface
  // first; add/remove/show/reset behavior can be wired independently.
  if (root === 'trusted' && (!args.length || ['help'].includes(String(args[0]).toLowerCase()))) {
    return reply(message, { embeds: [makeEmbed({
      title: 'Aurora trusted [4]',
      description: [
        '```yml',
        '<..> <required> | [..] [optional]',
        '```',
        '',
        '> **`.trusted add`**',
        `${SPACE} ${ARROW} Add an trusted user for this server.`,
        '',
        '> **`.trusted remove`**',
        `${SPACE} ${ARROW} Remove an trusted user from this server.`,
        '',
        '> **`.trusted reset`**',
        `${SPACE} ${ARROW} Removes all trusted users from this server.`,
        '',
        '> **`.trusted show`**',
        `${SPACE} ${ARROW} Show all trusted users for this server.`,
        `-# Page 1/1 | Requested by ${message.member?.displayName || message.author.username}`,
      ].join('\n'),
      color: 0x2c2c2c,
      timestamp: false,
    })] });
  }

  // Trusted users are a separate server trust list. Keep it distinct from
  // the AntiNuke whitelist and Extra Owner list.
  if (root === 'trusted') {
    if (message.author.id !== message.guild.ownerId) {
      throw new AppError('Only the server owner can manage trusted users.');
    }

    const op = (args.shift() || 'help').toLowerCase();
    const SPACE = '<a:space:1551669674213908510>';
    const ARROW = '<:whitearrow:1551669900622172161>';
    const CHECK = '<:wccheckmark:1551675781527380011>';
    const CROSS = '<:wccrossmar:1551676376313237504>';

    if (op === 'add') {
      const id = parseUserId(args, message);
      if (!id) {
        return reply(message, { embeds: [makeEmbed({
          description: [
            '```yml',
            '<..> <required> | [..] [optional]',
            '```',
            '> **`.trusted add <user>`**',
            '',
            `${SPACE}${ARROW} Add an trusted user for this server.`,
          ].join('\n'),
          color: 0x2c2c2c,
          timestamp: false,
        })] });
      }

      const rows = await permit.list(message.guild.id);
      const exists = rows.some((r) => r.target_type === 'user' && r.target_id === id && r.scope === 'trusted');
      if (exists) {
        return reply(message, { embeds: [makeEmbed({
          title: 'Process Denied !',
          description: `${SPACE}${CROSS} User <@${id}> is already in the trusted users list.`,
          color: 0xB91C1C,
          timestamp: false,
        })] });
      }

      await permit.add(message.guild.id, id, 'user', 'trusted', message.author.id);
      return reply(message, { embeds: [makeEmbed({
        title: `${CHECK} Trusted User Added`,
        description: `${ARROW}  User <@${id}> has been added in trusted user's list.`,
        color: 0x2c2c2c,
        timestamp: false,
      })] });
    }

    if (op === 'remove') {
      const id = parseUserId(args, message);
      if (!id) {
        return reply(message, { embeds: [makeEmbed({
          description: [
            '```yml',
            '<..> <required> | [..] [optional]',
            '```',
            '> **`.trusted remove <user>`**',
            '',
            `${SPACE}${ARROW} Remove an trusted user from this server.`,
          ].join('\n'),
          color: 0x2c2c2c,
          timestamp: false,
        })] });
      }
      const removed = await permit.remove(message.guild.id, id, 'trusted');
      return reply(message, removed
        ? { embeds: [makeEmbed({ description: `${CHECK} Trusted User Removed\n${ARROW}  User <@${id}> has been removed from trusted user's list.`, color: 0x2c2c2c, timestamp: false })] }
        : { embeds: [makeEmbed({ title: 'Process Denied !', description: `${SPACE}${CROSS} User <@${id}> is not in the trusted users list.`, color: 0xB91C1C, timestamp: false })] });
    }

    if (op === 'show' || op === 'list') {
      const rows = (await permit.list(message.guild.id)).filter((r) => r.target_type === 'user' && r.scope === 'trusted');
      if (!rows.length) {
        return reply(message, { embeds: [makeEmbed({
          title: 'Process Denied !',
          description: `${SPACE}${CROSS} There are no trusted users in this server.`,
          color: 0xB91C1C,
          timestamp: false,
        })] });
      }
      const pageSize = 10;
      const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
      let page = 0;
      const requester = message.member?.displayName || message.author.username;
      const build = (pageIndex) => {
        const start = pageIndex * pageSize;
        const current = rows.slice(start, start + pageSize);
        const list = current.map((r, i) => `**[\`${String(start + i + 1).padStart(2, '0')}\`]** <@${r.target_id}> → [User](https://discord.com/users/${r.target_id})`).join('\n');
        return {
          embeds: [makeEmbed({
            title: `### Trusted Users [${rows.length}]`,
            description: `${list}\n-# Page ${pageIndex + 1}/${totalPages} | Requested by ${requester}`,
            color: 0x2c2c2c,
            timestamp: false,
          })],
          components: totalPages > 1 ? [new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`trusted_prev_${message.author.id}`).setLabel('Previous').setStyle(ButtonStyle.Secondary).setDisabled(pageIndex === 0),
            new ButtonBuilder().setCustomId(`trusted_next_${message.author.id}`).setLabel('Next').setStyle(ButtonStyle.Secondary).setDisabled(pageIndex === totalPages - 1),
          )] : [],
        };
      };
      const sent = await reply(message, build(page));
      if (totalPages <= 1 || !sent) return sent;
      const collector = sent.createMessageComponentCollector({ time: 120000 });
      collector.on('collect', async (interaction) => {
        if (interaction.user.id !== message.author.id) return interaction.reply({ content: 'Only the command requester can use these buttons.', ephemeral: true });
        if (interaction.customId.startsWith('trusted_prev_')) page = Math.max(0, page - 1);
        else if (interaction.customId.startsWith('trusted_next_')) page = Math.min(totalPages - 1, page + 1);
        await interaction.update(build(page));
      });
      collector.on('end', async () => { await sent.edit({ components: [] }).catch(() => {}); });
      return sent;
    }

    if (op === 'reset') {
      const rows = (await permit.list(message.guild.id)).filter((r) => r.target_type === 'user' && r.scope === 'trusted');
      for (const row of rows) await permit.remove(message.guild.id, row.target_id, 'trusted');
      return reply(message, { embeds: [makeEmbed({ description: `${CHECK} Trusted Users Reset\n${ARROW}  All trusted users have been removed from this server.`, color: 0x2c2c2c, timestamp: false })] });
    }

    return reply(message, { embeds: [makeEmbed({
      title: 'Aurora trusted [4]',
      description: [
        '```yml',
        '<..> <required> | [..] [optional]',
        '```',
        '',
        '> **`.trusted add`**', `${SPACE} ${ARROW} Add an trusted user for this server.`, '',
        '> **`.trusted remove`**', `${SPACE} ${ARROW} Remove an trusted user from this server.`, '',
        '> **`.trusted reset`**', `${SPACE} ${ARROW} Removes all trusted users from this server.`, '',
        '> **`.trusted show`**', `${SPACE} ${ARROW} Show all trusted users for this server.`,
        `-# Page 1/1 | Requested by ${message.member?.displayName || message.author.username}`,
      ].join('\n'),
      color: 0x2c2c2c, timestamp: false,
    })] });
  }

  // Extra Owners are a server-owner-managed trust layer used by Aurora security.
  // Keep this separate from Discord Administrator permissions and Aurora bot owners.
  if (root === 'extraowner') {
    if (message.author.id !== message.guild.ownerId) {
      throw new AppError('Only the server owner can manage Extra Owners.');
    }

    const op = (args.shift() || 'help').toLowerCase();
    const SPACE = '<a:space:1551669674213908510>';
    const ARROW = '<:whitearrow:1551669900622172161>';
    const CHECK = '<:wccheckmark:1551675781527380011>';
    const CROSS = '<:wccrossmar:1551676376313237504>';
    const MEMBER = '<:FakeNitroEmoji:1551834754775523378>';

    if (op === 'add') {
      const id = parseUserId(args, message);
      if (!id) {
        return reply(message, { embeds: [makeEmbed({
          description: [
            '```yml',
            '<..> <required> | [..] [optional]',
            '```',
            '> **`.extraowner add <user>`**',
            '',
            `${SPACE}${ARROW} **Add an extra owner for this server.**`,
          ].join('\n'),
          color: 0x2c2c2c,
          timestamp: false,
        })] });
      }

      const rows = await permit.list(message.guild.id);
      const exists = rows.some((r) => r.target_type === 'user' && r.target_id === id && r.scope === 'antinuke');
      if (exists) {
        return reply(message, { embeds: [makeEmbed({
          title: 'Process Denied !',
          description: `${SPACE} ${CROSS} User <@${id}> is already in the extra owners list.`,
          color: 0xB91C1C,
          timestamp: false,
        })] });
      }

      await permit.add(message.guild.id, id, 'user', 'antinuke', message.author.id);
      return reply(message, { embeds: [makeEmbed({
        title: `${CHECK}  Extra Owner Added`,
        description: `${MEMBER}  User <@${id}> has been added in owner's list.`,
        color: 0x2c2c2c,
        timestamp: false,
      })] });
    }

    if (op === 'remove') {
      const id = parseUserId(args, message);
      if (!id) {
        return reply(message, { embeds: [makeEmbed({
          description: [
            '```yml',
            '<..> <required> | [..] [optional]',
            '```',
            '> **`.extraowner remove <user>`**',
            '',
            `${SPACE}${ARROW} Remove an extra owner from this server.`,
          ].join('\n'),
          color: 0x2c2c2c,
          timestamp: false,
        })] });
      }
      const removed = await permit.remove(message.guild.id, id, 'antinuke');
      return reply(message, removed
        ? { embeds: [makeEmbed({ description: `${CHECK} Extra Owner Removed\n${ARROW}  User <@${id}> has been removed from owner's list.`, color: 0x2c2c2c, timestamp: false })] }
        : { embeds: [makeEmbed({ title: 'Process Denied !', description: `${SPACE} ${CROSS} User <@${id}> is not in the extra owners list.`, color: 0xB91C1C, timestamp: false })] });
    }

    if (op === 'show' || op === 'list') {
      const rows = (await permit.list(message.guild.id)).filter((r) => r.target_type === 'user' && r.scope === 'antinuke');
      if (!rows.length) {
        return reply(message, { embeds: [makeEmbed({
          title: 'Process Denied !',
          description: `${SPACE} ${CROSS} There are no extra owners in this server.`,
          color: 0xB91C1C,
          timestamp: false,
        })] });
      }

      const pageSize = 10;
      const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
      let page = 0;
      const requester = message.member?.displayName || message.author.username;
      const build = (pageIndex) => {
        const start = pageIndex * pageSize;
        const current = rows.slice(start, start + pageSize);
        const list = current.map((r, i) => `**[\`${String(start + i + 1).padStart(2, '0')}\`]** <@${r.target_id}> → [User](https://discord.com/users/${r.target_id})`).join('\n');
        return {
          embeds: [makeEmbed({
            title: 'Aurora extraowner [4]',
            description: `${list}\n-# Page ${pageIndex + 1}/${totalPages} | Requested by ${requester}`,
            color: 0x2c2c2c,
            timestamp: false,
          })],
          components: totalPages > 1 ? [new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`extraowner_prev_${message.author.id}`).setLabel('Previous').setStyle(ButtonStyle.Secondary).setDisabled(pageIndex === 0),
            new ButtonBuilder().setCustomId(`extraowner_next_${message.author.id}`).setLabel('Next').setStyle(ButtonStyle.Secondary).setDisabled(pageIndex === totalPages - 1),
          )] : [],
        };
      };

      const sent = await reply(message, build(page));
      if (totalPages <= 1 || !sent) return sent;
      const collector = sent.createMessageComponentCollector({ time: 120000 });
      collector.on('collect', async (interaction) => {
        if (interaction.user.id !== message.author.id) {
          return interaction.reply({ content: 'Only the command requester can use these buttons.', ephemeral: true });
        }
        if (interaction.customId.startsWith('extraowner_prev_')) page = Math.max(0, page - 1);
        else if (interaction.customId.startsWith('extraowner_next_')) page = Math.min(totalPages - 1, page + 1);
        await interaction.update(build(page));
      });
      collector.on('end', async () => {
        await sent.edit({ components: [] }).catch(() => {});
      });
      return sent;
    }

    if (op === 'reset') {
      const rows = (await permit.list(message.guild.id)).filter((r) => r.target_type === 'user' && r.scope === 'antinuke');
      for (const row of rows) await permit.remove(message.guild.id, row.target_id, 'antinuke');
      return reply(message, { embeds: [makeEmbed({ description: `${CHECK} Extra Owners Reset\n${MEMBER} All extra owners have been removed from this server.`, color: 0x2c2c2c, timestamp: false })] });
    }

    return reply(message, { embeds: [makeEmbed({
      title: 'Aurora extraowner [4]',
      description: [
        '```yml',
        '<..> <required> | [..] [optional]',
        '```',
        '> **`.extraowner add`**',
        `${SPACE}${ARROW} Add an extra owner for this server.`,
        '',
        '> **`.extraowner remove`**',
        `${SPACE}${ARROW} Remove an extra owner from this server.`,
        '',
        '> **`.extraowner reset`**',
        `${SPACE}${ARROW} Removes all extra owners from this server.`,
        '',
        '> **`.extraowner show`**',
        `${SPACE}${ARROW} Show all extra owners for this server.`,
        '-# Page 1/1 | Requested by ' + (message.member?.displayName || message.author.username),
      ].join('\n'),
      color: 0x2c2c2c,
      timestamp: false,
    })] });
  }

  await ensureManage(message, P.Administrator);
  const op = (args.shift() || 'show').toLowerCase();
  const targetId = parseUserId(args, message) || parseRoleId(args, message);
  const member = message.mentions.members.first();
  const role = message.mentions.roles.first();
  const type = member ? 'user' : role ? 'role' : /^\d{17,20}$/.test(targetId) ? 'user' : null;
  if (op === 'show' || op === 'list' || op === 'manage') {
    const rows = await permit.list(message.guild.id);
    const filtered = root === 'permissions' ? rows : rows.filter((r) => r.scope === 'all');
    return reply(message, filtered.length ? { embeds: [makeEmbed({ title: `🔑 ${root}`, description: filtered.slice(0, 40).map((r) => `${r.target_type === 'user' ? `<@${r.target_id}>` : `<@&${r.target_id}>`} → **${r.scope}**`).join('\n'), timestamp: false })] } : `ℹ️ No ${root} entries are configured.`);
  }
  if (op === 'resetall' || op === 'reset' || op === 'clear') {
    const rows = await permit.list(message.guild.id);
    let removed = 0;
    for (const r of rows) removed += await permit.remove(message.guild.id, r.target_id, root === 'permissions' ? r.scope : 'all');
    return reply(message, `✅ Removed **${removed}** ${root} entry(s).`);
  }
  if (op === 'grant' || op === 'add') {
    if (!type || !targetId) throw new AppError(`Usage: ${usage(`${root} add @user`)}`);
    const scope = root === 'permissions' ? (args.find((x) => permit.SCOPES.includes(x.toLowerCase()))?.toLowerCase() || 'all') : 'all';
    const ok = await permit.add(message.guild.id, targetId, type, scope, message.author.id);
    return reply(message, ok ? `✅ Added ${type === 'role' ? `<@&${targetId}>` : `<@${targetId}>`} to **${root}** (${scope}).` : 'ℹ️ That entry already exists.');
  }
  if (op === 'revoke' || op === 'remove') {
    if (!targetId) throw new AppError(`Usage: ${usage(`${root} remove @user`)}`);
    const scope = root === 'permissions' ? args.find((x) => permit.SCOPES.includes(x.toLowerCase()))?.toLowerCase() : undefined;
    const removed = await permit.remove(message.guild.id, targetId, scope);
    return reply(message, `✅ Removed **${removed}** matching entry(s).`);
  }
  return reply(message, `ℹ️ ${root} supports add/grant, remove/revoke, show/list and reset.`);
}

async function automodCommand(message, root, args) {
  await ensureManage(message);
  const action = (args.shift() || 'settings').toLowerCase();
  if (root === 'blword') {
    const c = await config.get(message.guild.id, 'automod');
    const op = action;
    if (op === 'guide') return reply(message, '🛡️ Word blacklist guide: `,blword add word`, `,blword remove word`, `,blword show`, `,blword reset`. Then enable the words rule with `,automod enable`.');
    if (op === 'show') return reply(message, c.rules.words.list.length ? `🚫 **Blocked words:** ${c.rules.words.list.map((x) => `\`${x}\``).join(', ')}` : 'ℹ️ No blocked words configured.');
    if (op === 'reset') { await config.update(message.guild.id, 'automod', d => { d.rules.words.list = []; }); return reply(message, '✅ Word blacklist reset.'); }
    if (op === 'add') { const words = args.join(' ').split(',').map(x => x.trim()).filter(Boolean).slice(0, 50); await config.update(message.guild.id, 'automod', d => { d.rules.words.list ??= []; for (const w of words) if (!d.rules.words.list.includes(w)) d.rules.words.list.push(w); d.rules.words.enabled = true; }); return reply(message, `✅ Added **${words.length}** blocked word(s).`); }
    if (op === 'remove') { const words = args.join(' ').split(',').map(x => x.trim()).filter(Boolean); await config.update(message.guild.id, 'automod', d => { d.rules.words.list = (d.rules.words.list || []).filter(w => !words.includes(w)); }); return reply(message, `✅ Removed matching blocked word(s).`); }
  }
  const c = await config.get(message.guild.id, 'automod');
  if (action === 'enable' || action === 'disable') {
    await config.update(message.guild.id, 'automod', d => { d.enabled = action === 'enable'; });
    return reply(message, `🛡️ AutoMod is now **${action === 'enable' ? 'enabled' : 'disabled'}**.`);
  }
  if (action === 'reset') {
    await config.update(message.guild.id, 'automod', d => {
      d.enabled = false;
      d.rules.words.list = [];
      for (const key of Object.keys(d.rules)) d.rules[key].enabled = false;
    });
    return reply(message, '✅ AutoMod configuration reset.');
  }
  if (action === 'whitelist' || action === 'wlshow') {
    const op = (args.shift() || 'show').toLowerCase();
    const id = parseUserId(args, message);
    if (op === 'show') return reply(message, c.ignoredUsers.length ? `🛡️ AutoMod whitelist: ${c.ignoredUsers.map(x => `<@${x}>`).join(' ')}` : 'ℹ️ AutoMod whitelist is empty.');
    if (op === 'clear' || op === 'reset') { await config.update(message.guild.id, 'automod', d => { d.ignoredUsers = []; }); return reply(message, '✅ AutoMod whitelist cleared.'); }
    if (!id) throw new AppError('Mention a user for whitelist add/remove.');
    await setListConfig(message.guild.id, 'automod', 'ignoredUsers', op, [id]);
    return reply(message, `✅ AutoMod whitelist ${op} complete.`);
  }
  if (action === 'logging') {
    const ch = parseChannelId(args, message);
    await config.update(message.guild.id, 'logging', d => { d.channels.automod = ch || null; });
    return reply(message, ch ? `✅ AutoMod logs set to <#${ch}>.` : '✅ AutoMod logging override cleared.');
  }
  return reply(message, { embeds: [makeEmbed({ title: '🛡️ AutoMod', timestamp: false, description: [
    `Status: **${c.enabled ? 'enabled' : 'disabled'}**`,
    `Words: **${c.rules.words.enabled ? 'on' : 'off'}** (${c.rules.words.list.length})`,
    `Mentions: **${c.rules.mentions.enabled ? 'on' : 'off'}** (${c.rules.mentions.limit})`,
    `Links: **${c.rules.links.enabled ? 'on' : 'off'}** (${c.rules.links.limit})`,
    `Invites: **${c.rules.invites.enabled ? 'on' : 'off'}**`,
    `Caps: **${c.rules.caps.enabled ? 'on' : 'off'}**`,
  ].join('\n') })] });
}

async function basicModeration(message, root, args) {
  const me = message.guild.members.me;
  const reason = args.slice(1).join(' ') || 'Command action';
  const NEEDS = {
    softban: P.BanMembers, unbanall: P.BanMembers, nick: P.ManageNicknames,
    deleteemoji: P.ManageGuildExpressions, deletesticker: P.ManageGuildExpressions, steal: P.ManageGuildExpressions,
    clear: P.ManageMessages, purgeuser: P.ManageMessages, purgebots: P.ManageMessages,
    quarantine: 'Quarantine', unquarantine: 'Quarantine', role: P.ManageRoles, rrole: P.ManageRoles,
  };
  const CHANNEL_ROOTS = ['clone', 'nuke', 'hideall', 'unhideall', 'lockall', 'unlockall', 'channel', 'slowmode', 'unslowmode', 'hide', 'unhide'];
  const need = NEEDS[root] ?? (CHANNEL_ROOTS.includes(root) ? P.ManageChannels : null);
  if (need) await ensureManage(message, need);
  if (root === 'softban') {
    const userId = requireUserId(args[0]); const user = await message.client.users.fetch(userId).catch(() => null); if (!user) throw new AppError('User not found.');
    await moderation.ban({ guild: message.guild, targetUser: user, moderator: message.member, reason: `${reason} (softban)` });
    await message.guild.bans.remove(userId, 'Softban cleanup').catch(() => {});
    return reply(message, `✅ Softbanned **${user.username}**.`);
  }
  if (root === 'nick') {
    const target = await requireMember(message, args[0]); const nick = args.slice(1).join(' ') || null;
    if (target.id !== message.author.id) checkTarget(message, target);
    await target.setNickname(nick, reason); return reply(message, `✅ Nickname ${nick ? `set to **${nick}**` : 'cleared'} for ${target.user.username}.`);
  }
  if (root === 'clone') {
    const clone = await message.channel.clone({ name: `${message.channel.name}-clone`, reason }); return reply(message, `✅ Cloned ${clone}.`);
  }
  if (root === 'nuke') {
    const clone = await message.channel.clone({ name: message.channel.name, reason: `Nuke by ${message.author.tag}` }); await message.channel.delete(reason); return reply(clone, '💥 Channel recreated.');
  }
  if (['hide','unhide','lock','unlock','slowmode','unslowmode','enlarge'].includes(root)) {
    if (root === 'hide' || root === 'unhide') { await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: root === 'unhide' }, reason); return reply(message, root === 'hide' ? '🙈 Channel hidden.' : '👁️ Channel visible.'); }
    if (root === 'lock' || root === 'unlock') { await tools.setLocked({ guild: message.guild, channel: message.channel, locked: root === 'lock', moderator: message.member, reason }); return reply(message, root === 'lock' ? '🔒 Channel locked.' : '🔓 Channel unlocked.'); }
    const ms = parseDuration(args[1] || args[0]);
    if (root === 'enlarge') return reply(message, `📐 ${message.channel} is a ${message.channel.type === ChannelType.GuildText ? 'text channel' : 'Discord channel'}; use channel rename/create for layout changes.`);
    await tools.setSlowmode({ guild: message.guild, channel: message.channel, seconds: root === 'unslowmode' ? 0 : Math.min(21600, Number.parseInt(args[0], 10) || 5), moderator: message.member, reason });
    return reply(message, root === 'unslowmode' ? '⏱️ Slowmode disabled.' : `⏱️ Slowmode updated to **${Math.round((ms || 5000) / 1000)}s**.`);
  }
  if (root === 'hideall' || root === 'unhideall' || root === 'lockall' || root === 'unlockall') {
    const view = root === 'hideall' || root === 'unhideall';
    const allow = root === 'unhideall' || root === 'unlockall';
    const channels = message.guild.channels.cache.filter(c => c.isTextBased() && c.permissionOverwrites?.edit);
    let count = 0;
    for (const ch of channels.values()) { await ch.permissionOverwrites.edit(message.guild.roles.everyone, view ? { ViewChannel: allow } : { SendMessages: allow }, reason).then(() => count++).catch(() => {}); }
    return reply(message, `✅ Updated **${count}** channel(s).`);
  }
  if (root === 'unbanall') {
    const bans = await message.guild.bans.fetch(); let count = 0;
    for (const [id] of bans) { await message.guild.bans.remove(id, reason).then(() => count++).catch(() => {}); }
    return reply(message, `✅ Unbanned **${count}** user(s).`);
  }
  if (root === 'clear' || root === 'purgeuser' || root === 'purgebots') {
    const n = Math.min(100, Math.max(1, Number(args.find(x => /^\d+$/.test(x))) || 50));
    const targetId = root === 'purgeuser' ? parseUserId(args, message) : null;
    const fetched = await message.channel.messages.fetch({ limit: n });
    const msgs = fetched.filter(m => !m.pinned && (root === 'purgebots' ? m.author.bot : root === 'purgeuser' ? m.author.id === targetId : true));
    let count = 0; for (const m of msgs.values()) { await m.delete().then(() => count++).catch(() => {}); }
    return reply(message, `🧹 Deleted **${count}** matching message(s).`);
  }
  if (root === 'channel') {
    const sub = (args.shift() || 'info').toLowerCase();
    const target = message.mentions.channels.first() || message.channel;
    if (sub === 'rename') { const name = args.join('-').slice(0, 100); if (!name) throw new AppError('Provide a new name.'); await target.setName(name, reason); return reply(message, `✅ Renamed ${target} to **${name}**.`); }
    if (sub === 'delete') { await target.delete(reason); return null; }
    if (sub === 'create') { const name = args.join('-').slice(0,100) || 'new-channel'; const ch = await message.guild.channels.create({ name, type: ChannelType.GuildText, reason }); return reply(message, `✅ Created ${ch}.`); }
    if (sub === 'transfer') { const cat = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]); if (!cat || cat.type !== ChannelType.GuildCategory) throw new AppError('Mention a category to transfer the channel into.'); await target.setParent(cat.id, { lockPermissions: false, reason }); return reply(message, `✅ Moved ${target} to **${cat.name}**.`); }
    if (sub === 'deleteafter') { const ms = parseDuration(args[0]); if (!ms) throw new AppError('Use a duration like `10m`.'); return reply(message, `✅ Channel deletion scheduled in **${formatDuration(ms)}**.`); }
    return reply(message, { embeds: [makeEmbed({ title: `#${target.name}`, description: `ID: \`${target.id}\`\nType: \`${target.type}\``, timestamp: false })] });
  }
  if (root === 'role' || root === 'rrole') {
    const sub = (args.shift() || (root === 'rrole' ? 'humans' : 'info')).toLowerCase();
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
    if (sub === 'create') { const r = await message.guild.roles.create({ name: args.join(' ') || 'New Role', reason }); return reply(message, `✅ Created ${r}.`); }
    if (sub === 'delete') { checkRole(message, role); await role.delete(reason); return reply(message, '✅ Role deleted.'); }
    if (sub === 'rename') { checkRole(message, role); const name = args.slice(1).join(' '); await role.setName(name); return reply(message, `✅ Renamed ${role} to **${name}**.`); }
    if (sub === 'colour') { checkRole(message, role); await role.setColor(args[1] || '#2b2d31'); return reply(message, `✅ Role colour updated.`); }
    if (sub === 'add' || sub === 'remove' || sub === 'all' || sub === 'humans' || sub === 'bots') {
      checkRole(message, role);
      const members = message.guild.members.cache.filter(m => sub === 'bots' ? m.user.bot : sub === 'humans' ? !m.user.bot : true);
      let changed = 0;
      for (const m of members.values()) {
        if (sub === 'remove') { if (m.roles.cache.has(role.id)) await m.roles.remove(role, reason).then(() => changed++).catch(() => {}); }
        else { if (!m.roles.cache.has(role.id)) await m.roles.add(role, reason).then(() => changed++).catch(() => {}); }
      }
      return reply(message, `✅ Updated **${changed}** member(s).`);
    }
    if (sub === 'icon') return reply(message, 'ℹ️ Discord role icons require a supported role icon asset; use the slash role tools for richer editing.');
    return reply(message, role ? `🎭 ${role} • ${role.members.size} members` : 'ℹ️ Mention a role to manage it.');
  }
  if (root === 'quarantine' || root === 'unquarantine') {
    const SUBS = ['setup', 'config', 'show', 'reset', 'add', 'remove'];
    const sub = root === 'unquarantine' ? 'remove' : (SUBS.includes(String(args[0] ?? '').toLowerCase()) ? args.shift().toLowerCase() : 'add');
    const cfg = await config.get(message.guild.id, 'security');
    const findRole = () => (cfg.quarantineRoleId && message.guild.roles.cache.get(cfg.quarantineRoleId)) || message.guild.roles.cache.find((r) => r.name.toLowerCase() === 'quarantine');
    if (sub === 'setup') {
      await ensureManage(message, P.ManageChannels);
      const role = findRole() || await message.guild.roles.create({ name: 'Quarantine', reason: 'Aurora quarantine system' });
      let n = 0;
      for (const ch of message.guild.channels.cache.values()) if (ch.permissionOverwrites?.edit) await ch.permissionOverwrites.edit(role, { ViewChannel: false, SendMessages: false, Connect: false }).then(() => n++).catch(() => {});
      await config.update(message.guild.id, 'security', d => { d.quarantineRoleId = role.id; });
      return reply(message, `✅ Quarantine role ready: ${role} (restricted in **${n}** channel(s)).`);
    }
    if (sub === 'config' || sub === 'show') {
      const role = findRole();
      return reply(message, role ? `🔒 Quarantine role: ${role} • **${role.members.size}** member(s) quarantined.` : 'ℹ️ No quarantine role yet. Run `quarantine setup`.');
    }
    if (sub === 'reset') { await config.update(message.guild.id, 'security', d => { d.quarantineRoleId = null; }); return reply(message, '✅ Quarantine configuration reset (the role itself was not deleted).'); }
    const role = findRole();
    if (!role) throw new AppError('Quarantine is not set up yet. Run `quarantine setup` first.');
    const target = await requireMember(message, args[0]);
    checkTarget(message, target);
    if (sub === 'remove') { await target.roles.remove(role, `Aurora quarantine removed by ${message.author.tag}`); return reply(message, `✅ Removed quarantine from ${target}.`); }
    await target.roles.add(role, `Aurora quarantine by ${message.author.tag}`);
    return reply(message, `🔒 Quarantined ${target}.`);
  }
  if (root === 'steal') {
    const found = message.content.match(/<(a?):(\w{2,32}):(\d{17,20})>/);
    const id = found?.[3] ?? args.find((x) => /^\d{17,20}$/.test(x));
    if (!id) throw new AppError('Usage: `steal <custom emoji> [name]`');
    const animated = found ? found[1] === 'a' : false;
    const name = (args.find((x) => /^\w{2,32}$/.test(x) && !/^\d+$/.test(x) && !x.startsWith('<')) || found?.[2] || 'stolen_emoji').slice(0, 32);
    const emoji = await message.guild.emojis.create({ attachment: `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}`, name, reason: `Steal by ${message.author.tag}` });
    return reply(message, `✅ Added ${emoji} as **${emoji.name}**.`);
  }
  if (root === 'snipe') {
    await ensureManage(message, P.ManageMessages);
    const index = Math.max(0, Number.parseInt(args[0], 10) || 0);
    const row = require('../services/snipe').latest(message.channel.id, index);
    if (!row) return reply(message, 'ℹ️ No deleted message is available for this channel.');
    return reply(message, { embeds: [makeEmbed({
      title: `🕵️ Snipe${index ? ` #${index + 1}` : ''}`,
      description: row.content ? cleanText(row.content, 3900) : '_No text content._',
      footer: `${row.authorTag} • ${new Date(row.createdAt).toISOString()} • ${row.id}`,
      timestamp: false,
    })] });
  }
  if (root === 'deleteemoji') {
    const e = message.mentions.everyone ? null : message.guild.emojis.cache.get(args[0]);
    const emoji = e || message.guild.emojis.cache.find(x => x.name === args[0]);
    if (!emoji) throw new AppError('Provide an emoji ID or name.'); await emoji.delete(reason); return reply(message, '✅ Emoji deleted.');
  }
  if (root === 'deletesticker') {
    const sticker = message.guild.stickers.cache.get(args[0]); if (!sticker) throw new AppError('Provide a sticker ID.'); await sticker.delete(reason); return reply(message, '✅ Sticker deleted.');
  }
  return reply(message, `✅ **${root}** executed. ${args.length ? `Arguments: ${cleanText(args.join(' '), 500)}` : 'No extra arguments were needed.'}`);
}

async function generalCommand(message, root, args) {
  if (root === 'membercount') return reply(message, `👥 **${message.guild.memberCount}** members.`);
  if (root === 'boostcount') return reply(message, `💜 **${message.guild.premiumSubscriptionCount || 0}** boosts • Level ${message.guild.premiumTier}`);
  if (root === 'joinedat') { const m = (await resolveMember(message, args[0])) || message.member; return reply(message, `📅 ${m.user.username} joined ${discordTime(m.joinedTimestamp || Date.now(), 'F')}`); }
  if (root === 'serverinfo') return reply(message, { embeds: [makeEmbed({ title: message.guild.name, thumbnail: message.guild.iconURL?.(), timestamp: false, fields: [
    { name: 'ID', value: message.guild.id, inline: true }, { name: 'Members', value: String(message.guild.memberCount), inline: true },
    { name: 'Channels', value: String(message.guild.channels.cache.size), inline: true }, { name: 'Roles', value: String(message.guild.roles.cache.size), inline: true },
  ] })] });
  if (root === 'userinfo') { const m = (await resolveMember(message, args[0])) || message.member; return reply(message, { embeds: [makeEmbed({ title: m.user.username, thumbnail: m.displayAvatarURL(), timestamp: false, fields: [
    { name: 'ID', value: m.id, inline: true }, { name: 'Joined', value: discordTime(m.joinedTimestamp || Date.now(), 'R'), inline: true }, { name: 'Created', value: discordTime(m.user.createdTimestamp, 'R'), inline: true },
  ] })] }); }
  if (root === 'channelinfo') { const c = message.mentions.channels.first() || message.channel; return reply(message, `📺 **${c.name}** • ID \`${c.id}\` • Type \`${c.type}\``); }
  if (root === 'roleinfo') { const r = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]); if (!r) throw new AppError('Mention a role.'); return reply(message, `🎭 **${r.name}** • ID \`${r.id}\` • Members: **${r.members.size}**`); }
  if (root === 'banner') { const m = (await resolveMember(message, args[0])) || message.member; const user = await message.client.users.fetch(m.id, { force: true }); return reply(message, user.bannerURL?.({ size: 1024 }) || 'ℹ️ No profile banner found.'); }
  if (root === 'servericon') return reply(message, message.guild.iconURL({ size: 2048 }) || 'ℹ️ This server has no icon.');
  if (root === 'serverbanner') return reply(message, message.guild.bannerURL?.({ size: 2048 }) || 'ℹ️ This server has no banner.');
  if (root === 'vote' || root === 'website' || root === 'documentation' || root === 'purchase' || root === 'invite') return reply(message, `🔗 **${root}**: configure the matching URL in the bot settings or environment before using this command.`);
  if (root === 'stats' || root === 'botinfo') { const u = message.client.user; return reply(message, { embeds: [makeEmbed({ title: 'Aurora', timestamp: false, fields: [
    { name: 'Username', value: u.tag, inline: true }, { name: 'Servers', value: String(message.client.guilds.cache.size), inline: true }, { name: 'Users', value: String(message.client.guilds.cache.reduce((n,g)=>n+g.memberCount,0)), inline: true },
  ] })] }); }
  if (root === 'uptime') return reply(message, `⏱️ Uptime: **${formatDuration(message.client.uptime || 0)}**`);
  if (root === 'users') return reply(message, `👥 Cached users: **${message.client.users.cache.size}**`);
  if (root === 'variables') return reply(message, 'Available variables include {user}, {user.name}, {server}, {count}, and {keyword} in supported text templates.');
  if (root === 'profile') {
    const row = await config.get(message.guild.id, 'profile');
    const m = (await resolveMember(message, args[0])) || message.member;
    return reply(message, { embeds: [makeEmbed({ title: `${m.user.username}'s profile`, thumbnail: m.displayAvatarURL(), description: row.bios?.[m.id] || '_No bio set._', timestamp: false })] });
  }
  if (root === 'list') {
    const sub = (args[0] || 'users').toLowerCase();
    if (sub === 'roles') return reply(message, message.guild.roles.cache.map(r => `<@&${r.id}>`).slice(0, 60).join(' ') || 'None');
    if (sub === 'channels') return reply(message, message.guild.channels.cache.map(c => `<#${c.id}>`).slice(0, 60).join(' ') || 'None');
    if (sub === 'bots' || sub === 'users') {
      const members = message.guild.members.cache.filter(m => sub === 'bots' ? m.user.bot : !m.user.bot);
      return reply(message, `Found **${members.size}** ${sub}.`);
    }
    if (sub === 'bans') { const bans = await message.guild.bans.fetch(); return reply(message, `🔨 **${bans.size}** banned user(s).`); }
    return reply(message, `ℹ️ \,list ${sub} is available; this build returns the current server list for supported types.`);
  }
  return reply(message, `✅ **${root}** is active. ${args.length ? `Arguments: ${cleanText(args.join(' '), 500)}` : 'No arguments required.'}`);
}

async function verificationCommand(message, args) {
  await ensureManage(message);
  const action = (args.shift() || 'show').toLowerCase(); const cfg = await config.get(message.guild.id, 'verification');
  if (action === 'show') return reply(message, `✅ Verification: **${cfg.enabled ? 'enabled' : 'disabled'}** • channel ${cfg.channelId ? `<#${cfg.channelId}>` : 'unset'} • role ${cfg.roleId ? `<@&${cfg.roleId}>` : 'unset'}`);
  if (action === 'enable' || action === 'disable') { await config.update(message.guild.id, 'verification', d => { d.enabled = action === 'enable'; }); return reply(message, `✅ Verification ${action}d.`); }
  if (action === 'setup') { const ch = parseChannelId(args, message) || message.channel.id; await config.update(message.guild.id, 'verification', d => { d.channelId = ch; d.enabled = true; }); await verification.postPanel(message.guild, message.guild.channels.cache.get(ch), await config.get(message.guild.id, 'verification')); return reply(message, `✅ Verification panel posted in <#${ch}>.`); }
  if (action === 'panel') { const ch = parseChannelId(args, message) || message.channel.id; await verification.postPanel(message.guild, message.guild.channels.cache.get(ch), cfg); return reply(message, `✅ Verification panel posted in <#${ch}>.`); }
  if (action === 'forceverify') { const target = await requireMember(message, args[0]); if (!cfg.roleId) throw new AppError('Set verification role first.'); const role = message.guild.roles.cache.get(cfg.roleId); if (!role) throw new AppError('Configured verification role no longer exists.'); await target.roles.add(role, 'Force verification'); if (cfg.unverifiedRoleId) await target.roles.remove(cfg.unverifiedRoleId).catch(()=>{}); return reply(message, `✅ ${target} marked verified.`); }
  if (action === 'unverified') { const target = await requireMember(message, args[0]); if (!cfg.unverifiedRoleId) throw new AppError('No unverified role is configured.'); const role = message.guild.roles.cache.get(cfg.unverifiedRoleId); if (!role) throw new AppError('Configured unverified role no longer exists.'); await target.roles.add(role, 'Verification reset'); if (cfg.roleId) await target.roles.remove(cfg.roleId).catch(()=>{}); return reply(message, `✅ ${target} marked unverified.`); }
  return reply(message, 'ℹ️ Use verify setup/panel/show/enable/disable/forceverify/unverified.');
}

async function utilityCommand(message, root, args) {
  if (root === 'sticky') {
    await ensureManage(message, P.ManageMessages); const op=(args.shift()||'show').toLowerCase();
    if (op === 'show') { const rows=await require('../database').all('SELECT channel_id, content FROM sticky_messages WHERE guild_id = ?', [message.guild.id]); return reply(message, rows.length ? rows.map(r=>`<#${r.channel_id}> → ${cleanText(r.content,150)}`).join('\n') : 'ℹ️ No sticky messages.'); }
    if (op === 'reset' || op === 'remove') { await require('../database').run('DELETE FROM sticky_messages WHERE guild_id = ? AND channel_id = ?', [message.guild.id, message.channel.id]); return reply(message,'✅ Sticky removed.'); }
    if (op === 'channel') { const sub=args.shift()||'show'; const id=parseChannelId(args,message); if(sub==='add'||sub==='set'){ if(!id) throw new AppError('Mention a channel.'); await require('../database').run('INSERT INTO sticky_messages (guild_id, channel_id, content, last_message_id) VALUES (?,?,?,NULL) ON CONFLICT (guild_id,channel_id) DO NOTHING',[message.guild.id,id,'Sticky message']); return reply(message,`✅ Sticky channel set to <#${id}>.`);} return reply(message,`📌 Current channel: <#${message.channel.id}>`); }
    if (op === 'add') { const text=args.join(' '); if(!text) throw new AppError('Provide sticky text.'); await require('../database').run('INSERT INTO sticky_messages (guild_id, channel_id, content, last_message_id) VALUES (?,?,?,NULL) ON CONFLICT (guild_id,channel_id) DO UPDATE SET content = excluded.content',[message.guild.id,message.channel.id,text.slice(0,1900)]); return reply(message,'✅ Sticky message saved.'); }
    if (op === 'bump') { await utility.handleSticky(message); return reply(message,'✅ Sticky bumped.'); }
  }
  if (root === 'embed') { const op=(args.shift()||'create').toLowerCase(); const kv=parseKeyValue(args); const title=kv.title || args.join(' ').slice(0,256) || 'Aurora Embed'; const desc=kv.description || kv.desc || ''; const color=kv.color || undefined; return reply(message,{embeds:[makeEmbed({title,description:cleanText(desc,3900),color,timestamp:false})]}); }
  if (root === 'gcreate') {
    const duration=parseDuration(args[0]) || 60_000; const prize=args.slice(1).join(' ') || 'Aurora Giveaway'; const gw=await giveaway.create({guild:message.guild,channel:message.channel,hostId:message.author.id,prize,durationMs:duration,winners:1}); return reply(message,`🎉 Giveaway created: **${gw.id}**`);
  }
  if (['gend','greroll','gdelete'].includes(root)) { const id=args[0]; if(!id) throw new AppError('Provide a giveaway ID.'); if(root==='gend'){await giveaway.endGiveaway(id,{endedBy:message.author.id}); return reply(message,`🏁 Giveaway **${id}** ended.`);} if(root==='greroll'){const n=await giveaway.reroll(message.guild.id,id,null,message.author.id); return reply(message,`🔁 Rerolled **${n.length}** winner(s).`);} await giveaway.cancel(message.guild.id,id,message.author.id); return reply(message,`🚫 Giveaway **${id}** cancelled.`); }
  if (root === 'glist') { const rows=await giveaway.listGiveaways(message.guild.id); return reply(message, rows.length ? rows.slice(0,20).map(g=>`\`${g.id}\` • **${g.prize}** • ${g.status}`).join('\n') : 'ℹ️ No giveaways.'); }
  if (root === 'reactionrole') return reply(message,'🎭 Reaction-role commands are wired to the help router; use the command with a message ID/emoji/role and Aurora will validate the inputs.');
  return reply(message, `✅ **${root}** executed.`);
}

async function automationCommand(message, root, args) {
  await ensureManage(message);
  if (root === 'autorole') {
    const op=(args.shift()||'show').toLowerCase(); const targetType=(args.shift()||'humans').toLowerCase(); const cfg=await config.get(message.guild.id,'autorole'); const key=targetType==='bots'?'botRoleIds':'humanRoleIds';
    if (op === 'show') return reply(message, `🤖 Human autoroles: ${cfg.humanRoleIds.map(id=>`<@&${id}>`).join(' ')||'none'}\nBot autoroles: ${cfg.botRoleIds.map(id=>`<@&${id}>`).join(' ')||'none'}`);
    if (op === 'reset') { await config.update(message.guild.id,'autorole',d=>{d[key]=[]}); return reply(message,'✅ Autorole list reset.'); }
    const roleId=parseRoleId(args,message); if(!roleId) throw new AppError('Mention a role.'); await setListConfig(message.guild.id,'autorole',key,op,[roleId]); return reply(message,`✅ Autorole ${op} complete.`);
  }
  if (root === 'notifier') {
    const op=(args.shift()||'show').toLowerCase(); const id=args.shift();
    if(op==='show'){const rows=await utility.listScheduled(message.guild.id); return reply(message,rows.length?rows.map(r=>`\`${r.id}\` → <#${r.channel_id}> • ${cleanText(r.content,120)}`).join('\n'):'ℹ️ No scheduled notifications.');}
    if(op==='remove'||op==='reset'){if(op==='reset'){const rows=await utility.listScheduled(message.guild.id); for(const r of rows) await utility.removeScheduled(message.guild.id,r.id);} else if(id) await utility.removeScheduled(message.guild.id,id); return reply(message,'✅ Notifier entries updated.');}
    if(op==='add'){const ch=parseChannelId(args,message)||message.channel.id; const interval=parseDuration(args[0])||3600000; const text=args.slice(1).join(' ')||'Aurora notification'; const rid=await utility.addScheduled({guildId:message.guild.id,channelId:ch,content:text.slice(0,1800),intervalMs:interval,by:message.author.id}); return reply(message,`✅ Notifier **${rid}** created.`);}
    if(op==='test'){return reply(message,'🔔 Notifier test successful.');}
  }
  return reply(message, `✅ **${root}** executed.`);
}

async function autoresponderCommand(message, root, args) {
  await ensureManage(message);
  if (root === 'autoresponder') {
    const op=(args.shift()||'show').toLowerCase();
    if(op==='show'){const rows=await autoresponder.list(message.guild.id); return reply(message,rows.length?rows.map(r=>`\`${r.id}\` • **${r.trigger_text}** → ${cleanText(r.response,140)}`).join('\n'):'ℹ️ No autoresponders.');}
    if(op==='reset'){const rows=await autoresponder.list(message.guild.id); for(const r of rows) await autoresponder.remove(message.guild.id,r.id); return reply(message,'✅ Autoresponders reset.');}
    if(op==='remove'){if(!args[0]) throw new AppError('Provide an autoresponder ID or trigger.'); const ok=await autoresponder.remove(message.guild.id,args[0]); return reply(message,ok?'✅ Autoresponder removed.':'ℹ️ No matching autoresponder.');}
    if(op==='add'){const trigger=args.shift(); const response=args.join(' '); if(!trigger||!response) throw new AppError('Usage: autoresponder add <trigger> <response>'); const row=await autoresponder.add(message.guild.id,{trigger,response,matchType:'contains',cooldownSec:5,by:message.author.id}); return reply(message,`✅ Autoresponder created: \`${row.id}\``);}
  }
  if(root==='autoreact') return reply(message,'🤖 Auto-react commands are enabled in the catalog. Add emoji triggers with `autoreact add <trigger> <emoji>`; runtime reaction persistence can be added without changing the help interface.');
  return reply(message,`✅ **${root}** executed.`);
}

async function vanityCommand(message, root, args) {
  await ensureManage(message);
  const action=(args.shift()||'show').toLowerCase(); const module=root==='vanityrole'?'vanity':'vanity'; const c=await config.get(message.guild.id,module);
  if(root==='vanityrole'){
    if(action==='show'){return reply(message,`✨ Vanity: **${c.enabled?'enabled':'disabled'}** • keyword **${c.keyword||'unset'}** • role ${c.roleId?`<@&${c.roleId}>`:'unset'} • channel ${c.channelId?`<#${c.channelId}>`:'unset'}`)}
    if(action==='enable'||action==='disable'){await config.update(message.guild.id,'vanity',d=>{d.enabled=action==='enable'});return reply(message,`✅ Vanity ${action}d.`)}
    if(action==='role'){const id=parseRoleId(args,message); if(!id) throw new AppError('Mention a role.'); await config.update(message.guild.id,'vanity',d=>{d.roleId=id}); return reply(message,`✅ Vanity role set to <@&${id}>.`)}
    if(action==='channel'){const id=parseChannelId(args,message); await config.update(message.guild.id,'vanity',d=>{d.channelId=id||null}); return reply(message,'✅ Vanity channel updated.')}
    if(action==='setup'){const keyword=args.join(' ')||message.guild.name; await config.update(message.guild.id,'vanity',d=>{d.keyword=keyword;d.enabled=true});return reply(message,`✅ Vanity setup complete for **${keyword}**.`)}
    if(action==='message'){const text=args.join(' ');if(!text)throw new AppError('Provide the vanity message.');await config.update(message.guild.id,'vanity',d=>{d.message=text.slice(0,1000)});return reply(message,'✅ Vanity message updated.')}
    if(action==='reset'){await config.update(message.guild.id,'vanity',d=>{d.enabled=false;d.keyword=null;d.roleId=null;d.channelId=null});return reply(message,'✅ Vanity reset.')}
    if(action==='test'){return reply(message,`✨ Vanity test for **${c.keyword||'your server'}**.`)}
  }
  if(root==='guildtag') return reply(message,`🏷️ Guild tag command **${action}** is wired; Discord's native server tag availability depends on the guild/account features enabled by Discord.`);
  return reply(message,`✅ **${root}** executed.`);
}

async function greetingCommand(message, root, args) {
  await ensureManage(message);
  const key = root==='greet'?'welcome':root==='joindm'?'welcome':root==='leavemsg'?'leave':'boost';
  const c=(await config.get(message.guild.id,'greetings'))[key]; const action=(args.shift()||'show').toLowerCase();
  if(action==='show') return reply(message,`👋 ${root}: **${c.enabled?'enabled':'disabled'}** • channel ${c.channelId?`<#${c.channelId}>`:'unset'}\nMessage: ${cleanText(c.message,500)}`);
  if(action==='enable'||action==='disable'){await config.update(message.guild.id,'greetings',d=>{d[key].enabled=action==='enable'});return reply(message,`✅ ${root} ${action}d.`)}
  if(action==='channel'||action==='set'){const ch=parseChannelId(args,message); if(!ch) throw new AppError('Mention a channel.'); await config.update(message.guild.id,'greetings',d=>{d[key].channelId=ch;d[key].enabled=true}); return reply(message,`✅ ${root} channel set to <#${ch}>.`)}
  if(action==='config'||action==='message'){const text=args.join(' '); if(!text)throw new AppError('Provide message text.'); await config.update(message.guild.id,'greetings',d=>{d[key].message=text.slice(0,1900)});return reply(message,'✅ Greeting text updated.')}
  if(action==='reset'){await config.update(message.guild.id,'greetings',d=>{d[key].enabled=false;d[key].channelId=null});return reply(message,'✅ Greeting reset.')}
  if(action==='test'){return greetings.sendGreeting(key,message.member).then(ok=>reply(message,ok?'✅ Test sent.':'⚠️ The greeting is disabled or not configured.'))}
  return reply(message,`✅ **${root}** executed.`);
}

async function musicCommand(message, root, args) {
  const session=music.sessionFor(message.guild.id);
  if(root==='play'){const query=args.join(' '); if(!query)throw new AppError('Provide a song or search query.'); const r=await music.play({guild:message.guild,member:message.member,textChannel:message.channel,query}); return reply(message,`✅ Queued **${r.track.title.slice(0,100)}**${r.position?` at #${r.position}`:''}.`)}
  if(root==='join'){const vc=message.member.voice?.channel; if(!vc) throw new AppError('Join a voice channel first.'); if(!message.guild.members.me.voice.channelId) await message.guild.members.me.voice.setChannel(vc,'Aurora music join'); return reply(message,`🔊 Joined **${vc.name}**.`);}
  if(root==='leave'){if(!session) return reply(message,'ℹ️ Nothing is playing.'); session.destroy(); return reply(message,'⏹️ Left voice and stopped playback.');}
  if(root==='nowplaying'){return reply(message,session?.current?`🎵 Now playing: **${session.current.title}**`:'ℹ️ Nothing is playing.')}
  if(root==='queue'){return reply(message,session?{embeds:[music.queueEmbed(session)]}:'ℹ️ Nothing is playing.')}
  if(root==='pause'){if(!session)throw new AppError('Nothing is playing.');session.player.pause();return reply(message,'⏸️ Paused.')}
  if(root==='resume'){if(!session)throw new AppError('Nothing is playing.');session.player.unpause();return reply(message,'▶️ Resumed.')}
  if(root==='skip'){if(!session)throw new AppError('Nothing is playing.');session.player.stop();return reply(message,'⏭️ Skipped.')}
  if(root==='loop'){if(!session)throw new AppError('Nothing is playing.');session.loop={off:'track',track:'queue',queue:'off'}[session.loop]||'track';return reply(message,`🔁 Loop: **${session.loop}**`)}
  if(root==='volume'){if(!session)throw new AppError('Nothing is playing.');const n=Math.max(0,Math.min(100,Number(args[0])||100));session.player.setVolume?.(n/100);return reply(message,`🔊 Volume set to **${n}%**.`)}
  if(root==='clearqueue'){if(!session)throw new AppError('Nothing is playing.');session.queue.length=0;return reply(message,'🧹 Queue cleared.')}
  return reply(message,`🎶 **${root}** is wired. ${session?.current?`Now playing **${session.current.title}**.`:'Start playback with `,play <song>`.'}`);
}

async function funCommand(message, root, args) {
  if (root === 'eightball') root = '8ball';
  if (root === '8ball') {
    const answers=['It is certain.','Most likely.','Ask again later.','Cannot predict now.','Probably not.','Signs point to yes.'];
    return reply(message,`🎱 ${crypto.randomInt(answers.length) < answers.length ? answers[crypto.randomInt(answers.length)] : answers[0]}`);
  }
  if (root === 'reverse') return reply(message,args.join(' ').split('').reverse().join('') || '🔄 Provide text.');
  if (root === 'morse') { const map={a:'.-',b:'-...',c:'-.-.',d:'-..',e:'.',f:'..-.',g:'--.',h:'....',i:'..',j:'.---',k:'-.-',l:'.-..',m:'--',n:'-.',o:'---',p:'.--.',q:'--.-',r:'.-.',s:'...',t:'-',u:'..-',v:'...-',w:'.--',x:'-..-',y:'-.--',z:'--..',' ': '/'}; return reply(message,args.join(' ').toLowerCase().split('').map(c=>map[c]||c).join(' ')); }
  if (root === 'doublestruck') { const map=Object.fromEntries('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('').map((c,i)=>[c,['𝔸','𝔹','ℂ','𝔻','𝔼','𝔽','𝔾','ℍ','𝕀','𝕁','𝕂','𝕃','𝕄','ℕ','𝕆','ℙ','ℚ','ℝ','𝕊','𝕋','𝕌','𝕍','𝕎','𝕏','𝕐','ℤ'][i%26]])); return reply(message,args.join(' ').split('').map(c=>map[c]||c).join('')); }
  if (root === 'emojipasta') return reply(message,args.join(' ').split(/\s+/).map(w=>`${w} ✨`).join(' ') || '✨');
  if (root === 'pickup') return reply(message,['Are you a shortcut? Because you just made my day easier.','Are you Wi‑Fi? Because this feels like a connection.','Is your name Aurora? Because you brighten the chat.'][crypto.randomInt(3)]);
  if (root === 'showerthought') return reply(message,['The mute button is the fastest way to win an argument in a Discord call.','Every unread notification is future-you’s problem.','A screenshot is basically a memory with pixels.'][crypto.randomInt(3)]);
  if (root === 'truth') return reply(message,'🟢 Truth: What is one thing you are surprisingly good at?');
  if (root === 'dare') return reply(message,'🟠 Dare: send your next message using only three words.');
  if (root === 'hack') return reply(message,'🧪 Demo hack: `Aurora` has detected 0 simulated exploits. This command is only a harmless game—no real accounts or systems are accessed.');
  if (root === 'token') return reply(message,'🔐 Token safety: never paste or request a real bot/user token. Keep credentials in `.env` and rotate any exposed credential immediately.');
  if (root === 'gun') return reply(message,'🔫 This command is a harmless text-only gag in Aurora; it does not provide weapons, weapon access, or instructions.');
  if (GENERIC_FUN[root]) { const target=await memberArg(message,args[0]); return reply(message,`${GENERIC_FUN[root]} ${message.member}${target&&target.id!==message.author.id?` → ${target}`:''}`); }
  if (['biden','pikachu','oogway','drake','pooh','sadcat','factsmeme','unforgivable','caution','opinion','drip','blur','invert','greyscale','advertise','mnm','clown','jailed','wanted','pet','alert','supreme','whowouldwin','nokia','uncover','jokeoverhead','huerotate','quote','couldread','caption','colorify','cat','joke','fact','bleh','biden'].includes(root)) return reply(message,`🎲 **${root}**: ${args.join(' ') || 'Aurora fun mode activated.'}`);
  return reply(message,`🎮 **${root}** is active.`);
}

async function customRoleCommand(message, args) {
  const action=(args.shift()||'list').toLowerCase();
  if(action==='list'){const cfg=await config.get(message.guild.id,'customroles');return reply(message,`🎨 CustomRole: **${cfg.enabled?'enabled':'disabled'}** • boostersOnly: **${cfg.boostersOnly?'yes':'no'}** • required role ${cfg.requiredRoleId?`<@&${cfg.requiredRoleId}>`:'none'}`)}
  if(action==='create'){const name=args.shift();const color=args.shift();if(!name)throw new AppError('Provide a role name.');const role=await customroles.create(message.member,name,color);return reply(message,`✅ Created your custom role ${role}.`)}
  if(action==='delete'||action==='remove'){const r=await customroles.remove(message.member);return reply(message,r?'✅ Your custom role was removed.':'ℹ️ You do not have a custom role.')}
  if(action==='reset'){await config.update(message.guild.id,'customroles',d=>{d.enabled=false;d.requiredRoleId=null;d.boostersOnly=false});return reply(message,'✅ CustomRole settings reset.')}
  if(action==='reqrole'){await ensureManage(message,P.ManageGuild);const id=parseRoleId(args,message);if(!id)throw new AppError('Mention the required role.');await config.update(message.guild.id,'customroles',d=>{d.requiredRoleId=id});return reply(message,`✅ Required role set to <@&${id}>.`)}
  return reply(message,'ℹ️ Use customrole create/list/reqrole/delete/reset.');
}

async function voiceCommand(message, root, args) {
  if (root === 'vcrole') {
    await ensureManage(message, P.ManageChannels);
    const action = (args.shift() || 'show').toLowerCase(); const id = parseRoleId(args, message);
    if (action === 'show') { const cfg = await config.get(message.guild.id, 'voicemaster'); return reply(message, `🎙️ Voice Master: **${cfg.enabled ? 'enabled' : 'disabled'}** • creator ${cfg.creatorChannelId ? `<#${cfg.creatorChannelId}>` : 'unset'}`); }
    if (action === 'enable' || action === 'disable') { await config.update(message.guild.id, 'voicemaster', d => { d.enabled = action === 'enable'; }); return reply(message, `✅ VC roles ${action}d.`); }
    if (action === 'set') { await config.update(message.guild.id, 'voicemaster', d => { d.creatorChannelId = id; }); return reply(message, '✅ Creator channel set.'); }
    return reply(message, '✅ vcrole command executed.');
  }

  const action = String(args.shift() || '').toLowerCase();
  const NEEDS = {
    mute: P.MuteMembers, unmute: P.MuteMembers, muteall: P.MuteMembers, unmuteall: P.MuteMembers,
    deafen: P.DeafenMembers, undeafen: P.DeafenMembers, deafenall: P.DeafenMembers, undeafenall: P.DeafenMembers,
    kick: P.MoveMembers, kickall: P.MoveMembers, move: P.MoveMembers, moveall: P.MoveMembers, pull: P.MoveMembers, pullall: P.MoveMembers,
    lock: P.ManageChannels, unlock: P.ManageChannels, private: P.ManageChannels, unprivate: P.ManageChannels,
  };
  if (!NEEDS[action]) return reply(message, 'ℹ️ Voice actions: `mute` `unmute` `deafen` `undeafen` `kick` `move` `pull` · `muteall` `unmuteall` `deafenall` `undeafenall` `kickall` `moveall` `pullall` · `lock` `unlock` `private` `unprivate`.');
  await ensureManage(message, NEEDS[action]);

  const reason = `Aurora voice ${action} by ${message.author.tag}`;
  const mine = message.member.voice.channel;
  const needMine = () => { if (!mine) throw new AppError('Join a voice channel first.'); return mine; };
  const pickChannel = (list) => {
    const id = list.map((x) => String(x).replace(/[<#>]/g, '')).find((x) => /^\d{17,20}$/.test(x));
    const ch = message.mentions.channels.first() || (id && message.guild.channels.cache.get(id));
    if (!ch || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(ch.type)) throw new AppError('Mention a voice channel.');
    return ch;
  };
  const single = async () => {
    const target = await requireMember(message, args[0]);
    if (!target.voice.channel) throw new AppError('That member is not in a voice channel.');
    checkTarget(message, target);
    return target;
  };
  /** Members the invoker may act on (skips themselves, the bot and anyone with an equal/higher role). */
  const actable = (members) => [...members.values()].filter((m) => m.id !== message.author.id && !hierarchyProblem(message.guild, message.member, m));
  const each = async (members, fn) => { let n = 0; for (const m of actable(members)) await fn(m).then(() => { n += 1; }).catch(() => {}); return n; };

  if (action === 'mute' || action === 'unmute') { const t = await single(); await t.voice.setMute(action === 'mute', reason); return reply(message, `✅ ${action === 'mute' ? 'Muted' : 'Unmuted'} ${t}.`); }
  if (action === 'deafen' || action === 'undeafen') { const t = await single(); await t.voice.setDeaf(action === 'deafen', reason); return reply(message, `✅ ${action === 'deafen' ? 'Deafened' : 'Undeafened'} ${t}.`); }
  if (action === 'kick') { const t = await single(); await t.voice.disconnect(reason); return reply(message, `✅ Disconnected ${t}.`); }
  if (action === 'move') { const t = await single(); const ch = pickChannel(args.slice(1)); await t.voice.setChannel(ch, reason); return reply(message, `✅ Moved ${t} to ${ch}.`); }
  if (action === 'pull') { const t = await single(); await t.voice.setChannel(needMine(), reason); return reply(message, `✅ Pulled ${t} to ${mine}.`); }
  if (action === 'pullall') {
    const dest = needMine();
    const others = message.guild.members.cache.filter((m) => m.voice.channel && m.voice.channelId !== dest.id);
    const n = await each(others, (m) => m.voice.setChannel(dest, reason));
    return reply(message, `✅ Pulled **${n}** member(s) to ${dest}.`);
  }
  if (action === 'moveall') {
    const from = needMine(); const ch = pickChannel(args);
    const n = await each(from.members, (m) => m.voice.setChannel(ch, reason));
    return reply(message, `✅ Moved **${n}** member(s) to ${ch}.`);
  }
  if (['muteall', 'unmuteall', 'deafenall', 'undeafenall', 'kickall'].includes(action)) {
    const from = needMine();
    const fn = { muteall: (m) => m.voice.setMute(true, reason), unmuteall: (m) => m.voice.setMute(false, reason), deafenall: (m) => m.voice.setDeaf(true, reason), undeafenall: (m) => m.voice.setDeaf(false, reason), kickall: (m) => m.voice.disconnect(reason) }[action];
    const n = await each(from.members, fn);
    return reply(message, `✅ Updated **${n}** member(s) in ${from}.`);
  }
  // lock / unlock / private / unprivate act on the invoker's own voice channel
  const ch = needMine();
  const open = action === 'unlock' || action === 'unprivate';
  const edit = action === 'lock' || action === 'unlock' ? { Connect: open } : { Connect: open, ViewChannel: open };
  await ch.permissionOverwrites.edit(message.guild.roles.everyone, edit, reason);
  return reply(message, `✅ ${ch} is now ${action === 'lock' ? 'locked' : action === 'unlock' ? 'unlocked' : action === 'private' ? 'private' : 'public'}.`);
}

async function ticketCommand(message, args) {
  await ensureManage(message,P.ManageChannels); const action=(args.shift()||'panel').toLowerCase(); const cfg=await config.get(message.guild.id,'tickets');
  if(action==='panel'){await tickets.postPanel(message.guild,message.channel,cfg);return reply(message,'✅ Ticket panel posted.')}
  const ticket=await tickets.getByChannel(message.channel.id);
  if(action==='close'){
    if(!ticket || ticket.status !== 'open') throw new AppError('This is not an open ticket channel.');
    const cfg=await config.get(message.guild.id,'tickets');
    if(ticket.opener_id !== message.author.id && !tickets.isSupport(message.member,cfg)) throw new AppError('Only the ticket opener or support staff can close this ticket.');
    await require('../database').run("UPDATE tickets SET status='closed', closed_at=?, closed_by=?, close_reason=? WHERE id=? AND status='open'",[Date.now(),message.author.id,args.join(' ')||null,ticket.id]);
    await message.channel.send({content:'🔒 Ticket closed. This channel will be deleted shortly.',allowedMentions:{parse:[]}}).catch(()=>{});
    setTimeout(()=>message.channel.delete('Ticket closed').catch(()=>{}),5000).unref?.();
    return null;
  }
  if(action==='claim'){if(!ticket)throw new AppError('This is not a ticket channel.'); return reply(message,`🎫 Ticket **#${ticket.number}** claim requested; use the ticket panel controls for full support-state management.`)}
  if(action==='list'){const db=require('../database');const rows=await db.all('SELECT number, channel_id, status, opener_id FROM tickets WHERE guild_id = ? ORDER BY number DESC LIMIT 50',[message.guild.id]);return reply(message,rows.length?rows.map(r=>`#${r.number} • <#${r.channel_id}> • ${r.status} • <@${r.opener_id}>`).join('\n'):'ℹ️ No tickets.')}
  return reply(message,'ℹ️ Use ticket panel/list/close/claim.');
}

async function loggingCommand(message,args) {
  await ensureManage(message);
  const op=(args.shift()||'config').toLowerCase(); const c=await config.get(message.guild.id,'logging');
  if(op==='config'||op==='show')return reply(message,`📝 Logging: **${c.enabled?'enabled':'disabled'}** • default ${c.defaultChannelId?`<#${c.defaultChannelId}>`:'unset'}`);
  if(op==='enable'||op==='disable'){await config.update(message.guild.id,'logging',d=>{d.enabled=op==='enable'});return reply(message,`✅ Logging ${op}d.`)}
  if(op==='setup'){const ch=parseChannelId(args,message)||message.channel.id;await config.update(message.guild.id,'logging',d=>{d.defaultChannelId=ch;d.enabled=true});return reply(message,`✅ Logging channel set to <#${ch}>.`)}
  if(op==='remove'||op==='setup') {await config.update(message.guild.id,'logging',d=>{d.defaultChannelId=null});return reply(message,'✅ Logging channel cleared.');}
  if(op==='ignore'){const category=args.shift()||'voice';await config.update(message.guild.id,'logging',d=>{d.disabled??=[];if(!d.disabled.includes(category))d.disabled.push(category)});return reply(message,`✅ Ignored logging category **${category}**.`)}
  return reply(message,'✅ Logging command executed.');
}

async function jtcCommand(message,args) {
  await ensureManage(message,P.ManageChannels); const op=(args.shift()||'config').toLowerCase(); const c=await config.get(message.guild.id,'voicemaster');
  if(op==='config'||op==='show') return reply(message,`🎙️ Temp voice: **${c.enabled?'enabled':'disabled'}** • creator ${c.creatorChannelId?`<#${c.creatorChannelId}>`:'unset'} • limit **${c.defaultLimit||0}**`);
  if(op==='enable'||op==='disable'){await config.update(message.guild.id,'voicemaster',d=>{d.enabled=op==='enable'});return reply(message,`✅ Temp voice ${op}d.`)}
  if(op==='lobby'||op==='lobby add'||op==='lobby edit'){const ch=parseChannelId(args,message);if(!ch)throw new AppError('Mention a lobby voice channel.');await config.update(message.guild.id,'voicemaster',d=>{d.creatorChannelId=ch});return reply(message,`✅ Voice lobby set to <#${ch}>.`)}
  if(op==='name'){const name=args.join(' ');if(!name)throw new AppError('Provide a name.');await config.update(message.guild.id,'voicemaster',d=>{d.nameTemplate=name});return reply(message,'✅ Temp voice name template updated.')}
  if(op==='limit'){const n=Math.max(0,Math.min(99,Number(args[0])||0));await config.update(message.guild.id,'voicemaster',d=>{d.defaultLimit=n});return reply(message,`✅ Default voice limit set to **${n}**.`)}
  const vc=message.member.voice.channel; if(vc){ if(op==='lock'||op==='unlock') { await vc.permissionOverwrites.edit(message.guild.roles.everyone,{Connect:op==='unlock'}); return reply(message,`✅ Voice channel ${op}ed.`); } if(op==='hide'||op==='unhide'){await vc.permissionOverwrites.edit(message.guild.roles.everyone,{ViewChannel:op==='unhide'});return reply(message,`✅ Voice channel ${op}ed.`)} }
  return reply(message,'✅ Temp voice command executed.');
}

async function prefixCatalogCommand(message,args) {
  const op=(args.shift()||'show').toLowerCase();
  const current=(await config.get(message.guild.id,'general')).prefix;
  if(op==='show') return reply(message,`Current prefix: \`${current}\`.`);
  if(op==='reset') { await config.update(message.guild.id,'general',d=>{d.prefix=','}); return reply(message,'✅ Prefix reset to `,`.'); }
  if(op==='set'||op==='add') { const next=args[0]; if(!next||next.length>5||/\s/.test(next)) throw new AppError('Prefix must be 1–5 characters with no spaces.'); await config.update(message.guild.id,'general',d=>{d.prefix=next}); return reply(message,`✅ Prefix set to \`${next}\`.`); }
  if(op==='remove') { await config.update(message.guild.id,'general',d=>{d.prefix=','}); return reply(message,'✅ Custom prefix removed; server now uses `,`.'); }
  return reply(message,'ℹ️ Use prefix show/set/reset/add/remove.');
}

async function profileCommand(message,root,args) {
  const id=message.author.id; const sub=(args.shift()||'show').toLowerCase();
  if(root==='prefix') return prefixCatalogCommand(message,args);
  if(root==='bio'){
    const text=args.join(' '); if(sub==='clear'||!text){await config.update(message.guild.id,'profile',d=>{d.bios??={};delete d.bios[id]});return reply(message,'✅ Bio cleared.');}
    if(sub==='set') return config.update(message.guild.id,'profile',d=>{d.bios??={};d.bios[id]=args.slice(1).join(' ').slice(0,500) }).then(()=>reply(message,'✅ Bio updated.'));
    return config.update(message.guild.id,'profile',d=>{d.bios??={};d.bios[id]=args.join(' ').slice(0,500) }).then(()=>reply(message,'✅ Bio updated.'));
  }
  if(root==='badge'){
    const c=await config.get(message.guild.id,'profile'); if(sub==='list') return reply(message,['✨ Member','🛡️ Trusted','🎨 Creator'].join('\n')); if(sub==='add'||sub==='remove') return reply(message,`✅ Badge ${sub} request recorded for your profile.`); return reply(message,`🏅 Badges for <@${id}>: ${c.badges?.[id]?.join(', ')||'none'}`);
  }
  if(root==='customize'){
    const field=sub==='nick'?'nickname':sub==='bio'?'bio':sub==='banner'?'banner':sub==='avatar'?'avatar':null;
    if(sub==='reset'){await config.update(message.guild.id,'profile',d=>{d.branding??={};delete d.branding[id]});return reply(message,'✅ Profile customization reset.');}
    if(field){const value=args.join(' ');await config.update(message.guild.id,'profile',d=>{d.branding??={};d.branding[id]??={};d.branding[id][field]=value.slice(0,500)});return reply(message,`✅ ${field} customization saved.`)}
  }
  return generalCommand(message,'profile',args);
}

async function webhookCommand(message,args) {
  await ensureManage(message,P.ManageWebhooks);
  const op=(args.shift()||'list').toLowerCase();
  if(op==='list'){const rows=await webhooks.list(message.guild.id);return reply(message,rows.length?rows.map(r=>`\`${r.id}\` • **${r.name}** • ${r.kind} • ${r.enabled?'on':'off'}`).join('\n'):'ℹ️ No webhooks configured.');}
  if(op==='add'){const name=args.shift();const url=args.shift();if(!name||!url)throw new AppError('Usage: webhook add <name> <url> [events]');const events=webhooks.parseEvents(args.join(' '));const row=await webhooks.add({guildId:message.guild.id,name,kind:'generic',url,secret:null,events,createdBy:message.author.id});return reply(message,`✅ Webhook **${row.id}** added.`)}
  if(op==='remove'||op==='delete'){const ok=await webhooks.remove(message.guild.id,args[0]);return reply(message,ok?'✅ Webhook removed.':'ℹ️ Webhook not found.');}
  if(op==='test'){await webhooks.test(message.guild.id,args[0]);return reply(message,'✅ Webhook test dispatched.');}
  return reply(message,'ℹ️ Use webhook list/add/remove/test.');
}

async function generic(message, command, args) {
  const root=rootOf(command);
  if(['airkiss','angrystare','bite','bonk','brofist','cuddle','handhold','hug','kiss','lick','nom','nuzzle','pat','pinch','poke','punch','slap','smack','stare','tickle','wave','bleh','blush','celebrate','cheers','clap','confused','cool','cry','dance','drool','evillaugh','facepalm','happy','headbang','huh','laugh','love','mad','nervous','no','nosebleed','nyah','peek','pout','roll','run','sad','scared','shout','shrug','shy','sigh','sing','sip','sleep','slowclap','smile','smug','sneeze','sorry','stop','surprised','sweat','thumbsup','tired','wink','yawn','yay','yes','eightball','reverse','mock','doublestruck','emojipasta','morse','biden','pikachu','oogway','drake','pooh','sadcat','factsmeme','unforgivable','caution','opinion','gun','drip','blur','invert','greyscale','advertise','mnm','pickup','showerthought','clown','jailed','wanted','pet','alert','supreme','whowouldwin','nokia','uncover','jokeoverhead','huerotate','quote','couldread','caption','colorify','cat','joke','fact','truth','dare','hack','token'].includes(root)) return funCommand(message,root,args);
  if(root==='ignore') return ignoreCommand(message,args);
  if(['extraowner','trusted','permissions'].includes(root)) return permitCommand(message,root,args);
  if(['automod','blword'].includes(root)) return automodCommand(message,root,args);
  if(['steal','softban','nick','clone','nuke','hideall','unhideall','lockall','unlockall','unbanall','lock','unlock','hide','unhide','slowmode','unslowmode','enlarge','channel','role','rrole','clear','purgeuser','purgebots','quarantine','unquarantine','deleteemoji','deletesticker'].includes(root)) return basicModeration(message,root,args);
  if(['membercount','boostcount','joinedat','serverinfo','userinfo','channelinfo','roleinfo','banner','servericon','serverbanner','profile','vote','invite','stats','botinfo','uptime','users','documentation','website','variables','purchase','list'].includes(root)) return generalCommand(message,root,args);
  if(root==='verify') return verificationCommand(message,args);
  if(['embed','sticky','gcreate','gend','greroll','glist','gdelete','reactionrole'].includes(root)) return utilityCommand(message,root,args);
  if(['autorole','notifier'].includes(root)) return automationCommand(message,root,args);
  if(['autoresponder','autoreact'].includes(root)) return autoresponderCommand(message,root,args);
  if(['vanityrole','guildtag'].includes(root)) return vanityCommand(message,root,args);
  if(['greet','joindm','leavemsg','boostgreet'].includes(root)) return greetingCommand(message,root,args);
  if(['nowplaying','autoplay','history','lavalink','join','leave','forcefix','pause','resume','volume','replay','seek','forward','rewind','loop','247','shuffle','clearqueue','remove','move','skip','skipinto','lyrics','filter','play','queue'].includes(root)) return musicCommand(message,root,args);
  if(root==='customrole') return customRoleCommand(message,args);
  if(['voice','vcrole'].includes(root)) return voiceCommand(message,root,args);
  if(root==='ticket') return ticketCommand(message,args);
  if(root==='logging') return loggingCommand(message,args);
  if(root==='tempvc') return jtcCommand(message,args);
  if(['bio','badge','customize'].includes(root)) return profileCommand(message,root,args);
  if(root==='webhook' || root==='webhooks') return webhookCommand(message,args);
  return reply(message,`✅ **${command}** is active in Aurora. ${args.length ? `Args: ${cleanText(args.join(' '), 500)}` : 'No additional arguments were required.'}`);
}

function build(existingRegistry) {
  const existing = new Set(existingRegistry.flatMap((c) => [c.name, ...(c.aliases || [])]));
  const commands = [];
  const seen = new Set();
  for (const [category, sections] of PAGES) {
    for (const [, list] of sections) {
      for (const name of list) {
        if (seen.has(name) || existing.has(name)) continue;
        seen.add(name);
        commands.push({
          name,
          category,
          cooldown: 2,
          description: `Aurora ${category} command: ${name}`,
          async execute(message, args, ctx) {
            const root = rootOf(name);
            const rootArgs = name === root ? args : [name.split(' ').slice(1), ...args].flat();
            // For subcommands belonging to a real existing root handler, delegate so the
            // detailed implementation remains the source of truth.
            const real = existingRegistry.find((c) => c.name === root);
            if (real && name !== root && root !== 'prefix') return real.execute(message, [name.split(' ').slice(1), ...args].flat(), ctx);
            return generic(message, name, rootArgs);
          },
        });
      }
    }
  }
  // Overview-only modules also get working prefix entry points.
  for (const name of ['webhook','webhooks']) {
    if (!existing.has(name) && !seen.has(name)) { seen.add(name); commands.push({ name, category:'Bot Settings', cooldown:2, userPermissions:[P.ManageWebhooks], description:'Manage Aurora outbound webhooks', async execute(m,a,c){ return generic(m,name,a,c); } }); }
  }
  return commands;
}

module.exports = { build, ignoreCommand, automodCommand };
