'use strict';
const config = require('./guildConfig');
const moderation = require('./moderation');
const logging = require('./logging');
const { isExempt, sendTemp } = require('./exemptions');
const logger = require('../utils/logger');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser, clip } = require('../utils/embeds');

const INVITE_RE = /(?:discord(?:app)?\.com\/invite|discord\.gg|dsc\.gg|invite\.gg)\/([a-z0-9-]{2,32})/gi;
const URL_RE = /\b(?:https?:\/\/|www\.)[^\s<>()[\]]{2,200}/gi;

// ── helpers (pure, exported for tests) ──
const normalizeText = (s) => String(s ?? '').normalize('NFKC').replace(/[\u200b-\u200f\u2060\ufeff]/g, '');
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const wordCache = new Map(); // guildId -> { sig, regex }
function wordRegex(guildId, list) {
  const sig = list.join('\n');
  const hit = wordCache.get(guildId);
  if (hit && hit.sig === sig) return hit.regex;
  const regex = list.length
    ? new RegExp(`(?<![\\p{L}\\p{N}_])(?:${list.map((w) => escapeRegex(w).replace(/\\?\s+/g, '\\s+')).join('|')})(?![\\p{L}\\p{N}_])`, 'iu')
    : null;
  wordCache.set(guildId, { sig, regex });
  return regex;
}

function extractDomains(text) {
  const out = [];
  for (const m of text.matchAll(URL_RE)) {
    try {
      const u = new URL(m[0].startsWith('www.') ? `https://${m[0]}` : m[0]);
      out.push(u.hostname.toLowerCase().replace(/^www\./, ''));
    } catch { out.push(m[0].toLowerCase()); }
  }
  return out;
}

function longestRun(text) {
  let best = 0, run = 0, prev = null;
  for (const ch of text) {
    if (ch === prev && !/\s/.test(ch)) run += 1; else run = 1;
    prev = ch;
    if (run > best) best = run;
  }
  return best;
}

function longestWordRun(text) {
  const words = text.toLowerCase().split(/\s+/).filter(Boolean);
  let best = 0, run = 0, prev = null;
  for (const w of words) {
    run = w === prev ? run + 1 : 1;
    prev = w;
    if (run > best) best = run;
  }
  return best;
}

/** Built-in adult-site list for the NSFW-link filter (extend per server with rules.nsfw.extraDomains). */
const NSFW_DOMAINS = [
  'pornhub.com', 'xvideos.com', 'xnxx.com', 'xhamster.com', 'redtube.com', 'youporn.com', 'tube8.com', 'spankbang.com',
  'porn.com', 'brazzers.com', 'chaturbate.com', 'stripchat.com', 'cam4.com', 'bongacams.com', 'rule34.xxx', 'e621.net',
  'nhentai.net', 'hanime.tv', 'hentaihaven.xxx', 'e-hentai.org', 'onlyfans.com', 'fansly.com',
];
const domainMatches = (domain, list) => list.some((d) => domain === d || domain.endsWith(`.${d}`));

/** Custom (<:a:1>) + unicode emoji in a text. */
function countEmojis(text) {
  const custom = (text.match(/<a?:\w{2,32}:\d{17,20}>/g) ?? []).length;
  const unicode = (text.replace(/<a?:\w{2,32}:\d{17,20}>/g, '').match(/\p{Extended_Pictographic}/gu) ?? []).length;
  return custom + unicode;
}

/** Longest run of consecutive combining marks (zalgo stacks many; normal accents / Indic vowel signs stack 1-3). */
function maxMarkStack(text) {
  let best = 0, run = 0;
  for (const ch of text) {
    if (/\p{M}/u.test(ch)) { run += 1; if (run > best) best = run; } else run = 0;
  }
  return best;
}

const countMarks = (text) => (String(text).match(/\p{M}/gu) ?? []).length;
const countUpper = (text) => [...text].filter((c) => /\p{L}/u.test(c) && c !== c.toLowerCase()).length;
const countNewlines = (text) => (String(text).match(/\n/g) ?? []).length;

/** Dice coefficient over character bigrams, 0..1. */
function similarity(a, b) {
  if (a === b) return 1;
  if (a.length < 2 || b.length < 2) return 0;
  const grams = new Map();
  for (let i = 0; i < a.length - 1; i += 1) { const g = a.slice(i, i + 2); grams.set(g, (grams.get(g) ?? 0) + 1); }
  let hits = 0;
  for (let i = 0; i < b.length - 1; i += 1) {
    const g = b.slice(i, i + 2); const n = grams.get(g);
    if (n) { hits += 1; grams.set(g, n - 1); }
  }
  return (2 * hits) / (a.length + b.length - 2);
}
const similarKey = (text) => text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');

/** Heat meter: violations add heat, it cools down over time, 100 = Auto Mute. Pure (injectable clock) so it can be unit-tested. */
class HeatTracker {
  constructor() { this.users = new Map(); }

  /** @returns the user's heat after adding `amount` */
  add(key, amount, now = Date.now(), decayPerSec = 1) {
    const cur = this.users.get(key);
    const base = cur ? Math.max(0, cur.heat - ((now - cur.at) / 1000) * decayPerSec) : 0;
    const heat = base + amount;
    this.users.set(key, { heat, at: now });
    return heat;
  }

  clear(key) { this.users.delete(key); }

  sweep(now = Date.now(), maxAgeMs = 600_000) { for (const [k, v] of this.users) if (now - v.at > maxAgeMs) this.users.delete(k); }
}
const heatTracker = new HeatTracker();
setInterval(() => heatTracker.sweep(), 120_000).unref();

/** Rules this message is whitelisted for (by author, one of their roles, or the channel / its category). */
function whitelistedRules(cfg, message) {
  const out = new Set();
  const uid = message.author?.id ?? message.member?.id;
  const roles = message.member?.roles?.cache;
  const parentId = message.channel?.parentId;
  for (const [rule, t] of Object.entries(cfg.whitelist ?? {})) {
    if ((uid && t.users?.includes(uid))
      || t.channels?.includes(message.channelId) || (parentId && t.channels?.includes(parentId))
      || (roles && t.roles?.some((id) => roles.has(id)))) out.add(rule);
  }
  return out;
}

/** Per user message history for the spam / similar-message rules. */
const history = new Map(); // `${guildId}:${userId}` -> [{ ts, key }]
function recordMessage(key, ts, text) {
  const list = (history.get(key) ?? []).filter((m) => ts - m.ts <= 120_000);
  list.push({ ts, key: similarKey(text) });
  if (list.length > 30) list.splice(0, list.length - 30);
  history.set(key, list);
  return list;
}
setInterval(() => { const cut = Date.now() - 180_000; for (const [k, l] of history) if (!l.length || l[l.length - 1].ts < cut) history.delete(k); }, 60_000).unref();

const inviteCache = new Map(); // guildId -> { at, codes }
async function ownInviteCodes(guild) {
  const hit = inviteCache.get(guild.id);
  if (hit && Date.now() - hit.at < 300_000) return hit.codes;
  const codes = new Set();
  if (guild.vanityURLCode) codes.add(guild.vanityURLCode.toLowerCase());
  try { (await guild.invites.fetch()).forEach((i) => codes.add(i.code.toLowerCase())); } catch { /* no ManageGuild */ }
  inviteCache.set(guild.id, { at: Date.now(), codes });
  return codes;
}

/**
 * Evaluates all enabled rules (minus the ones this message is whitelisted for); returns the first violation or null.
 * `units` = how many "things" were wrong (mentions, emojis, capital letters, ...): the rule's heat is charged per unit.
 */
async function evaluate(message, cfg) {
  const raw = String(message.content ?? '');
  const text = normalizeText(raw);
  const r = cfg.rules;
  const skip = whitelistedRules(cfg, message);
  const on = (k) => !!r[k]?.enabled && !skip.has(k);
  const hit = (rule, reason, units = 1) => ({ rule, reason, actions: r[rule].action, units });

  // Rules that also apply to messages without text (attachments only) or need the message history.
  if (on('attachments') && (message.attachments?.size ?? 0) >= r.attachments.limit) return hit('attachments', `Too many attachments (${message.attachments.size})`, message.attachments.size);
  let past = null;
  if (on('spam') || on('similar')) {
    past = recordMessage(`${message.guild.id}:${message.author?.id ?? message.member?.id}`, message.createdTimestamp ?? Date.now(), text);
  }
  if (on('spam')) {
    const cutoff = (message.createdTimestamp ?? Date.now()) - r.spam.intervalSec * 1000;
    const n = past.filter((m) => m.ts >= cutoff).length;
    if (n >= r.spam.limit) return hit('spam', `Sending messages too fast (${n} in ${r.spam.intervalSec}s)`);
  }
  if (!text) return null;

  if (on('invites')) {
    const codes = [...text.matchAll(INVITE_RE)].map((m) => m[1].toLowerCase());
    if (codes.length) {
      const own = r.invites.allowOwnServer ? await ownInviteCodes(message.guild) : new Set();
      if (codes.some((c) => !own.has(c))) return hit('invites', 'Discord invite link');
    }
  }
  if (on('nsfw')) {
    const blocked = [...NSFW_DOMAINS, ...(r.nsfw.extraDomains ?? [])];
    if (extractDomains(text).some((d) => domainMatches(d, blocked))) return hit('nsfw', 'NSFW link');
  }
  if (on('links')) {
    const allowed = r.links.allowedDomains;
    const domains = extractDomains(text).filter((d) => !allowed.some((a) => d === a || d.endsWith(`.${a}`)));
    if (domains.length >= r.links.limit) return hit('links', `Too many links (${domains.length})`, domains.length);
  }
  if (on('words') && r.words.list.length) {
    const m = wordRegex(message.guild.id, r.words.list).exec(text);
    if (m) return hit('words', 'Banned word or phrase');
  }
  if (on('mentions')) {
    const n = new Set([...message.mentions.users.keys(), ...message.mentions.roles.keys()]).size;
    if (n >= r.mentions.limit) return hit('mentions', `Excessive mentions (${n})`, n);
  }
  if (on('emojis')) {
    const n = countEmojis(text);
    if (n >= r.emojis.limit) return hit('emojis', `Too many emojis (${n})`, n);
  }
  if (on('newlines')) {
    const n = countNewlines(raw);
    if (n >= r.newlines.limit) return hit('newlines', `Too many line breaks (${n})`, n);
  }
  if (on('charlimit') && raw.length > r.charlimit.maxChars) return hit('charlimit', `Message too long (${raw.length} characters)`, raw.length);
  if (on('zalgo') && maxMarkStack(text) >= r.zalgo.maxStack) return hit('zalgo', 'Zalgo / stacked combining characters', countMarks(text));
  if (on('repeated')) {
    if (longestRun(text) >= r.repeated.maxChars) return hit('repeated', 'Repeated characters');
    if (longestWordRun(text) >= r.repeated.maxWords) return hit('repeated', 'Repeated words');
  }
  if (on('caps') && text.length >= r.caps.minLength) {
    const letters = [...text].filter((c) => /\p{L}/u.test(c));
    if (letters.length >= r.caps.minLength * 0.6) {
      const upper = letters.filter((c) => c !== c.toLowerCase()).length;
      if ((upper / letters.length) * 100 >= r.caps.percent) return hit('caps', 'Excessive capital letters', upper);
    }
  }
  if (on('similar')) {
    const me = past[past.length - 1];
    if (me.key.length >= 6) {
      const cutoff = me.ts - r.similar.windowSec * 1000;
      const n = past.filter((m) => m.ts >= cutoff && m.key.length >= 6 && similarity(m.key, me.key) >= r.similar.similarity).length;
      if (n >= r.similar.limit) return hit('similar', `Similar messages repeated (${n})`);
    }
  }
  return null;
}

const HEAT_LIMIT = 100;
const noticeCooldown = new Map();

/** Returns true if the message was actioned (later handlers should skip it). */
async function process(message) {
  const { guild, member } = message;
  if (!member) return false;
  const cfg = await config.get(guild.id, 'automod');
  if (!cfg.enabled) return false;
  if (await isExempt(cfg, message, member, 'automod')) return false;

  const verdict = await evaluate(message, cfg);
  if (!verdict) return false;

  const actions = String(verdict.actions ?? 'delete').split('+');
  const done = [];
  if (actions.includes('delete')) {
    if (await message.delete().then(() => true, () => false)) done.push('Message deleted');
  }

  // Heat: every violation adds heat; reaching 100 = Auto Mute (and the meter starts over).
  const heatKey = `${guild.id}:${member.id}`;
  const added = (cfg.rules[verdict.rule].heat ?? 100) * (verdict.units ?? 1);
  const heat = heatTracker.add(heatKey, added, Date.now(), cfg.heatDecayPerSec ?? 1);
  let muted = false;
  if (heat >= HEAT_LIMIT) {
    const reason = `AutoMod (${verdict.rule}): ${verdict.reason}`;
    try {
      await moderation.timeout({ guild, target: member, moderator: null, durationMs: cfg.timeoutSec * 1000, reason, source: 'automod' });
      done.push(`Auto Mute ${cfg.timeoutSec}s`);
      muted = true;
    } catch (err) { logger.debug(`AutoMod timeout failed: ${err.message}`); }
    heatTracker.clear(heatKey);
  }

  const noticeKey = `${guild.id}:${member.id}`;
  if (!noticeCooldown.has(noticeKey) || Date.now() - noticeCooldown.get(noticeKey) > 10_000) {
    noticeCooldown.set(noticeKey, Date.now());
    await sendTemp(message.channel, `🛡️ ${member}, your message was removed: ${verdict.reason}.${muted ? ' You have been muted.' : ''}`, member.id);
  }

  await logging.send(guild, 'automod', makeEmbed({
    title: `🛡️ AutoMod — ${verdict.rule}`, color: COLORS.mod,
    fields: [
      { name: 'User', value: describeUser(member.user), inline: true },
      { name: 'Channel', value: `<#${message.channelId}>`, inline: true },
      { name: 'Rule', value: verdict.reason },
      { name: 'Heat', value: `+${Math.round(added * 100) / 100} → ${muted ? 'muted (reset)' : `${Math.round(heat * 100) / 100}/${HEAT_LIMIT}`}`, inline: true },
      { name: 'Actions', value: done.join(', ') || 'None could be applied' },
      { name: 'Content', value: `\`\`\`${clip(message.content.replace(/`/g, "'"), 900)}\`\`\`` },
    ],
    footer: `User ID: ${member.id} • Message ID: ${message.id}`,
  }));
  return true;
}

setInterval(() => { const cut = Date.now() - 60_000; for (const [k, t] of noticeCooldown) if (t < cut) noticeCooldown.delete(k); }, 60_000).unref();

module.exports = { process, evaluate, normalizeText, wordRegex, extractDomains, longestRun, longestWordRun, countEmojis, maxMarkStack, countNewlines, similarity, domainMatches, NSFW_DOMAINS, HeatTracker, whitelistedRules, HEAT_LIMIT };
