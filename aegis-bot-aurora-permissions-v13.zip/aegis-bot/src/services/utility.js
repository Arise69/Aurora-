'use strict';
/** Reminders, AFK, scheduled messages, sticky messages, autopublish, autorole. */
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { AppError } = require('../utils/errors');
const { shortId } = require('../utils/ids');
const { makeEmbed, clip } = require('../utils/embeds');
const { discordTime } = require('../utils/duration');

// ───────────── Reminders ─────────────
async function addReminder({ userId, guildId, channelId, message, remindAt }) {
  const n = Number((await db.get('SELECT COUNT(*) AS n FROM reminders WHERE user_id = ?', [userId])).n);
  if (n >= 25) throw new AppError('You can have at most 25 pending reminders.');
  const id = shortId(6);
  await db.run('INSERT INTO reminders (id, user_id, guild_id, channel_id, message, remind_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)', [id, userId, guildId, channelId, message, remindAt, Date.now()]);
  return id;
}
const listReminders = (userId) => db.all('SELECT id, message, remind_at FROM reminders WHERE user_id = ? ORDER BY remind_at LIMIT 25', [userId]);
const cancelReminder = async (userId, id) => (await db.run('DELETE FROM reminders WHERE user_id = ? AND id = ?', [userId, id.toUpperCase()])).changes > 0;

async function processReminders() {
  const due = await db.all('SELECT * FROM reminders WHERE remind_at <= ? LIMIT 25', [Date.now()]);
  const client = getClient();
  for (const r of due) {
    if ((await db.run('DELETE FROM reminders WHERE id = ?', [r.id])).changes === 0) continue; // claimed
    const embed = makeEmbed({ title: '⏰ Reminder', description: clip(r.message, 3900), color: 0x3498db, footer: `Set ${new Date(Number(r.remind_at)).toUTCString()}` });
    const user = await client.users.fetch(r.user_id).catch(() => null);
    if (user && await user.send({ embeds: [embed] }).then(() => true, () => false)) continue;
    const channel = r.channel_id && (await client.channels.fetch(r.channel_id).catch(() => null));
    if (channel?.isTextBased()) await channel.send({ content: `<@${r.user_id}>`, embeds: [embed], allowedMentions: { users: [r.user_id] } }).catch(() => {});
  }
}

// ───────────── AFK ─────────────
async function setAfk(guildId, userId, reason) {
  await db.run(
    `INSERT INTO afk (guild_id, user_id, reason, since) VALUES (?, ?, ?, ?)
     ON CONFLICT (guild_id, user_id) DO UPDATE SET reason = excluded.reason, since = excluded.since`, [guildId, userId, reason, Date.now()]);
}

/** Called for every guild message: clears the author's AFK and notifies about mentioned AFK users. */
async function handleAfk(message) {
  const removed = await db.run('DELETE FROM afk WHERE guild_id = ? AND user_id = ?', [message.guild.id, message.author.id]);
  if (removed.changes > 0) {
    const m = await message.reply({ content: `👋 Welcome back ${message.author}, I removed your AFK status.`, allowedMentions: { parse: [], repliedUser: false } }).catch(() => null);
    if (m) setTimeout(() => m.delete().catch(() => {}), 8000).unref?.();
  }
  const ids = [...message.mentions.users.keys()].filter((id) => id !== message.author.id).slice(0, 3);
  if (!ids.length) return;
  const marks = ids.map(() => '?').join(',');
  const rows = await db.all(`SELECT user_id, reason, since FROM afk WHERE guild_id = ? AND user_id IN (${marks})`, [message.guild.id, ...ids]);
  if (!rows.length) return;
  const text = rows.map((r) => `💤 <@${r.user_id}> is AFK${r.reason ? `: ${clip(r.reason, 150)}` : ''} (since ${discordTime(Number(r.since), 'R')})`).join('\n');
  await message.reply({ content: text, allowedMentions: { parse: [], repliedUser: false } }).catch(() => {});
}

// ───────────── Scheduled messages ─────────────
async function addScheduled({ guildId, channelId, content, intervalMs, by }) {
  const n = Number((await db.get('SELECT COUNT(*) AS n FROM scheduled_messages WHERE guild_id = ?', [guildId])).n);
  if (n >= 10) throw new AppError('You can have at most 10 scheduled messages.');
  if (intervalMs < 5 * 60_000) throw new AppError('The interval must be at least 5 minutes.');
  const id = shortId(6);
  await db.run('INSERT INTO scheduled_messages (id, guild_id, channel_id, content, interval_ms, next_run_at, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [id, guildId, channelId, content, intervalMs, Date.now() + intervalMs, by, Date.now()]);
  return id;
}
const listScheduled = (guildId) => db.all('SELECT id, channel_id, content, interval_ms, next_run_at FROM scheduled_messages WHERE guild_id = ? ORDER BY next_run_at', [guildId]);
const removeScheduled = async (guildId, id) => (await db.run('DELETE FROM scheduled_messages WHERE guild_id = ? AND id = ?', [guildId, id.toUpperCase()])).changes > 0;

async function processScheduled() {
  const due = await db.all('SELECT * FROM scheduled_messages WHERE next_run_at <= ? LIMIT 25', [Date.now()]);
  for (const s of due) {
    const claim = await db.run('UPDATE scheduled_messages SET next_run_at = ? WHERE id = ? AND next_run_at = ?', [Date.now() + Number(s.interval_ms), s.id, s.next_run_at]);
    if (claim.changes === 0) continue;
    const channel = getClient().channels.cache.get(s.channel_id);
    if (channel?.isTextBased() && channel.permissionsFor(channel.guild.members.me)?.has([P.ViewChannel, P.SendMessages])) {
      await channel.send({ content: s.content, allowedMentions: { parse: [] } }).catch((err) => logger.debug(`Scheduled message failed: ${err.message}`));
    }
  }
}

// ───────────── Sticky messages ─────────────
const stickyBusy = new Set();
async function handleSticky(message) {
  const row = await db.get('SELECT content, last_message_id FROM sticky_messages WHERE guild_id = ? AND channel_id = ?', [message.guild.id, message.channelId]);
  if (!row || stickyBusy.has(message.channelId)) return;
  stickyBusy.add(message.channelId);
  try {
    await new Promise((r) => setTimeout(r, 1500)); // let bursts settle
    if (row.last_message_id) await message.channel.messages.delete(row.last_message_id).catch(() => {});
    const sent = await message.channel.send({ content: `📌 ${row.content}`, allowedMentions: { parse: [] } });
    await db.run('UPDATE sticky_messages SET last_message_id = ? WHERE guild_id = ? AND channel_id = ?', [sent.id, message.guild.id, message.channelId]);
  } catch (err) { logger.debug(`Sticky failed: ${err.message}`); } finally { stickyBusy.delete(message.channelId); }
}

// ───────────── Autopublish ─────────────
async function handleAutopublish(message) {
  if (message.channel.type !== ChannelType.GuildAnnouncement || !message.crosspostable) return;
  const cfg = await config.get(message.guild.id, 'automation');
  if (cfg.autopublishChannelIds.includes(message.channelId)) await message.crosspost().catch((err) => logger.debug(`Crosspost failed: ${err.message}`));
}

// ───────────── Autorole ─────────────
async function applyAutorole(member) {
  const cfg = await config.get(member.guild.id, 'autorole');
  const ids = member.user.bot ? cfg.botRoleIds : cfg.humanRoleIds;
  const me = member.guild.members.me;
  const roles = ids.map((id) => member.guild.roles.cache.get(id)).filter((r) => r && me.roles.highest.comparePositionTo(r) > 0 && !r.managed);
  if (roles.length) await member.roles.add(roles, 'Autorole').catch((err) => logger.debug(`Autorole failed: ${err.message}`));
}

module.exports = {
  addReminder, listReminders, cancelReminder, processReminders, setAfk, handleAfk,
  addScheduled, listScheduled, removeScheduled, processScheduled, handleSticky, handleAutopublish, applyAutorole,
};
