'use strict';
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, AttachmentBuilder, MessageFlags, PermissionFlagsBits: P,
} = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logging = require('./logging');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { AppError } = require('../utils/errors');
const { shortId } = require('../utils/ids');
const { COLORS } = require('../config/constants');
const { makeEmbed, clip } = require('../utils/embeds');
const { respond } = require('../utils/reply');

const openCooldown = new Map();
const MEMBER_PERMS = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles, P.EmbedLinks];

async function nextNumber(guildId) {
  const row = await db.get(
    `INSERT INTO counters (guild_id, name, value) VALUES (?, 'ticket', 1)
     ON CONFLICT (guild_id, name) DO UPDATE SET value = counters.value + 1 RETURNING value`, [guildId]);
  return Number(row.value);
}

const getByChannel = (channelId) => db.get('SELECT * FROM tickets WHERE channel_id = ?', [channelId]);
const isSupport = (member, cfg) => member.permissions.has(P.ManageChannels) || cfg.supportRoleIds.some((r) => member.roles.cache.has(r));

function buildPanel(cfg) {
  const row = new ActionRowBuilder();
  cfg.types.slice(0, 5).forEach((type, i) => row.addComponents(
    new ButtonBuilder().setCustomId(`ticket:open:${i}`).setLabel(clip(type, 80)).setEmoji('🎫').setStyle(ButtonStyle.Primary)));
  return {
    embeds: [makeEmbed({ title: '🎫 Support Tickets', description: 'Need help? Press a button below to open a private ticket with our staff.', color: COLORS.primary, timestamp: false })],
    components: [row],
  };
}

async function postPanel(guild, channel, cfg) {
  if (!channel.permissionsFor(guild.members.me)?.has([P.ViewChannel, P.SendMessages, P.EmbedLinks])) throw new AppError(`I can't send messages with embeds in ${channel}.`);
  return channel.send(buildPanel(cfg));
}

async function open(interaction, typeIndex) {
  const { guild, member } = interaction;
  const cfg = await config.get(guild.id, 'tickets');
  if (!cfg.enabled) throw new AppError('Tickets are currently disabled.');
  const type = cfg.types[typeIndex];
  if (!type) throw new AppError('That ticket type no longer exists.');
  if (Date.now() - (openCooldown.get(member.id) ?? 0) < 10_000) throw new AppError('Please wait a few seconds before opening another ticket.');
  openCooldown.set(member.id, Date.now());

  const existing = await db.all(`SELECT channel_id FROM tickets WHERE guild_id = ? AND opener_id = ? AND status = 'open'`, [guild.id, member.id]);
  if (existing.length >= cfg.maxOpenPerUser) throw new AppError(`You already have ${existing.length} open ticket(s): <#${existing[0].channel_id}>.`);
  if (!guild.members.me.permissions.has(P.ManageChannels)) throw new AppError('I need the **Manage Channels** permission to create tickets.');

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const number = await nextNumber(guild.id);
  const parent = cfg.categoryId && guild.channels.cache.get(cfg.categoryId)?.type === ChannelType.GuildCategory ? cfg.categoryId : null;
  const supportRoles = cfg.supportRoleIds.filter((r) => guild.roles.cache.has(r));
  const channel = await guild.channels.create({
    name: `ticket-${String(number).padStart(4, '0')}`,
    type: ChannelType.GuildText,
    parent,
    topic: `Ticket #${number} • ${type} • opened by ${member.user.username} (${member.id})`,
    permissionOverwrites: [
      { id: guild.id, deny: [P.ViewChannel] },
      { id: member.id, allow: MEMBER_PERMS },
      ...supportRoles.map((id) => ({ id, allow: [...MEMBER_PERMS, P.ManageMessages] })),
      { id: guild.members.me.id, allow: [...MEMBER_PERMS, P.ManageChannels] },
    ],
    reason: `Ticket #${number} opened by ${member.user.username}`,
  });
  const id = shortId(8);
  await db.run(
    `INSERT INTO tickets (id, guild_id, number, channel_id, opener_id, category, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'open', ?)`,
    [id, guild.id, number, channel.id, member.id, type, Date.now()],
  );
  await channel.send({
    content: `${member}${supportRoles.length ? ` ${supportRoles.map((r) => `<@&${r}>`).join(' ')}` : ''}`,
    allowedMentions: { users: [member.id], roles: supportRoles },
    embeds: [makeEmbed({
      title: `🎫 Ticket #${number} — ${type}`, color: COLORS.primary,
      description: 'Please describe your issue. A staff member will be with you shortly.',
      fields: [{ name: 'Opened by', value: `${member}`, inline: true }],
    })],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket:close').setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('ticket:claim').setLabel('Claim').setEmoji('🙋').setStyle(ButtonStyle.Secondary),
    )],
  });
  await logging.send(guild, 'tickets', makeEmbed({
    title: '🎫 Ticket opened', color: COLORS.success,
    fields: [{ name: 'Ticket', value: `#${number} (<#${channel.id}>)`, inline: true }, { name: 'Type', value: type, inline: true }, { name: 'Opened by', value: `${member} (\`${member.id}\`)` }],
    footer: `Ticket ID: ${id}`,
  }));
  return respond(interaction, `🎫 Your ticket has been created: ${channel}`);
}

async function buildTranscript(channel, ticket) {
  const all = [];
  let before;
  for (let i = 0; i < 10; i++) {
    const batch = await channel.messages.fetch({ limit: 100, before }).catch(() => null);
    if (!batch?.size) break;
    all.push(...batch.values());
    before = batch.last().id;
    if (batch.size < 100) break;
  }
  all.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
  const header = `Transcript of ticket #${ticket.number} (${ticket.category}) — opened ${new Date(Number(ticket.created_at)).toISOString()}\n${'─'.repeat(60)}\n`;
  const body = all.map((m) => {
    const files = m.attachments.size ? ` [attachments: ${[...m.attachments.values()].map((a) => a.name).join(', ')}]` : '';
    const embeds = m.embeds.length ? ` [${m.embeds.length} embed(s)]` : '';
    return `[${new Date(m.createdTimestamp).toISOString().replace('T', ' ').slice(0, 19)}] ${m.author.username} (${m.author.id}): ${m.content}${files}${embeds}`;
  }).join('\n');
  return Buffer.from(header + body, 'utf8');
}

async function close(interaction, { reason = null } = {}) {
  const { guild, channel, member } = interaction;
  const ticket = await getByChannel(channel.id);
  if (!ticket || ticket.status !== 'open') throw new AppError('This is not an open ticket channel.');
  const cfg = await config.get(guild.id, 'tickets');
  if (ticket.opener_id !== member.id && !isSupport(member, cfg)) throw new AppError('Only the ticket opener or support staff can close this ticket.');

  const claim = await db.run(
    `UPDATE tickets SET status = 'closed', closed_at = ?, closed_by = ?, close_reason = ? WHERE id = ? AND status = 'open'`,
    [Date.now(), member.id, reason, ticket.id],
  );
  if (claim.changes === 0) throw new AppError('This ticket is already closing.');

  if (!interaction.deferred && !interaction.replied) await interaction.deferReply().catch(() => {});
  await respond(interaction, '🔒 Closing this ticket in 5 seconds… saving transcript.', { ephemeral: false }).catch(() => {});

  let transcript = null;
  try { transcript = new AttachmentBuilder(await buildTranscript(channel, ticket), { name: `transcript-${String(ticket.number).padStart(4, '0')}.txt` }); }
  catch (err) { logger.warn(`Transcript failed: ${err.message}`); }

  const embed = makeEmbed({
    title: `🔒 Ticket #${ticket.number} closed`, color: COLORS.mod,
    fields: [
      { name: 'Opened by', value: `<@${ticket.opener_id}>`, inline: true }, { name: 'Closed by', value: `${member}`, inline: true },
      { name: 'Type', value: ticket.category ?? 'n/a', inline: true }, { name: 'Reason', value: reason || 'No reason provided' },
    ],
    footer: `Ticket ID: ${ticket.id}`,
  });
  const files = transcript ? [transcript] : [];
  if (cfg.logChannelId) {
    const logCh = guild.channels.cache.get(cfg.logChannelId);
    if (logCh?.isTextBased()) await logCh.send({ embeds: [embed], files, allowedMentions: { parse: [] } }).catch(() => {});
  } else {
    await logging.send(guild, 'tickets', embed, { files });
  }
  if (cfg.dmTranscript && transcript) {
    const opener = await getClient().users.fetch(ticket.opener_id).catch(() => null);
    await opener?.send({ content: `Your ticket in **${guild.name}** was closed. Transcript attached.`, files }).catch(() => {});
  }
  setTimeout(() => channel.delete(`Ticket closed by ${member.user.username}`).catch(() => {}), 5000).unref?.();
}

async function claimTicket(interaction) {
  const { guild, channel, member } = interaction;
  const ticket = await getByChannel(channel.id);
  if (!ticket || ticket.status !== 'open') throw new AppError('This is not an open ticket channel.');
  const cfg = await config.get(guild.id, 'tickets');
  if (!isSupport(member, cfg)) throw new AppError('Only support staff can claim tickets.');
  const res = await db.run('UPDATE tickets SET claimed_by = ? WHERE id = ? AND claimed_by IS NULL', [member.id, ticket.id]);
  if (res.changes === 0) throw new AppError(`This ticket is already claimed by <@${ticket.claimed_by}>.`);
  return respond(interaction, { content: `🙋 ${member} has claimed this ticket.`, allowedMentions: { parse: [] } }, { ephemeral: false });
}

async function handleComponent(interaction) {
  const [, action, arg] = interaction.customId.split(':');
  if (!interaction.inGuild()) return null;
  if (action === 'open') return open(interaction, Number(arg));
  if (action === 'claim') return claimTicket(interaction);
  if (action === 'close') {
    return interaction.reply({
      flags: MessageFlags.Ephemeral, content: 'Are you sure you want to close this ticket?',
      components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket:confirm').setLabel('Yes, close it').setStyle(ButtonStyle.Danger))],
    });
  }
  if (action === 'confirm') { await interaction.deferUpdate(); return close(interaction); }
  return null;
}

module.exports = { postPanel, buildPanel, open, close, claimTicket, getByChannel, isSupport, handleComponent, buildTranscript, MEMBER_PERMS };
