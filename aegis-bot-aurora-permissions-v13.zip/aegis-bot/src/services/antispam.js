'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const config = require('./guildConfig');
const moderation = require('./moderation');
const logging = require('./logging');
const { isExempt, sendTemp } = require('./exemptions');
const logger = require('../utils/logger');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser } = require('../utils/embeds');
const { formatDuration } = require('../utils/duration');

/** Sliding-window flood + duplicate detector. Pure (no Discord objects) so it is unit-testable. */
class SpamTracker {
  constructor() { this.users = new Map(); }

  /**
   * @param key   unique per guild+user
   * @param msg   { ts, hash|null, channelId, messageId }
   * @param opts  { messageLimit, intervalMs, duplicateLimit, duplicateWindowMs }
   * @returns null | { type: 'flood'|'duplicate', count, messages }
   */
  check(key, msg, opts) {
    const horizon = msg.ts - Math.max(opts.intervalMs, opts.duplicateWindowMs);
    const history = (this.users.get(key) ?? []).filter((m) => m.ts >= horizon);
    history.push(msg);
    if (history.length > 60) history.splice(0, history.length - 60);
    this.users.set(key, history);

    const recent = history.filter((m) => m.ts >= msg.ts - opts.intervalMs);
    if (recent.length >= opts.messageLimit) return { type: 'flood', count: recent.length, messages: recent };
    if (msg.hash) {
      const dups = history.filter((m) => m.hash === msg.hash && m.ts >= msg.ts - opts.duplicateWindowMs);
      if (dups.length >= opts.duplicateLimit) return { type: 'duplicate', count: dups.length, messages: dups };
    }
    return null;
  }

  clear(key) { this.users.delete(key); }

  sweep(now = Date.now(), maxAgeMs = 120_000) {
    for (const [key, list] of this.users) {
      if (!list.length || now - list[list.length - 1].ts > maxAgeMs) this.users.delete(key);
    }
  }
}

/** Normalises content for duplicate comparison; very short messages ("lol", "ok") are never hashed. */
function contentHash(text) {
  const norm = String(text ?? '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
  return norm.length >= 4 ? norm : null;
}

const tracker = new SpamTracker();
const strikes = new Map(); // key -> { count, lastAt, cooldownUntil }

async function deleteTracked(guild, messages) {
  const me = guild.members.me;
  const byChannel = new Map();
  for (const m of messages) byChannel.set(m.channelId, [...(byChannel.get(m.channelId) ?? []), m.messageId]);
  for (const [channelId, ids] of byChannel) {
    const channel = guild.channels.cache.get(channelId);
    if (!channel?.isTextBased() || !channel.permissionsFor(me)?.has(P.ManageMessages)) continue;
    try {
      if (ids.length === 1) await channel.messages.delete(ids[0]);
      else await channel.bulkDelete(ids, true);
    } catch (err) { logger.debug(`Spam cleanup failed: ${err.message}`); }
  }
}

/** Returns true if the message was punished/removed and later handlers should stop. */
async function process(message) {
  const { guild, member } = message;
  if (!member) return false;
  const cfg = await config.get(guild.id, 'antispam');
  if (!cfg.enabled) return false;
  if (await isExempt(cfg, message, member, 'antispam')) return false;

  const key = `${guild.id}:${member.id}`;
  const result = tracker.check(key, {
    ts: Date.now(), hash: contentHash(message.content), channelId: message.channelId, messageId: message.id,
  }, {
    messageLimit: cfg.messageLimit,
    intervalMs: cfg.intervalSec * 1000,
    duplicateLimit: cfg.duplicateLimit,
    duplicateWindowMs: cfg.duplicateWindowSec * 1000,
  });
  if (!result) return false;
  await punish(message, member, cfg, result, key);
  return true;
}

async function punish(message, member, cfg, result, key) {
  const { guild } = message;
  const now = Date.now();
  const state = strikes.get(key) ?? { count: 0, lastAt: 0, cooldownUntil: 0 };
  tracker.clear(key);

  // Inside the cooldown: only clean up (the user was just punished) – no re-escalation.
  if (now < state.cooldownUntil) {
    if (cfg.deleteMessages) await deleteTracked(guild, result.messages);
    return;
  }
  if (now - state.lastAt > cfg.strikeResetMin * 60_000) state.count = 0;
  state.count += 1;
  state.lastAt = now;
  state.cooldownUntil = now + cfg.cooldownSec * 1000;
  strikes.set(key, state);

  if (cfg.deleteMessages) await deleteTracked(guild, result.messages);

  const reason = result.type === 'flood'
    ? `Message flooding (${result.count} messages in ${cfg.intervalSec}s)`
    : `Repeated identical messages (${result.count}x)`;
  let outcome;
  try {
    if (state.count === 1) {
      if (cfg.recordWarning) {
        const w = await moderation.warn({ guild, target: member, moderator: null, reason: `Anti-spam: ${reason}`, source: 'antispam' });
        outcome = `Warning issued (${w.id})`;
      } else {
        outcome = 'Warning (not recorded)';
      }
      await sendTemp(message.channel, `⚠️ ${member}, please slow down — that looks like spam.`, member.id);
    } else {
      const seconds = cfg.timeoutSteps[Math.min(state.count - 2, cfg.timeoutSteps.length - 1)] ?? 300;
      await moderation.timeout({ guild, target: member, moderator: null, durationMs: seconds * 1000, reason: `Anti-spam: ${reason}`, source: 'antispam' });
      outcome = `Timeout ${formatDuration(seconds * 1000)}`;
      await sendTemp(message.channel, `🔇 ${member} was timed out for spamming.`, member.id);
    }
  } catch (err) {
    outcome = `Action failed: ${err.message}`;
    logger.debug(`Anti-spam action failed in ${guild.id}: ${err.message}`);
  }

  await logging.send(guild, 'security', makeEmbed({
    title: '🚨 Spam detected', color: COLORS.security,
    fields: [
      { name: 'User', value: describeUser(member.user), inline: true },
      { name: 'Channel', value: `<#${message.channelId}>`, inline: true },
      { name: 'Strike', value: String(state.count), inline: true },
      { name: 'Detection', value: reason },
      { name: 'Action', value: outcome },
    ],
    footer: `User ID: ${member.id}`,
  }));
}

/** Scheduler hook: prune memory. */
function sweep() {
  tracker.sweep();
  const cutoff = Date.now() - 3_600_000;
  for (const [key, s] of strikes) if (s.lastAt < cutoff) strikes.delete(key);
}

const resetUser = (guildId, userId) => { strikes.delete(`${guildId}:${userId}`); tracker.clear(`${guildId}:${userId}`); };

module.exports = { SpamTracker, contentHash, process, sweep, resetUser };
