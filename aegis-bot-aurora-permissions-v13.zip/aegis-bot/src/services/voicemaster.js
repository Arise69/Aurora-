'use strict';
/** "Voice Master": join-to-create temporary voice channels with owner controls. */
const { ChannelType, PermissionFlagsBits: P } = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { AppError } = require('../utils/errors');
const { render, memberVars } = require('../utils/template');

const createCooldown = new Map();
const renameLog = new Map(); // channelId -> timestamps (Discord allows 2 renames / 10 min per channel)

const getRow = (channelId) => db.get('SELECT * FROM voice_channels WHERE channel_id = ?', [channelId]);

const sanitizeName = (s) => String(s).replace(/[\u0000-\u001f\u007f@#:`]/g, '').replace(/\s+/g, ' ').trim().slice(0, 100) || 'voice';

async function createTemp(member, cfg) {
  const { guild } = member;
  if (Date.now() - (createCooldown.get(member.id) ?? 0) < 5000) return;
  createCooldown.set(member.id, Date.now());
  const me = guild.members.me;
  if (!me.permissions.has([P.ManageChannels, P.MoveMembers])) return;

  const owned = await db.get('SELECT channel_id FROM voice_channels WHERE guild_id = ? AND owner_id = ?', [guild.id, member.id]);
  if (owned) {
    const existing = guild.channels.cache.get(owned.channel_id);
    if (existing) return member.voice.setChannel(existing).catch(() => {});
    await db.run('DELETE FROM voice_channels WHERE channel_id = ?', [owned.channel_id]);
  }
  const creator = guild.channels.cache.get(cfg.creatorChannelId);
  const parent = cfg.categoryId && guild.channels.cache.get(cfg.categoryId) ? cfg.categoryId : creator?.parentId ?? null;
  const channel = await guild.channels.create({
    name: sanitizeName(render(cfg.nameTemplate, memberVars(member))),
    type: ChannelType.GuildVoice,
    parent,
    userLimit: cfg.defaultLimit || 0,
    permissionOverwrites: [
      { id: member.id, allow: [P.ViewChannel, P.Connect, P.Speak] },
      { id: me.id, allow: [P.ViewChannel, P.Connect, P.ManageChannels, P.MoveMembers] },
    ],
    reason: `Voice Master channel for ${member.user.username}`,
  });
  await db.run('INSERT INTO voice_channels (channel_id, guild_id, owner_id, created_at) VALUES (?, ?, ?, ?)', [channel.id, guild.id, member.id, Date.now()]);
  if (!(await member.voice.setChannel(channel).then(() => true, () => false))) {
    await channel.delete('Owner left before move').catch(() => {});
    await db.run('DELETE FROM voice_channels WHERE channel_id = ?', [channel.id]);
  }
}

async function deleteIfEmpty(channel) {
  if (!channel || channel.members.size > 0) return;
  const row = await getRow(channel.id);
  if (!row) return;
  await db.run('DELETE FROM voice_channels WHERE channel_id = ?', [channel.id]);
  await channel.delete('Voice Master channel is empty').catch((err) => logger.debug(`VM delete failed: ${err.message}`));
}

async function onVoiceStateUpdate(oldState, newState) {
  try {
    const guild = newState.guild;
    if (newState.channelId && newState.channelId !== oldState.channelId && newState.member && !newState.member.user.bot) {
      const cfg = await config.get(guild.id, 'voicemaster');
      if (cfg.enabled && cfg.creatorChannelId === newState.channelId) await createTemp(newState.member, cfg);
    }
    if (oldState.channelId && oldState.channelId !== newState.channelId) await deleteIfEmpty(oldState.channel);
  } catch (err) { logger.warn(`Voice Master handler failed: ${err.message}`); }
}

/** Startup cleanup: remove rows for vanished channels and delete channels left empty during downtime. */
async function reconcile() {
  const rows = await db.all('SELECT channel_id, guild_id FROM voice_channels');
  for (const row of rows) {
    const guild = getClient().guilds.cache.get(row.guild_id);
    const channel = guild?.channels.cache.get(row.channel_id);
    if (!channel) { await db.run('DELETE FROM voice_channels WHERE channel_id = ?', [row.channel_id]); continue; }
    await deleteIfEmpty(channel);
  }
}

/** Resolves the caller's owned temp channel or throws a friendly error. */
async function requireOwned(interaction, { allowUnowned = false } = {}) {
  const channel = interaction.member.voice.channel;
  if (!channel) throw new AppError('Join your Voice Master channel first.');
  const row = await getRow(channel.id);
  if (!row) throw new AppError('You are not in a Voice Master channel.');
  if (!allowUnowned && row.owner_id !== interaction.user.id) throw new AppError(`Only the channel owner (<@${row.owner_id}>) can do that.`);
  return { channel, row };
}

function checkRenameLimit(channelId) {
  const now = Date.now();
  const list = (renameLog.get(channelId) ?? []).filter((t) => now - t < 600_000);
  if (list.length >= 2) throw new AppError('Discord limits channel renames to 2 per 10 minutes. Try again later.');
  list.push(now);
  renameLog.set(channelId, list);
}

const setOwner = (channelId, ownerId) => db.run('UPDATE voice_channels SET owner_id = ? WHERE channel_id = ?', [ownerId, channelId]);

module.exports = { onVoiceStateUpdate, reconcile, requireOwned, checkRenameLimit, setOwner, sanitizeName, getRow };
