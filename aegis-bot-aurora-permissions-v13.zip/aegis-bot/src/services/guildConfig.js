'use strict';
/**
 * Per-guild configuration store. Every module (antispam, automod, logging, ...) is a JSON document in
 * guild_settings, deep-merged over config/defaults.js and cached in memory.
 *
 * get()    -> frozen object (never mutate it)
 * update() -> serialised read-modify-write; the mutator receives a mutable draft
 */
const db = require('../database');
const DEFAULTS = require('../config/defaults');
const logger = require('../utils/logger');

const cache = new Map();
const locks = new Map();

function deepMerge(base, over) {
  if (Array.isArray(over)) return over.slice();
  if (over && typeof over === 'object' && base && typeof base === 'object' && !Array.isArray(base)) {
    const out = { ...base };
    for (const [k, v] of Object.entries(over)) {
      if (k === '__proto__' || k === 'constructor') continue;
      out[k] = k in base ? deepMerge(base[k], v) : v;
    }
    return out;
  }
  return over === undefined ? base : over;
}

function deepFreeze(o) {
  if (o && typeof o === 'object' && !Object.isFrozen(o)) {
    Object.freeze(o);
    for (const v of Object.values(o)) deepFreeze(v);
  }
  return o;
}

const keyOf = (guildId, module) => `${guildId}:${module}`;

async function get(guildId, module) {
  if (!DEFAULTS[module]) throw new Error(`Unknown config module "${module}"`);
  const key = keyOf(guildId, module);
  const hit = cache.get(key);
  if (hit) return hit;
  const row = await db.get('SELECT data FROM guild_settings WHERE guild_id = ? AND module = ?', [guildId, module]);
  let stored = {};
  if (row) {
    try { stored = JSON.parse(row.data); } catch (err) { logger.error(`Corrupt config ${key}; using defaults`, err); }
  }
  const merged = deepFreeze(deepMerge(DEFAULTS[module](), stored));
  cache.set(key, merged);
  return merged;
}

/**
 * @param mutator (draft) => void | newObject
 * @param audit   { actorId, summary } -> written to the "server" log category
 */
async function update(guildId, module, mutator, audit = null) {
  const key = keyOf(guildId, module);
  const previous = locks.get(key) ?? Promise.resolve();
  let release;
  locks.set(key, new Promise((r) => { release = r; }));
  await previous.catch(() => {});
  try {
    const current = await get(guildId, module);
    const draft = structuredClone(current);
    const result = await mutator(draft);
    const next = deepFreeze(result === undefined ? draft : result);
    await db.run(
      `INSERT INTO guild_settings (guild_id, module, data, updated_at) VALUES (?, ?, ?, ?)
       ON CONFLICT (guild_id, module) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`,
      [guildId, module, JSON.stringify(next), Date.now()],
    );
    cache.set(key, next);
    if (audit) {
      require('./logging').logConfigChange(guildId, module, audit.actorId, audit.summary).catch(() => {});
    }
    return next;
  } finally {
    release();
    if (locks.get(key) && locks.size > 5000) locks.clear();
  }
}

const invalidate = (guildId, module) => cache.delete(keyOf(guildId, module));
const clearCache = () => cache.clear();

module.exports = { get, update, invalidate, clearCache };
