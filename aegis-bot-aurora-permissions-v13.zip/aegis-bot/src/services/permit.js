'use strict';
/** "Permit" system: users/roles exempt from specific security systems. */
const db = require('../database');

const SCOPES = ['all', 'automod', 'antispam', 'antiraid', 'antinuke'];
const cache = new Map(); // guildId -> rows

async function list(guildId) {
  if (cache.has(guildId)) return cache.get(guildId);
  const rows = await db.all('SELECT target_id, target_type, scope, created_by, created_at FROM permits WHERE guild_id = ? ORDER BY created_at', [guildId]);
  cache.set(guildId, rows);
  return rows;
}

async function add(guildId, targetId, targetType, scope, by) {
  const res = await db.run(
    'INSERT INTO permits (guild_id, target_id, target_type, scope, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT DO NOTHING',
    [guildId, targetId, targetType, scope, by, Date.now()],
  );
  cache.delete(guildId);
  return res.changes > 0;
}

async function remove(guildId, targetId, scope) {
  const res = scope
    ? await db.run('DELETE FROM permits WHERE guild_id = ? AND target_id = ? AND scope = ?', [guildId, targetId, scope])
    : await db.run('DELETE FROM permits WHERE guild_id = ? AND target_id = ?', [guildId, targetId]);
  cache.delete(guildId);
  return res.changes;
}

/** True when the member (by user id or any role) is permitted for `scope` (or for "all"). */
async function isPermitted(guildId, member, scope) {
  const rows = await list(guildId);
  if (!rows.length || !member) return false;
  return rows.some((r) =>
    (r.scope === scope || r.scope === 'all') &&
    (r.target_type === 'user' ? r.target_id === member.id : member.roles?.cache?.has(r.target_id)));
}

module.exports = { SCOPES, list, add, remove, isPermitted };
