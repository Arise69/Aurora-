'use strict';

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
} = require('discord.js');
const { getClient } = require('../utils/context');
const { makeEmbed, clip } = require('../utils/embeds');
const config = require('./guildConfig');

const HELP_COLOR = 0x2c2c2c;

/*
 * Aurora's 19-page help catalogue.
 * The catalogue is intentionally explicit so the help UI can document the
 * complete command layout even while individual modules are being implemented.
 */
const PAGES = [['Security',
  [['Antinuke',
    ['antinuke',
     'antinuke wizard',
     'antinuke owneronly',
     'antinuke betrayalguard',
     'antinuke enable',
     'antinuke limit',
     'antinuke whitelisted',
     'antinuke manage',
     'antinuke disable',
     'antinuke logging',
     'antinuke whitelist',
     'antinuke config',
     'antinuke autorecovery']],
   ['Mainrole', ['mainrole', 'mainrole show', 'mainrole reset', 'mainrole remove', 'mainrole add']]]],
 ['Permit Commands',
  [['Extraowner', ['extraowner', 'extraowner remove', 'extraowner show', 'extraowner add', 'extraowner reset']],
   ['Trusted', ['trusted', 'trusted reset', 'trusted show', 'trusted remove', 'trusted add']],
   ['Fake Permissions',
    ['permissions',
     'permissions list',
     'permissions revoke',
     'permissions resetall',
     'permissions manage',
     'permissions grant']],
   ['Ignore',
    ['ignore',
     'ignore channel',
     'ignore channel remove',
     'ignore channel add',
     'ignore channel reset',
     'ignore channel show',
     'ignore role',
     'ignore role show',
     'ignore role reset',
     'ignore role remove',
     'ignore role add',
     'ignore command',
     'ignore command show',
     'ignore command add',
     'ignore command reset',
     'ignore command remove',
     'ignore bypass',
     'ignore bypass reset',
     'ignore bypass show',
     'ignore bypass add',
     'ignore bypass remove']]]],
 ['Automod',
  [['Automod',
    ['automod',
     'automod logging',
     'automod reset',
     'automod enable',
     'automod manage',
     'automod wlshow',
     'automod disable',
     'automod settings',
     'automod whitelist']],
   ['Word Blacklist', ['blword', 'blword show', 'blword remove', 'blword reset', 'blword add', 'blword guide']]]],
 ['Moderation',
  [['Basic Commands',
    ['ban',
     'softban',
     'kick',
     'mute',
     'unmute',
     'unban',
     'nick',
     'clone',
     'nuke',
     'hideall',
     'unhideall',
     'lockall',
     'unlockall',
     'unbanall',
     'lock',
     'unlock',
     'hide',
     'unhide',
     'slowmode',
     'unslowmode',
     'channel',
     'channel rename',
     'channel delete',
     'channel transfer',
     'channel deleteafter',
     'channel create',
     'enlarge',
     'steal',
     'deleteemoji',
     'deletesticker',
     'snipe']],
   ['Role Commands',
    ['role',
     'role all',
     'role icon',
     'role humans',
     'role delete',
     'role remove',
     'role add',
     'role colour',
     'role taskcancel',
     'role create',
     'role rename',
     'role bots',
     'rrole',
     'rrole humans',
     'rrole bots',
     'rrole all']],
   ['Purge Commands',
    ['clear',
     'clear embed',
     'clear files',
     'clear all',
     'clear bots',
     'clear reactions',
     'clear contain',
     'clear user',
     'clear image',
     'clear mentions',
     'clear emoji',
     'purgeuser',
     'purgebots']],
   ['Quarantine Commands',
    ['quarantine',
     'quarantine setup',
     'quarantine config',
     'quarantine remove',
     'quarantine show',
     'quarantine reset',
     'quarantine add',
     'unquarantine']]]],
 ['General',
  [['Basic Commands',
    ['afk',
     'membercount',
     'boostcount',
     'joinedat',
     'serverinfo',
     'userinfo',
     'channelinfo',
     'roleinfo',
     'avatar',
     'banner',
     'servericon',
     'serverbanner',
     'profile',
     'vote']],
   ['Bot Information',
    ['invite', 'stats', 'botinfo', 'ping', 'uptime', 'users', 'documentation', 'website', 'variables', 'purchase']],
   ['List Commands',
    ['list',
     'list inrole',
     'list invoice',
     'list createdat',
     'list early',
     'list joinedat',
     'list bans',
     'list activedeveloper',
     'list bughunters',
     'list hypesquad',
     'list pending',
     'list channels',
     'list timeouts',
     'list users',
     'list hasperms',
     'list boosters',
     'list emojis',
     'list bots',
     'list admins',
     'list mods',
     'list roles']]]],
 ['Verification System',
  [['Verification Commands',
    ['verify', 'verify forceverify', 'verify panel', 'verify show', 'verify setup', 'verify unverified']]]],
 ['Utility',
  [['Embed System',
    ['embed',
     'embed edit',
     'embed export',
     'embed delete',
     'embed rename',
     'embed save',
     'embed send',
     'embed import',
     'embed create',
     'embed show']],
   ['Sticky Message',
    ['sticky',
     'sticky show',
     'sticky reset',
     'sticky add',
     'sticky bump',
     'sticky remove',
     'sticky channel',
     'sticky channel remove',
     'sticky channel add']],
   ['Reaction Role',
    ['reactionrole',
     'reactionrole edit',
     'reactionrole remove',
     'reactionrole addmany',
     'reactionrole info',
     'reactionrole clone',
     'reactionrole clear',
     'reactionrole show',
     'reactionrole add',
     'reactionrole format',
     'reactionrole maxroles']]]],
 ['Automations',
  [['Auto Roles',
    ['autorole',
     'autorole bots',
     'autorole bots remove',
     'autorole bots reset',
     'autorole bots show',
     'autorole bots add',
     'autorole disable',
     'autorole enable',
     'autorole humans',
     'autorole humans show',
     'autorole humans remove',
     'autorole humans reset',
     'autorole humans add']],
   ['Notifier',
    ['notifier',
     'notifier message',
     'notifier channel',
     'notifier add',
     'notifier disable',
     'notifier test',
     'notifier show',
     'notifier reset',
     'notifier enable',
     'notifier remove']]]],
 ['Autoresponders',
  [['Auto Responders',
    ['autoresponder',
     'autoresponder rename',
     'autoresponder editreply',
     'autoresponder remove',
     'autoresponder show',
     'autoresponder reset',
     'autoresponder add']],
   ['Auto Reactors',
    ['autoreact',
     'autoreact remove',
     'autoreact editemojis',
     'autoreact add',
     'autoreact reset',
     'autoreact show',
     'autoreact rename']]]],
 ['Vanity & Tags',
  [['Vanity Roles <:0_:1509325949659775103><:1_:1509325967288569917><:2_:1509325980592902306>',
    ['vanityrole',
     'vanityrole enable',
     'vanityrole role',
     'vanityrole role add',
     'vanityrole role remove',
     'vanityrole reset',
     'vanityrole test',
     'vanityrole channel',
     'vanityrole show',
     'vanityrole setup',
     'vanityrole message',
     'vanityrole disable']],
   ['Guild Tags <:0_:1509325949659775103><:1_:1509325967288569917><:2_:1509325980592902306>',
    ['guildtag',
     'guildtag disable',
     'guildtag channel',
     'guildtag reset',
     'guildtag role',
     'guildtag role remove',
     'guildtag role add',
     'guildtag enable',
     'guildtag setup',
     'guildtag test',
     'guildtag show',
     'guildtag message']]]],
 ['Greetings',
  [['Welcomer',
    ['greet',
     'greet disable',
     'greet channel',
     'greet channel set',
     'greet channel reset',
     'greet delete',
     'greet config',
     'greet create',
     'greet test',
     'greet enable',
     'greet card',
     'greet style',
     'greet autodelete']],
   ['Join DM',
    ['joindm', 'joindm enable', 'joindm test', 'joindm reset', 'joindm set', 'joindm disable', 'joindm show']],
   ['Leave Msg',
    ['leavemsg',
     'leavemsg set',
     'leavemsg reset',
     'leavemsg disable',
     'leavemsg enable',
     'leavemsg show',
     'leavemsg test']],
   ['Boost Greet',
    ['boostgreet',
     'boostgreet show',
     'boostgreet test',
     'boostgreet enable',
     'boostgreet disable',
     'boostgreet reset',
     'boostgreet set']]]],
 ['Music',
  [['Music Commands',
    ['play',
     'nowplaying',
     'autoplay',
     'history',
     'queue',
     'lavalink',
     'join',
     'leave',
     'forcefix',
     'pause',
     'resume',
     'volume',
     'replay',
     'seek',
     'forward',
     'rewind',
     'loop',
     '247',
     'shuffle',
     'clearqueue',
     'remove',
     'move',
     'skip',
     'skipinto',
     'lyrics']],
   ['Filter Commands', ['filter', 'filter reset', 'filter toggle']]]],
 ['Fun Commands',
  [['Fun Commands',
    ['airkiss',
     'angrystare',
     'bite',
     'bonk',
     'brofist',
     'cuddle',
     'handhold',
     'hug',
     'kiss',
     'lick',
     'nom',
     'nuzzle',
     'pat',
     'pinch',
     'poke',
     'punch',
     'slap',
     'smack',
     'stare',
     'tickle',
     'wave',
     'bleh',
     'blush',
     'celebrate',
     'cheers',
     'clap',
     'confused',
     'cool',
     'cry',
     'dance',
     'drool',
     'evillaugh',
     'facepalm',
     'happy',
     'headbang',
     'huh',
     'laugh',
     'love',
     'mad',
     'nervous',
     'no',
     'nosebleed',
     'nyah',
     'peek',
     'pout',
     'roll',
     'run',
     'sad',
     'scared',
     'shout',
     'shrug',
     'shy',
     'sigh',
     'sing',
     'sip',
     'sleep',
     'slowclap',
     'smile',
     'smug',
     'sneeze',
     'sorry',
     'stop',
     'surprised',
     'sweat',
     'thumbsup',
     'tired',
     'wink',
     'yawn',
     'yay',
     'yes',
     'eightball',
     'reverse',
     'mock',
     'doublestruck',
     'emojipasta',
     'morse',
     'biden',
     'pikachu',
     'oogway',
     'drake',
     'pooh',
     'sadcat',
     'factsmeme',
     'unforgivable',
     'caution',
     'opinion',
     'gun',
     'drip',
     'blur',
     'invert',
     'greyscale',
     'advertise',
     'mnm',
     'pickup',
     'showerthought',
     'clown',
     'jailed',
     'wanted',
     'pet',
     'alert',
     'supreme',
     'whowouldwin',
     'nokia',
     'uncover',
     'jokeoverhead',
     'huerotate',
     'quote',
     'couldread',
     'caption',
     'colorify',
     'cat',
     'joke',
     'fact',
     'truth',
     'dare',
     'hack',
     'token']]]],
 ['CustomRole',
  [['Custom Role',
    ['customrole',
     'customrole list',
     'customrole create',
     'customrole reqrole',
     'customrole reset',
     'customrole delete']]]],
 ['Voice Commands',
  [['Voice Commands',
    ['voice',
     'voice muteall',
     'voice unmute',
     'voice moveall',
     'voice pullall',
     'voice undeafen',
     'voice private',
     'voice deafenall',
     'voice move',
     'voice unlock',
     'voice lock',
     'voice pull',
     'voice kickall',
     'voice unmuteall',
     'voice kick',
     'voice deafen',
     'voice unprivate',
     'voice mute',
     'voice undeafenall']],
   ['VC Roles', ['vcrole', 'vcrole reset', 'vcrole enable', 'vcrole disable', 'vcrole set', 'vcrole show']]]],
 ['Ticket Commands',
  [['Ticket Commands',
    ['ticket',
     'ticket remove',
     'ticket autotranscript',
     'ticket transcript',
     'ticket support',
     'ticket support add',
     'ticket support show',
     'ticket support remove',
     'ticket support reset',
     'ticket reopen',
     'ticket type',
     'ticket type create',
     'ticket type delete',
     'ticket type edit',
     'ticket rename',
     'ticket list',
     'ticket category',
     'ticket logging',
     'ticket close',
     'ticket add',
     'ticket delete',
     'ticket greetmsg',
     'ticket maxtickets',
     'ticket panel']]]],
 ['Logging Commands',
  [['Logging Commands',
    ['logging',
     'logging config',
     'logging enable',
     'logging disable',
     'logging setup',
     'logging setup auto',
     'logging setup channel',
     'logging setup clear',
     'logging wizard',
     'logging remove',
     'logging ignore',
     'logging ignore remove',
     'logging ignore add',
     'logging ignore voice',
     'logging ignore embed']]]],
 ['JTC Commands',
  [['Temp Voice',
    ['tempvc',
     'tempvc unhide',
     'tempvc hide',
     'tempvc lobby',
     'tempvc lobby remove',
     'tempvc lobby add',
     'tempvc lobby edit',
     'tempvc kick',
     'tempvc trust',
     'tempvc unlock',
     'tempvc config',
     'tempvc transfer',
     'tempvc limit',
     'tempvc untrust',
     'tempvc claim',
     'tempvc lock',
     'tempvc unban',
     'tempvc name',
     'tempvc ban']]]],
 ['Bot Settings',
  [['Profile', ['profile', 'bio', 'bio clear', 'bio set', 'badge', 'badge list', 'badge remove', 'badge add']],
   ['Branding',
    ['customize', 'customize nick', 'customize bio', 'customize reset', 'customize banner', 'customize avatar']],
   ['Prefix', ['prefix', 'prefix reset', 'prefix add', 'prefix show', 'prefix set', 'prefix remove']],
   ['Owner', ['owner', 'owner stats', 'owner list', 'owner add', 'owner remove', 'owner noprefix add', 'owner noprefix remove', 'owner noprefix list']]]]];

const CATEGORIES = [
  ['Security'], ['Permit Commands'], ['Automod'], ['Moderation'], ['General'], ['Verification'],
  ['Utility'], ['Automations'], ['Autoresponders'], ['Vanity & Tags'], ['Greetings'], ['Music'],
  ['Fun Commands'], ['CustomRole'], ['Voice Commands'], ['Tickets'], ['Logging'], ['Voice Master'],
];

const CATEGORY_EMOJIS = {
  'Security': ['anti_308', '1551629514512269493'],
  'Permit Commands': ['GirlOwners_361', '1551629533562535937'],
  'Automod': ['automodemoji', '1551631194326831176'],
  'Moderation': ['Mods_1641', '1551629517548683374'],
  'General': ['Snap_9742', '1551629923540533278'],
  'Verification System': ['arrkiii_11053', '1551630183528923159'],
  'Utility': ['config_14386', '1551629941836357677'],
  'Automations': ['links_15056', '1551629872525221949'],
  'Autoresponders': ['OxP_16908', '1551629885179699334'],
  'Vanity & Tags': ['vanity', '1551630665806516224'],
  'Greetings': ['welc_7862', '1551630712061304973'],
  'Music': ['music_8962', '1551630705258397848'],
  'Fun Commands': ['Partners_12142', '1551630757787729961'],
  'CustomRole': ['Mods_1641', '1551629517548683374'],
  'Voice Commands': ['volumehigh_5313', '1551630980819714121'],
  'Ticket Commands': ['profile_6431', '1551630971877728256'],
  'Logging Commands': ['Voters_14336', '1551630956241231948'],
  'JTC Commands': ['volumelow_3771', '1551631037321322622'],
  'Bot Settings': ['ping_4647', '1551631041565958296'],
};

const VANITY_EMOJIS = [
  ['0_', '1509325949659775103'],
  ['1_', '1509325967288569917'],
  ['2_', '1509325980592902306'],
];

function emoji(id, name, guild) {
  // Prefer the real emoji if the guild can resolve it.
  if (guild?.emojis?.cache?.has(id)) return `<:${name}:${id}>`;
  // Discord can render external emojis when the bot has Use External Emojis.
  // Returning the raw mention keeps the configured IDs intact.
  return `<:${name}:${id}>`;
}

function categoryEmoji(category, guild) {
  const pair = CATEGORY_EMOJIS[category];
  return pair ? emoji(pair[1], pair[0], guild) : '📁';
}

function vanityEmojiString(guild) {
  return VANITY_EMOJIS.map(([name, id]) => emoji(id, name, guild)).join('');
}

function commandText(commands) {
  return commands.map((c) => `\`${c}\``).join(', ');
}

function renderPage(pageIndex, guild) {
  const [title, sections] = PAGES[pageIndex];
  const body = sections.map(([section, commands]) => {
    let heading = `**__${section}__**`;
    if (title === 'Vanity & Tags') heading += ` ${vanityEmojiString(guild)}`;
    return `${heading}\n${commandText(commands)}`;
  }).join('\n\n');

  let description = body;

  if (title === 'Verification System') {
    description += [
      '',
      '',
      '**__How it works?__**',
      '',
      'Our verification system uses a secure web portal to help protect your server from bot-raids, VPNs, and suspicious accounts. Users who verify are checked for signals such as browser/device characteristics and network information. The system can reject verification when the available signals indicate unusually high risk.',
      '',
      '**__Disclaimer__**',
      '',
      'Users must have cookies enabled. VPN/proxy connections may be rejected, and a device can be denied if the verification system flags it as highly suspicious.',
    ].join('\n');
  }

  return {
    embeds: [makeEmbed({
      title: `${categoryEmoji(title, guild)} ${title}`,
      description: clip(description, 3900),
      color: HELP_COLOR,
      footer: `Powered By Aurora Devs • ${pageIndex + 1}/${PAGES.length}`,
      timestamp: false,
    })],
    components: buildComponents(pageIndex, guild),
  };
}

function buildComponents(pageIndex, guild) {
  const previous = new ButtonBuilder()
    .setCustomId(`help:prev:${pageIndex}`)
    .setLabel('‹')
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(pageIndex === 0);

  const remove = new ButtonBuilder()
    .setCustomId(`help:delete:${pageIndex}`)
    .setLabel('🗑')
    .setStyle(ButtonStyle.Secondary);

  const next = new ButtonBuilder()
    .setCustomId(`help:next:${pageIndex}`)
    .setLabel('›')
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(pageIndex === PAGES.length - 1);

  const modules = new ButtonBuilder()
    .setCustomId(`help:modules:${pageIndex}`)
    .setLabel('↕')
    .setStyle(ButtonStyle.Secondary);

  const page = new ButtonBuilder()
    .setCustomId(`help:page:${pageIndex}`)
    .setLabel(`${pageIndex + 1}/${PAGES.length}`)
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(true);

  const select = new StringSelectMenuBuilder()
    .setCustomId(`help:select:${pageIndex}`)
    .setPlaceholder('Select a module to see')
    .addOptions(PAGES.map(([name], i) => ({
      label: name,
      value: String(i),
      default: i === pageIndex,
      emoji: (() => {
        const pair = CATEGORY_EMOJIS[name];
        return pair ? { id: pair[1], name: pair[0] } : undefined;
      })(),
    })));

  return [
    new ActionRowBuilder().addComponents(previous, remove, next, modules, page),
    new ActionRowBuilder().addComponents(select),
  ];
}

function getPrefix(guildId) {
  return config.get(guildId, 'general').then((v) => v.prefix).catch(() => ',');
}

function landingComponents() {
  const select = new StringSelectMenuBuilder()
    .setCustomId('help:select:landing')
    .setPlaceholder('Select a module to see')
    .addOptions(PAGES.map(([name], i) => ({
      label: name,
      value: String(i),
      emoji: (() => {
        const pair = CATEGORY_EMOJIS[name];
        return pair ? { id: pair[1], name: pair[0] } : undefined;
      })(),
    })));

  return [new ActionRowBuilder().addComponents(select)];
}

function overview(prefix, guild) {
  const categoryLines = PAGES.map(([name]) =>
    `> ${categoryEmoji(name, guild)} \`»\` **${name}**`
  );

  // These two modules are shown in the overview because they are part of
  // Aurora's public module catalogue even when they do not have their own
  // dedicated 19-page command sheet yet.

  const commandCount = 580;

  return {
    embeds: [makeEmbed({
      title: `Hey, I'm ${getClient().user?.username ?? 'Aurora'}`,
      color: HELP_COLOR,
      thumbnail: getClient().user?.displayAvatarURL?.(),
      description: [
        `- **My prefix for this server is ** \`${prefix}\``,
        `- **Type \`${prefix}help [context]\` for more**`,
        `- **Total commands:** \`${commandCount}\``,
        '',
        ...categoryLines,
      ].join('\n'),
      footer: 'Powered By Aurora Devs',
      timestamp: false,
    })],
    components: landingComponents(),
  };
}

function resolve(context, prefix, guild) {
  const text = String(context ?? '').trim();
  if (!text) return overview(prefix, guild);

  const normalized = text.toLowerCase();
  const exactPage = PAGES.findIndex(([name]) => name.toLowerCase() === normalized);
  if (exactPage >= 0) return renderPage(exactPage, guild);

  // Also accept "page 3", "3", or a known top-level command name.
  const pageMatch = normalized.match(/^page\s*(\d+)$/) || normalized.match(/^(\d+)$/);
  if (pageMatch) {
    const index = Number(pageMatch[1]) - 1;
    if (index >= 0 && index < PAGES.length) return renderPage(index, guild);
  }

  const pageForCommand = PAGES.findIndex(([, sections]) =>
    sections.some(([, commands]) => commands.some((c) => c.toLowerCase() === normalized)),
  );
  if (pageForCommand >= 0) return renderPage(pageForCommand, guild);

  return null;
}

async function handleComponent(interaction) {
  const parts = String(interaction.customId).split(':');
  const action = parts[1];
  const current = Number(parts[2] ?? 0);
  const safeCurrent = Number.isInteger(current) && current >= 0 && current < PAGES.length ? current : 0;

  if (action === 'delete') {
    // This is a public help message, so deleting it removes it for everyone.
    return interaction.message.delete().catch(() => interaction.update({
      content: 'Help message expired.',
      embeds: [],
      components: [],
    }));
  }

  if (action === 'prev' || action === 'next') {
    const next = action === 'prev'
      ? Math.max(0, safeCurrent - 1)
      : Math.min(PAGES.length - 1, safeCurrent + 1);
    return interaction.update(renderPage(next, interaction.guild));
  }

  if (action === 'modules') {
    // The module selector below is the main navigation; this button simply
    // gives a quick private hint without changing the public help message.
    return interaction.reply({
      content: 'Use **Select a module to see** below to jump between all 19 help pages.',
      ephemeral: true,
    });
  }

  if (action === 'select') {
    const index = Number(interaction.values?.[0]);
    if (!Number.isInteger(index) || index < 0 || index >= PAGES.length) return;
    return interaction.update(renderPage(index, interaction.guild));
  }

  return undefined;
}

module.exports = {
  PAGES,
  CATEGORIES,
  resolve,
  overview,
  handleComponent,
  getPrefix,
};
