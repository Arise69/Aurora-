'use strict';
/**
 * Music playback (optional feature).
 *  - Direct audio URLs (mp3/ogg/wav/... over http/https) via FFmpeg.
 *  - YouTube search/URLs via the optional `play-dl` package.
 * Needs: @discordjs/voice, an Opus encoder (opusscript), libsodium-wrappers and FFmpeg (ffmpeg-static or system ffmpeg).
 * NOTE: streaming from YouTube may violate YouTube's Terms of Service and can break without notice; you are
 * responsible for compliance. Set ENABLE_MUSIC=false to disable the feature entirely.
 */
const { PermissionFlagsBits: P } = require('discord.js');
const env = require('../config/env');
const config = require('./guildConfig');
const logger = require('../utils/logger');
const { AppError } = require('../utils/errors');
const { assertPublicUrl } = require('../utils/netsafe');
const { COLORS } = require('../config/constants');
const { makeEmbed, clip } = require('../utils/embeds');

let voice = null;
let playdl = null;
if (env.musicEnabled) {
  try { voice = require('@discordjs/voice'); } catch { logger.warn('Music disabled: @discordjs/voice is not installed.'); }
  try { playdl = require('play-dl'); } catch { logger.info('play-dl not installed: only direct audio URLs can be played.'); }
}
const available = () => Boolean(voice);
const sessions = new Map(); // guildId -> Session

class Session {
  constructor(guild, textChannel) {
    this.guild = guild; this.textChannel = textChannel;
    this.queue = []; this.current = null; this.loop = 'off'; this.connection = null; this.idleTimer = null;
    this.player = voice.createAudioPlayer({ behaviors: { noSubscriber: voice.NoSubscriberBehavior.Pause } });
    this.player.on(voice.AudioPlayerStatus.Idle, () => this.advance());
    this.player.on('error', (err) => { logger.warn(`Audio player error: ${err.message}`); this.notify(`⚠️ Playback error for **${clip(this.current?.title ?? 'track', 80)}** — skipping.`); this.advance(); });
  }

  notify(text) { this.textChannel?.send({ content: text, allowedMentions: { parse: [] } }).catch(() => {}); }

  async connect(channel) {
    if (this.connection && this.connection.joinConfig.channelId === channel.id) return;
    this.connection?.destroy();
    this.connection = voice.joinVoiceChannel({ channelId: channel.id, guildId: this.guild.id, adapterCreator: this.guild.voiceAdapterCreator, selfDeaf: true });
    try { await voice.entersState(this.connection, voice.VoiceConnectionStatus.Ready, 15_000); }
    catch { this.destroy(); throw new AppError('I could not connect to that voice channel in time.'); }
    this.connection.on(voice.VoiceConnectionStatus.Disconnected, async () => {
      try {
        await Promise.race([
          voice.entersState(this.connection, voice.VoiceConnectionStatus.Signalling, 5000),
          voice.entersState(this.connection, voice.VoiceConnectionStatus.Connecting, 5000),
        ]);
      } catch { this.destroy(); }
    });
    this.connection.subscribe(this.player);
  }

  async advance() {
    clearTimeout(this.idleTimer);
    if (this.current && this.loop === 'track') this.queue.unshift(this.current);
    else if (this.current && this.loop === 'queue') this.queue.push(this.current);
    this.current = this.queue.shift() ?? null;
    if (!this.current) {
      this.idleTimer = setTimeout(() => this.destroy(), 180_000);
      this.idleTimer.unref?.();
      return;
    }
    try {
      const resource = await createResource(this.current);
      this.player.play(resource);
      this.notify(`🎶 Now playing **${clip(this.current.title, 100)}**`);
    } catch (err) {
      logger.warn(`Could not play track: ${err.message}`);
      this.notify(`⚠️ Couldn't play **${clip(this.current.title, 80)}** — skipping.`);
      this.current = null;
      this.advance();
    }
  }

  destroy() {
    clearTimeout(this.idleTimer);
    try { this.player.stop(true); } catch { /* ignore */ }
    try { this.connection?.destroy(); } catch { /* ignore */ }
    sessions.delete(this.guild.id);
  }
}

async function createResource(track) {
  if (track.kind === 'yt') {
    const stream = await playdl.stream(track.url, { quality: 2 });
    return voice.createAudioResource(stream.stream, { inputType: stream.type });
  }
  await assertPublicUrl(track.url, { allowHttp: true }); // re-check at play time
  return voice.createAudioResource(track.url);
}

const AUDIO_EXT = /\.(mp3|ogg|opus|wav|flac|m4a|aac|webm)(\?.*)?$/i;

async function resolveTrack(query, requestedBy) {
  if (/^https?:\/\//i.test(query)) {
    const isYt = /^https?:\/\/(www\.|music\.|m\.)?(youtube\.com|youtu\.be)\//i.test(query);
    if (isYt) {
      if (!playdl) throw new AppError('YouTube playback is not available on this bot (play-dl is not installed).');
      const info = await playdl.video_info(query).catch(() => null);
      if (!info) throw new AppError('I could not load that YouTube video.');
      const d = info.video_details;
      return { kind: 'yt', title: d.title ?? 'Unknown', url: d.url, seconds: d.durationInSec, requestedBy };
    }
    if (!AUDIO_EXT.test(query)) throw new AppError('Only YouTube links, search terms and direct audio file URLs (.mp3, .ogg, .wav, …) are supported.');
    try { await assertPublicUrl(query, { allowHttp: true }); } catch (err) { throw new AppError(err.message); }
    return { kind: 'url', title: decodeURIComponent(new URL(query).pathname.split('/').pop() || 'Audio'), url: query, seconds: 0, requestedBy };
  }
  if (!playdl) throw new AppError('Search is not available (play-dl is not installed). Provide a direct audio URL instead.');
  const results = await playdl.search(query, { limit: 1, source: { youtube: 'video' } }).catch(() => []);
  if (!results.length) throw new AppError('No results found.');
  const v = results[0];
  return { kind: 'yt', title: v.title ?? 'Unknown', url: v.url, seconds: v.durationInSec, requestedBy };
}

function sessionFor(guildId) { return sessions.get(guildId) ?? null; }

async function play({ guild, member, textChannel, query }) {
  if (!available()) throw new AppError('Music is not available on this bot.');
  const vc = member.voice.channel;
  if (!vc) throw new AppError('Join a voice channel first.');
  const perms = vc.permissionsFor(guild.members.me);
  if (!perms?.has([P.ViewChannel, P.Connect, P.Speak])) throw new AppError("I need permission to **connect and speak** in your voice channel.");
  const cfg = await config.get(guild.id, 'music');
  let session = sessions.get(guild.id);
  if (session && session.connection && session.guild.members.me.voice.channelId !== vc.id) throw new AppError("I'm already playing in another voice channel.");
  if (session && session.queue.length >= cfg.maxQueue) throw new AppError(`The queue is full (${cfg.maxQueue} tracks).`);

  const track = await resolveTrack(query.slice(0, 300), member.id);
  if (track.seconds && track.seconds > cfg.maxTrackMinutes * 60) throw new AppError(`Tracks are limited to ${cfg.maxTrackMinutes} minutes.`);
  if (!session) { session = new Session(guild, textChannel); sessions.set(guild.id, session); }
  session.textChannel = textChannel;
  await session.connect(vc);
  session.queue.push(track);
  const starting = !session.current && session.player.state.status === voice.AudioPlayerStatus.Idle;
  if (starting) await session.advance();
  return { track, position: starting ? 0 : session.queue.length };
}

/** DJ-role / same-channel gate for control commands. */
async function assertController(guild, member) {
  const session = sessions.get(guild.id);
  if (!session) throw new AppError('Nothing is playing.');
  if (member.voice.channelId !== guild.members.me.voice.channelId) throw new AppError('Join my voice channel to control the music.');
  const cfg = await config.get(guild.id, 'music');
  if (cfg.djRoleId && !member.roles.cache.has(cfg.djRoleId) && !member.permissions.has(P.ManageGuild)) throw new AppError(`Only members with <@&${cfg.djRoleId}> can control the music.`);
  return session;
}

const fmt = (s) => (s ? `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}` : 'live/unknown');

function queueEmbed(session) {
  const lines = session.queue.slice(0, 15).map((t, i) => `**${i + 1}.** ${clip(t.title, 70)} \`${fmt(t.seconds)}\``);
  return makeEmbed({
    title: '🎶 Queue', color: COLORS.primary,
    description: `**Now playing:** ${session.current ? clip(session.current.title, 90) : 'nothing'}\n\n${lines.join('\n') || '_The queue is empty._'}${session.queue.length > 15 ? `\n…and ${session.queue.length - 15} more` : ''}`,
    footer: `Loop: ${session.loop}`,
  });
}

/** Leave when the bot is alone in the channel. */
function onVoiceStateUpdate(oldState) {
  const session = sessions.get(oldState.guild.id);
  if (!session) return;
  const channel = oldState.guild.members.me?.voice.channel;
  if (!channel) return;
  if (channel.members.filter((m) => !m.user.bot).size === 0) {
    clearTimeout(session.aloneTimer);
    session.aloneTimer = setTimeout(() => {
      const ch = oldState.guild.members.me?.voice.channel;
      if (ch && ch.members.filter((m) => !m.user.bot).size === 0) session.destroy();
    }, 60_000);
    session.aloneTimer.unref?.();
  }
}

const shutdownAll = () => { for (const s of [...sessions.values()]) s.destroy(); };

module.exports = { available, sessionFor, play, assertController, queueEmbed, onVoiceStateUpdate, shutdownAll, fmt };
