'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const db = require('../database');
const logger = require('../utils/logger');
const { AppError } = require('../utils/errors');
const { shortId } = require('../utils/ids');
const { render, memberVars } = require('../utils/template');

const MATCH_TYPES = ['exact', 'contains', 'starts', 'ends'];
const MAX_PER_GUILD = 100;
const cache = new Map();      // guildId -> rows
const lastFired = new Map();  // `${id}:${channel}` -> ts

async function list(guildId) {
  if (!cache.has(guildId)) cache.set(guildId, await db.all('SELECT * FROM autoresponders WHERE guild_id = ? ORDER BY created_at', [guildId]));
  return cache.get(guildId);
}

async function add(guildId, { trigger, response, matchType, cooldownSec, by }) {
  trigger = trigger.trim().toLowerCase();
  if (!trigger || trigger.length > 100) throw new AppError('Trigger must be 1–100 characters.');
  if (!response.trim() || response.length > 1500) throw new AppError('Response must be 1–1500 characters.');
  if (!MATCH_TYPES.includes(matchType)) throw new AppError('Invalid match type.');
  const rows = await list(guildId);
  if (rows.length >= MAX_PER_GUILD) throw new AppError(`You can have at most ${MAX_PER_GUILD} autoresponders.`);
  if (rows.some((r) => r.trigger_text === trigger)) throw new AppError('An autoresponder with that trigger already exists.');
  const id = shortId(6);
  await db.run(
    'INSERT INTO autoresponders (id, guild_id, trigger_text, response, match_type, cooldown_sec, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [id, guildId, trigger, response, matchType, cooldownSec, by, Date.now()],
  );
  cache.delete(guildId);
  return id;
}

async function remove(guildId, idOrTrigger) {
  const res = await db.run('DELETE FROM autoresponders WHERE guild_id = ? AND (id = ? OR trigger_text = ?)', [guildId, idOrTrigger.toUpperCase(), idOrTrigger.toLowerCase()]);
  cache.delete(guildId);
  return res.changes > 0;
}

const matches = (row, text) => {
  switch (row.match_type) {
    case 'exact': return text === row.trigger_text;
    case 'starts': return text.startsWith(row.trigger_text);
    case 'ends': return text.endsWith(row.trigger_text);
    default: return text.includes(row.trigger_text);
  }
};

/** Replies to the first matching responder (per-channel cooldown). Returns true if one fired. */
async function process(message) {
  const rows = await list(message.guild.id);
  if (!rows.length || !message.content) return false;
  const text = message.content.toLowerCase().trim();
  const row = rows.find((r) => matches(r, text));
  if (!row) return false;
  const key = `${row.id}:${message.channelId}`;
  if (Date.now() - (lastFired.get(key) ?? 0) < row.cooldown_sec * 1000) return false;
  if (!message.channel.permissionsFor(message.guild.members.me)?.has([P.SendMessages])) return false;
  lastFired.set(key, Date.now());
  try {
    await message.reply({ content: render(row.response, memberVars(message.member)).slice(0, 2000), allowedMentions: { parse: [], repliedUser: false } });
  } catch (err) { logger.debug(`Autoresponder failed: ${err.message}`); }
  return true;
}

setInterval(() => { const cut = Date.now() - 3_600_000; for (const [k, t] of lastFired) if (t < cut) lastFired.delete(k); }, 600_000).unref();

module.exports = { MATCH_TYPES, list, add, remove, process };
