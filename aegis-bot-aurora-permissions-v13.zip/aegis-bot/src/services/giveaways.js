'use strict';
/**
 * Giveaways. All state lives in the database (giveaways + giveaway_entries); the scheduler polls for due
 * items every few seconds, so giveaways survive restarts and are ended late (never lost) after downtime.
 */
const crypto = require('node:crypto');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags, PermissionFlagsBits: P } = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logging = require('./logging');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { AppError } = require('../utils/errors');
const { shortId } = require('../utils/ids');
const { COLORS, LIMITS } = require('../config/constants');
const { makeEmbed, clip } = require('../utils/embeds');
const { respond, fail } = require('../utils/reply');
const { formatDuration, discordTime } = require('../utils/duration');

const updateTimers = new Map();

const parse = (r) => r && ({
  ...r,
  ends_at: Number(r.ends_at), starts_at: Number(r.starts_at),
  min_account_age_ms: Number(r.min_account_age_ms), min_member_age_ms: Number(r.min_member_age_ms),
  excluded_role_ids: JSON.parse(r.excluded_role_ids || '[]'),
  winner_ids: JSON.parse(r.winner_ids || '[]'),
});
const getGiveaway = async (id) => parse(await db.get('SELECT * FROM giveaways WHERE id = ?', [String(id).toUpperCase()]));
const countEntries = async (id) => Number((await db.get('SELECT COUNT(*) AS n FROM giveaway_entries WHERE giveaway_id = ?', [id])).n);

// ───────────── Rendering ─────────────
function requirementLines(gw) {
  const lines = [];
  if (gw.required_role_id) lines.push(`• Must have <@&${gw.required_role_id}>`);
  if (gw.excluded_role_ids.length) lines.push(`• Excluded: ${gw.excluded_role_ids.map((r) => `<@&${r}>`).join(' ')}`);
  if (gw.min_account_age_ms) lines.push(`• Account older than ${formatDuration(gw.min_account_age_ms)}`);
  if (gw.min_member_age_ms) lines.push(`• In server for ${formatDuration(gw.min_member_age_ms)}+`);
  return lines.length ? `\n**Requirements**\n${lines.join('\n')}` : '';
}

function buildActive(gw, entries) {
  const embed = makeEmbed({
    title: `🎉 ${gw.prize}`,
    color: COLORS.gold,
    description: [
      gw.description,
      '',
      `**Ends:** ${discordTime(gw.ends_at, 'R')} (${discordTime(gw.ends_at, 'f')})`,
      `**Hosted by:** <@${gw.host_id}>`,
      `**Winners:** ${gw.winner_count}`,
      `**Entries:** ${entries}`,
    ].filter((l) => l !== null && l !== undefined).join('\n') + requirementLines(gw),
    footer: `Giveaway ID: ${gw.id} • Ends`,
    timestamp: new Date(gw.ends_at),
  });
  const button = new ButtonBuilder().setCustomId(`gw:enter:${gw.id}`).setLabel(`Enter (${entries})`).setEmoji('🎉').setStyle(ButtonStyle.Primary);
  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(button)] };
}

function buildFinished(gw, entries, { cancelled = false } = {}) {
  const winners = gw.winner_ids;
  const embed = makeEmbed({
    title: `${cancelled ? '🚫' : '🏆'} ${gw.prize}${cancelled ? ' (cancelled)' : ''}`,
    color: cancelled ? COLORS.neutral : COLORS.success,
    description: [
      gw.description,
      '',
      cancelled ? '**This giveaway was cancelled.**' : `**Winner${winners.length === 1 ? '' : 's'}:** ${winners.length ? winners.map((w) => `<@${w}>`).join(', ') : 'No valid entries'}`,
      `**Hosted by:** <@${gw.host_id}>`,
      `**Entries:** ${entries}`,
    ].filter((l) => l !== null && l !== undefined).join('\n'),
    footer: `Giveaway ID: ${gw.id} • ${cancelled ? 'Cancelled' : 'Ended'}`,
  });
  const button = new ButtonBuilder().setCustomId(`gw:done:${gw.id}`).setLabel(cancelled ? 'Cancelled' : 'Ended').setEmoji('🎉').setStyle(ButtonStyle.Secondary).setDisabled(true);
  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(button)] };
}

async function fetchChannel(gw) {
  const client = getClient();
  return client.channels.cache.get(gw.channel_id) ?? (await client.channels.fetch(gw.channel_id).catch(() => null));
}

// ───────────── Eligibility ─────────────
/** Returns a human-readable reason the member cannot enter/win, or null when eligible. */
function eligibility(member, gw) {
  if (member.user.bot) return 'Bots cannot enter giveaways.';
  if (gw.required_role_id && !member.roles.cache.has(gw.required_role_id)) return `You need the <@&${gw.required_role_id}> role to enter.`;
  if (gw.excluded_role_ids.some((r) => member.roles.cache.has(r))) return 'One of your roles is excluded from this giveaway.';
  if (gw.min_account_age_ms && Date.now() - member.user.createdTimestamp < gw.min_account_age_ms) return `Your account must be older than ${formatDuration(gw.min_account_age_ms)}.`;
  if (gw.min_member_age_ms && Date.now() - (member.joinedTimestamp ?? Date.now()) < gw.min_member_age_ms) return `You must have been in this server for ${formatDuration(gw.min_member_age_ms)}.`;
  return null;
}

// ───────────── Creation / posting ─────────────
async function post(gw, guild) {
  const channel = await fetchChannel(gw);
  if (!channel?.isTextBased()) throw new AppError('The giveaway channel no longer exists.');
  const me = guild.members.me;
  if (!channel.permissionsFor(me)?.has([P.ViewChannel, P.SendMessages, P.EmbedLinks])) throw new AppError(`I can't send messages with embeds in <#${channel.id}>.`);
  const cfg = await config.get(guild.id, 'giveaways');
  const ping = gw.ping_role_id ?? cfg.pingRoleId;
  const msg = await channel.send({
    content: ping ? `<@&${ping}> 🎉 **New giveaway!**` : undefined,
    ...buildActive(gw, await countEntries(gw.id)),
    allowedMentions: { roles: ping ? [ping] : [] },
  });
  await db.run('UPDATE giveaways SET message_id = ? WHERE id = ?', [msg.id, gw.id]);
  gw.message_id = msg.id;
  return msg;
}

async function create({ guild, channel, hostId, prize, durationMs, winners = 1, description = null, requiredRoleId = null, excludedRoleIds = [], minAccountAgeMs = 0, minMemberAgeMs = 0, startInMs = 0, pingRoleId = null }) {
  prize = String(prize).replace(/\s+/g, ' ').trim();
  if (!prize || prize.length > 200) throw new AppError('The prize must be 1–200 characters.');
  if (description && description.length > 1000) throw new AppError('The description can be at most 1000 characters.');
  if (!Number.isInteger(winners) || winners < 1 || winners > 20) throw new AppError('Winners must be between 1 and 20.');
  if (durationMs < LIMITS.minGiveawayMs || durationMs > LIMITS.maxGiveawayMs) throw new AppError('Duration must be between 10 seconds and 60 days.');
  if (startInMs < 0 || startInMs > LIMITS.maxGiveawayMs) throw new AppError('The start delay must be at most 60 days.');
  const cfg = await config.get(guild.id, 'giveaways');
  const active = Number((await db.get(`SELECT COUNT(*) AS n FROM giveaways WHERE guild_id = ? AND status IN ('active', 'scheduled')`, [guild.id])).n);
  if (active >= cfg.maxActive) throw new AppError(`This server already has ${cfg.maxActive} active/scheduled giveaways.`);

  const now = Date.now();
  const gw = {
    id: shortId(6), guild_id: guild.id, channel_id: channel.id, message_id: null, host_id: hostId, prize, description,
    winner_count: winners, starts_at: now + startInMs, ends_at: now + startInMs + durationMs, duration_ms: durationMs,
    status: startInMs > 0 ? 'scheduled' : 'active', required_role_id: requiredRoleId, excluded_role_ids: excludedRoleIds,
    min_account_age_ms: minAccountAgeMs, min_member_age_ms: minMemberAgeMs, winner_ids: [], ping_role_id: pingRoleId,
  };
  await db.run(
    `INSERT INTO giveaways (id, guild_id, channel_id, host_id, prize, description, winner_count, starts_at, ends_at, duration_ms, status,
       required_role_id, excluded_role_ids, min_account_age_ms, min_member_age_ms, winner_ids, ping_role_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?)`,
    [gw.id, gw.guild_id, gw.channel_id, hostId, prize, description, winners, gw.starts_at, gw.ends_at, durationMs, gw.status,
      requiredRoleId, JSON.stringify(excludedRoleIds), minAccountAgeMs, minMemberAgeMs, pingRoleId, now],
  );
  if (gw.status === 'active') {
    try { await post(gw, guild); } catch (err) {
      await db.run('DELETE FROM giveaways WHERE id = ?', [gw.id]);
      throw err;
    }
  }
  await logging.send(guild, 'giveaways', makeEmbed({
    title: gw.status === 'scheduled' ? '🗓️ Giveaway scheduled' : '🎉 Giveaway created', color: COLORS.gold,
    fields: [
      { name: 'Prize', value: prize, inline: true }, { name: 'Winners', value: String(winners), inline: true },
      { name: 'Host', value: `<@${hostId}>`, inline: true }, { name: 'Channel', value: `<#${channel.id}>`, inline: true },
      { name: gw.status === 'scheduled' ? 'Starts' : 'Ends', value: discordTime(gw.status === 'scheduled' ? gw.starts_at : gw.ends_at, 'R'), inline: true },
    ],
    footer: `Giveaway ID: ${gw.id}`,
  }));
  return gw;
}

// ───────────── Entering ─────────────
async function enter(interaction, id) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const gw = await getGiveaway(id);
  if (!gw || gw.status !== 'active' || gw.ends_at <= Date.now()) throw new AppError('This giveaway is no longer accepting entries.');
  const problem = eligibility(interaction.member, gw);
  if (problem) throw new AppError(problem);
  const res = await db.run(
    'INSERT INTO giveaway_entries (giveaway_id, user_id, entered_at) VALUES (?, ?, ?) ON CONFLICT DO NOTHING',
    [gw.id, interaction.user.id, Date.now()],
  );
  if (res.changes === 0) {
    return respond(interaction, {
      content: "You're already entered in this giveaway. Good luck! 🍀",
      components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`gw:leave:${gw.id}`).setLabel('Leave giveaway').setStyle(ButtonStyle.Danger))],
    });
  }
  scheduleRefresh(gw.id);
  return respond(interaction, `🎉 You're in! Good luck winning **${clip(gw.prize, 100)}**.`);
}

async function leave(interaction, id) {
  await interaction.deferUpdate();
  const gw = await getGiveaway(id);
  if (!gw || gw.status !== 'active') return interaction.editReply({ content: 'This giveaway has already ended.', components: [] });
  await db.run('DELETE FROM giveaway_entries WHERE giveaway_id = ? AND user_id = ?', [gw.id, interaction.user.id]);
  scheduleRefresh(gw.id);
  return interaction.editReply({ content: 'You left the giveaway.', components: [] });
}

/** Debounced message refresh so the live entry count never hits Discord rate limits (max 1 edit / 7s / giveaway). */
function scheduleRefresh(id) {
  if (updateTimers.has(id)) return;
  const t = setTimeout(async () => {
    updateTimers.delete(id);
    try {
      const gw = await getGiveaway(id);
      if (!gw || gw.status !== 'active' || !gw.message_id) return;
      const channel = await fetchChannel(gw);
      await channel?.messages.edit(gw.message_id, buildActive(gw, await countEntries(id)));
    } catch (err) { logger.debug(`Giveaway refresh failed: ${err.message}`); }
  }, 7000);
  t.unref?.();
  updateTimers.set(id, t);
}

// ───────────── Winner selection ─────────────
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

/** Draws winners, skipping (and thereby replacing) anyone who left or no longer qualifies. */
async function pickWinners(guild, gw, count, exclude = []) {
  const skip = new Set(exclude);
  const rows = await db.all('SELECT user_id FROM giveaway_entries WHERE giveaway_id = ?', [gw.id]);
  const winners = [];
  let checked = 0;
  for (const userId of shuffle(rows.map((r) => r.user_id).filter((u) => !skip.has(u)))) {
    if (winners.length >= count || ++checked > count * 25 + 50) break;
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member || eligibility(member, gw)) continue;
    winners.push(userId);
  }
  return winners;
}

async function announce(gw, guild, winners, { rerolled = false } = {}) {
  const channel = await fetchChannel(gw);
  const link = gw.message_id ? `https://discord.com/channels/${guild.id}/${gw.channel_id}/${gw.message_id}` : null;
  if (channel?.isTextBased() && channel.permissionsFor(guild.members.me)?.has([P.ViewChannel, P.SendMessages])) {
    await channel.send({
      content: winners.length
        ? `🎉 ${rerolled ? 'New winner' : 'Congratulations'}${winners.length > 1 ? 's' : ''} ${winners.map((w) => `<@${w}>`).join(', ')}! You won **${clip(gw.prize, 200)}**!`
        : `😕 No valid entries for **${clip(gw.prize, 200)}** — nobody won.`,
      allowedMentions: { users: winners },
      reply: gw.message_id ? { messageReference: gw.message_id, failIfNotExists: false } : undefined,
      components: link ? [new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('View giveaway').setStyle(ButtonStyle.Link).setURL(link))] : [],
    }).catch((err) => logger.debug(`Winner announcement failed: ${err.message}`));
  }
  const cfg = await config.get(guild.id, 'giveaways');
  if (cfg.dmWinners) {
    for (const id of winners) {
      const user = await getClient().users.fetch(id).catch(() => null);
      await user?.send(`🎉 You won **${clip(gw.prize, 200)}** in **${guild.name}**!${link ? `\n${link}` : ''}`).catch(() => {});
    }
  }
}

async function editMessage(gw, payload) {
  if (!gw.message_id) return;
  try { (await fetchChannel(gw))?.messages.edit(gw.message_id, payload).catch(() => {}); } catch { /* channel gone */ }
}

// ───────────── Ending / reroll / cancel ─────────────
async function endGiveaway(id, { endedBy = null } = {}) {
  const gw = await getGiveaway(id);
  if (!gw) throw new AppError('No giveaway with that ID.');
  if (gw.status !== 'active') throw new AppError('That giveaway is not active.');
  const guild = getClient().guilds.cache.get(gw.guild_id);
  if (!guild) { await db.run(`UPDATE giveaways SET status = 'ended', ended_at = ? WHERE id = ?`, [Date.now(), gw.id]); return null; }

  const winners = await pickWinners(guild, gw, gw.winner_count);
  // Atomic claim: only one caller (scheduler or /giveaway end) can finish a giveaway.
  const claim = await db.run(
    `UPDATE giveaways SET status = 'ended', winner_ids = ?, ended_at = ? WHERE id = ? AND status = 'active'`,
    [JSON.stringify(winners), Date.now(), gw.id],
  );
  if (claim.changes === 0) throw new AppError('That giveaway was already ended.');
  gw.winner_ids = winners; gw.status = 'ended';

  const entries = await countEntries(gw.id);
  await editMessage(gw, buildFinished(gw, entries));
  await announce(gw, guild, winners);
  await logging.send(guild, 'giveaways', makeEmbed({
    title: '🏁 Giveaway completed', color: COLORS.success,
    fields: [
      { name: 'Prize', value: gw.prize, inline: true }, { name: 'Entries', value: String(entries), inline: true },
      { name: 'Winners', value: winners.length ? winners.map((w) => `<@${w}>`).join(', ') : 'None', inline: false },
      endedBy ? { name: 'Ended early by', value: `<@${endedBy}>`, inline: true } : null,
    ].filter(Boolean),
    footer: `Giveaway ID: ${gw.id}`,
  }));
  return { gw, winners };
}

async function reroll(guildId, id, count = null, by = null) {
  const gw = await getGiveaway(id);
  if (!gw || gw.guild_id !== guildId) throw new AppError('No giveaway with that ID in this server.');
  if (gw.status !== 'ended') throw new AppError('Only ended giveaways can be rerolled.');
  const guild = getClient().guilds.cache.get(guildId);
  const n = Math.min(Math.max(count ?? gw.winner_count, 1), 20);
  const winners = await pickWinners(guild, gw, n, gw.winner_ids);
  if (!winners.length) throw new AppError('There are no other eligible entrants to draw from.');
  gw.winner_ids = [...gw.winner_ids, ...winners];
  await db.run('UPDATE giveaways SET winner_ids = ? WHERE id = ?', [JSON.stringify(gw.winner_ids), gw.id]);
  await editMessage(gw, buildFinished(gw, await countEntries(gw.id)));
  await announce(gw, guild, winners, { rerolled: true });
  await logging.send(guild, 'giveaways', makeEmbed({
    title: '🔁 Giveaway rerolled', color: COLORS.info,
    fields: [
      { name: 'Prize', value: gw.prize, inline: true }, { name: 'New winners', value: winners.map((w) => `<@${w}>`).join(', ') },
      by ? { name: 'By', value: `<@${by}>`, inline: true } : null,
    ].filter(Boolean),
    footer: `Giveaway ID: ${gw.id}`,
  }));
  return winners;
}

async function cancel(guildId, id, by) {
  const gw = await getGiveaway(id);
  if (!gw || gw.guild_id !== guildId) throw new AppError('No giveaway with that ID in this server.');
  const res = await db.run(`UPDATE giveaways SET status = 'cancelled', ended_at = ? WHERE id = ? AND status IN ('active', 'scheduled')`, [Date.now(), gw.id]);
  if (res.changes === 0) throw new AppError('That giveaway is already finished.');
  await editMessage(gw, buildFinished(gw, await countEntries(gw.id), { cancelled: true }));
  const guild = getClient().guilds.cache.get(guildId);
  if (guild) {
    await logging.send(guild, 'giveaways', makeEmbed({
      title: '🚫 Giveaway cancelled', color: COLORS.neutral,
      fields: [{ name: 'Prize', value: gw.prize, inline: true }, { name: 'Cancelled by', value: `<@${by}>`, inline: true }],
      footer: `Giveaway ID: ${gw.id}`,
    }));
  }
  return gw;
}

async function listGiveaways(guildId, statuses = ['active', 'scheduled'], query = '', limit = 25) {
  const marks = statuses.map(() => '?').join(',');
  const rows = await db.all(
    `SELECT * FROM giveaways WHERE guild_id = ? AND status IN (${marks}) ORDER BY ends_at ASC LIMIT 100`, [guildId, ...statuses],
  );
  const q = query.toLowerCase();
  return rows.map(parse).filter((g) => !q || g.prize.toLowerCase().includes(q) || g.id.toLowerCase().includes(q)).slice(0, limit);
}

// ───────────── Scheduler / component hooks ─────────────
async function tick() {
  const now = Date.now();
  const starts = await db.all(`SELECT id FROM giveaways WHERE status = 'scheduled' AND starts_at <= ? LIMIT 10`, [now]);
  for (const { id } of starts) {
    try {
      const claim = await db.run(`UPDATE giveaways SET status = 'active' WHERE id = ? AND status = 'scheduled'`, [id]);
      if (claim.changes === 0) continue;
      const gw = await getGiveaway(id);
      const guild = getClient().guilds.cache.get(gw.guild_id);
      if (!guild) continue;
      await post(gw, guild);
    } catch (err) {
      logger.warn(`Scheduled giveaway ${id} failed to start: ${err.message}`);
      await db.run(`UPDATE giveaways SET status = 'cancelled' WHERE id = ?`, [id]);
    }
  }
  const due = await db.all(`SELECT id FROM giveaways WHERE status = 'active' AND ends_at <= ? LIMIT 10`, [now]);
  for (const { id } of due) {
    try { await endGiveaway(id); } catch (err) { if (!(err instanceof AppError)) logger.error(`Ending giveaway ${id} failed`, err); }
  }
}

async function handleComponent(interaction) {
  const [, action, id] = interaction.customId.split(':');
  if (!interaction.inGuild()) return null;
  if (action === 'enter') return enter(interaction, id);
  if (action === 'leave') return leave(interaction, id);
  return fail(interaction, 'This giveaway is no longer active.');
}

module.exports = { create, endGiveaway, reroll, cancel, listGiveaways, getGiveaway, countEntries, eligibility, tick, handleComponent, shuffle };
