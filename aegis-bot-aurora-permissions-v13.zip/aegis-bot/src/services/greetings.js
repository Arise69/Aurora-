'use strict';
const { MessageType, PermissionFlagsBits: P } = require('discord.js');
const config = require('./guildConfig');
const logger = require('../utils/logger');
const { COLORS } = require('../config/constants');
const { makeEmbed } = require('../utils/embeds');
const { render, memberVars } = require('../utils/template');

const BOOST_TYPES = new Set([MessageType.GuildBoost, MessageType.GuildBoostTier1, MessageType.GuildBoostTier2, MessageType.GuildBoostTier3]);

async function sendGreeting(kind, member) {
  const cfg = (await config.get(member.guild.id, 'greetings'))[kind];
  if (!cfg.enabled) return false;
  const text = render(cfg.message, memberVars(member)).slice(0, 2000);
  const payload = cfg.embed
    ? { embeds: [makeEmbed({ description: text, color: kind === 'leave' ? COLORS.neutral : kind === 'boost' ? 0xf47fff : COLORS.success, thumbnail: member.user.displayAvatarURL?.(), footer: member.guild.name })] }
    : { content: text };
  const allowedMentions = kind === 'leave' ? { parse: [] } : { users: [member.id] };

  if (cfg.dm && kind !== 'leave') await member.send({ ...payload, allowedMentions }).catch(() => {});
  if (!cfg.channelId) return true;
  const channel = member.guild.channels.cache.get(cfg.channelId);
  if (!channel?.isTextBased() || !channel.permissionsFor(member.guild.members.me)?.has([P.ViewChannel, P.SendMessages])) return false;
  try {
    const msg = await channel.send({ ...payload, allowedMentions });
    if (cfg.deleteAfterSec > 0) setTimeout(() => msg.delete().catch(() => {}), cfg.deleteAfterSec * 1000).unref?.();
  } catch (err) { logger.debug(`Greeting failed: ${err.message}`); }
  return true;
}

/** Boost greetings use the system message so they work without member caching. */
async function onSystemMessage(message) {
  if (!message.guild || !BOOST_TYPES.has(message.type)) return;
  const member = message.member ?? await message.guild.members.fetch(message.author.id).catch(() => null);
  if (member) await sendGreeting('boost', member);
}

module.exports = { sendGreeting, onSystemMessage };
