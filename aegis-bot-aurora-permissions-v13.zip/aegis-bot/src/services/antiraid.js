'use strict';
/**
 * Anti-raid: join-rate detection, optional automatic lockdown, safe recovery.
 *
 * Lockdown safety design (administrators can never lock themselves out):
 *  - Only @everyone's SendMessages / SendMessagesInThreads are touched, and only when lockChannels is on.
 *    Roles with explicit allow overwrites and Administrators are unaffected; View/UseApplicationCommands are never denied,
 *    so /raid unlock always works.
 *  - The previous overwrite state of every channel is stored in the database and restored exactly.
 *  - Lockdowns always expire (1 minute .. 24 hours) and expired ones are reconciled on startup and every scheduler tick.
 *  - Suspicious joiners are timed out only until the lockdown ends, and released afterwards.
 */
const { ChannelType, PermissionFlagsBits: P } = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logging = require('./logging');
const permit = require('./permit');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { AppError } = require('../utils/errors');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser } = require('../utils/embeds');
const { formatDuration, discordTime } = require('../utils/duration');

const MIN_MS = 60_000;
const MAX_MS = 24 * 3_600_000;
const joins = new Map();          // guildId -> [{ ts, id }]
const raidCooldown = new Map();   // guildId -> ts
const lockCache = new Map();      // guildId -> row | null

const LOCKABLE = new Set([ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum]);

async function getLockdown(guildId) {
  if (lockCache.has(guildId)) return lockCache.get(guildId);
  const row = await db.get('SELECT * FROM lockdowns WHERE guild_id = ?', [guildId]);
  const parsed = row && {
    ...row,
    channel_state: JSON.parse(row.channel_state || '{}'),
    restricted_users: JSON.parse(row.restricted_users || '[]'),
  };
  lockCache.set(guildId, parsed ?? null);
  return parsed ?? null;
}

const isLockedDown = async (guildId) => Boolean(await getLockdown(guildId));

async function lockChannels(guild, cfg, reason) {
  const verification = await config.get(guild.id, 'verification');
  const skip = new Set([...cfg.excludedChannels, verification.channelId].filter(Boolean));
  const state = {};
  let count = 0;
  for (const channel of guild.channels.cache.values()) {
    if (!LOCKABLE.has(channel.type) || skip.has(channel.id) || !channel.manageable || count >= 200) continue;
    const overwrite = channel.permissionOverwrites.cache.get(guild.id);
    if (overwrite?.deny.has(P.SendMessages)) continue; // already locked by staff – leave alone
    state[channel.id] = {
      s: overwrite?.allow.has(P.SendMessages) ? 'allow' : 'neutral',
      t: overwrite?.allow.has(P.SendMessagesInThreads) ? 'allow' : 'neutral',
    };
    try {
      await channel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: false, SendMessagesInThreads: false }, { reason });
      count += 1;
    } catch (err) {
      delete state[channel.id];
      logger.debug(`Lockdown: could not lock ${channel.id}: ${err.message}`);
    }
  }
  return state;
}

async function unlockChannels(guild, state, reason) {
  let failed = 0;
  for (const [channelId, prev] of Object.entries(state)) {
    const channel = guild.channels.cache.get(channelId);
    if (!channel) continue;
    try {
      await channel.permissionOverwrites.edit(guild.roles.everyone, {
        SendMessages: prev.s === 'allow' ? true : null,
        SendMessagesInThreads: prev.t === 'allow' ? true : null,
      }, { reason });
    } catch { failed += 1; }
  }
  return failed;
}

/** Starts (or extends) a lockdown. */
async function startLockdown(guild, { durationMs, reason = 'Lockdown', startedBy = null, auto = false } = {}) {
  const cfg = await config.get(guild.id, 'antiraid');
  const ms = Math.min(Math.max(durationMs ?? cfg.lockdownDurationMin * 60_000, MIN_MS), MAX_MS);
  const now = Date.now();
  const existing = await getLockdown(guild.id);
  if (existing) {
    await db.run('UPDATE lockdowns SET ends_at = ?, reason = ? WHERE guild_id = ?', [now + ms, reason, guild.id]);
    lockCache.delete(guild.id);
    return { extended: true, endsAt: now + ms };
  }
  let state = {};
  if (cfg.lockChannels) {
    const me = guild.members.me;
    if (!me.permissions.has([P.ManageChannels, P.ManageRoles])) {
      throw new AppError('Channel locking needs the **Manage Channels** and **Manage Roles** permissions.');
    }
    state = await lockChannels(guild, cfg, `Lockdown: ${reason}`);
  }
  await db.run(
    `INSERT INTO lockdowns (guild_id, started_at, ends_at, reason, started_by, channel_state, restricted_users) VALUES (?, ?, ?, ?, ?, ?, '[]')`,
    [guild.id, now, now + ms, reason, startedBy, JSON.stringify(state)],
  );
  lockCache.delete(guild.id);
  await logging.send(guild, 'security', makeEmbed({
    title: '🔒 Lockdown enabled', color: COLORS.security,
    fields: [
      { name: 'Started by', value: startedBy ? `<@${startedBy}>` : '🤖 Automatic (raid detection)', inline: true },
      { name: 'Ends', value: `${discordTime(now + ms, 'R')} (${formatDuration(ms)})`, inline: true },
      { name: 'Channels locked', value: cfg.lockChannels ? String(Object.keys(state).length) : 'Disabled in config', inline: true },
      { name: 'Reason', value: reason },
      { name: 'Recovery', value: 'Use `/raid unlock` at any time. Lockdown ends automatically.' },
    ],
  }));
  return { extended: false, endsAt: now + ms, auto };
}

async function endLockdown(guild, { by = null, reason = 'Lockdown ended' } = {}) {
  const row = await getLockdown(guild.id);
  if (!row) throw new AppError('This server is not in lockdown.');
  // Remove the row first: even if restoration partially fails, the server is never stuck "in lockdown".
  await db.run('DELETE FROM lockdowns WHERE guild_id = ?', [guild.id]);
  lockCache.set(guild.id, null);

  const failedChannels = await unlockChannels(guild, row.channel_state, `Lockdown ended: ${reason}`);
  let released = 0;
  for (const userId of row.restricted_users) {
    const member = await guild.members.fetch(userId).catch(() => null);
    // only lift timeouts that were ours (expiring at/near the lockdown end)
    if (member?.communicationDisabledUntilTimestamp && member.communicationDisabledUntilTimestamp <= row.ends_at + 120_000 && member.moderatable) {
      if (await member.timeout(null, 'Lockdown ended').then(() => true, () => false)) released += 1;
    }
  }
  await logging.send(guild, 'security', makeEmbed({
    title: '🔓 Lockdown ended', color: COLORS.success,
    fields: [
      { name: 'Ended by', value: by ? `<@${by}>` : '⏱️ Automatically', inline: true },
      { name: 'Channels restored', value: String(Object.keys(row.channel_state).length - failedChannels), inline: true },
      { name: 'Users released', value: String(released), inline: true },
      failedChannels ? { name: '⚠️ Could not restore', value: `${failedChannels} channel(s) — check permissions manually.` } : null,
    ].filter(Boolean),
  }));
  return { failedChannels, released };
}

/** Handles a new member during lockdown and feeds the join-rate detector. */
async function onMemberJoin(member) {
  const { guild } = member;
  const cfg = await config.get(guild.id, 'antiraid');
  if (!cfg.enabled) return;

  const lock = await getLockdown(guild.id);
  let removed = false;
  if (lock) removed = await enforceOnJoiner(member, cfg, lock);

  if (member.user.bot) return removed;
  const now = Date.now();
  const window = cfg.joinWindowSec * 1000;
  const list = (joins.get(guild.id) ?? []).filter((j) => now - j.ts <= window);
  list.push({ ts: now, id: member.id });
  joins.set(guild.id, list);

  if (list.length >= cfg.joinThreshold && now - (raidCooldown.get(guild.id) ?? 0) > 60_000) {
    raidCooldown.set(guild.id, now);
    await onRaidDetected(guild, cfg, list).catch((err) => logger.error('Raid handler failed', err));
  }
  return removed;
}

async function enforceOnJoiner(member, cfg, lock) {
  if (member.user.bot || cfg.newAccountAction === 'none') return false;
  const ageMs = Date.now() - member.user.createdTimestamp;
  if (ageMs >= cfg.newAccountAgeHours * 3_600_000) return false;
  if (await permit.isPermitted(member.guild.id, member, 'antiraid')) return false;
  const reason = 'Server lockdown: new accounts are restricted';
  try {
    if (cfg.newAccountAction === 'kick') {
      if (!member.kickable) return false;
      await member.send('This server is temporarily locked down. Please try joining again later.').catch(() => {});
      await member.kick(reason);
    } else {
      if (!member.moderatable) return false;
      const ms = Math.max(lock.ends_at - Date.now(), MIN_MS);
      await member.timeout(Math.min(ms, 28 * 86_400_000), reason);
      lock.restricted_users.push(member.id);
      lock.restricted_users = lock.restricted_users.slice(-500);
      await db.run('UPDATE lockdowns SET restricted_users = ? WHERE guild_id = ?', [JSON.stringify(lock.restricted_users), member.guild.id]);
    }
    await logging.send(member.guild, 'security', makeEmbed({
      title: `🛑 New account ${cfg.newAccountAction === 'kick' ? 'kicked' : 'restricted'} during lockdown`, color: COLORS.security,
      fields: [
        { name: 'User', value: describeUser(member.user), inline: true },
        { name: 'Account created', value: discordTime(member.user.createdTimestamp, 'R'), inline: true },
      ],
    }));
    return cfg.newAccountAction === 'kick';
  } catch (err) { logger.debug(`Lockdown enforcement failed: ${err.message}`); return false; }
}

async function onRaidDetected(guild, cfg, recent) {
  const ids = recent.map((j) => j.id);
  let lockdownNote = 'Automatic lockdown is **off**. Use `/raid lockdown` if needed.';
  if (cfg.autoLockdown && !(await isLockedDown(guild.id))) {
    try {
      await startLockdown(guild, { reason: `Raid detected: ${ids.length} joins in ${cfg.joinWindowSec}s`, auto: true });
      lockdownNote = `🔒 Lockdown enabled for ${cfg.lockdownDurationMin} minute(s).`;
      const lock = await getLockdown(guild.id);
      for (const id of ids) { // catch the burst that triggered detection
        const m = guild.members.cache.get(id);
        if (m && lock) await enforceOnJoiner(m, cfg, lock);
      }
    } catch (err) { lockdownNote = `⚠️ Automatic lockdown failed: ${err.message}`; }
  } else if (cfg.autoLockdown) lockdownNote = '🔒 Server is already in lockdown.';

  await logging.send(guild, 'security', makeEmbed({
    title: '🚨 Possible raid detected', color: COLORS.security,
    description: `**${ids.length}** members joined within **${cfg.joinWindowSec}s** (threshold: ${cfg.joinThreshold}).`,
    fields: [
      { name: 'Recent joiners', value: ids.slice(0, 15).map((i) => `<@${i}>`).join(' ') + (ids.length > 15 ? ` …+${ids.length - 15}` : '') },
      { name: 'Response', value: lockdownNote },
    ],
  }), cfg.alertRoleId ? { content: `<@&${cfg.alertRoleId}>`, allowedMentions: { roles: [cfg.alertRoleId] } } : {});
}

async function status(guild) {
  const cfg = await config.get(guild.id, 'antiraid');
  const now = Date.now();
  const recent = (joins.get(guild.id) ?? []).filter((j) => now - j.ts <= cfg.joinWindowSec * 1000).length;
  return { cfg, recentJoins: recent, lockdown: await getLockdown(guild.id) };
}

/** Scheduler hook: end expired lockdowns (also runs right after startup, recovering from downtime). */
async function tick() {
  const due = await db.all('SELECT guild_id FROM lockdowns WHERE ends_at <= ?', [Date.now()]);
  for (const { guild_id: guildId } of due) {
    const guild = getClient().guilds.cache.get(guildId);
    if (!guild) { await db.run('DELETE FROM lockdowns WHERE guild_id = ?', [guildId]); lockCache.delete(guildId); continue; }
    await endLockdown(guild, { reason: 'Duration elapsed' }).catch((err) => logger.warn(`Auto-unlock failed in ${guildId}: ${err.message}`));
  }
  const cut = Date.now() - 300_000;
  for (const [g, list] of joins) if (!list.length || list[list.length - 1].ts < cut) joins.delete(g);
}

module.exports = { isLockedDown, getLockdown, startLockdown, endLockdown, onMemberJoin, status, tick, MIN_MS, MAX_MS };
