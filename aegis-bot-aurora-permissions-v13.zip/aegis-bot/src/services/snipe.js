'use strict';

const MAX = 50;
const recent = new Map();

function remember(message) {
  if (!message?.guild || !message.channelId || !message.author) return;
  const row = {
    id: message.id,
    authorId: message.author.id,
    authorTag: message.author.tag,
    content: String(message.content || ''),
    createdAt: message.createdTimestamp || Date.now(),
    attachmentNames: [...(message.attachments?.values?.() || [])].map(a => a.name).filter(Boolean),
  };
  const list = recent.get(message.channelId) || [];
  list.unshift(row);
  if (list.length > 10) list.length = 10;
  recent.set(message.channelId, list);
}

function latest(channelId, index = 0) {
  const list = recent.get(channelId) || [];
  return list[index] || null;
}

function clear(channelId) {
  recent.delete(channelId);
}

module.exports = { remember, latest, clear };
