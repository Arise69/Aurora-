'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logger = require('../utils/logger');
const { AppError } = require('../utils/errors');

const HEX = /^#?([0-9a-f]{6})$/i;
const cooldown = new Map();

function cleanName(name, cfg) {
  const n = String(name).replace(/[\u0000-\u001f\u007f\u200b-\u200f@]/g, '').replace(/\s+/g, ' ').trim();
  if (!n) throw new AppError('Please provide a role name.');
  if (n.length > cfg.maxNameLength) throw new AppError(`Role names can be at most ${cfg.maxNameLength} characters.`);
  const lower = n.toLowerCase();
  if (cfg.blockedNames.some((b) => lower.includes(b))) throw new AppError('That name is not allowed.');
  return n;
}

function parseColor(color) {
  if (!color) return undefined;
  const m = HEX.exec(color.trim());
  if (!m) throw new AppError('Colors must be hex codes like `#ff66aa`.');
  return `#${m[1]}`;
}

async function checkEligible(member, cfg) {
  if (!cfg.enabled) throw new AppError('Custom roles are not enabled on this server.');
  const ok = (cfg.boostersOnly && member.premiumSince) || (cfg.requiredRoleId && member.roles.cache.has(cfg.requiredRoleId)) ||
    (!cfg.boostersOnly && !cfg.requiredRoleId) || member.permissions.has(P.Administrator);
  if (!ok) throw new AppError(cfg.boostersOnly ? 'Custom roles are for server boosters.' : 'You do not have the required role for a custom role.');
}

const getRow = (guildId, userId) => db.get('SELECT * FROM custom_roles WHERE guild_id = ? AND user_id = ?', [guildId, userId]);

async function create(member, name, color) {
  const { guild } = member;
  const cfg = await config.get(guild.id, 'customroles');
  await checkEligible(member, cfg);
  if (await getRow(guild.id, member.id)) throw new AppError('You already have a custom role. Use `/customrole edit` or delete it first.');
  if (Date.now() - (cooldown.get(member.id) ?? 0) < 30_000) throw new AppError('Please wait a bit before creating another role.');
  cooldown.set(member.id, Date.now());
  const me = guild.members.me;
  if (!me.permissions.has(P.ManageRoles)) throw new AppError('I need the **Manage Roles** permission.');

  const role = await guild.roles.create({
    name: cleanName(name, cfg), color: parseColor(color), permissions: [], mentionable: false, hoist: false,
    reason: `Custom role for ${member.user.username}`,
  });
  const base = cfg.baseRoleId ? guild.roles.cache.get(cfg.baseRoleId) : null;
  if (base && me.roles.highest.comparePositionTo(base) > 0) await role.setPosition(base.position).catch((err) => logger.debug(`Custom role position: ${err.message}`));
  await member.roles.add(role, 'Custom role owner');
  await db.run('INSERT INTO custom_roles (guild_id, user_id, role_id, created_at) VALUES (?, ?, ?, ?)', [guild.id, member.id, role.id, Date.now()]);
  return role;
}

async function ownedRole(member) {
  const row = await getRow(member.guild.id, member.id);
  const role = row && member.guild.roles.cache.get(row.role_id);
  if (!role) {
    if (row) await db.run('DELETE FROM custom_roles WHERE guild_id = ? AND user_id = ?', [member.guild.id, member.id]);
    throw new AppError("You don't have a custom role.");
  }
  return role;
}

async function edit(member, { name, color }) {
  const cfg = await config.get(member.guild.id, 'customroles');
  await checkEligible(member, cfg);
  const role = await ownedRole(member);
  if (!name && !color) throw new AppError('Provide a new name and/or color.');
  await role.edit({ name: name ? cleanName(name, cfg) : undefined, color: parseColor(color), reason: 'Custom role edited by owner' });
  return role;
}

async function remove(member) {
  const role = await ownedRole(member);
  await role.delete('Custom role deleted by owner');
  await db.run('DELETE FROM custom_roles WHERE guild_id = ? AND user_id = ?', [member.guild.id, member.id]);
}

/** Cleanup when the owner leaves or the role disappears. */
async function onMemberLeave(member) {
  const row = await getRow(member.guild.id, member.id);
  if (!row) return;
  await member.guild.roles.cache.get(row.role_id)?.delete('Custom role owner left').catch(() => {});
  await db.run('DELETE FROM custom_roles WHERE guild_id = ? AND user_id = ?', [member.guild.id, member.id]);
}
const onRoleDelete = (role) => db.run('DELETE FROM custom_roles WHERE guild_id = ? AND role_id = ?', [role.guild.id, role.id]);

module.exports = { create, edit, remove, ownedRole, onMemberLeave, onRoleDelete, getRow };
