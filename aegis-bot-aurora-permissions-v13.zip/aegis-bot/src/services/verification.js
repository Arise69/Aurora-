'use strict';
const crypto = require('node:crypto');
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags, PermissionFlagsBits: P,
} = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logging = require('./logging');
const logger = require('../utils/logger');
const { AppError } = require('../utils/errors');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser } = require('../utils/embeds');
const { respond, fail } = require('../utils/reply');
const { formatDuration, discordTime } = require('../utils/duration');

const CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const codes = new Map();     // `${guild}:${user}` -> { code, expires }
const lastPress = new Map(); // `${guild}:${user}` -> ts

function buildPanel(cfg) {
  return {
    embeds: [makeEmbed({ title: `✅ ${cfg.title}`, description: cfg.description, color: COLORS.success, timestamp: false })],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('verify:start').setLabel('Verify').setEmoji('✅').setStyle(ButtonStyle.Success),
    )],
  };
}

async function postPanel(guild, channel, cfg) {
  const me = guild.members.me;
  if (!channel.permissionsFor(me)?.has([P.ViewChannel, P.SendMessages, P.EmbedLinks])) {
    throw new AppError(`I can't send messages with embeds in ${channel}.`);
  }
  const msg = await channel.send(buildPanel(cfg));
  return msg;
}

async function getAttempts(guildId, userId) {
  return db.get('SELECT failures, locked_until FROM verification_attempts WHERE guild_id = ? AND user_id = ?', [guildId, userId]);
}

async function recordFailure(guildId, userId, cfg) {
  const now = Date.now();
  await db.run(
    `INSERT INTO verification_attempts (guild_id, user_id, failures, last_attempt_at, locked_until) VALUES (?, ?, 1, ?, 0)
     ON CONFLICT (guild_id, user_id) DO UPDATE SET failures = verification_attempts.failures + 1, last_attempt_at = excluded.last_attempt_at`,
    [guildId, userId, now],
  );
  const row = await getAttempts(guildId, userId);
  if (Number(row.failures) >= cfg.maxAttempts) {
    await db.run('UPDATE verification_attempts SET failures = 0, locked_until = ? WHERE guild_id = ? AND user_id = ?', [now + cfg.lockoutMin * 60_000, guildId, userId]);
    return { locked: true, remaining: 0 };
  }
  return { locked: false, remaining: cfg.maxAttempts - Number(row.failures) };
}

const logEvent = (guild, title, color, member, extra = []) =>
  logging.send(guild, 'verification', makeEmbed({
    title, color, fields: [{ name: 'User', value: describeUser(member.user), inline: true }, ...extra], footer: `User ID: ${member.id}`,
  }));

async function grant(interaction, cfg) {
  const { guild, member } = interaction;
  const role = guild.roles.cache.get(cfg.roleId);
  const me = guild.members.me;
  if (!role || !me.permissions.has(P.ManageRoles) || me.roles.highest.comparePositionTo(role) <= 0) {
    await logEvent(guild, '⚠️ Verification misconfigured', COLORS.warning, member, [{ name: 'Problem', value: 'The verified role is missing or above my highest role.' }]);
    throw new AppError('Verification is not set up correctly. Please contact a moderator.');
  }
  await member.roles.add(role, 'Passed verification');
  if (cfg.unverifiedRoleId && member.roles.cache.has(cfg.unverifiedRoleId)) await member.roles.remove(cfg.unverifiedRoleId, 'Passed verification').catch(() => {});
  await db.run('DELETE FROM verification_attempts WHERE guild_id = ? AND user_id = ?', [guild.id, member.id]);
  codes.delete(`${guild.id}:${member.id}`);
  await logEvent(guild, '✅ Member verified', COLORS.success, member, [{ name: 'Mode', value: cfg.mode, inline: true }]);
  return respond(interaction, `✅ You're verified! Welcome to **${guild.name}**.`);
}

async function start(interaction) {
  const { guild, member } = interaction;
  const cfg = await config.get(guild.id, 'verification');
  if (!cfg.enabled || !cfg.roleId) throw new AppError('Verification is currently disabled.');
  if (member.roles.cache.has(cfg.roleId)) throw new AppError("You're already verified.");

  const key = `${guild.id}:${member.id}`;
  const now = Date.now();
  if (now - (lastPress.get(key) ?? 0) < 3000) throw new AppError('Please wait a few seconds before trying again.');
  lastPress.set(key, now);

  const attempts = await getAttempts(guild.id, member.id);
  if (attempts && Number(attempts.locked_until) > now) {
    throw new AppError(`Too many failed attempts. Try again ${discordTime(Number(attempts.locked_until), 'R')}.`);
  }

  if (cfg.minAccountAgeHours > 0) {
    const age = now - member.user.createdTimestamp;
    if (age < cfg.minAccountAgeHours * 3_600_000) {
      const res = await recordFailure(guild.id, member.id, cfg);
      await logEvent(guild, '⛔ Verification denied (account too new)', COLORS.warning, member, [
        { name: 'Account age', value: formatDuration(age), inline: true }, { name: 'Required', value: `${cfg.minAccountAgeHours}h`, inline: true },
      ]);
      throw new AppError(`Your account must be at least **${cfg.minAccountAgeHours} hour(s)** old to verify.${res.locked ? ' You have been temporarily locked out.' : ''}`);
    }
  }

  if (cfg.mode === 'code') {
    let code = '';
    for (let i = 0; i < 5; i++) code += CODE_CHARS[crypto.randomInt(CODE_CHARS.length)];
    codes.set(key, { code, expires: now + 120_000 });
    return interaction.reply({
      flags: MessageFlags.Ephemeral,
      content: `Your verification code is **\`${code}\`**\nPress the button and type it in (valid for 2 minutes).`,
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('verify:enter').setLabel('Enter code').setStyle(ButtonStyle.Primary),
      )],
    });
  }
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  return grant(interaction, cfg);
}

function showModal(interaction) {
  const modal = new ModalBuilder().setCustomId('verify:submit').setTitle('Enter verification code').addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('code').setLabel('Code').setStyle(TextInputStyle.Short).setMinLength(5).setMaxLength(5).setRequired(true),
    ),
  );
  return interaction.showModal(modal);
}

async function submit(interaction) {
  const { guild, member } = interaction;
  const cfg = await config.get(guild.id, 'verification');
  if (!cfg.enabled || !cfg.roleId) throw new AppError('Verification is currently disabled.');
  const key = `${guild.id}:${member.id}`;
  const attempts = await getAttempts(guild.id, member.id);
  if (attempts && Number(attempts.locked_until) > Date.now()) throw new AppError(`Too many failed attempts. Try again ${discordTime(Number(attempts.locked_until), 'R')}.`);

  const entry = codes.get(key);
  if (!entry || entry.expires < Date.now()) throw new AppError('Your code expired. Press **Verify** again to get a new one.');
  const given = interaction.fields.getTextInputValue('code').trim().toUpperCase();
  if (given !== entry.code) {
    const res = await recordFailure(guild.id, member.id, cfg);
    codes.delete(key);
    await logEvent(guild, '❌ Verification failed (wrong code)', COLORS.warning, member);
    throw new AppError(res.locked ? `Wrong code. You are locked out for ${cfg.lockoutMin} minute(s).` : `Wrong code. ${res.remaining} attempt(s) left — press **Verify** for a new code.`);
  }
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  return grant(interaction, cfg);
}

/** customId router for verify:* components. */
async function handleComponent(interaction) {
  const action = interaction.customId.split(':')[1];
  if (!interaction.inGuild()) return;
  if (action === 'start') return start(interaction);
  if (action === 'enter') return showModal(interaction);
  if (action === 'submit') return submit(interaction);
  return fail(interaction, 'Unknown verification action.');
}

/** Gives the optional "unverified" role to new members. */
async function onMemberJoin(member) {
  if (member.user.bot) return;
  const cfg = await config.get(member.guild.id, 'verification');
  if (!cfg.enabled || !cfg.unverifiedRoleId) return;
  const role = member.guild.roles.cache.get(cfg.unverifiedRoleId);
  if (role) await member.roles.add(role, 'Pending verification').catch((err) => logger.debug(`Unverified role failed: ${err.message}`));
}

setInterval(() => {
  const now = Date.now();
  for (const [k, v] of codes) if (v.expires < now) codes.delete(k);
  for (const [k, t] of lastPress) if (now - t > 60_000) lastPress.delete(k);
}, 60_000).unref();

module.exports = { buildPanel, postPanel, handleComponent, onMemberJoin };
