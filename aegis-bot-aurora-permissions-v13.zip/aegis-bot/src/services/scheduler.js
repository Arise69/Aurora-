'use strict';
/** Single polling loop for everything time-based (giveaways, reminders, lockdowns, temp bans, scheduled posts). */
const logger = require('../utils/logger');
const giveaways = require('./giveaways');
const antiraid = require('./antiraid');
const antispam = require('./antispam');
const moderation = require('./moderation');
const utility = require('./utility');

let timer = null;
let running = false;
let ticks = 0;

async function tick() {
  if (running) return;
  running = true;
  try {
    const jobs = [giveaways.tick(), antiraid.tick(), moderation.processTempBans(), utility.processReminders(), utility.processScheduled()];
    const results = await Promise.allSettled(jobs);
    results.forEach((r) => { if (r.status === 'rejected') logger.error('Scheduler job failed', r.reason); });
    if (++ticks % 12 === 0) antispam.sweep();
  } finally { running = false; }
}

const start = () => { if (!timer) { timer = setInterval(tick, 5000); timer.unref?.(); tick(); } };
const stop = () => { if (timer) clearInterval(timer); timer = null; };

module.exports = { start, stop, tick };
