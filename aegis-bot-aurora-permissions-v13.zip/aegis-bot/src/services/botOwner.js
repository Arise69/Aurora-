'use strict';

const db = require('../database');
const env = require('../config/env');

const CACHE_TTL = 30_000;
let cached = null;
let cachedAt = 0;

function normalizeIds(value) {
  return [...new Set((Array.isArray(value) ? value : []).map(String).filter((id) => /^\d{17,20}$/.test(id)))];
}

async function load() {
  const now = Date.now();
  if (cached && now - cachedAt < CACHE_TTL) return cached;
  const row = await db.get('SELECT data FROM bot_settings WHERE key = ?', ['owners']);
  let data = {};
  if (row?.data) {
    try { data = JSON.parse(row.data); } catch { data = {}; }
  }
  cached = {
    owners: normalizeIds(data.owners),
    noPrefix: normalizeIds(data.noPrefix),
  };
  cachedAt = now;
  return cached;
}

async function save(next) {
  const data = {
    owners: normalizeIds(next.owners),
    noPrefix: normalizeIds(next.noPrefix),
  };
  await db.run(
    `INSERT INTO bot_settings (key, data, updated_at) VALUES (?, ?, ?)
     ON CONFLICT (key) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`,
    ['owners', JSON.stringify(data), Date.now()],
  );
  cached = data;
  cachedAt = Date.now();
  return data;
}

async function get() { return load(); }

async function isOwner(userId) {
  const id = String(userId);
  if (env.ownerIds.includes(id)) return true;
  const data = await load();
  return data.owners.includes(id);
}

async function hasNoPrefixAccess(userId) {
  if (await isOwner(userId)) return true;
  const data = await load();
  return data.noPrefix.includes(String(userId));
}

async function addOwner(userId) {
  const data = await load();
  if (!data.owners.includes(String(userId))) data.owners.push(String(userId));
  return save(data);
}

async function removeOwner(userId) {
  const data = await load();
  data.owners = data.owners.filter((id) => id !== String(userId));
  return save(data);
}

async function grantNoPrefix(userId) {
  const data = await load();
  if (!data.noPrefix.includes(String(userId))) data.noPrefix.push(String(userId));
  return save(data);
}

async function revokeNoPrefix(userId) {
  const data = await load();
  data.noPrefix = data.noPrefix.filter((id) => id !== String(userId));
  return save(data);
}

async function clearCache() { cached = null; cachedAt = 0; }

module.exports = {
  get,
  isOwner,
  hasNoPrefixAccess,
  addOwner,
  removeOwner,
  grantNoPrefix,
  revokeNoPrefix,
  clearCache,
};
