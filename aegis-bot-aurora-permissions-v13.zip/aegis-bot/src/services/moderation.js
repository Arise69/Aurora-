'use strict';
/** Shared moderation logic used by slash commands, prefix commands, AutoMod, anti-spam and warning thresholds. */
const { PermissionFlagsBits: P } = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logging = require('./logging');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { AppError } = require('../utils/errors');
const { shortId } = require('../utils/ids');
const { COLORS, LIMITS } = require('../config/constants');
const { hierarchyProblem, assertBotPermissions } = require('../utils/permissions');
const { makeEmbed, clip } = require('../utils/embeds');
const { formatDuration, discordTime } = require('../utils/duration');

const cleanReason = (r) =>
  String(r ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, LIMITS.reasonLength) || 'No reason provided';

/** Audit-log reason (max 512 chars) crediting the human moderator, since the bot is the executor. */
const auditReason = (reason, moderator) =>
  clip(moderator ? `${reason} | by ${moderator.user?.username ?? moderator.username}` : `${reason} | automated`, 500);

async function notifyUser(user, guild, { title, color, reason, extra = '' }) {
  try {
    const cfg = await config.get(guild.id, 'general');
    if (!cfg.dmNotify) return false;
    await user.send({
      embeds: [makeEmbed({ title, color, description: `**Server:** ${guild.name}\n**Reason:** ${clip(reason, 1000)}${extra}` })],
      allowedMentions: { parse: [] },
    });
    return true;
  } catch { return false; } // DMs closed – expected
}

/** Hierarchy check for both human moderators and automated (system) actions. */
function checkTarget(guild, moderator, member) {
  if (!member) return;
  if (moderator) {
    const problem = hierarchyProblem(guild, moderator, member);
    if (problem) throw new AppError(problem);
    return;
  }
  const me = guild.members.me;
  if (member.id === guild.ownerId || member.id === getClient().user.id || me.roles.highest.comparePositionTo(member.roles.highest) <= 0) {
    throw new AppError('Target cannot be moderated automatically.');
  }
}

const modId = (moderator) => moderator?.id ?? getClient().user.id;
const modUser = (moderator) => moderator?.user ?? null;

// ───────────────────────── Warnings ─────────────────────────

async function insertWarning(guildId, userId, moderatorId, reason) {
  for (let attempt = 0; attempt < 5; attempt++) {
    const id = shortId(8);
    try {
      await db.run('INSERT INTO warnings (id, guild_id, user_id, moderator_id, reason, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        [id, guildId, userId, moderatorId, reason, Date.now()]);
      return id;
    } catch (err) {
      if (attempt === 4 || !/unique|constraint|duplicate/i.test(String(err.message))) throw err;
    }
  }
  return null;
}

const countWarnings = async (guildId, userId) =>
  Number((await db.get('SELECT COUNT(*) AS n FROM warnings WHERE guild_id = ? AND user_id = ?', [guildId, userId])).n);

async function warn({ guild, target, moderator = null, reason, source = 'manual' }) {
  if (target.user.bot) throw new AppError('Bots cannot be warned.');
  checkTarget(guild, moderator, target);
  reason = cleanReason(reason);
  const id = await insertWarning(guild.id, target.id, modId(moderator), reason);
  const total = await countWarnings(guild.id, target.id);

  await logging.logModeration(guild, {
    action: '⚠️ Member Warned', color: COLORS.warning, target: target.user, moderator: modUser(moderator), reason,
    fields: [{ name: 'Total warnings', value: String(total), inline: true }, { name: 'Source', value: source, inline: true }],
    ids: { 'Warning ID': id, 'User ID': target.id },
  });
  await notifyUser(target.user, guild, { title: '⚠️ You have been warned', color: COLORS.warning, reason, extra: `\n**Total warnings:** ${total}` });

  const threshold = await applyThreshold({ guild, target, total });
  return { id, total, threshold };
}

/** Applies the punishment configured for exactly `total` warnings (fires once per milestone). */
async function applyThreshold({ guild, target, total }) {
  const cfg = await config.get(guild.id, 'warnings');
  const rule = cfg.thresholds.find((t) => t.count === total);
  if (!rule) return null;
  const reason = `Automatic punishment: reached ${total} warnings`;
  try {
    if (rule.action === 'timeout') await timeout({ guild, target, moderator: null, durationMs: rule.durationSec * 1000, reason, source: 'warning-threshold' });
    else if (rule.action === 'kick') await kick({ guild, target, moderator: null, reason, source: 'warning-threshold' });
    else if (rule.action === 'ban') await ban({ guild, targetUser: target.user, targetMember: target, moderator: null, reason, source: 'warning-threshold', durationMs: rule.durationSec ? rule.durationSec * 1000 : 0 });
    else return null;
    return rule;
  } catch (err) {
    logger.warn(`Warning threshold action failed in ${guild.id}: ${err.message}`);
    return null;
  }
}

async function listWarnings(guildId, userId) {
  return db.all('SELECT id, moderator_id, reason, created_at FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT 100', [guildId, userId]);
}

async function removeWarning({ guild, id, moderator }) {
  const row = await db.get('SELECT * FROM warnings WHERE id = ? AND guild_id = ?', [String(id).toUpperCase(), guild.id]);
  if (!row) throw new AppError('No warning with that ID exists in this server.');
  await db.run('DELETE FROM warnings WHERE id = ? AND guild_id = ?', [row.id, guild.id]);
  const user = await getClient().users.fetch(row.user_id).catch(() => null);
  await logging.logModeration(guild, {
    action: '🧹 Warning Removed', color: COLORS.info, target: user ?? { id: row.user_id }, moderator: modUser(moderator), reason: `Original: ${row.reason}`,
    ids: { 'Warning ID': row.id, 'User ID': row.user_id },
  });
  return row;
}

async function clearWarnings({ guild, userId, moderator }) {
  const res = await db.run('DELETE FROM warnings WHERE guild_id = ? AND user_id = ?', [guild.id, userId]);
  const user = await getClient().users.fetch(userId).catch(() => null);
  await logging.logModeration(guild, {
    action: '🧹 Warnings Cleared', color: COLORS.info, target: user ?? { id: userId }, moderator: modUser(moderator), reason: `${res.changes} warning(s) removed`,
    ids: { 'User ID': userId },
  });
  return res.changes;
}

// ───────────────────────── Timeouts, kicks, bans ─────────────────────────

async function timeout({ guild, target, moderator, durationMs, reason, source = 'manual' }) {
  assertBotPermissions(guild, P.ModerateMembers);
  checkTarget(guild, moderator, target);
  if (target.user.bot && moderator) throw new AppError('Bots cannot be timed out with this command.');
  if (target.permissions.has(P.Administrator)) throw new AppError('Discord does not allow timing out administrators.');
  if (!target.moderatable) throw new AppError("I can't time out that member.");
  reason = cleanReason(reason);
  const ms = Math.min(Math.max(durationMs, 1000), LIMITS.maxTimeoutMs);
  await notifyUser(target.user, guild, { title: '🔇 You have been timed out', color: COLORS.mod, reason, extra: `\n**Duration:** ${formatDuration(ms)}` });
  await target.timeout(ms, auditReason(reason, moderator));
  await logging.logModeration(guild, {
    action: '🔇 Member Timed Out', color: COLORS.mod, target: target.user, moderator: modUser(moderator), reason,
    fields: [{ name: 'Duration', value: `${formatDuration(ms)} (ends ${discordTime(Date.now() + ms, 'R')})`, inline: true }, { name: 'Source', value: source, inline: true }],
    ids: { 'User ID': target.id },
  });
  return ms;
}

async function untimeout({ guild, target, moderator, reason }) {
  assertBotPermissions(guild, P.ModerateMembers);
  if (!target.isCommunicationDisabled()) throw new AppError('That member is not timed out.');
  checkTarget(guild, moderator, target);
  reason = cleanReason(reason);
  await target.timeout(null, auditReason(reason, moderator));
  await logging.logModeration(guild, {
    action: '🔊 Timeout Removed', color: COLORS.success, target: target.user, moderator: modUser(moderator), reason, ids: { 'User ID': target.id },
  });
}

async function kick({ guild, target, moderator, reason, source = 'manual' }) {
  assertBotPermissions(guild, P.KickMembers);
  checkTarget(guild, moderator, target);
  if (!target.kickable) throw new AppError("I can't kick that member.");
  reason = cleanReason(reason);
  await notifyUser(target.user, guild, { title: '👢 You have been kicked', color: COLORS.mod, reason });
  await target.kick(auditReason(reason, moderator));
  await logging.logModeration(guild, {
    action: '👢 Member Kicked', color: COLORS.mod, target: target.user, moderator: modUser(moderator), reason,
    fields: [{ name: 'Source', value: source, inline: true }], ids: { 'User ID': target.id },
  });
}

async function ban({ guild, targetUser, targetMember = null, moderator, reason, deleteDays = 0, durationMs = 0, source = 'manual', dmTitle = '🔨 You have been banned', logAction = null }) {
  assertBotPermissions(guild, P.BanMembers);
  if (!targetMember) targetMember = await guild.members.fetch(targetUser.id).catch(() => null);
  checkTarget(guild, moderator, targetMember);
  if (targetUser.id === guild.ownerId) throw new AppError('The server owner cannot be banned.');
  if (targetMember && !targetMember.bannable) throw new AppError("I can't ban that member.");
  reason = cleanReason(reason);
  let dmSent = false;
  if (targetMember) {
    dmSent = await notifyUser(targetUser, guild, {
      title: dmTitle, color: COLORS.error, reason,
      extra: durationMs ? `\n**Duration:** ${formatDuration(durationMs)}` : '',
    });
  }
  const days = Math.min(Math.max(Number(deleteDays) || 0, 0), 7);
  await guild.bans.create(targetUser.id, { reason: auditReason(reason, moderator), deleteMessageSeconds: days * 86400 });
  if (durationMs > 0) {
    await db.run(
      `INSERT INTO temp_bans (guild_id, user_id, unban_at, moderator_id) VALUES (?, ?, ?, ?)
       ON CONFLICT (guild_id, user_id) DO UPDATE SET unban_at = excluded.unban_at, moderator_id = excluded.moderator_id`,
      [guild.id, targetUser.id, Date.now() + durationMs, modId(moderator)],
    );
  }
  await logging.logModeration(guild, {
    action: logAction ?? (durationMs ? '⏳ Member Temp-Banned' : '🔨 Member Banned'), color: COLORS.error, target: targetUser, moderator: modUser(moderator), reason,
    fields: [
      durationMs ? { name: 'Duration', value: formatDuration(durationMs), inline: true } : null,
      { name: 'Source', value: source, inline: true },
    ].filter(Boolean),
    ids: { 'User ID': targetUser.id },
  });
  return { dmSent };
}

/** Ban (deleting 7 days of messages) and immediately unban, to purge a member's messages. */
async function softban({ guild, targetUser, targetMember = null, moderator, reason, source = 'manual' }) {
  const { dmSent } = await ban({
    guild, targetUser, targetMember, moderator, reason: `${cleanReason(reason)} (softban)`, deleteDays: 7, source,
    dmTitle: '👢 You have been soft-banned', logAction: '🔨 Member Soft-Banned',
  });
  try { await guild.bans.remove(targetUser.id, auditReason('Softban cleanup', moderator)); }
  catch { throw new AppError('The member was banned, but I could not unban them again. Please unban them manually.'); }
  return { dmSent };
}

async function unban({ guild, userId, moderator, reason }) {
  assertBotPermissions(guild, P.BanMembers);
  reason = cleanReason(reason);
  const existing = await guild.bans.fetch({ user: userId, force: true }).catch(() => null);
  if (!existing) throw new AppError('That user is not banned.');
  await guild.bans.remove(userId, auditReason(reason, moderator));
  await db.run('DELETE FROM temp_bans WHERE guild_id = ? AND user_id = ?', [guild.id, userId]);
  await logging.logModeration(guild, {
    action: '🔓 Member Unbanned', color: COLORS.success, target: existing.user, moderator: modUser(moderator), reason, ids: { 'User ID': userId },
  });
  return existing.user;
}

/** Scheduler hook: lifts expired temporary bans. */
async function processTempBans() {
  const due = await db.all('SELECT guild_id, user_id FROM temp_bans WHERE unban_at <= ? LIMIT 25', [Date.now()]);
  for (const row of due) {
    const guild = getClient().guilds.cache.get(row.guild_id);
    try {
      if (guild) await unban({ guild, userId: row.user_id, moderator: null, reason: 'Temporary ban expired' });
    } catch (err) {
      logger.debug(`Temp-ban lift failed: ${err.message}`);
    }
    await db.run('DELETE FROM temp_bans WHERE guild_id = ? AND user_id = ?', [row.guild_id, row.user_id]);
  }
}

module.exports = {
  cleanReason, notifyUser, warn, applyThreshold, listWarnings, removeWarning, clearWarnings, countWarnings,
  timeout, untimeout, kick, ban, softban, unban, processTempBans,
};
