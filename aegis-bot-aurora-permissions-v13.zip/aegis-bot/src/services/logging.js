'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const config = require('./guildConfig');
const webhooks = require('./webhooks');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { COLORS, LOG_CATEGORIES } = require('../config/constants');
const { makeEmbed, describeUser, modEmbed } = require('../utils/embeds');

const NEED = [P.ViewChannel, P.SendMessages, P.EmbedLinks];

async function resolveChannel(guild, category) {
  const cfg = await config.get(guild.id, 'logging');
  if (!cfg.enabled || cfg.disabled.includes(category)) return null;
  const id = cfg.channels[category] ?? cfg.defaultChannelId;
  if (!id) return null;
  const channel = guild.channels.cache.get(id) ?? (await guild.channels.fetch(id).catch(() => null));
  if (!channel || !channel.isTextBased() || !channel.permissionsFor(guild.members.me)?.has(NEED)) return null;
  return channel;
}

/**
 * Sends a log embed to the channel configured for `category` and fans it out to matching webhooks.
 * Never throws: logging must not break the action that produced the log.
 */
async function send(guild, category, embed, options = {}) {
  try {
    const channel = await resolveChannel(guild, category);
    if (channel) await channel.send({ embeds: [embed], allowedMentions: { parse: [] }, ...options });
  } catch (err) {
    logger.debug(`Failed to send ${category} log in guild ${guild.id}: ${err.message}`);
  }
  webhooks.dispatch(guild.id, category, embed).catch(() => {});
}

/** Convenience: standard moderation embed -> "moderation" category. */
const logModeration = (guild, data) => send(guild, 'moderation', modEmbed(data));

/** Configuration change audit trail -> "server" category. */
async function logConfigChange(guildId, module, actorId, summary) {
  const guild = getClient().guilds.cache.get(guildId);
  if (!guild) return;
  await send(guild, 'server', makeEmbed({
    title: '⚙️ Setting changed',
    color: COLORS.info,
    fields: [
      { name: 'Module', value: `\`${module}\``, inline: true },
      { name: 'Changed by', value: actorId ? `<@${actorId}> (\`${actorId}\`)` : 'System', inline: true },
      { name: 'Change', value: summary || 'Configuration updated' },
    ],
  }));
}

const describeChannel = (ch) => (ch ? `<#${ch.id}> (\`${ch.name ?? 'unknown'}\`)` : 'Unknown');

module.exports = { LOG_CATEGORIES, send, logModeration, logConfigChange, describeUser, describeChannel };
