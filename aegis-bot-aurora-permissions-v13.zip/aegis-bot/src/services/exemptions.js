'use strict';
const permit = require('./permit');
const { isStaff } = require('../utils/permissions');

/** Shared "should this member/channel bypass the system?" check for anti-spam and AutoMod. */
async function isExempt(cfg, message, member, scope) {
  const parentId = message.channel?.parentId;
  if (cfg.ignoredChannels.includes(message.channelId) || (parentId && cfg.ignoredChannels.includes(parentId))) return true;
  if (cfg.ignoredUsers.includes(member.id)) return true;
  if (cfg.ignoredRoles.some((r) => member.roles.cache.has(r))) return true;
  if (cfg.exemptStaff && isStaff(member)) return true;
  return permit.isPermitted(member.guild.id, member, scope);
}

/** Sends a short notice that removes itself. */
async function sendTemp(channel, content, userId, ms = 6000) {
  try {
    const msg = await channel.send({ content, allowedMentions: { users: userId ? [userId] : [] } });
    setTimeout(() => msg.delete().catch(() => {}), ms).unref?.();
  } catch { /* no permission to speak – ignore */ }
}

module.exports = { isExempt, sendTemp };
