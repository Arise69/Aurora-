'use strict';
/** Vanity roles: members whose custom status contains the keyword get a role. Needs the Presence intent. */
const { ActivityType } = require('discord.js');
const config = require('./guildConfig');
const logger = require('../utils/logger');
const { render, memberVars } = require('../utils/template');
const { makeEmbed } = require('../utils/embeds');
const { COLORS } = require('../config/constants');

const busy = new Set();

async function onPresence(oldPresence, newPresence) {
  const member = newPresence.member;
  if (!member || member.user.bot) return;
  const cfg = await config.get(member.guild.id, 'vanity');
  if (!cfg.enabled || !cfg.keyword || !cfg.roleId) return;
  const role = member.guild.roles.cache.get(cfg.roleId);
  if (!role || !member.guild.members.me.permissions.has('ManageRoles') || member.guild.members.me.roles.highest.comparePositionTo(role) <= 0) return;

  const custom = newPresence.activities?.find((a) => a.type === ActivityType.Custom);
  const has = Boolean(custom?.state && custom.state.toLowerCase().includes(cfg.keyword.toLowerCase()));
  const holds = member.roles.cache.has(role.id);
  if (has === holds) return;

  const key = `${member.guild.id}:${member.id}`;
  if (busy.has(key)) return;
  busy.add(key);
  try {
    if (has) {
      await member.roles.add(role, 'Vanity keyword in status');
      const channel = cfg.channelId && member.guild.channels.cache.get(cfg.channelId);
      if (channel?.isTextBased()) {
        await channel.send({
          embeds: [makeEmbed({ description: render(cfg.message, memberVars(member, { keyword: cfg.keyword })), color: COLORS.success, timestamp: false })],
          allowedMentions: { users: [member.id] },
        }).catch(() => {});
      }
    } else {
      await member.roles.remove(role, 'Vanity keyword removed from status');
    }
  } catch (err) { logger.debug(`Vanity update failed: ${err.message}`); } finally { setTimeout(() => busy.delete(key), 5000).unref?.(); }
}

module.exports = { onPresence };
