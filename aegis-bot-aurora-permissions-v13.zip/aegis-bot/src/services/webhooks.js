'use strict';
/**
 * Outbound webhooks for moderation alerts, giveaway notifications, raid alerts, etc.
 *  - URLs/secrets are AES-256-GCM encrypted at rest and never logged or displayed.
 *  - "discord" webhooks must be genuine discord.com webhook URLs.
 *  - "external" webhooks (opt-in via ALLOW_EXTERNAL_WEBHOOKS) are SSRF-checked, HTTPS only, HMAC-signed.
 */
const crypto = require('node:crypto');
const db = require('../database');
const env = require('../config/env');
const logger = require('../utils/logger');
const cipher = require('../utils/crypto');
const { shortId } = require('../utils/ids');
const { AppError } = require('../utils/errors');
const { LOG_CATEGORIES } = require('../config/constants');
const { isDiscordWebhookUrl, assertPublicUrl } = require('../utils/netsafe');

const EVENT_NAMES = ['all', ...Object.keys(LOG_CATEGORIES)];
const MAX_PER_GUILD = 10;
const MAX_FAILURES = 10;
const cache = new Map(); // guildId -> { at, rows }

function parseEvents(input) {
  const events = [...new Set(String(input || 'moderation,security,giveaways').toLowerCase().split(/[\s,]+/).filter(Boolean))];
  const bad = events.filter((e) => !EVENT_NAMES.includes(e));
  if (bad.length) throw new AppError(`Unknown event(s): ${bad.join(', ')}. Valid: ${EVENT_NAMES.join(', ')}.`);
  return events;
}

async function add({ guildId, name, kind, url, secret, events, createdBy }) {
  if (!cipher.isConfigured()) throw new AppError('Webhooks are disabled: the bot owner has not set a valid `ENCRYPTION_KEY`.');
  if (!/^[\w -]{1,32}$/.test(name)) throw new AppError('Webhook names may only contain letters, numbers, spaces, `_` and `-` (max 32).');
  const count = await db.get('SELECT COUNT(*) AS n FROM webhooks WHERE guild_id = ?', [guildId]);
  if (Number(count.n) >= MAX_PER_GUILD) throw new AppError(`You can have at most ${MAX_PER_GUILD} webhooks.`);
  const dup = await db.get('SELECT id FROM webhooks WHERE guild_id = ? AND name = ?', [guildId, name]);
  if (dup) throw new AppError('A webhook with that name already exists.');

  if (kind === 'discord') {
    if (!isDiscordWebhookUrl(url)) throw new AppError('That is not a valid Discord webhook URL (https://discord.com/api/webhooks/<id>/<token>).');
  } else {
    if (!env.allowExternalWebhooks) throw new AppError('External webhooks are disabled on this bot (`ALLOW_EXTERNAL_WEBHOOKS=false`).');
    try { await assertPublicUrl(url); } catch (err) { throw new AppError(err.message); }
  }
  const id = shortId(6);
  await db.run(
    `INSERT INTO webhooks (id, guild_id, name, kind, url_enc, secret_enc, events, enabled, failures, created_by, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, ?, ?)`,
    [id, guildId, name, kind, cipher.encrypt(url), secret ? cipher.encrypt(secret) : null, JSON.stringify(events), createdBy, Date.now()],
  );
  cache.delete(guildId);
  return id;
}

async function list(guildId) {
  const rows = await db.all('SELECT id, name, kind, events, enabled, failures, created_at FROM webhooks WHERE guild_id = ? ORDER BY created_at', [guildId]);
  return rows.map((r) => ({ ...r, events: JSON.parse(r.events) }));
}

async function remove(guildId, nameOrId) {
  const res = await db.run('DELETE FROM webhooks WHERE guild_id = ? AND (name = ? OR id = ?)', [guildId, nameOrId, nameOrId.toUpperCase()]);
  cache.delete(guildId);
  return res.changes > 0;
}

async function loadRows(guildId) {
  const hit = cache.get(guildId);
  if (hit && Date.now() - hit.at < 60_000) return hit.rows;
  const rows = await db.all('SELECT * FROM webhooks WHERE guild_id = ? AND enabled = 1', [guildId]);
  cache.set(guildId, { at: Date.now(), rows });
  return rows;
}

async function deliver(row, event, embed, guildId) {
  const url = cipher.decrypt(row.url_enc);
  let body;
  const headers = { 'Content-Type': 'application/json', 'User-Agent': 'AegisBot-Webhook/1.0' };
  if (row.kind === 'discord') {
    body = JSON.stringify({ username: 'Aegis', embeds: [embed], allowed_mentions: { parse: [] } });
  } else {
    body = JSON.stringify({ event, guildId, timestamp: new Date().toISOString(), embed });
    if (row.secret_enc) {
      headers['X-Aegis-Signature'] = `sha256=${crypto.createHmac('sha256', cipher.decrypt(row.secret_enc)).update(body).digest('hex')}`;
    }
  }
  const res = await fetch(url, { method: 'POST', headers, body, redirect: 'error', signal: AbortSignal.timeout(5000) });
  if (!res.ok && res.status !== 429) throw new Error(`HTTP ${res.status}`);
  return res.status;
}

async function recordResult(row, ok) {
  if (ok) { if (row.failures) await db.run('UPDATE webhooks SET failures = 0 WHERE id = ?', [row.id]); return; }
  const failures = Number(row.failures) + 1;
  row.failures = failures;
  await db.run('UPDATE webhooks SET failures = ?, enabled = ? WHERE id = ?', [failures, failures >= MAX_FAILURES ? 0 : 1, row.id]);
  if (failures >= MAX_FAILURES) cache.delete(row.guild_id);
}

/** Fire-and-forget fan-out. Errors are logged without ever including the URL. */
async function dispatch(guildId, category, embed) {
  if (!cipher.isConfigured()) return;
  let rows;
  try { rows = await loadRows(guildId); } catch { return; }
  const json = typeof embed.toJSON === 'function' ? embed.toJSON() : embed;
  for (const row of rows) {
    let events;
    try { events = JSON.parse(row.events); } catch { continue; }
    if (!events.includes('all') && !events.includes(category)) continue;
    try {
      await deliver(row, category, json, guildId);
      await recordResult(row, true);
    } catch (err) {
      logger.warn(`Webhook "${row.name}" (${row.id}) delivery failed: ${err.message}`);
      await recordResult(row, false).catch(() => {});
    }
  }
}

/** Sends a test payload; returns true on success. */
async function test(guildId, nameOrId) {
  const row = await db.get('SELECT * FROM webhooks WHERE guild_id = ? AND (name = ? OR id = ?)', [guildId, nameOrId, nameOrId.toUpperCase()]);
  if (!row) throw new AppError('No webhook with that name.');
  const { makeEmbed } = require('../utils/embeds');
  try {
    await deliver(row, 'test', makeEmbed({ title: '🔔 Webhook test', description: 'This is a test notification from Aegis.' }).toJSON(), guildId);
    return true;
  } catch (err) {
    logger.warn(`Webhook test failed for ${row.id}: ${err.message}`);
    return false;
  }
}

module.exports = { EVENT_NAMES, parseEvents, add, list, remove, dispatch, test };
