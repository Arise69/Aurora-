'use strict';
const db = require('../database');
const { AppError } = require('../utils/errors');

const NAME_RE = /^[a-z0-9][a-z0-9_-]{0,31}$/;
const MAX_TAGS = 200;

const normName = (n) => String(n).trim().toLowerCase();

async function create(guildId, name, content, ownerId) {
  name = normName(name);
  if (!NAME_RE.test(name)) throw new AppError('Tag names: 1–32 chars, letters/numbers/`-`/`_`, no spaces.');
  if (!content.trim() || content.length > 1800) throw new AppError('Tag content must be 1–1800 characters.');
  const n = Number((await db.get('SELECT COUNT(*) AS n FROM tags WHERE guild_id = ?', [guildId])).n);
  if (n >= MAX_TAGS) throw new AppError(`This server reached the ${MAX_TAGS} tag limit.`);
  const now = Date.now();
  const res = await db.run('INSERT INTO tags (guild_id, name, content, owner_id, uses, created_at, updated_at) VALUES (?, ?, ?, ?, 0, ?, ?) ON CONFLICT DO NOTHING', [guildId, name, content, ownerId, now, now]);
  if (!res.changes) throw new AppError('A tag with that name already exists.');
}

async function getTag(guildId, name) {
  return db.get('SELECT * FROM tags WHERE guild_id = ? AND name = ?', [guildId, normName(name)]);
}

async function use(guildId, name) {
  const tag = await getTag(guildId, name);
  if (!tag) throw new AppError('No tag with that name.');
  await db.run('UPDATE tags SET uses = uses + 1 WHERE guild_id = ? AND name = ?', [guildId, tag.name]);
  return tag;
}

/** Only the owner or a member with ManageMessages may change a tag. */
function assertCanModify(tag, member) {
  if (tag.owner_id !== member.id && !member.permissions.has('ManageMessages')) throw new AppError('You can only modify your own tags.');
}

async function edit(guildId, name, content, member) {
  const tag = await getTag(guildId, name);
  if (!tag) throw new AppError('No tag with that name.');
  assertCanModify(tag, member);
  if (!content.trim() || content.length > 1800) throw new AppError('Tag content must be 1–1800 characters.');
  await db.run('UPDATE tags SET content = ?, updated_at = ? WHERE guild_id = ? AND name = ?', [content, Date.now(), guildId, tag.name]);
}

async function remove(guildId, name, member) {
  const tag = await getTag(guildId, name);
  if (!tag) throw new AppError('No tag with that name.');
  assertCanModify(tag, member);
  await db.run('DELETE FROM tags WHERE guild_id = ? AND name = ?', [guildId, tag.name]);
}

const list = (guildId) => db.all('SELECT name, uses, owner_id FROM tags WHERE guild_id = ? ORDER BY name LIMIT 200', [guildId]);
const search = (guildId, q) => db.all('SELECT name FROM tags WHERE guild_id = ? AND name LIKE ? ORDER BY name LIMIT 25', [guildId, `${normName(q).replace(/[%_]/g, '')}%`]);

module.exports = { create, getTag, use, edit, remove, list, search };
