'use strict';
/** Server "ignore list" enforcement for prefix commands (managed with `.ignore command|bypass …`). */
const config = require('./guildConfig');

/** The `ignore` command itself can never be ignored — otherwise a server could lock itself out of the list. */
const isIgnoreCommand = (cmd) => String(cmd.name).split(' ')[0] === 'ignore';

/** An ignored name covers that command and its subcommands ("role" covers "role add"). Aliases resolve to the same command object. */
const covers = (ignored, cmd) => ignored.some((x) => cmd.name === x || cmd.name.startsWith(`${x} `));

/** True when `cmd` is on the server's ignored-commands list and `userId` is not a bypass user. */
async function isCommandIgnored(guildId, userId, cmd) {
  if (isIgnoreCommand(cmd)) return false;
  const cfg = await config.get(guildId, 'automod');
  if (!cfg.ignoredCommands?.length || !covers(cfg.ignoredCommands, cmd)) return false;
  return !cfg.ignoredBypassUsers?.includes(userId);
}

module.exports = { isCommandIgnored, isIgnoreCommand };
