'use strict';
/**
 * Fake permissions: a server can give a role access to groups of bot commands that normally need a real
 * Discord permission, WITHOUT giving that role the real permission.
 *
 * A role is granted *categories* (what the `.permissions grant` panel toggles). Each category expands to the
 * permission(s) the corresponding commands check for.
 *
 * Rules (security-relevant, keep in sync with the README):
 *  - Fake permissions only satisfy the *command access check*. The bot performs the action with its own
 *    permissions, and role-hierarchy checks still use the member's REAL roles.
 *  - A fake grant can never satisfy a requirement of real Administrator.
 *  - Configuring fake permissions (`.permissions …`) always needs the REAL Manage Server permission.
 *  - Commands can opt out with `fakePermissions: false`.
 */
const { PermissionsBitField } = require('discord.js');
const config = require('./guildConfig');

/** Order = order shown in the panel. `perms` are what commands check for; 'Quarantine' is a bot-only pseudo permission. */
const CATEGORIES = [
  { key: 'quarantine', label: 'Quarantine Users',         perms: ['Quarantine'],                                   aliases: ['quarantineusers'] },
  { key: 'ban',        label: 'Ban / Unban Users',        perms: ['BanMembers'],                                   aliases: ['unban', 'banunban', 'banmembers'] },
  { key: 'kick',       label: 'Kick Users',               perms: ['KickMembers'],                                  aliases: ['kickmembers'] },
  { key: 'timeout',    label: 'Timeout / Mute Users',     perms: ['ModerateMembers'],                              aliases: ['mute', 'moderatemembers', 'timeoutmembers'] },
  { key: 'messages',   label: 'Purge / Manage Messages',  perms: ['ManageMessages'],                               aliases: ['purge', 'managemessages'] },
  { key: 'channels',   label: 'Manage Channels',          perms: ['ManageChannels'],                               aliases: ['managechannels', 'managechannel'] },
  { key: 'roles',      label: 'Manage Roles',             perms: ['ManageRoles'],                                  aliases: ['manageroles'] },
  { key: 'nicknames',  label: 'Manage Nicknames',         perms: ['ManageNicknames'],                              aliases: ['nick', 'managenicknames'] },
  { key: 'emojis',     label: 'Manage Emojis / Stickers', perms: ['ManageGuildExpressions'],                       aliases: ['stickers', 'manageemojis', 'manageemojisandstickers', 'manageguildexpressions'] },
  { key: 'voice',      label: 'Voice Moderation',         perms: ['MoveMembers', 'MuteMembers', 'DeafenMembers'],  aliases: ['movemembers', 'mutemembers', 'deafenmembers'] },
];
const KEYS = CATEGORIES.map((c) => c.key);
const BY_KEY = new Map(CATEGORIES.map((c) => [c.key, c]));

/** Pseudo permission -> the REAL permission that also satisfies it. */
const PSEUDO = { Quarantine: 'ManageRoles' };
/** Names Discord renamed; both spellings mean the same permission. */
const EQUIVALENT = { ManageEmojisAndStickers: 'ManageGuildExpressions' };
const unify = (name) => EQUIVALENT[name] ?? name;

const normalize = (v) => String(v ?? '').replace(/[\s_/-]+/g, '').toLowerCase();
const ALIAS = new Map();
for (const c of CATEGORIES) {
  for (const a of [c.key, normalize(c.label), ...c.aliases]) ALIAS.set(normalize(a), c.key);
}
const ALL_WORDS = new Set(['all', 'allperms', 'everything', 'administrator', 'admin']); // legacy "administrator" = all categories

/** "ban" / "Kick Users" / "BanMembers" -> category key (or null). */
const parseCategory = (raw) => ALIAS.get(normalize(raw)) ?? null;
const isAllWord = (raw) => ALL_WORDS.has(normalize(raw));

/** Any list of stored/typed values -> unique valid category keys, in panel order. Legacy Discord-permission names are migrated. */
function normalizeKeys(values) {
  const out = new Set();
  for (const v of values ?? []) {
    if (isAllWord(v)) { KEYS.forEach((k) => out.add(k)); continue; }
    const k = parseCategory(v);
    if (k) out.add(k);
  }
  return KEYS.filter((k) => out.has(k));
}

/** Permission flag(s) or names -> unified names. Unknown values become null (never satisfiable). */
function namesFor(perm) {
  if (typeof perm === 'string' && PSEUDO[perm]) return [perm];
  try {
    const names = new PermissionsBitField(perm).toArray();
    return names.length ? names.map(unify) : [null];
  } catch { return [null]; }
}

function roleIdsOf(member) {
  const roles = member?.roles;
  if (!roles) return [];
  if (roles.cache) return [...roles.cache.keys()];
  return Array.isArray(roles) ? roles : [];
}

/** Category keys held by a role. */
async function keysOfRole(guildId, roleId) {
  const cfg = await config.get(guildId, 'permissions');
  return normalizeKeys(cfg.roles?.[roleId]?.permissions);
}

/** Union of permission names (unified) a member holds through the categories of their roles. */
async function grantedTo(member) {
  const guildId = member?.guild?.id ?? member?.guildId;
  if (!guildId) return new Set();
  const cfg = await config.get(guildId, 'permissions');
  const out = new Set();
  for (const id of roleIdsOf(member)) {
    for (const key of normalizeKeys(cfg.roles?.[id]?.permissions)) {
      for (const p of BY_KEY.get(key).perms) out.add(unify(p));
    }
  }
  return out;
}

/** discord.js throws on an unknown permission name; treat that as "does not have it". */
function hasReal(perms, perm) {
  try { return !!perms?.has(perm); } catch { return false; }
}

/**
 * Can `member` use something that requires `required` (a flag, name, or array of those)?
 * Each required permission is satisfied by the real permission OR by a fake one.
 *
 * @param opts.realPermissions  real permission set (defaults to member.permissions; slash commands pass interaction.memberPermissions)
 * @param opts.fakeable         false => only real permissions count
 */
async function satisfies(member, required, { realPermissions = member?.permissions, fakeable = true } = {}) {
  const list = (Array.isArray(required) ? required : [required]).filter((p) => p !== undefined && p !== null);
  if (!list.length) return true;
  let fake = null; // loaded lazily, only if a real check fails
  for (const perm of list) {
    if (hasReal(realPermissions, typeof perm === 'string' && PSEUDO[perm] ? PSEUDO[perm] : perm)) continue;
    if (!fakeable) return false;
    const needed = namesFor(perm);
    if (needed.includes(null) || needed.includes('Administrator')) return false; // unknown, or real-Administrator only
    fake ??= await grantedTo(member);
    if (!needed.every((n) => fake.has(n))) return false;
  }
  return true;
}

/** Atomically change a role's categories. `fn(Set<key>) -> iterable of keys`. Empty result removes the role entry. */
async function updateRole(guildId, roleId, fn, { actorId = null, summary = null } = {}) {
  let result = [];
  await config.update(guildId, 'permissions', (d) => {
    d.roles ??= {};
    const next = normalizeKeys([...fn(new Set(normalizeKeys(d.roles[roleId]?.permissions)))]);
    result = next;
    if (next.length) d.roles[roleId] = { permissions: next, createdBy: d.roles[roleId]?.createdBy ?? actorId, updatedAt: Date.now() };
    else delete d.roles[roleId];
  }, actorId && summary ? { actorId, summary } : null);
  return result;
}

module.exports = { CATEGORIES, KEYS, PSEUDO, parseCategory, isAllWord, normalizeKeys, namesFor, keysOfRole, grantedTo, satisfies, updateRole };
