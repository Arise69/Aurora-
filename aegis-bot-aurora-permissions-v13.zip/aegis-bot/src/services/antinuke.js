'use strict';
/**
 * Audit-log driven anti-nuke protection.
 *
 * The service follows Discord's audit-log model: the destructive gateway/audit
 * event identifies the executor, then each executor/action pair is counted in
 * a rolling window. Trusted actors are exempt unless betrayal guard is enabled,
 * in which case the separate betrayalLimits are applied to whitelist members.
 *
 * Auto-recovery uses live + persistent snapshots for channels and roles. This
 * means the bot can recover recently deleted structures even after a restart.
 */
const { AuditLogEvent, PermissionFlagsBits, ChannelType } = require('discord.js');
const db = require('../database');
const config = require('./guildConfig');
const logging = require('./logging');
const permit = require('./permit');
const logger = require('../utils/logger');
const { getClient } = require('../utils/context');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser } = require('../utils/embeds');
const { isDangerousRole } = require('../utils/permissions');

const TYPES = new Map([
  [AuditLogEvent.ChannelCreate, 'channelCreate'],
  [AuditLogEvent.ChannelDelete, 'channelDelete'],
  [AuditLogEvent.ChannelUpdate, 'channelUpdate'],
  [AuditLogEvent.ChannelOverwriteCreate, 'channelUpdate'],
  [AuditLogEvent.ChannelOverwriteDelete, 'channelUpdate'],
  [AuditLogEvent.ChannelOverwriteUpdate, 'channelUpdate'],
  [AuditLogEvent.RoleCreate, 'roleCreate'],
  [AuditLogEvent.RoleDelete, 'roleDelete'],
  [AuditLogEvent.RoleUpdate, 'roleUpdate'],
  [AuditLogEvent.MemberBanAdd, 'ban'],
  [AuditLogEvent.MemberKick, 'kick'],
  [AuditLogEvent.BotAdd, 'botAdd'],
  [AuditLogEvent.WebhookCreate, 'webhookCreate'],
  [AuditLogEvent.WebhookDelete, 'webhookDelete'],
  [AuditLogEvent.WebhookUpdate, 'webhookUpdate'],
  [AuditLogEvent.GuildUpdate, 'guildUpdate'],
  [AuditLogEvent.EmojiDelete, 'emojiDelete'],
  [AuditLogEvent.StickerDelete, 'stickerDelete'],
  [AuditLogEvent.MemberRoleUpdate, 'memberRoleUpdate'],
]);

for (const [eventName, type] of [
  ['MemberPrune', 'prune'],
  ['IntegrationCreate', 'integration'],
  ['IntegrationUpdate', 'integration'],
  ['IntegrationDelete', 'integration'],
]) {
  const event = AuditLogEvent[eventName];
  if (event !== undefined && event !== null) TYPES.set(event, type);
}


const actions = new Map();
const punished = new Map();
const recoveryCache = new Map();
const mentionCooldown = new Map();

const DANGEROUS = [
  'Administrator', 'ManageGuild', 'ManageRoles', 'ManageChannels',
  'BanMembers', 'KickMembers', 'ManageWebhooks', 'ManageMessages',
  'MentionEveryone', 'ManageNicknames', 'ModerateMembers',
];

const channelSnapshot = (channel) => {
  if (!channel?.guildId) return null;
  const permissionOverwrites = channel.permissionOverwrites?.cache
    ? [...channel.permissionOverwrites.cache.values()].map((o) => ({
        id: o.id,
        allow: o.allow.bitfield.toString(),
        deny: o.deny.bitfield.toString(),
        type: o.type,
      }))
    : [];
  return {
    id: channel.id,
    guildId: channel.guildId,
    name: channel.name,
    type: channel.type,
    parentId: channel.parentId ?? null,
    position: Number.isFinite(channel.rawPosition) ? channel.rawPosition : (channel.position ?? 0),
    topic: 'topic' in channel ? (channel.topic ?? null) : null,
    nsfw: 'nsfw' in channel ? Boolean(channel.nsfw) : false,
    rateLimitPerUser: 'rateLimitPerUser' in channel ? (channel.rateLimitPerUser ?? 0) : 0,
    bitrate: 'bitrate' in channel ? (channel.bitrate ?? 0) : 0,
    userLimit: 'userLimit' in channel ? (channel.userLimit ?? 0) : 0,
    rtcRegion: 'rtcRegion' in channel ? (channel.rtcRegion ?? null) : null,
    permissionOverwrites,
  };
};

const roleSnapshot = (role) => {
  if (!role?.guild?.id || role.managed || role.id === role.guild.id) return null;
  return {
    id: role.id,
    guildId: role.guild.id,
    name: role.name,
    color: role.color,
    hoist: Boolean(role.hoist),
    mentionable: Boolean(role.mentionable),
    permissions: role.permissions.bitfield.toString(),
    position: Number(role.position ?? 0),
  };
};

async function saveSnapshot(kind, snap) {
  if (!snap) return;
  recoveryCache.set(`${snap.guildId}:${kind}:${snap.id}`, { data: snap, at: Date.now() });
  await db.run(
    `INSERT INTO antinuke_snapshots (guild_id, kind, target_id, data, updated_at) VALUES (?, ?, ?, ?, ?)\n     ON CONFLICT (guild_id, kind, target_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`,
    [snap.guildId, kind, snap.id, JSON.stringify(snap), Date.now()],
  );
}

async function captureChannel(channel) {
  try { await saveSnapshot('channel', channelSnapshot(channel)); } catch (err) { logger.warn(`Anti-nuke channel snapshot failed: ${err.message}`); }
}
async function captureRole(role) {
  try { await saveSnapshot('role', roleSnapshot(role)); } catch (err) { logger.warn(`Anti-nuke role snapshot failed: ${err.message}`); }
}

async function primeSnapshots(guild) {
  if (!guild?.id) return;
  const channels = guild.channels?.cache ? [...guild.channels.cache.values()] : [];
  const roles = guild.roles?.cache ? [...guild.roles.cache.values()] : [];
  for (const channel of channels) {
    if (channel.isThread?.()) continue;
    await captureChannel(channel);
  }
  for (const role of roles) {
    if (role.managed || role.id === guild.id) continue;
    await captureRole(role);
  }
}

async function clearData(guildId) {
  resetState(guildId);
  for (const key of recoveryCache.keys()) {
    if (key.startsWith(`${guildId}:`)) recoveryCache.delete(key);
  }
  await db.run('DELETE FROM antinuke_snapshots WHERE guild_id = ?', [guildId]).catch(() => {});
}

async function loadSnapshot(guildId, kind, targetId) {
  const key = `${guildId}:${kind}:${targetId}`;
  const hit = recoveryCache.get(key);
  if (hit && Date.now() - hit.at < 7 * 86_400_000) return hit.data;
  const row = await db.get(
    'SELECT data, updated_at FROM antinuke_snapshots WHERE guild_id = ? AND kind = ? AND target_id = ?',
    [guildId, kind, targetId],
  );
  if (!row) return null;
  try {
    const data = JSON.parse(row.data);
    recoveryCache.set(key, { data, at: Date.now() });
    return data;
  } catch { return null; }
}

async function sendSecurityLog(guild, embed, cfg) {
  await logging.send(guild, 'security', embed).catch(() => {});
  if (cfg.loggingChannelId) {
    const ch = guild.channels.cache.get(cfg.loggingChannelId)
      ?? await guild.channels.fetch(cfg.loggingChannelId).catch(() => null);
    if (ch?.isTextBased() && ch.permissionsFor(guild.members.me)?.has(['ViewChannel', 'SendMessages', 'EmbedLinks'])) {
      await ch.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => {});
    }
  }
}

function dangerousPermissionAdded(before, after) {
  return DANGEROUS.some((name) => {
    const bit = PermissionFlagsBits[name];
    return bit && (BigInt(after) & BigInt(bit)) !== 0n && (BigInt(before) & BigInt(bit)) === 0n;
  });
}

function dangerousRoleIds(guild, ids) {
  return ids.filter((id) => {
    const role = guild.roles.cache.get(id);
    return role && !role.managed && isDangerousRole(role);
  });
}

async function recoverChannel(snapshot, guild) {
  if (!snapshot || !guild.channels?.create) return false;
  const type = Number(snapshot.type);
  const options = {
    name: snapshot.name || 'recovered-channel',
    type,
    reason: 'Anti-nuke auto-recovery',
  };
  if (snapshot.parentId && guild.channels.cache.has(snapshot.parentId) && type !== ChannelType.GuildCategory) options.parent = snapshot.parentId;
  if (snapshot.permissionOverwrites?.length) options.permissionOverwrites = snapshot.permissionOverwrites;
  if (type === ChannelType.GuildText || type === ChannelType.GuildAnnouncement || type === ChannelType.GuildForum || type === ChannelType.GuildMedia) {
    if (snapshot.topic) options.topic = snapshot.topic;
    options.nsfw = Boolean(snapshot.nsfw);
    if (snapshot.rateLimitPerUser) options.rateLimitPerUser = snapshot.rateLimitPerUser;
  }
  if (type === ChannelType.GuildVoice || type === ChannelType.GuildStageVoice) {
    if (snapshot.bitrate) options.bitrate = snapshot.bitrate;
    if (snapshot.userLimit) options.userLimit = snapshot.userLimit;
    if (snapshot.rtcRegion) options.rtcRegion = snapshot.rtcRegion;
  }
  const created = await guild.channels.create(options);
  if (Number.isFinite(snapshot.position)) {
    await created.setPosition(Math.max(0, Math.min(snapshot.position, guild.channels.cache.size - 1))).catch(() => {});
  }
  return true;
}

async function recoverRole(snapshot, guild) {
  if (!snapshot || !guild.roles?.create) return false;
  const created = await guild.roles.create({
    name: snapshot.name || 'Recovered Role',
    color: snapshot.color ?? 0,
    hoist: Boolean(snapshot.hoist),
    mentionable: Boolean(snapshot.mentionable),
    permissions: BigInt(snapshot.permissions ?? 0),
    reason: 'Anti-nuke auto-recovery',
  });
  const botTop = guild.members.me?.roles?.highest?.position ?? 1;
  if (snapshot.position > 1 && created.editable) {
    await created.setPosition(Math.min(snapshot.position, botTop - 1)).catch(() => {});
  }
  return true;
}

async function tryRecover(guild, entry, cfg) {
  if (!cfg.autoRecovery || !entry) return { attempted: false, restored: false };
  if (entry.action === AuditLogEvent.ChannelDelete && cfg.recovery?.channels !== false) {
    const snap = await loadSnapshot(guild.id, 'channel', entry.targetId);
    if (!snap) return { attempted: true, restored: false };
    try { return { attempted: true, restored: await recoverChannel(snap, guild) }; }
    catch (err) { logger.warn(`Anti-nuke channel recovery failed: ${err.message}`); return { attempted: true, restored: false }; }
  }
  if (entry.action === AuditLogEvent.RoleDelete && cfg.recovery?.roles !== false) {
    const snap = await loadSnapshot(guild.id, 'role', entry.targetId);
    if (!snap) return { attempted: true, restored: false };
    try { return { attempted: true, restored: await recoverRole(snap, guild) }; }
    catch (err) { logger.warn(`Anti-nuke role recovery failed: ${err.message}`); return { attempted: true, restored: false }; }
  }
  return { attempted: false, restored: false };
}

function addAction(guildId, executorId, type, windowSec) {
  const key = `${guildId}:${executorId}:${type}`;
  const now = Date.now();
  const list = (actions.get(key) ?? []).filter((t) => now - t <= windowSec * 1000);
  list.push(now);
  actions.set(key, list);
  return list.length;
}

function moduleEnabled(cfg, type) {
  return cfg.modules?.[type] !== false;
}

function changeKeys(entry) {
  return (entry?.changes ?? []).map((c) => String(c.key ?? '').toLowerCase());
}

function hasChange(entry, ...keys) {
  const wanted = keys.map((k) => k.toLowerCase());
  return changeKeys(entry).some((key) => wanted.includes(key));
}

function roleTags(role) {
  return role?.tags ?? {};
}

function isLinkedRole(role) {
  const tags = roleTags(role);
  return Boolean(tags.guildConnections || tags.integrationId);
}

function isInviteRole(role) {
  // Discord has no native "invite role" flag. Aurora treats roles explicitly
  // named/tagged as invite roles only when the server has opted in via the
  // role name convention, avoiding false positives on ordinary roles.
  const name = String(role?.name ?? '').toLowerCase();
  return name.includes('invite role') || name === 'invite-role' || name.startsWith('invite-role-');
}

function specialProtection(entry, guild, security) {
  const changes = changeKeys(entry);
  const add = entry?.changes?.find((c) => c.key === '$add')?.new ?? [];
  const rem = entry?.changes?.find((c) => c.key === '$remove')?.new ?? [];
  const addedRoles = add.map((r) => guild.roles.cache.get(r.id)).filter(Boolean);
  const removedRoles = rem.map((r) => guild.roles.cache.get(r.id)).filter(Boolean);
  if (entry.action === AuditLogEvent.GuildUpdate) {
    const vanity = changes.some((k) => ['vanity_url_code', 'vanity_url', 'vanityurlcode'].includes(k));
    const onboarding = changes.some((k) => k.includes('onboarding') || k.includes('welcome_screen') || ['rules_channel_id', 'public_updates_channel_id'].includes(k));
    return {
      vanity: vanity,
      onboarding: onboarding,
    };
  }
  if (entry.action === AuditLogEvent.MemberRoleUpdate) {
    const mainrole = Boolean(security?.mainroleId && (addedRoles.some((r) => r.id === security.mainroleId) || removedRoles.some((r) => r.id === security.mainroleId)));
    const linkrole = addedRoles.some(isLinkedRole) || removedRoles.some(isLinkedRole);
    const inviteRole = addedRoles.some(isInviteRole) || removedRoles.some(isInviteRole);
    return { mainrole, linkrole, inviteRole };
  }
  return {};
}

function resetState(guildId) {
  for (const key of actions.keys()) if (key.startsWith(`${guildId}:`)) actions.delete(key);
  for (const key of punished.keys()) if (key.startsWith(`${guildId}:`)) punished.delete(key);
}

async function onAuditEntry(entry, guild) {
  const type = TYPES.get(entry.action);
  if (!type || !entry.executorId || !guild?.available) return;

  const cfg = await config.get(guild.id, 'antinuke');
  if (!cfg.enabled) return;

  const client = getClient();
  if (entry.executorId === client.user?.id || entry.executorId === guild.ownerId) return;

  let executor = await guild.members.fetch(entry.executorId).catch(() => null);
  const whitelist = cfg.whitelist ?? {};
  const legacyWhitelist = Array.isArray(whitelist) ? whitelist : [];
  const whitelistMap = !Array.isArray(whitelist) && whitelist && typeof whitelist === 'object' ? whitelist : {};
  const isWhitelistedFor = (filter) => legacyWhitelist.includes(entry.executorId) || Boolean(whitelistMap[entry.executorId]?.all || whitelistMap[entry.executorId]?.[filter]);

  const security = await config.get(guild.id, 'security');
  const special = specialProtection(entry, guild, security);
  const specialTypes = [];
  if (special.vanity && moduleEnabled(cfg, 'vanityUpdate')) specialTypes.push('vanityUpdate');
  if (special.onboarding && moduleEnabled(cfg, 'onboardingSafeguard')) specialTypes.push('onboardingSafeguard');
  if (special.linkrole && moduleEnabled(cfg, 'linkroleProtection')) specialTypes.push('linkroleProtection');
  if (special.inviteRole && moduleEnabled(cfg, 'inviteRoleProtection')) specialTypes.push('inviteRoleProtection');
  if (special.mainrole && moduleEnabled(cfg, 'mainroleProtection')) specialTypes.push('mainroleProtection');

  if (executor && !special.mainrole) {
    if (security.mainroleId && executor.roles.cache.has(security.mainroleId)) return;
    if (await permit.isPermitted(guild.id, executor, 'antinuke')) return;
  }

  // Special safeguards get their own counters. This lets sensitive changes
  // trip at their dedicated threshold without changing the general module.
  for (const specialType of specialTypes) {
    const inWhitelist = isWhitelistedFor(specialType);
    if (inWhitelist && !cfg.betrayalGuard) continue;
    const limits = inWhitelist ? (cfg.betrayalLimits ?? cfg.limits) : cfg.limits;
    const count = addAction(guild.id, entry.executorId, specialType, cfg.windowSec);
    const limit = Number(limits?.[specialType] ?? 1);
    if (limit && count >= limit) {
      return punishOnce(guild, executor, entry.executorId, specialType, count, cfg, entry, inWhitelist);
    }
  }

  // Normal module handling continues below.
  if (!moduleEnabled(cfg, type)) return;

  // Auto-recovery is a real protection mode: deleted channels/roles are restored immediately
  // when recovery is enabled, even when the configured punishment threshold is not reached yet.
  let preRecovery = null;
  if (cfg.autoRecovery && (entry.action === AuditLogEvent.ChannelDelete || entry.action === AuditLogEvent.RoleDelete)) {
    preRecovery = await tryRecover(guild, entry, cfg);
    if (preRecovery.attempted) {
      const recoveryEmbed = makeEmbed({
        title: preRecovery.restored ? '♻️ Anti-nuke auto-recovery' : '⚠️ Anti-nuke recovery failed',
        color: preRecovery.restored ? COLORS.success : COLORS.warning,
        fields: [
          { name: 'Executor', value: `<@${entry.executorId}> (\`${entry.executorId}\`)`, inline: true },
          { name: 'Target', value: `${type} • ${entry.targetId ?? 'unknown'}`, inline: true },
          { name: 'Result', value: preRecovery.restored ? 'Deleted structure restored.' : 'No usable snapshot or the restore operation failed.' },
        ],
      });
      await sendSecurityLog(guild, recoveryEmbed, cfg);
    }
  }

  const inWhitelist = isWhitelistedFor(type);
  if (inWhitelist && !cfg.betrayalGuard) return;
  const limits = inWhitelist ? (cfg.betrayalLimits ?? cfg.limits) : cfg.limits;
  const count = addAction(guild.id, entry.executorId, type, cfg.windowSec);
  const limit = Number(limits?.[type] ?? 0);

  // Dangerous permission escalation is a dedicated high-priority incident.
  if (entry.action === AuditLogEvent.RoleUpdate && moduleEnabled(cfg, 'permissionEscalation')) {
    const changed = entry.changes?.find((c) => c.key === 'permissions');
    if (changed) {
      const before = BigInt(changed.old ?? 0);
      const after = BigInt(changed.new ?? 0);
      if (after !== before && dangerousPermissionAdded(before, after)) {
        const breachCount = addAction(guild.id, entry.executorId, 'permissionEscalation', cfg.windowSec);
        const breachLimit = Number(limits?.permissionEscalation ?? 1);
        if (breachCount >= breachLimit) return punishOnce(guild, executor, entry.executorId, 'permissionEscalation', breachCount, cfg, entry, inWhitelist);
      }
    }
    const pos = entry.changes?.find((c) => c.key === 'position');
    if (pos && Number(pos.new) > Number(pos.old) && moduleEnabled(cfg, 'rolePosition')) {
      const positionCount = addAction(guild.id, entry.executorId, 'rolePosition', cfg.windowSec);
      const positionLimit = Number(limits?.rolePosition ?? 1);
      if (positionCount >= positionLimit) return punishOnce(guild, executor, entry.executorId, 'rolePosition', positionCount, cfg, entry, inWhitelist);
    }
  }

  // Assigning a dangerous role to a member is a separate escalation path.
  if (entry.action === AuditLogEvent.MemberRoleUpdate && moduleEnabled(cfg, 'permissionEscalation')) {
    const added = entry.changes?.find((c) => c.key === '$add')?.new ?? [];
    const dangerousIds = dangerousRoleIds(guild, added.map((r) => r.id).filter(Boolean));
    if (dangerousIds.length) {
      const breachCount = addAction(guild.id, entry.executorId, 'permissionEscalation', cfg.windowSec);
      const breachLimit = Number(limits?.permissionEscalation ?? 1);
      if (breachCount >= breachLimit) return punishOnce(guild, executor, entry.executorId, 'permissionEscalation', breachCount, cfg, entry, inWhitelist);
    }
  }

  if (!limit || count < limit) return;
  return punishOnce(guild, executor, entry.executorId, type, count, cfg, entry, inWhitelist, preRecovery);
}

async function punishOnce(guild, member, executorId, type, count, cfg, entry = null, inWhitelist = false, preRecovery = null) {
  const pKey = `${guild.id}:${executorId}`;
  const now = Date.now();
  if (now - (punished.get(pKey) ?? 0) < 60_000) return;
  punished.set(pKey, now);
  actions.delete(`${guild.id}:${executorId}:${type}`);

  const recovery = preRecovery ?? await tryRecover(guild, entry, cfg);
  await punish(guild, member, executorId, type, count, cfg, recovery, inWhitelist);
}


async function applyBarrier(guild, member, reason) {
  if (!member?.manageable) return false;
  const security = await config.get(guild.id, 'security');
  let role = security.barrierRoleId ? guild.roles.cache.get(security.barrierRoleId) : null;
  if (!role) return false;
  try {
    const removable = member.roles.cache.filter((r) => r.id !== guild.id && !r.managed && r.editable);
    if (removable.size) await member.roles.remove(removable, reason);
    await member.roles.add(role, reason);
    return true;
  } catch (err) {
    logger.warn(`Anti-nuke barrier application failed: ${err.message}`);
    return false;
  }
}

async function punish(guild, member, executorId, type, count, cfg, recovery = null, inWhitelist = false) {
  let outcome = 'Could not act (member left or is above the bot).';
  try {
    if (member) {
      if (cfg.punishment === 'ban' && member.bannable) {
        await member.ban({ reason: `Anti-nuke: ${count}x ${type}` }); outcome = 'Banned';
      } else if (cfg.punishment === 'kick' && member.kickable) {
        await member.kick(`Anti-nuke: ${count}x ${type}`); outcome = 'Kicked';
      } else if (member.manageable) {
        const reason = `Anti-nuke: ${count}x ${type}`;
        const barrierApplied = await applyBarrier(guild, member, reason);
        const risky = member.roles.cache.filter((r) => r.id !== guild.id && !r.managed && isDangerousRole(r));
        if (barrierApplied) outcome = `Applied Aurora Barrier [A+]${risky.size ? ` and removed ${risky.size} privileged role(s)` : ''}`;
        else if (risky.size) {
          await member.roles.remove(risky, reason);
          outcome = `Removed ${risky.size} privileged role(s)`;
        } else outcome = 'No removable privileged role or barrier available';
      }
    }
  } catch (err) {
    outcome = `Failed: ${err.message}`;
    logger.warn(`Anti-nuke punishment failed: ${err.message}`);
  }

  const trigger = `${count}× ${type} within ${cfg.windowSec}s${inWhitelist ? ' • betrayal guard' : ''}`;
  const recoveryText = recovery?.attempted
    ? (recovery.restored ? 'Recovered the deleted structure.' : 'Recovery was attempted, but the snapshot could not be restored.')
    : null;
  const embed = makeEmbed({
    title: '🛡️ Anti-nuke triggered', color: COLORS.security,
    fields: [
      { name: 'Executor', value: member ? describeUser(member.user) : `<@${executorId}> (\`${executorId}\`)`, inline: true },
      { name: 'Trigger', value: trigger, inline: true },
      { name: 'Action', value: outcome },
      recoveryText ? { name: 'Auto-recovery', value: recoveryText } : null,
    ].filter(Boolean),
  });
  await sendSecurityLog(guild, embed, cfg);
}

async function onMessage(message) {
  if (!message?.guild || !message.member || message.author?.bot) return false;
  const cfg = await config.get(message.guild.id, 'antinuke');
  if (!cfg.enabled || !moduleEnabled(cfg, 'mentionSpam')) return false;

  const executorId = message.author.id;
  if (executorId === message.guild.ownerId || executorId === getClient().user?.id) return false;
  if ((cfg.whitelist ?? []).includes(executorId) && !cfg.betrayalGuard) return false;

  const security = await config.get(message.guild.id, 'security');
  if (security.mainroleId && message.member.roles.cache.has(security.mainroleId)) return false;
  if (await permit.isPermitted(message.guild.id, message.member, 'antinuke')) return false;

  const mentionCount = message.mentions.users.size
    + message.mentions.roles.size
    + (message.mentions.everyone ? 5 : 0);
  if (mentionCount < 5) return false;

  const cooldownKey = `${message.guild.id}:${executorId}`;
  const now = Date.now();
  if (now - (mentionCooldown.get(cooldownKey) ?? 0) < 30_000) {
    await message.delete().catch(() => {});
    return true;
  }
  mentionCooldown.set(cooldownKey, now);

  await message.delete().catch(() => {});
  let outcome = 'Message deleted.';
  if (message.member.moderatable) {
    await message.member.timeout(5 * 60_000, 'Anti-nuke: mention spam').then(() => {
      outcome = 'Message deleted and member timed out for 5 minutes.';
    }).catch(() => {});
  }

  const embed = makeEmbed({
    title: '🛡️ Anti-nuke mention spam blocked',
    color: COLORS.warning,
    fields: [
      { name: 'Executor', value: describeUser(message.author), inline: true },
      { name: 'Mentions', value: String(mentionCount), inline: true },
      { name: 'Action', value: outcome },
    ],
  });
  await sendSecurityLog(message.guild, embed, cfg);
  return true;
}

async function prune() {
  const cut = Date.now() - 7 * 86_400_000;
  for (const [k, v] of actions) if (!v.length || v[v.length - 1] < Date.now() - 300_000) actions.delete(k);
  for (const [k, t] of punished) if (t < Date.now() - 300_000) punished.delete(k);
  for (const [k, v] of recoveryCache) if (v.at < cut) recoveryCache.delete(k);
  for (const [k, t] of mentionCooldown) if (t < Date.now() - 300_000) mentionCooldown.delete(k);
  await db.run('DELETE FROM antinuke_snapshots WHERE updated_at < ?', [cut]).catch(() => {});
}
setInterval(() => { prune().catch(() => {}); }, 120_000).unref();

module.exports = {
  onAuditEntry,
  onMessage,
  captureChannel,
  captureRole,
  resetState,
  clearData,
  primeSnapshots,
  TYPES,
};
