'use strict';
const { ChannelType, PermissionFlagsBits: P } = require('discord.js');
const logging = require('./logging');
const { AppError } = require('../utils/errors');
const { COLORS } = require('../config/constants');
const { makeEmbed, describeUser } = require('../utils/embeds');
const { assertBotPermissions } = require('../utils/permissions');

const TEXTUAL = new Set([ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.PublicThread, ChannelType.PrivateThread]);

function assertTextChannel(channel) {
  if (!channel || !TEXTUAL.has(channel.type)) throw new AppError('That only works in text channels.');
}

/** Bulk-deletes recent messages (Discord cannot bulk-delete messages older than 14 days). */
async function purge({ guild, channel, amount, moderator, userId = null }) {
  assertTextChannel(channel);
  assertBotPermissions(guild, [P.ManageMessages, P.ReadMessageHistory], channel);
  if (!Number.isInteger(amount) || amount < 1 || amount > 100) throw new AppError('Amount must be between 1 and 100.');
  const fetched = await channel.messages.fetch({ limit: 100 });
  const targets = [...fetched.values()].filter((m) => !m.pinned && (!userId || m.author.id === userId)).slice(0, amount);
  if (!targets.length) throw new AppError('No deletable messages found (messages older than 14 days cannot be bulk-deleted).');
  const deleted = await channel.bulkDelete(targets, true);
  await logging.send(guild, 'moderation', makeEmbed({
    title: '🧹 Messages purged', color: COLORS.mod,
    fields: [
      { name: 'Channel', value: `<#${channel.id}>`, inline: true }, { name: 'Deleted', value: String(deleted.size), inline: true },
      { name: 'Moderator', value: describeUser(moderator.user), inline: true }, userId ? { name: 'Filtered to', value: `<@${userId}>`, inline: true } : null,
    ].filter(Boolean),
    footer: `Moderator ID: ${moderator.id}`,
  }));
  return deleted.size;
}

async function setLocked({ guild, channel, locked, moderator, reason = 'No reason provided' }) {
  assertTextChannel(channel);
  if (channel.isThread()) throw new AppError('Threads cannot be locked this way.');
  assertBotPermissions(guild, P.ManageRoles, channel);
  await channel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: locked ? false : null }, { reason: `${locked ? 'Locked' : 'Unlocked'} by ${moderator.user.username}: ${reason}`.slice(0, 500) });
  await logging.send(guild, 'moderation', makeEmbed({
    title: locked ? '🔒 Channel locked' : '🔓 Channel unlocked', color: locked ? COLORS.mod : COLORS.success,
    fields: [{ name: 'Channel', value: `<#${channel.id}>`, inline: true }, { name: 'Moderator', value: describeUser(moderator.user), inline: true }, { name: 'Reason', value: reason }],
  }));
}

async function setSlowmode({ guild, channel, seconds, moderator }) {
  assertTextChannel(channel);
  assertBotPermissions(guild, P.ManageChannels, channel);
  if (!Number.isInteger(seconds) || seconds < 0 || seconds > 21600) throw new AppError('Slowmode must be between 0 and 21600 seconds (6 hours).');
  await channel.setRateLimitPerUser(seconds, `Slowmode set by ${moderator.user.username}`);
}

module.exports = { purge, setLocked, setSlowmode, assertTextChannel };
