'use strict';
/**
 * Versioned, append-only migrations. Never edit an applied migration; add a new one.
 * SQL is deliberately portable between SQLite and PostgreSQL:
 *   - TEXT ids (Discord snowflakes exceed 2^53), BIGINT epoch-millisecond timestamps
 *   - no AUTOINCREMENT / SERIAL: generated short IDs or counters instead
 *   - booleans as INTEGER 0/1
 */
const T = (sql) => sql.replace(/\s+/g, ' ').trim();

const MIGRATIONS = [
  {
    id: 1,
    name: 'initial_schema',
    statements: [
      // Per-guild configuration documents (one row per guild + module).
      T(`CREATE TABLE IF NOT EXISTS guild_settings (
        guild_id TEXT NOT NULL, module TEXT NOT NULL, data TEXT NOT NULL, updated_at BIGINT NOT NULL,
        PRIMARY KEY (guild_id, module))`),

      T(`CREATE TABLE IF NOT EXISTS warnings (
        id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, user_id TEXT NOT NULL, moderator_id TEXT NOT NULL,
        reason TEXT NOT NULL, created_at BIGINT NOT NULL)`),
      'CREATE INDEX IF NOT EXISTS idx_warnings_guild_user ON warnings (guild_id, user_id)',

      T(`CREATE TABLE IF NOT EXISTS giveaways (
        id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, message_id TEXT,
        host_id TEXT NOT NULL, prize TEXT NOT NULL, description TEXT, winner_count INTEGER NOT NULL,
        starts_at BIGINT NOT NULL, ends_at BIGINT NOT NULL, duration_ms BIGINT NOT NULL,
        status TEXT NOT NULL, required_role_id TEXT, excluded_role_ids TEXT NOT NULL DEFAULT '[]',
        min_account_age_ms BIGINT NOT NULL DEFAULT 0, min_member_age_ms BIGINT NOT NULL DEFAULT 0,
        winner_ids TEXT NOT NULL DEFAULT '[]', ping_role_id TEXT, created_at BIGINT NOT NULL, ended_at BIGINT)`),
      'CREATE INDEX IF NOT EXISTS idx_giveaways_status_ends ON giveaways (status, ends_at)',
      'CREATE INDEX IF NOT EXISTS idx_giveaways_status_starts ON giveaways (status, starts_at)',
      'CREATE INDEX IF NOT EXISTS idx_giveaways_guild ON giveaways (guild_id, status)',

      T(`CREATE TABLE IF NOT EXISTS giveaway_entries (
        giveaway_id TEXT NOT NULL, user_id TEXT NOT NULL, entered_at BIGINT NOT NULL,
        PRIMARY KEY (giveaway_id, user_id))`),

      T(`CREATE TABLE IF NOT EXISTS verification_attempts (
        guild_id TEXT NOT NULL, user_id TEXT NOT NULL, failures INTEGER NOT NULL DEFAULT 0,
        last_attempt_at BIGINT NOT NULL DEFAULT 0, locked_until BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id))`),

      // Webhook URLs/secrets are stored AES-256-GCM encrypted (see utils/crypto.js).
      T(`CREATE TABLE IF NOT EXISTS webhooks (
        id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, name TEXT NOT NULL, kind TEXT NOT NULL,
        url_enc TEXT NOT NULL, secret_enc TEXT, events TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1,
        failures INTEGER NOT NULL DEFAULT 0, created_by TEXT NOT NULL, created_at BIGINT NOT NULL)`),
      'CREATE INDEX IF NOT EXISTS idx_webhooks_guild ON webhooks (guild_id)',

      T(`CREATE TABLE IF NOT EXISTS permits (
        guild_id TEXT NOT NULL, target_id TEXT NOT NULL, target_type TEXT NOT NULL, scope TEXT NOT NULL,
        created_by TEXT NOT NULL, created_at BIGINT NOT NULL, PRIMARY KEY (guild_id, target_id, scope))`),

      T(`CREATE TABLE IF NOT EXISTS autoresponders (
        id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, trigger_text TEXT NOT NULL, response TEXT NOT NULL,
        match_type TEXT NOT NULL, cooldown_sec INTEGER NOT NULL DEFAULT 5, created_by TEXT NOT NULL, created_at BIGINT NOT NULL)`),
      'CREATE INDEX IF NOT EXISTS idx_autoresponders_guild ON autoresponders (guild_id)',

      T(`CREATE TABLE IF NOT EXISTS tags (
        guild_id TEXT NOT NULL, name TEXT NOT NULL, content TEXT NOT NULL, owner_id TEXT NOT NULL,
        uses INTEGER NOT NULL DEFAULT 0, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL,
        PRIMARY KEY (guild_id, name))`),

      T(`CREATE TABLE IF NOT EXISTS tickets (
        id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, number INTEGER NOT NULL, channel_id TEXT NOT NULL,
        opener_id TEXT NOT NULL, category TEXT, status TEXT NOT NULL, claimed_by TEXT,
        created_at BIGINT NOT NULL, closed_at BIGINT, closed_by TEXT, close_reason TEXT)`),
      'CREATE INDEX IF NOT EXISTS idx_tickets_channel ON tickets (channel_id)',
      'CREATE INDEX IF NOT EXISTS idx_tickets_guild_opener ON tickets (guild_id, opener_id, status)',

      T(`CREATE TABLE IF NOT EXISTS counters (
        guild_id TEXT NOT NULL, name TEXT NOT NULL, value INTEGER NOT NULL, PRIMARY KEY (guild_id, name))`),

      T(`CREATE TABLE IF NOT EXISTS reminders (
        id TEXT PRIMARY KEY, user_id TEXT NOT NULL, guild_id TEXT, channel_id TEXT, message TEXT NOT NULL,
        remind_at BIGINT NOT NULL, created_at BIGINT NOT NULL)`),
      'CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders (remind_at)',

      T(`CREATE TABLE IF NOT EXISTS afk (
        guild_id TEXT NOT NULL, user_id TEXT NOT NULL, reason TEXT, since BIGINT NOT NULL, PRIMARY KEY (guild_id, user_id))`),

      T(`CREATE TABLE IF NOT EXISTS scheduled_messages (
        id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, content TEXT NOT NULL,
        interval_ms BIGINT NOT NULL, next_run_at BIGINT NOT NULL, created_by TEXT NOT NULL, created_at BIGINT NOT NULL)`),
      'CREATE INDEX IF NOT EXISTS idx_scheduled_due ON scheduled_messages (next_run_at)',

      T(`CREATE TABLE IF NOT EXISTS voice_channels (
        channel_id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, owner_id TEXT NOT NULL, created_at BIGINT NOT NULL)`),

      T(`CREATE TABLE IF NOT EXISTS custom_roles (
        guild_id TEXT NOT NULL, user_id TEXT NOT NULL, role_id TEXT NOT NULL, created_at BIGINT NOT NULL,
        PRIMARY KEY (guild_id, user_id))`),

      T(`CREATE TABLE IF NOT EXISTS sticky_messages (
        guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, content TEXT NOT NULL, last_message_id TEXT,
        PRIMARY KEY (guild_id, channel_id))`),

      T(`CREATE TABLE IF NOT EXISTS lockdowns (
        guild_id TEXT PRIMARY KEY, started_at BIGINT NOT NULL, ends_at BIGINT NOT NULL, reason TEXT,
        started_by TEXT, channel_state TEXT NOT NULL DEFAULT '{}', restricted_users TEXT NOT NULL DEFAULT '[]')`),

      T(`CREATE TABLE IF NOT EXISTS temp_bans (
        guild_id TEXT NOT NULL, user_id TEXT NOT NULL, unban_at BIGINT NOT NULL, moderator_id TEXT,
        PRIMARY KEY (guild_id, user_id))`),
      'CREATE INDEX IF NOT EXISTS idx_temp_bans_due ON temp_bans (unban_at)',
    ],
  },
  {
    id: 2,
    name: 'antinuke_snapshots',
    statements: [
      T(`CREATE TABLE IF NOT EXISTS antinuke_snapshots (
        guild_id TEXT NOT NULL, kind TEXT NOT NULL, target_id TEXT NOT NULL,
        data TEXT NOT NULL, updated_at BIGINT NOT NULL,
        PRIMARY KEY (guild_id, kind, target_id))`),
      'CREATE INDEX IF NOT EXISTS idx_antinuke_snapshots_updated ON antinuke_snapshots (updated_at)',
    ],
  },
  {
    id: 3,
    name: 'bot_owner_settings',
    statements: [
      T(`CREATE TABLE IF NOT EXISTS bot_settings (
        key TEXT PRIMARY KEY, data TEXT NOT NULL, updated_at BIGINT NOT NULL)`),
      T(`UPDATE guild_settings SET data = REPLACE(data, '"prefix":","', '"prefix":"."') WHERE module = 'general'`),
    ],
  },

];

module.exports = { MIGRATIONS };
