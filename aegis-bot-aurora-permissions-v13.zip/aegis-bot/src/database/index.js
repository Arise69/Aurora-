'use strict';
const logger = require('../utils/logger');
const { MIGRATIONS } = require('./schema');

let driver = null;

function createDriver(url) {
  if (/^postgres(ql)?:\/\//i.test(url)) return new (require('./drivers/postgres'))(url);
  const file = url.replace(/^sqlite:(\/\/)?/i, '') || './data/aegis.db';
  return new (require('./drivers/sqlite'))(file);
}

async function migrate() {
  await driver.exec('CREATE TABLE IF NOT EXISTS schema_migrations (id INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at BIGINT NOT NULL)');
  const done = new Set((await driver.all('SELECT id FROM schema_migrations')).map((r) => Number(r.id)));
  for (const m of MIGRATIONS) {
    if (done.has(m.id)) continue;
    logger.info(`Applying migration ${m.id}: ${m.name}`);
    for (const sql of m.statements) await driver.exec(sql);
    await driver.run('INSERT INTO schema_migrations (id, name, applied_at) VALUES (?, ?, ?)', [m.id, m.name, Date.now()]);
  }
}

/** Opens the database (from DATABASE_URL or the given url) and applies pending migrations. */
async function init(url = require('../config/env').databaseUrl) {
  if (driver) return driver;
  driver = createDriver(url);
  await migrate();
  logger.info(`Database ready (${driver.kind}${driver.engine ? `/${driver.engine}` : ''}).`);
  return driver;
}

const need = () => { if (!driver) throw new Error('Database not initialised'); return driver; };

module.exports = {
  init,
  get: (sql, params) => need().get(sql, params),
  all: (sql, params) => need().all(sql, params),
  run: (sql, params) => need().run(sql, params),
  exec: (sql) => need().exec(sql),
  close: async () => { if (driver) { await driver.close(); driver = null; } },
  get kind() { return driver?.kind; },
};
