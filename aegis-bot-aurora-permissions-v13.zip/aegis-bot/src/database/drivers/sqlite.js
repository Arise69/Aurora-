'use strict';
const fs = require('node:fs');
const path = require('node:path');
const logger = require('../../utils/logger');

/**
 * SQLite driver. Prefers the native `better-sqlite3` package and falls back to Node's built-in
 * `node:sqlite` (Node >= 22.5), so deployment works even where native modules cannot be compiled.
 * Both expose the same synchronous prepare().get/all/run API; we wrap it in the async interface
 * shared with the PostgreSQL driver.
 */
class SqliteDriver {
  constructor(file) {
    this.kind = 'sqlite';
    if (file !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
    this.stmts = new Map();
    try {
      const Database = require('better-sqlite3');
      this.db = new Database(file);
      this.engine = 'better-sqlite3';
    } catch (err) {
      try {
        const { DatabaseSync } = require('node:sqlite');
        this.db = new DatabaseSync(file);
        this.engine = 'node:sqlite';
        logger.warn('better-sqlite3 unavailable; using built-in node:sqlite (experimental in Node 22).');
      } catch {
        throw new Error('No SQLite engine available. Run `npm install` (better-sqlite3) or use Node >= 22.5.');
      }
    }
    this.db.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL; PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON;');
  }

  #stmt(sql) {
    let s = this.stmts.get(sql);
    if (!s) {
      if (this.stmts.size > 500) this.stmts.clear();
      s = this.db.prepare(sql);
      this.stmts.set(sql, s);
    }
    return s;
  }
  static #params(params) {
    return params.map((p) => (p === undefined ? null : typeof p === 'boolean' ? Number(p) : p));
  }

  async get(sql, params = []) { return this.#stmt(sql).get(...SqliteDriver.#params(params)); }
  async all(sql, params = []) { return this.#stmt(sql).all(...SqliteDriver.#params(params)); }
  async run(sql, params = []) {
    const r = this.#stmt(sql).run(...SqliteDriver.#params(params));
    return { changes: Number(r.changes) };
  }
  async exec(sql) { this.db.exec(sql); }
  async close() { this.stmts.clear(); this.db.close(); }
}

module.exports = SqliteDriver;
