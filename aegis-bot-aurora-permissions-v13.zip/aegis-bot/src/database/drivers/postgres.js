'use strict';
/**
 * PostgreSQL driver (optional). Install with `npm install pg` and set
 * DATABASE_URL=postgres://user:pass@host:5432/db. All SQL in the project is written in the
 * portable subset (`?` placeholders, ON CONFLICT upserts, TEXT/INTEGER/BIGINT columns).
 */
class PostgresDriver {
  constructor(url) {
    this.kind = 'postgres';
    let pg;
    try { pg = require('pg'); } catch { throw new Error('DATABASE_URL points to PostgreSQL but the "pg" package is not installed. Run: npm install pg'); }
    pg.types.setTypeParser(20, (v) => Number(v)); // BIGINT -> number (timestamps / counts fit safely)
    this.pool = new pg.Pool({ connectionString: url, max: 10, idleTimeoutMillis: 30_000 });
    this.pool.on('error', (err) => require('../../utils/logger').error('PostgreSQL pool error', err));
  }
  static #convert(sql) { let i = 0; return sql.replace(/\?/g, () => `$${++i}`); }
  async get(sql, params = []) { return (await this.pool.query(PostgresDriver.#convert(sql), params)).rows[0]; }
  async all(sql, params = []) { return (await this.pool.query(PostgresDriver.#convert(sql), params)).rows; }
  async run(sql, params = []) { const r = await this.pool.query(PostgresDriver.#convert(sql), params); return { changes: r.rowCount ?? 0 }; }
  async exec(sql) { await this.pool.query(sql); }
  async close() { await this.pool.end(); }
}

module.exports = PostgresDriver;
