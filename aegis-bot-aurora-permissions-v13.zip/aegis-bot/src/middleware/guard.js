'use strict';
/** Cross-cutting interaction middleware: rate limits, permission checks and unified error handling. */
const { MessageFlags } = require('discord.js');
const { toUserMessage, reportUnexpected } = require('../utils/errors');
const { missingBotPermissions, permNames, isBotOwner } = require('../utils/permissions');
const { fail } = require('../utils/reply');
const fakePermissions = require('../services/fakePermissions');

const cooldowns = new Map();
const bursts = new Map();

/** Per-command cooldown + global burst limit (8 actions / 10 s). Returns an error string or null. */
function checkRateLimit(userId, key, cooldownSec) {
  if (isBotOwner(userId)) return null;
  const now = Date.now();
  const recent = (bursts.get(userId) ?? []).filter((t) => now - t < 10_000);
  if (recent.length >= 8) return 'You are doing that too quickly. Please slow down.';
  const last = cooldowns.get(`${userId}:${key}`) ?? 0;
  if (now - last < cooldownSec * 1000) return `Please wait ${Math.ceil((cooldownSec * 1000 - (now - last)) / 1000)}s before using that again.`;
  recent.push(now);
  bursts.set(userId, recent);
  cooldowns.set(`${userId}:${key}`, now);
  return null;
}

setInterval(() => {
  const now = Date.now();
  for (const [k, t] of cooldowns) if (now - t > 300_000) cooldowns.delete(k);
  for (const [k, l] of bursts) if (!l.length || now - l[l.length - 1] > 30_000) bursts.delete(k);
}, 60_000).unref();

async function handleError(interaction, err, label = '') {
  const { message, silent } = toUserMessage(err);
  if (silent) return;
  if (message) return fail(interaction, message);
  const ref = reportUnexpected(err, label);
  return fail(interaction, `Something went wrong on my side. Please try again later. (ref: \`${ref}\`)`);
}

async function runCommand(interaction, command) {
  if (!interaction.inGuild() || !interaction.guild) {
    return interaction.reply({ content: '❌ This command can only be used in a server.', flags: MessageFlags.Ephemeral });
  }
  const limited = checkRateLimit(interaction.user.id, interaction.commandName, command.cooldown ?? 3);
  if (limited) return fail(interaction, limited);

  if (command.userPermissions?.length && !(await fakePermissions.satisfies(interaction.member, command.userPermissions, {
    realPermissions: interaction.memberPermissions,
    fakeable: command.fakePermissions !== false,
  }))) {
    return fail(interaction, `You don't have permission to use this command. Required: **${permNames(command.userPermissions).join(', ')}**.`);
  }
  if (command.botPermissions?.length) {
    const missing = missingBotPermissions(interaction.guild, command.botPermissions);
    if (missing.length) return fail(interaction, `I'm missing the following permission(s): **${missing.join(', ')}**.`);
  }
  try {
    await command.execute(interaction);
  } catch (err) {
    await handleError(interaction, err, `in /${interaction.commandName}`);
  }
}

module.exports = { runCommand, handleError, checkRateLimit };
