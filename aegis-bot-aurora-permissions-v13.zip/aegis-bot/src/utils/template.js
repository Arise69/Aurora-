'use strict';
/** Replaces {key} placeholders using ONLY the provided variables. Unknown placeholders stay untouched. */
function render(template, vars) {
  return String(template).replace(/\{([\w.]+)\}/g, (match, key) =>
    Object.prototype.hasOwnProperty.call(vars, key) ? String(vars[key]) : match);
}

function memberVars(member, extra = {}) {
  const user = member.user ?? member;
  return {
    user: `<@${user.id}>`,
    'user.name': user.username,
    'user.tag': user.username,
    'user.id': user.id,
    server: member.guild?.name ?? '',
    count: member.guild?.memberCount ?? '',
    ...extra,
  };
}

module.exports = { render, memberVars };
