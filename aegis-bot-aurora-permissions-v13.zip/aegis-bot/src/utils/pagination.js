'use strict';
/** Splits an array of lines into chunks whose joined length stays under `limit` characters. */
function chunkLines(lines, limit = 3800) {
  const pages = [];
  let cur = '';
  for (const line of lines) {
    if (cur.length + line.length + 1 > limit) { pages.push(cur); cur = ''; }
    cur += `${line}\n`;
  }
  if (cur) pages.push(cur);
  return pages.length ? pages : [''];
}
module.exports = { chunkLines };
