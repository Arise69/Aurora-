'use strict';
/**
 * Declarative "set only the options the admin supplied" helper for configuration commands.
 * spec: [{ name, type: 'boolean'|'integer'|'string'|'channel'|'role', path: 'dot.path', label?, map?(value)->value }]
 */
const config = require('../services/guildConfig');
const { AppError } = require('./errors');

const GETTERS = { boolean: 'getBoolean', integer: 'getInteger', string: 'getString', channel: 'getChannel', role: 'getRole', number: 'getNumber' };

function setPath(obj, path, value) {
  const keys = path.split('.');
  let cur = obj;
  for (let i = 0; i < keys.length - 1; i++) cur = cur[keys[i]];
  cur[keys[keys.length - 1]] = value;
}

function readChanges(interaction, spec) {
  const changes = [];
  for (const s of spec) {
    const raw = interaction.options[GETTERS[s.type]](s.name);
    if (raw === null || raw === undefined) continue;
    const value = s.type === 'channel' || s.type === 'role' ? raw.id : raw;
    changes.push({ ...s, value: s.map ? s.map(value) : value, shown: s.type === 'channel' ? `<#${value}>` : s.type === 'role' ? `<@&${value}>` : String(value) });
  }
  return changes;
}

/** Applies supplied options to a config module. Returns a human-readable summary. */
async function patchConfig(interaction, module, spec, { validate } = {}) {
  const changes = readChanges(interaction, spec);
  if (!changes.length) throw new AppError('Provide at least one option to change.');
  if (validate) await validate(changes);
  await config.update(interaction.guildId, module, (cfg) => { for (const c of changes) setPath(cfg, c.path, c.value); },
    { actorId: interaction.user.id, summary: changes.map((c) => `${c.label ?? c.name} → ${c.shown}`).join(', ') });
  return changes.map((c) => `• **${c.label ?? c.name}** → ${c.shown}`).join('\n');
}

/** Adds/removes a snowflake in a config array. */
async function toggleInList(guildId, module, path, id, add, audit) {
  let changed = false;
  await config.update(guildId, module, (cfg) => {
    const keys = path.split('.');
    let cur = cfg;
    for (let i = 0; i < keys.length - 1; i++) cur = cur[keys[i]];
    const arr = cur[keys[keys.length - 1]];
    const has = arr.includes(id);
    if (add && !has) { if (arr.length >= 50) throw new AppError('That list is full (50 entries).'); arr.push(id); changed = true; }
    if (!add && has) { arr.splice(arr.indexOf(id), 1); changed = true; }
  }, audit);
  return changed;
}

module.exports = { patchConfig, readChanges, setPath, toggleInList };
