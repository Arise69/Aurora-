'use strict';
const logger = require('./logger');
const { shortId } = require('./ids');

/** An error whose message is safe and intended to be shown to the user. */
class AppError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AppError';
  }
}

const DISCORD_MESSAGES = {
  50013: "I don't have permission to do that. Check my role position and permissions.",
  50001: "I can't access that channel or resource.",
  50007: "I couldn't send a direct message to that user.",
  10008: 'That message no longer exists.',
  10003: 'That channel no longer exists.',
  10011: 'That role no longer exists.',
  10013: 'That user could not be found.',
  10007: 'That member is not in this server.',
  30005: 'This server has reached the maximum number of roles.',
  30013: 'This server has reached the maximum number of channels.',
  50035: 'Discord rejected that input. Please check the values and try again.',
};
const SILENT_CODES = new Set([40060, 10062]); // interaction already handled / expired

/** Returns a user-safe message for an error, plus whether it was an "expected" failure. */
function toUserMessage(err) {
  if (err instanceof AppError) return { message: err.message, expected: true };
  if (err && typeof err.code === 'number') {
    if (SILENT_CODES.has(err.code)) return { message: null, expected: true, silent: true };
    if (err.code in DISCORD_MESSAGES) return { message: DISCORD_MESSAGES[err.code], expected: true };
  }
  return { message: null, expected: false };
}

/** Logs an unexpected error server-side and returns a reference id for support. */
function reportUnexpected(err, context = '') {
  const ref = shortId(6);
  logger.error(`[${ref}] Unexpected error ${context}`, err);
  return ref;
}

module.exports = { AppError, toUserMessage, reportUnexpected };
