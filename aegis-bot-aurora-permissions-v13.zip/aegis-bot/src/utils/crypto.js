'use strict';
const crypto = require('node:crypto');
const env = require('../config/env');

function getKey() {
  const raw = env.encryptionKey;
  if (!raw) return null;
  if (/^[0-9a-fA-F]{64}$/.test(raw)) return Buffer.from(raw, 'hex');
  const b = Buffer.from(raw, 'base64');
  return b.length === 32 ? b : null;
}

const isConfigured = () => getKey() !== null;

/** AES-256-GCM. Output format: v1:<iv>:<tag>:<ciphertext> (all base64). */
function encrypt(plain) {
  const key = getKey();
  if (!key) throw new Error('ENCRYPTION_KEY is missing or not 32 bytes (hex or base64).');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  return ['v1', iv.toString('base64'), cipher.getAuthTag().toString('base64'), enc.toString('base64')].join(':');
}

function decrypt(payload) {
  const key = getKey();
  if (!key) throw new Error('ENCRYPTION_KEY is missing or not 32 bytes (hex or base64).');
  const [version, iv, tag, data] = String(payload).split(':');
  if (version !== 'v1' || !iv || !tag || !data) throw new Error('Unsupported ciphertext format.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'base64'));
  decipher.setAuthTag(Buffer.from(tag, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(data, 'base64')), decipher.final()]).toString('utf8');
}

module.exports = { isConfigured, encrypt, decrypt };
