'use strict';
/** Helpers for commands with subcommands / groups. */

/** Runs handlers[`group.sub`] or handlers[sub]. */
async function dispatch(interaction, handlers) {
  const group = interaction.options.getSubcommandGroup(false);
  const sub = interaction.options.getSubcommand(false);
  const key = group ? `${group}.${sub}` : sub;
  const fn = handlers[key];
  if (!fn) throw new Error(`No handler for subcommand "${key}"`);
  return fn(interaction);
}

/** Extracts up to `max` role IDs from a string of mentions / raw IDs and keeps only roles that exist in the guild. */
function parseRoles(input, guild, max = 5) {
  if (!input) return [];
  const ids = [...new Set(String(input).match(/\d{17,20}/g) ?? [])];
  return ids.filter((id) => guild.roles.cache.has(id) && id !== guild.id).slice(0, max);
}

/** Splits a comma / newline separated list, trims, lowercases and de-duplicates. */
function parseList(input, { max = 50, maxLength = 60, lower = true } = {}) {
  return [...new Set(String(input ?? '')
    .split(/[,\n]/)
    .map((s) => (lower ? s.trim().toLowerCase() : s.trim()))
    .filter((s) => s.length > 0 && s.length <= maxLength))].slice(0, max);
}

module.exports = { dispatch, parseRoles, parseList };
