'use strict';
/** SSRF protection helpers for user-supplied URLs (webhooks, direct audio links). */
const dns = require('node:dns').promises;
const net = require('node:net');

function ipv4ToInt(ip) {
  return ip.split('.').reduce((acc, o) => (acc * 256) + Number(o), 0);
}
const V4_BLOCKS = [
  ['0.0.0.0', 8], ['10.0.0.0', 8], ['100.64.0.0', 10], ['127.0.0.0', 8], ['169.254.0.0', 16],
  ['172.16.0.0', 12], ['192.0.0.0', 24], ['192.168.0.0', 16], ['198.18.0.0', 15], ['224.0.0.0', 4], ['240.0.0.0', 4],
].map(([base, bits]) => ({ base: ipv4ToInt(base), size: 2 ** (32 - bits) }));

function isPrivateIp(ip) {
  const family = net.isIP(ip);
  if (family === 4) {
    const n = ipv4ToInt(ip);
    return V4_BLOCKS.some((b) => n >= b.base && n < b.base + b.size);
  }
  if (family === 6) {
    const lower = ip.toLowerCase();
    if (lower === '::' || lower === '::1') return true;
    const mapped = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateIp(mapped[1]);
    return /^f[cd]/.test(lower) || /^fe[89ab]/.test(lower) || lower.startsWith('ff'); // ULA, link-local, multicast
  }
  return true; // not an IP => treat as unsafe
}

const DISCORD_WEBHOOK_HOSTS = new Set(['discord.com', 'ptb.discord.com', 'canary.discord.com', 'discordapp.com']);

/** Parses and validates a URL; resolves DNS and rejects private/internal addresses. Returns the URL object. */
async function assertPublicUrl(raw, { allowHttp = false } = {}) {
  let url;
  try { url = new URL(raw); } catch { throw new Error('That is not a valid URL.'); }
  if (url.protocol !== 'https:' && !(allowHttp && url.protocol === 'http:')) throw new Error('Only https:// URLs are allowed.');
  if (url.username || url.password) throw new Error('URLs containing credentials are not allowed.');
  const host = url.hostname.replace(/^\[|\]$/g, '');
  if (net.isIP(host)) {
    if (isPrivateIp(host)) throw new Error('That address points to a private network.');
    return url;
  }
  if (host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) throw new Error('That host is not allowed.');
  let records;
  try { records = await dns.lookup(host, { all: true }); } catch { throw new Error('Could not resolve that host.'); }
  if (!records.length || records.some((r) => isPrivateIp(r.address))) throw new Error('That host resolves to a private network.');
  return url;
}

function isDiscordWebhookUrl(raw) {
  try {
    const u = new URL(raw);
    return u.protocol === 'https:' && DISCORD_WEBHOOK_HOSTS.has(u.hostname) && /^\/api\/(v\d+\/)?webhooks\/\d+\/[\w-]+\/?$/.test(u.pathname);
  } catch { return false; }
}

module.exports = { isPrivateIp, assertPublicUrl, isDiscordWebhookUrl };
