'use strict';
const { PermissionsBitField, PermissionFlagsBits: P } = require('discord.js');
const { AppError } = require('./errors');
const { DANGEROUS_PERMISSIONS } = require('../config/constants');
const { getClient } = require('./context');

const permNames = (perms) => new PermissionsBitField(perms).toArray().map((n) => n.replace(/([a-z])([A-Z])/g, '$1 $2'));

/** Names of permissions the bot lacks in a guild or channel. */
function missingBotPermissions(guild, perms, channel = null) {
  const me = guild.members.me;
  if (!me) return permNames(perms);
  const have = channel ? channel.permissionsFor(me) : me.permissions;
  if (!have) return permNames(perms);
  return permNames(new PermissionsBitField(perms).remove(have.bitfield));
}

function assertBotPermissions(guild, perms, channel = null) {
  const missing = missingBotPermissions(guild, perms, channel);
  if (missing.length) throw new AppError(`I'm missing the following permission(s): **${missing.join(', ')}**.`);
}

/**
 * Hierarchy checks shared by every moderation action.
 * Returns an error string, or null if `actor` may act on `target`.
 */
function hierarchyProblem(guild, actor, target, { needBot = true } = {}) {
  const client = getClient();
  if (!target) return null; // user not in the server: only Discord-level checks apply (bans by ID)
  if (target.id === actor.id) return 'You cannot do that to yourself.';
  if (target.id === client.user.id) return 'I cannot do that to myself.';
  if (target.id === guild.ownerId) return 'You cannot moderate the server owner.';
  if (actor.id !== guild.ownerId && actor.roles.highest.comparePositionTo(target.roles.highest) <= 0) {
    return 'You cannot moderate someone with an equal or higher role than yours.';
  }
  if (needBot) {
    const me = guild.members.me;
    if (!me || me.roles.highest.comparePositionTo(target.roles.highest) <= 0) {
      return "I can't moderate that member because their highest role is equal to or above mine.";
    }
  }
  return null;
}

/** Roles that must never be assigned by automated systems. */
const isDangerousRole = (role) => DANGEROUS_PERMISSIONS.some((p) => role.permissions.has(p));

/**
 * Validates a role that will be assigned automatically. `actor` (GuildMember) is the admin configuring it.
 */
function assertAssignableRole(guild, role, actor = null) {
  if (role.id === guild.id) throw new AppError('You cannot use @everyone here.');
  if (role.managed) throw new AppError('That role is managed by an integration and cannot be assigned manually.');
  const me = guild.members.me;
  if (!me || me.roles.highest.comparePositionTo(role) <= 0) throw new AppError("I can't assign that role — it is above (or equal to) my highest role.");
  if (isDangerousRole(role)) throw new AppError('That role has powerful permissions (admin/moderation) and cannot be assigned automatically.');
  if (actor && actor.id !== guild.ownerId && actor.roles.highest.comparePositionTo(role) <= 0) {
    throw new AppError('You can only configure roles below your own highest role.');
  }
}

/** True if the member is server staff (used to exempt moderators from spam / AutoMod). */
const isStaff = (member) =>
  member.permissions.has(P.Administrator) || member.permissions.has(P.ManageGuild) || member.permissions.has(P.ManageMessages);

const isBotOwner = (userId) => require('../config/env').ownerIds.includes(userId);

module.exports = { permNames, missingBotPermissions, assertBotPermissions, hierarchyProblem, isDangerousRole, assertAssignableRole, isStaff, isBotOwner };
