'use strict';
const fs = require('node:fs');
const path = require('node:path');
const logger = require('./logger');

function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full));
    else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

/** Loads every command module under src/commands. Returns Map<name, command>. */
function loadCommands() {
  const commands = new Map();
  for (const file of walk(path.join(__dirname, '..', 'commands'))) {
    const cmd = require(file);
    if (!cmd?.data?.name || typeof cmd.execute !== 'function') { logger.warn(`Skipping invalid command file: ${path.relative(process.cwd(), file)}`); continue; }
    if (commands.has(cmd.data.name)) throw new Error(`Duplicate command name "${cmd.data.name}" in ${file}`);
    commands.set(cmd.data.name, cmd);
  }
  return commands;
}

/** Registers every handler exported from src/events/*.js (module.exports = handler | handler[]). */
function registerEvents(client) {
  let count = 0;
  for (const file of walk(path.join(__dirname, '..', 'events'))) {
    const mod = require(file);
    for (const h of Array.isArray(mod) ? mod : [mod]) {
      if (!h?.name || typeof h.execute !== 'function') continue;
      const wrapped = async (...args) => {
        try { await h.execute(...args); } catch (err) { logger.error(`Event handler "${h.name}" failed (${path.basename(file)})`, err); }
      };
      if (h.once) client.once(h.name, wrapped); else client.on(h.name, wrapped);
      count += 1;
    }
  }
  logger.info(`Registered ${count} event handlers.`);
}

module.exports = { loadCommands, registerEvents };
