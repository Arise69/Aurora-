'use strict';
const { MessageFlags } = require('discord.js');

/** Sends, edits or follows up depending on the interaction state. Ephemeral by default for status text. */
async function respond(interaction, payload, { ephemeral = true } = {}) {
  const body = typeof payload === 'string' ? { content: payload } : { ...payload };
  if (!body.allowedMentions) body.allowedMentions = { parse: [] };
  if (interaction.deferred) {
    delete body.flags;
    return interaction.editReply(body);
  }
  if (interaction.replied) {
    if (ephemeral) body.flags = MessageFlags.Ephemeral;
    return interaction.followUp(body);
  }
  if (ephemeral) body.flags = MessageFlags.Ephemeral;
  return interaction.reply(body);
}

const ok = (i, text, opts) => respond(i, `✅ ${text}`, opts);
const info = (i, text, opts) => respond(i, `ℹ️ ${text}`, opts);

/** Error replies are always private; if a public defer already happened, replace it with a private follow-up. */
async function fail(interaction, text) {
  const content = `❌ ${text}`;
  const body = { content, allowedMentions: { parse: [] } };
  try {
    if (interaction.deferred && interaction.ephemeral === false) {
      await interaction.deleteReply().catch(() => {});
      return await interaction.followUp({ ...body, flags: MessageFlags.Ephemeral });
    }
    return await respond(interaction, body);
  } catch { /* interaction expired – nothing more we can do */ }
  return null;
}

/** Defer helper: ephemeral unless told otherwise. */
const defer = (interaction, ephemeral = true) =>
  interaction.deferred || interaction.replied ? null : interaction.deferReply(ephemeral ? { flags: MessageFlags.Ephemeral } : {});

module.exports = { respond, ok, info, fail, defer };
