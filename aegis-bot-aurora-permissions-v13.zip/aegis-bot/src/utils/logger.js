'use strict';
/** Minimal leveled logger that redacts secrets (tokens, webhook URLs, env secrets) from every line. */
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const threshold = () => LEVELS[(process.env.LOG_LEVEL || 'info').toLowerCase()] ?? 20;

const PATTERNS = [
  /https?:\/\/(?:[\w-]+\.)?discord(?:app)?\.com\/api\/(?:v\d+\/)?webhooks\/\d+\/[\w-]+/gi,
  /[MNO][A-Za-z\d_-]{23,27}\.[\w-]{6,7}\.[\w-]{27,}/g,
];
const secretValues = () =>
  ['DISCORD_TOKEN', 'ENCRYPTION_KEY', 'DATABASE_URL'].map((k) => process.env[k]).filter((v) => v && v.length >= 8);

function redact(input) {
  let s = typeof input === 'string' ? input : String(input);
  for (const p of PATTERNS) s = s.replace(p, '[REDACTED]');
  for (const secret of secretValues()) s = s.split(secret).join('[REDACTED]');
  return s;
}

function format(value) {
  if (value instanceof Error) return value.stack || value.message;
  if (value && typeof value === 'object') {
    try { return JSON.stringify(value); } catch { return String(value); }
  }
  return String(value);
}

function write(level, msg, meta) {
  if (LEVELS[level] < threshold()) return;
  const parts = [new Date().toISOString(), level.toUpperCase().padEnd(5), redact(format(msg))];
  if (meta !== undefined) parts.push(redact(format(meta)));
  (level === 'error' || level === 'warn' ? console.error : console.log)(parts.join(' '));
}

module.exports = {
  redact,
  debug: (m, x) => write('debug', m, x),
  info: (m, x) => write('info', m, x),
  warn: (m, x) => write('warn', m, x),
  error: (m, x) => write('error', m, x),
};
