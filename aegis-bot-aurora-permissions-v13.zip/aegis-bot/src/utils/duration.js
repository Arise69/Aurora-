'use strict';
const UNITS = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000, w: 604_800_000 };

/** "1d12h30m" -> milliseconds. Returns null for anything malformed. */
function parseDuration(input) {
  if (typeof input !== 'string') return null;
  const str = input.trim().toLowerCase().replace(/\s+/g, '');
  if (str.length === 0 || str.length > 32 || !/^(\d+(?:\.\d+)?[smhdw])+$/.test(str)) return null;
  let total = 0;
  for (const m of str.matchAll(/(\d+(?:\.\d+)?)([smhdw])/g)) total += parseFloat(m[1]) * UNITS[m[2]];
  return Number.isFinite(total) && total > 0 ? Math.round(total) : null;
}

/** milliseconds -> "1d 12h 30m" (max 3 units). */
function formatDuration(ms) {
  if (!Number.isFinite(ms) || ms <= 0) return '0s';
  const parts = [];
  let rest = Math.round(ms / 1000);
  for (const [label, size] of [['d', 86400], ['h', 3600], ['m', 60], ['s', 1]]) {
    const n = Math.floor(rest / size);
    if (n > 0) { parts.push(`${n}${label}`); rest -= n * size; }
    if (parts.length === 3) break;
  }
  return parts.join(' ') || '0s';
}

const unix = (ms) => Math.floor(ms / 1000);
/** Discord timestamp markdown. Styles: t T d D f F R */
const discordTime = (ms, style = 'f') => `<t:${unix(ms)}:${style}>`;

module.exports = { parseDuration, formatDuration, discordTime, unix };
