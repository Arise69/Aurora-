'use strict';
const { SlashCommandBuilder, InteractionContextType } = require('discord.js');

/** New guild-only slash command with optional default member permissions. */
function newCommand(name, description, perms = null) {
  const b = new SlashCommandBuilder().setName(name).setDescription(description).setContexts(InteractionContextType.Guild);
  if (perms !== null && perms !== undefined) b.setDefaultMemberPermissions(perms);
  return b;
}

const reasonOpt = (o, required = false) => o.setName('reason').setDescription('Reason (shown in logs)').setMaxLength(500).setRequired(required);

module.exports = { newCommand, reasonOpt };
