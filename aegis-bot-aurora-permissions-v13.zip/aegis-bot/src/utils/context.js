'use strict';
let client = null;
module.exports = {
  setClient(c) { client = c; },
  getClient() {
    if (!client) throw new Error('Discord client has not been initialised yet.');
    return client;
  },
  hasClient: () => client !== null,
};
