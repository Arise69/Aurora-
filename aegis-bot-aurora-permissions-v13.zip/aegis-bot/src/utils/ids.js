'use strict';
const crypto = require('node:crypto');
// Crockford base32 (no I, L, O, U) - easy to read aloud and type.
const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';

function shortId(length = 8) {
  const bytes = crypto.randomBytes(length);
  let out = '';
  for (let i = 0; i < length; i++) out += ALPHABET[bytes[i] % 32];
  return out;
}

module.exports = { shortId };
