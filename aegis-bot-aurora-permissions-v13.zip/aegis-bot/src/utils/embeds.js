'use strict';
const { EmbedBuilder } = require('discord.js');
const { COLORS } = require('../config/constants');

const clip = (str, max) => {
  const s = String(str ?? '');
  return s.length > max ? `${s.slice(0, max - 1)}…` : s;
};

/** Neutralises markdown / mention injection when echoing user text inside embeds. */
const escapeText = (str) => String(str ?? '').replace(/[\\*_~`|>]/g, '\\$&').replace(/@(everyone|here)/gi, '@\u200b$1');

function makeEmbed({ title, description, color = COLORS.primary, fields, footer, timestamp = true, thumbnail, author } = {}) {
  const e = new EmbedBuilder().setColor(color);
  if (title) e.setTitle(clip(title, 256));
  if (description) e.setDescription(clip(description, 4000));
  if (fields?.length) {
    const clean = fields
      .filter((f) => f && f.value !== undefined && f.value !== null && String(f.value).length > 0)
      .slice(0, 25)
      .map((f) => ({ name: clip(f.name, 256), value: clip(f.value, 1024), inline: Boolean(f.inline) }));
    if (clean.length) e.addFields(clean);
  }
  if (footer) e.setFooter({ text: clip(footer, 2048) });
  if (thumbnail) e.setThumbnail(thumbnail);
  if (author) e.setAuthor(author);
  if (timestamp) e.setTimestamp(timestamp === true ? new Date() : timestamp);
  return e;
}

/** "@user (`username` · `id`)" */
function describeUser(user) {
  if (!user) return 'Unknown';
  return `<@${user.id}> (\`${escapeText(user.username ?? 'unknown')}\` · \`${user.id}\`)`;
}

/** Standard moderation-log embed: Action, User, Moderator/System, Reason, Timestamp, IDs. */
function modEmbed({ action, color = COLORS.mod, target, moderator, reason, fields = [], ids = {} }) {
  const idFooter = Object.entries(ids).filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`).join(' • ');
  return makeEmbed({
    title: action,
    color,
    thumbnail: target?.displayAvatarURL?.(),
    fields: [
      { name: 'User', value: describeUser(target), inline: true },
      { name: 'Moderator', value: moderator ? describeUser(moderator) : '🤖 System', inline: true },
      { name: 'Reason', value: clip(reason || 'No reason provided', 1000) },
      ...fields,
    ],
    footer: idFooter || (target ? `User ID: ${target.id}` : undefined),
  });
}

const simple = (color, text) => makeEmbed({ description: text, color, timestamp: false });
const successEmbed = (t) => simple(COLORS.success, `✅ ${t}`);
const errorEmbed = (t) => simple(COLORS.error, `❌ ${t}`);
const infoEmbed = (t) => simple(COLORS.info, `ℹ️ ${t}`);

module.exports = { clip, escapeText, makeEmbed, describeUser, modEmbed, successEmbed, errorEmbed, infoEmbed };
