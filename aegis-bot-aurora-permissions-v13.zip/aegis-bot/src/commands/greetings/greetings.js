'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const greetings = require('../../services/greetings');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

const KINDS = ['welcome', 'leave', 'boost'];
const opts = (s) => s
  .addBooleanOption((o) => o.setName('enabled').setDescription('Turn this greeting on or off'))
  .addChannelOption((o) => o.setName('channel').setDescription('Channel to post in').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
  .addStringOption((o) => o.setName('message').setDescription('Message text — see /greetings variables').setMaxLength(1000))
  .addBooleanOption((o) => o.setName('embed').setDescription('Send as an embed'))
  .addIntegerOption((o) => o.setName('delete-after').setDescription('Delete after N seconds (0 = keep)').setMinValue(0).setMaxValue(3600))
  .addBooleanOption((o) => o.setName('dm').setDescription('Also DM the member (welcome/boost only)'));

module.exports = {
  category: 'Greetings',
  userPermissions: [P.ManageGuild],
  data: newCommand('greetings', 'Welcome, leave and boost messages', P.ManageGuild)
    .addSubcommand((s) => opts(s.setName('welcome').setDescription('Configure the welcome message')))
    .addSubcommand((s) => opts(s.setName('leave').setDescription('Configure the leave message')))
    .addSubcommand((s) => opts(s.setName('boost').setDescription('Configure the server-boost message')))
    .addSubcommand((s) => s.setName('test').setDescription('Preview a greeting using yourself').addStringOption((o) => o.setName('type').setDescription('Greeting').setRequired(true).addChoices(...KINDS.map((k) => ({ name: k, value: k })))))
    .addSubcommand((s) => s.setName('variables').setDescription('List the message placeholders'))
    .addSubcommand((s) => s.setName('status').setDescription('Show all greetings')),
  execute: (i) => {
    const configure = (kind) => async (interaction) => {
      const o = interaction.options;
      const channel = o.getChannel('channel');
      if (channel && !interaction.guild.channels.cache.get(channel.id)?.permissionsFor(interaction.guild.members.me)?.has([P.ViewChannel, P.SendMessages])) {
        throw new AppError(`I can't send messages in <#${channel.id}>.`);
      }
      if (o.getBoolean('enabled') === null && !channel && !o.getString('message') && o.getBoolean('embed') === null && o.getInteger('delete-after') === null && o.getBoolean('dm') === null) {
        throw new AppError('Provide at least one option to change.');
      }
      const next = await config.update(interaction.guildId, 'greetings', (c) => {
        const g = c[kind];
        if (o.getBoolean('enabled') !== null) g.enabled = o.getBoolean('enabled');
        if (channel) g.channelId = channel.id;
        if (o.getString('message')) g.message = o.getString('message');
        if (o.getBoolean('embed') !== null) g.embed = o.getBoolean('embed');
        if (o.getInteger('delete-after') !== null) g.deleteAfterSec = o.getInteger('delete-after');
        if (o.getBoolean('dm') !== null) g.dm = o.getBoolean('dm');
        if (g.enabled && !g.channelId && !g.dm) throw new AppError('Set a channel (or enable DMs) before enabling this greeting.');
      }, { actorId: interaction.user.id, summary: `Greeting "${kind}" updated` });
      return ok(interaction, `**${kind}** greeting saved (${next[kind].enabled ? 'enabled' : 'disabled'}). Use \`/greetings test type:${kind}\` to preview.`);
    };
    return dispatch(i, {
      welcome: configure('welcome'), leave: configure('leave'), boost: configure('boost'),
      async test(interaction) {
        const kind = interaction.options.getString('type', true);
        const cfg = (await config.get(interaction.guildId, 'greetings'))[kind];
        if (!cfg.enabled) throw new AppError(`The ${kind} greeting is disabled. Enable it first.`);
        await greetings.sendGreeting(kind, interaction.member);
        return ok(interaction, `Preview sent${cfg.channelId ? ` to <#${cfg.channelId}>` : ''}.`);
      },
      async variables(interaction) {
        return respond(interaction, '**Placeholders**\n`{user}` mention • `{user.name}` username • `{user.id}` ID • `{server}` server name • `{count}` member count');
      },
      async status(interaction) {
        const c = await config.get(interaction.guildId, 'greetings');
        return respond(interaction, { embeds: [makeEmbed({ title: '👋 Greetings', timestamp: false, fields: KINDS.map((k) => ({
          name: `${c[k].enabled ? '✅' : '⚪'} ${k}`, value: `${c[k].channelId ? `<#${c[k].channelId}>` : 'no channel'} • ${c[k].embed ? 'embed' : 'text'}${c[k].dm ? ' • DM' : ''}\n${c[k].message.slice(0, 150)}`,
        })) })] });
      },
    });
  },
};
