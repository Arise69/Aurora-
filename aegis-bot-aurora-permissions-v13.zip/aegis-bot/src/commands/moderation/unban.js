'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand, reasonOpt } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { AppError } = require('../../utils/errors');
const { ok } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.BanMembers],
  botPermissions: [P.BanMembers],
  data: newCommand('unban', 'Unban a user by ID', P.BanMembers)
    .addStringOption((o) => o.setName('user-id').setDescription('User ID').setRequired(true).setMinLength(17).setMaxLength(20))
    .addStringOption((o) => reasonOpt(o)),
  async execute(interaction) {
    const id = interaction.options.getString('user-id', true).trim();
    if (!/^\d{17,20}$/.test(id)) throw new AppError('That is not a valid user ID.');
    const user = await moderation.unban({ guild: interaction.guild, userId: id, moderator: interaction.member, reason: interaction.options.getString('reason') });
    return ok(interaction, `Unbanned **${user.username}**.`);
  },
};
