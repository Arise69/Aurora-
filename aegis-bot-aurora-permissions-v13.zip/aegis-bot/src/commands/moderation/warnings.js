'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { makeEmbed, escapeText, clip } = require('../../utils/embeds');
const { discordTime } = require('../../utils/duration');
const { respond } = require('../../utils/reply');
const { COLORS } = require('../../config/constants');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ModerateMembers],
  data: newCommand('warnings', "List a user's warnings", P.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const rows = await moderation.listWarnings(interaction.guildId, user.id);
    if (!rows.length) return respond(interaction, `ℹ️ **${escapeText(user.username)}** has no warnings.`);
    const lines = rows.slice(0, 15).map((w) => `**\`${w.id}\`** • ${discordTime(Number(w.created_at), 'd')} • <@${w.moderator_id}>\n> ${escapeText(clip(w.reason, 200))}`);
    return respond(interaction, { embeds: [makeEmbed({
      title: `⚠️ Warnings for ${user.username}`, color: COLORS.warning, thumbnail: user.displayAvatarURL(),
      description: lines.join('\n'), footer: `${rows.length} warning(s)${rows.length > 15 ? ' — showing the newest 15' : ''} • User ID: ${user.id}`,
    })] });
  },
};
