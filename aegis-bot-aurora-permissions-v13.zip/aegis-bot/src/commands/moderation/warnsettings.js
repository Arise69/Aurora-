'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const { AppError } = require('../../utils/errors');
const { parseDuration, formatDuration } = require('../../utils/duration');
const { dispatch } = require('../../utils/dispatch');
const { ok, respond } = require('../../utils/reply');
const { makeEmbed } = require('../../utils/embeds');

const describeRule = (t) => `**${t.count}** warnings → **${t.action}**${t.durationSec ? ` (${formatDuration(t.durationSec * 1000)})` : ''}`;

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ManageGuild],
  data: newCommand('warnsettings', 'Configure automatic punishments for warning counts', P.ManageGuild)
    .addSubcommand((s) => s.setName('set').setDescription('Set the punishment for reaching a warning count')
      .addIntegerOption((o) => o.setName('count').setDescription('Warning count that triggers it').setRequired(true).setMinValue(1).setMaxValue(50))
      .addStringOption((o) => o.setName('action').setDescription('Punishment').setRequired(true).addChoices(
        { name: 'Timeout', value: 'timeout' }, { name: 'Kick', value: 'kick' }, { name: 'Ban (optionally temporary)', value: 'ban' }))
      .addStringOption((o) => o.setName('duration').setDescription('For timeout / temp-ban, e.g. 1h, 1d (max 28d for timeouts)')))
    .addSubcommand((s) => s.setName('remove').setDescription('Remove the rule for a warning count')
      .addIntegerOption((o) => o.setName('count').setDescription('Warning count').setRequired(true).setMinValue(1).setMaxValue(50)))
    .addSubcommand((s) => s.setName('list').setDescription('Show the automatic punishment rules')),
  execute: (i) => dispatch(i, {
    async set(interaction) {
      const count = interaction.options.getInteger('count', true);
      const action = interaction.options.getString('action', true);
      const raw = interaction.options.getString('duration');
      const ms = raw ? parseDuration(raw) : 0;
      if (raw && !ms) throw new AppError('Invalid duration. Examples: `30m`, `1h`, `7d`.');
      if (action === 'timeout' && (!ms || ms > 28 * 86_400_000)) throw new AppError('Timeouts need a duration between 1 second and 28 days.');
      await config.update(interaction.guildId, 'warnings', (cfg) => {
        cfg.thresholds = cfg.thresholds.filter((t) => t.count !== count);
        if (cfg.thresholds.length >= 10) throw new AppError('You can configure at most 10 rules.');
        cfg.thresholds.push({ count, action, durationSec: Math.round((ms || 0) / 1000) });
        cfg.thresholds.sort((a, b) => a.count - b.count);
      }, { actorId: interaction.user.id, summary: `Warning rule set: ${count} warnings → ${action}` });
      return ok(interaction, `Rule saved: ${describeRule({ count, action, durationSec: Math.round(ms / 1000) })}.`);
    },
    async remove(interaction) {
      const count = interaction.options.getInteger('count', true);
      let removed = false;
      await config.update(interaction.guildId, 'warnings', (cfg) => {
        const before = cfg.thresholds.length;
        cfg.thresholds = cfg.thresholds.filter((t) => t.count !== count);
        removed = cfg.thresholds.length < before;
      }, { actorId: interaction.user.id, summary: `Warning rule removed for ${count} warnings` });
      if (!removed) throw new AppError('There is no rule for that warning count.');
      return ok(interaction, `Removed the rule for **${count}** warnings.`);
    },
    async list(interaction) {
      const cfg = await config.get(interaction.guildId, 'warnings');
      return respond(interaction, { embeds: [makeEmbed({ title: '⚠️ Warning thresholds', description: cfg.thresholds.length ? cfg.thresholds.map(describeRule).join('\n') : 'No automatic punishments configured.', timestamp: false })] });
    },
  }),
};
