'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand, reasonOpt } = require('../../utils/builder');
const tools = require('../../services/channelTools');
const { ok } = require('../../utils/reply');

const LOCKED = 'unlock' === 'lock';

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ManageChannels],
  botPermissions: [P.ManageRoles],
  data: newCommand('unlock', LOCKED ? 'Prevent @everyone from sending messages in a channel' : 'Restore @everyone messaging in a channel', P.ManageChannels)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel (default: this one)'))
    .addStringOption((o) => reasonOpt(o)),
  async execute(interaction) {
    const picked = interaction.options.getChannel('channel') ?? interaction.channel;
    const channel = interaction.guild.channels.cache.get(picked.id) ?? picked;
    await tools.setLocked({ guild: interaction.guild, channel, locked: LOCKED, moderator: interaction.member, reason: interaction.options.getString('reason') ?? undefined });
    return ok(interaction, `${LOCKED ? '🔒 Locked' : '🔓 Unlocked'} <#${channel.id}>.`);
  },
};
