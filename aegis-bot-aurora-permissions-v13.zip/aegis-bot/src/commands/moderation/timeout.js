'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand, reasonOpt } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { AppError } = require('../../utils/errors');
const { parseDuration, formatDuration } = require('../../utils/duration');
const { ok, defer } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ModerateMembers],
  botPermissions: [P.ModerateMembers],
  data: newCommand('timeout', 'Temporarily mute a member', P.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(true))
    .addStringOption((o) => o.setName('duration').setDescription('e.g. 10m, 2h, 1d (max 28d)').setRequired(true))
    .addStringOption((o) => reasonOpt(o)),
  async execute(interaction) {
    const target = interaction.options.getMember('user');
    if (!target) throw new AppError('That user is not in this server.');
    const ms = parseDuration(interaction.options.getString('duration', true));
    if (!ms) throw new AppError('Invalid duration. Examples: `10m`, `2h`, `1d`.');
    await defer(interaction, false);
    const applied = await moderation.timeout({ guild: interaction.guild, target, moderator: interaction.member, durationMs: ms, reason: interaction.options.getString('reason') });
    return ok(interaction, `Timed out **${target.user.username}** for ${formatDuration(applied)}.`, { ephemeral: false });
  },
};
