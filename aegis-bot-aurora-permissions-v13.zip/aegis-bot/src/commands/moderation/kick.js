'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand, reasonOpt } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { AppError } = require('../../utils/errors');
const { ok, defer } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.KickMembers],
  botPermissions: [P.KickMembers],
  data: newCommand('kick', 'Kick a member from the server', P.KickMembers)
    .addUserOption((o) => o.setName('user').setDescription('Member to kick').setRequired(true))
    .addStringOption((o) => reasonOpt(o)),
  async execute(interaction) {
    const target = interaction.options.getMember('user');
    if (!target) throw new AppError('That user is not in this server.');
    await defer(interaction, false);
    await moderation.kick({ guild: interaction.guild, target, moderator: interaction.member, reason: interaction.options.getString('reason') });
    return ok(interaction, `Kicked **${target.user.username}**.`, { ephemeral: false });
  },
};
