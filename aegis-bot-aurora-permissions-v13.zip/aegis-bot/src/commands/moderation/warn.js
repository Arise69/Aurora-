'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand, reasonOpt } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { AppError } = require('../../utils/errors');
const { ok, defer } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ModerateMembers],
  data: newCommand('warn', 'Warn a member', P.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('Member to warn').setRequired(true))
    .addStringOption((o) => reasonOpt(o, true)),
  async execute(interaction) {
    const target = interaction.options.getMember('user');
    if (!target) throw new AppError('That user is not in this server.');
    await defer(interaction, false);
    const r = await moderation.warn({ guild: interaction.guild, target, moderator: interaction.member, reason: interaction.options.getString('reason', true) });
    const extra = r.threshold ? ` Automatic **${r.threshold.action}** applied (${r.total} warnings).` : '';
    return ok(interaction, `Warned **${target.user.username}** — ID \`${r.id}\` (${r.total} total).${extra}`, { ephemeral: false });
  },
};
