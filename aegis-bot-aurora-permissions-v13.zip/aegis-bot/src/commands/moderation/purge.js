'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const tools = require('../../services/channelTools');
const { ok, defer } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ManageMessages],
  botPermissions: [P.ManageMessages, P.ReadMessageHistory],
  cooldown: 5,
  data: newCommand('purge', 'Bulk-delete recent messages in this channel', P.ManageMessages)
    .addIntegerOption((o) => o.setName('amount').setDescription('How many messages (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption((o) => o.setName('user').setDescription('Only delete messages from this user')),
  async execute(interaction) {
    await defer(interaction);
    const n = await tools.purge({
      guild: interaction.guild, channel: interaction.channel, amount: interaction.options.getInteger('amount', true),
      moderator: interaction.member, userId: interaction.options.getUser('user')?.id ?? null,
    });
    return ok(interaction, `Deleted **${n}** message(s).`);
  },
};
