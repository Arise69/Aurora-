'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand, reasonOpt } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { AppError } = require('../../utils/errors');
const { ok } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ModerateMembers],
  botPermissions: [P.ModerateMembers],
  data: newCommand('untimeout', 'Remove a member\'s timeout', P.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(true))
    .addStringOption((o) => reasonOpt(o)),
  async execute(interaction) {
    const target = interaction.options.getMember('user');
    if (!target) throw new AppError('That user is not in this server.');
    await moderation.untimeout({ guild: interaction.guild, target, moderator: interaction.member, reason: interaction.options.getString('reason') });
    return ok(interaction, `Removed the timeout from **${target.user.username}**.`);
  },
};
