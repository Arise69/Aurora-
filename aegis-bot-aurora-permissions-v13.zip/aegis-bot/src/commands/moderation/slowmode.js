'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const tools = require('../../services/channelTools');
const { ok } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ManageChannels],
  data: newCommand('slowmode', 'Set the slowmode for a channel', P.ManageChannels)
    .addIntegerOption((o) => o.setName('seconds').setDescription('0 disables slowmode (max 21600)').setRequired(true).setMinValue(0).setMaxValue(21600))
    .addChannelOption((o) => o.setName('channel').setDescription('Channel (default: this one)')),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel') ?? interaction.channel;
    const seconds = interaction.options.getInteger('seconds', true);
    await tools.setSlowmode({ guild: interaction.guild, channel: interaction.guild.channels.cache.get(channel.id) ?? channel, seconds, moderator: interaction.member });
    return ok(interaction, seconds ? `Slowmode in <#${channel.id}> set to **${seconds}s**.` : `Slowmode disabled in <#${channel.id}>.`);
  },
};
