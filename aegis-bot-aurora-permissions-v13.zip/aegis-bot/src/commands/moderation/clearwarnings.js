'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { ok } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ModerateMembers],
  data: newCommand('clearwarnings', 'Remove all warnings from a user', P.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const n = await moderation.clearWarnings({ guild: interaction.guild, userId: user.id, moderator: interaction.member });
    return ok(interaction, `Cleared **${n}** warning(s) for **${user.username}**.`);
  },
};
