'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { ok } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.ModerateMembers],
  data: newCommand('removewarning', 'Remove a single warning by its ID', P.ModerateMembers)
    .addStringOption((o) => o.setName('warning-id').setDescription('Warning ID (from /warnings)').setRequired(true).setMinLength(4).setMaxLength(16)),
  async execute(interaction) {
    const row = await moderation.removeWarning({ guild: interaction.guild, id: interaction.options.getString('warning-id', true).trim(), moderator: interaction.member });
    return ok(interaction, `Removed warning \`${row.id}\` from <@${row.user_id}>.`);
  },
};
