'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand, reasonOpt } = require('../../utils/builder');
const moderation = require('../../services/moderation');
const { AppError } = require('../../utils/errors');
const { parseDuration, formatDuration } = require('../../utils/duration');
const { ok, defer } = require('../../utils/reply');

module.exports = {
  category: 'Moderation',
  userPermissions: [P.BanMembers],
  botPermissions: [P.BanMembers],
  data: newCommand('ban', 'Ban a user (works on users not in the server)', P.BanMembers)
    .addUserOption((o) => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption((o) => reasonOpt(o))
    .addIntegerOption((o) => o.setName('delete-days').setDescription('Delete their messages from the last N days').setMinValue(0).setMaxValue(7))
    .addStringOption((o) => o.setName('duration').setDescription('Make it temporary, e.g. 3d (default: permanent)')),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const raw = interaction.options.getString('duration');
    const durationMs = raw ? parseDuration(raw) : 0;
    if (raw && !durationMs) throw new AppError('Invalid duration. Examples: `12h`, `3d`, `2w`.');
    await defer(interaction, false);
    await moderation.ban({
      guild: interaction.guild, targetUser: user, targetMember: interaction.options.getMember('user'), moderator: interaction.member,
      reason: interaction.options.getString('reason'), deleteDays: interaction.options.getInteger('delete-days') ?? 0, durationMs,
    });
    return ok(interaction, `Banned **${user.username}**${durationMs ? ` for ${formatDuration(durationMs)}` : ''}.`, { ephemeral: false });
  },
};
