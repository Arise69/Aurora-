'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { hierarchyProblem, assertBotPermissions } = require('../../utils/permissions');
const logging = require('../../services/logging');
const { makeEmbed, describeUser } = require('../../utils/embeds');
const { COLORS } = require('../../config/constants');
const { ok, defer } = require('../../utils/reply');

const VOICE_TYPES = [ChannelType.GuildVoice, ChannelType.GuildStageVoice];
const userOpt = (s, desc = 'Member in a voice channel') => s.addUserOption((o) => o.setName('user').setDescription(desc).setRequired(true));

/** Resolves a target that must be connected to voice, after permission + hierarchy checks. */
function voiceTarget(interaction, perm) {
  if (!interaction.memberPermissions.has(perm)) throw new AppError("You don't have permission to do that.");
  assertBotPermissions(interaction.guild, perm);
  const member = interaction.options.getMember('user');
  if (!member) throw new AppError('That user is not in this server.');
  if (!member.voice.channelId) throw new AppError('That member is not in a voice channel.');
  const problem = hierarchyProblem(interaction.guild, interaction.member, member);
  if (problem) throw new AppError(problem);
  return member;
}

const audit = (interaction, action, target, extra = []) => logging.send(interaction.guild, 'voice', makeEmbed({
  title: `🎙️ ${action}`, color: COLORS.mod,
  fields: [{ name: 'Member', value: describeUser(target.user ?? target), inline: true }, { name: 'Moderator', value: describeUser(interaction.user), inline: true }, ...extra],
}));

module.exports = {
  category: 'Voice Commands',
  cooldown: 3,
  data: newCommand('voice', 'Moderate voice channels')
    .addSubcommand((s) => userOpt(s.setName('mute').setDescription('Server-mute a member (Mute Members)')))
    .addSubcommand((s) => userOpt(s.setName('unmute').setDescription('Remove a server mute')))
    .addSubcommand((s) => userOpt(s.setName('deafen').setDescription('Server-deafen a member (Deafen Members)')))
    .addSubcommand((s) => userOpt(s.setName('undeafen').setDescription('Remove a server deafen')))
    .addSubcommand((s) => userOpt(s.setName('disconnect').setDescription('Disconnect a member from voice (Move Members)')))
    .addSubcommand((s) => userOpt(s.setName('move').setDescription('Move a member to another voice channel (Move Members)'))
      .addChannelOption((o) => o.setName('to').setDescription('Destination').setRequired(true).addChannelTypes(...VOICE_TYPES)))
    .addSubcommand((s) => s.setName('moveall').setDescription('Move everyone from one voice channel to another (Move Members)')
      .addChannelOption((o) => o.setName('from').setDescription('Source').setRequired(true).addChannelTypes(...VOICE_TYPES))
      .addChannelOption((o) => o.setName('to').setDescription('Destination').setRequired(true).addChannelTypes(...VOICE_TYPES)))
    .addSubcommand((s) => s.setName('disconnectall').setDescription('Disconnect everyone in a voice channel (Move Members)')
      .addChannelOption((o) => o.setName('channel').setDescription('Channel').setRequired(true).addChannelTypes(...VOICE_TYPES))),
  execute: (i) => dispatch(i, {
    async mute(x) { const m = voiceTarget(x, P.MuteMembers); await m.voice.setMute(true, `By ${x.user.username}`); await audit(x, 'Voice mute', m); return ok(x, `Muted **${m.user.username}**.`); },
    async unmute(x) { const m = voiceTarget(x, P.MuteMembers); await m.voice.setMute(false, `By ${x.user.username}`); await audit(x, 'Voice unmute', m); return ok(x, `Unmuted **${m.user.username}**.`); },
    async deafen(x) { const m = voiceTarget(x, P.DeafenMembers); await m.voice.setDeaf(true, `By ${x.user.username}`); await audit(x, 'Voice deafen', m); return ok(x, `Deafened **${m.user.username}**.`); },
    async undeafen(x) { const m = voiceTarget(x, P.DeafenMembers); await m.voice.setDeaf(false, `By ${x.user.username}`); await audit(x, 'Voice undeafen', m); return ok(x, `Undeafened **${m.user.username}**.`); },
    async disconnect(x) { const m = voiceTarget(x, P.MoveMembers); await m.voice.disconnect(`By ${x.user.username}`); await audit(x, 'Voice disconnect', m); return ok(x, `Disconnected **${m.user.username}**.`); },
    async move(x) {
      const m = voiceTarget(x, P.MoveMembers);
      const to = x.guild.channels.cache.get(x.options.getChannel('to', true).id);
      if (!to.permissionsFor(x.guild.members.me)?.has(P.Connect)) throw new AppError("I can't connect to that channel.");
      await m.voice.setChannel(to, `By ${x.user.username}`);
      await audit(x, 'Voice move', m, [{ name: 'To', value: `<#${to.id}>`, inline: true }]);
      return ok(x, `Moved **${m.user.username}** to <#${to.id}>.`);
    },
    async moveall(x) {
      if (!x.memberPermissions.has(P.MoveMembers)) throw new AppError("You don't have permission to do that.");
      assertBotPermissions(x.guild, P.MoveMembers);
      const from = x.guild.channels.cache.get(x.options.getChannel('from', true).id);
      const to = x.guild.channels.cache.get(x.options.getChannel('to', true).id);
      if (from.id === to.id) throw new AppError('Pick two different channels.');
      await defer(x);
      let n = 0;
      for (const m of [...from.members.values()]) if (await m.voice.setChannel(to, `Move-all by ${x.user.username}`).then(() => true, () => false)) n += 1;
      await audit(x, 'Voice move-all', x.member, [{ name: 'Moved', value: `${n} member(s) <#${from.id}> → <#${to.id}>` }]);
      return ok(x, `Moved **${n}** member(s).`);
    },
    async disconnectall(x) {
      if (!x.memberPermissions.has(P.MoveMembers)) throw new AppError("You don't have permission to do that.");
      assertBotPermissions(x.guild, P.MoveMembers);
      const ch = x.guild.channels.cache.get(x.options.getChannel('channel', true).id);
      await defer(x);
      let n = 0;
      for (const m of [...ch.members.values()]) {
        if (hierarchyProblem(x.guild, x.member, m)) continue;
        if (await m.voice.disconnect(`Disconnect-all by ${x.user.username}`).then(() => true, () => false)) n += 1;
      }
      await audit(x, 'Voice disconnect-all', x.member, [{ name: 'Disconnected', value: `${n} from <#${ch.id}>` }]);
      return ok(x, `Disconnected **${n}** member(s).`);
    },
  }),
};
