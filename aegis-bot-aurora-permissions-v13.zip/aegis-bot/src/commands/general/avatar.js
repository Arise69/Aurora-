'use strict';
const { newCommand } = require('../../utils/builder');
const { makeEmbed } = require('../../utils/embeds');
const { respond } = require('../../utils/reply');

module.exports = {
  category: 'General',
  cooldown: 3,
  data: newCommand('avatar', 'Show a user\'s avatar').addUserOption((o) => o.setName('user').setDescription('User (default: you)')),
  async execute(interaction) {
    const user = interaction.options.getUser('user') ?? interaction.user;
    return respond(interaction, { embeds: [makeEmbed({ title: `${user.username}'s avatar`, timestamp: false }).setImage(user.displayAvatarURL({ size: 1024 }))] });
  },
};
