'use strict';
const { ChannelType, version: djsVersion } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const { makeEmbed } = require('../../utils/embeds');
const { discordTime, formatDuration } = require('../../utils/duration');
const { respond } = require('../../utils/reply');

module.exports = {
  category: 'General',
  cooldown: 5,
  data: newCommand('botinfo', 'Show information about the bot'),
  async execute(interaction) {
    const c = interaction.client;
    return respond(interaction, { embeds: [makeEmbed({
      title: `About ${c.user.username}`, thumbnail: c.user.displayAvatarURL(),
      fields: [
        { name: 'Servers', value: String(c.guilds.cache.size), inline: true }, { name: 'Commands', value: String(c.commands.size), inline: true },
        { name: 'Uptime', value: formatDuration(c.uptime), inline: true }, { name: 'Ping', value: `${Math.round(c.ws.ping)}ms`, inline: true },
        { name: 'discord.js', value: `v${djsVersion}`, inline: true }, { name: 'Node.js', value: process.version, inline: true },
        { name: 'Memory', value: `${(process.memoryUsage().rss / 1048576).toFixed(0)} MB`, inline: true },
      ],
    })] });
  },
};
