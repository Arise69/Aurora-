'use strict';
const { ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const { makeEmbed } = require('../../utils/embeds');
const { discordTime } = require('../../utils/duration');
const { respond } = require('../../utils/reply');

module.exports = {
  category: 'General',
  cooldown: 5,
  data: newCommand('serverinfo', 'Show information about this server'),
  async execute(interaction) {
    const g = interaction.guild;
    const count = (t) => g.channels.cache.filter((c) => c.type === t).size;
    return respond(interaction, { embeds: [makeEmbed({
      title: g.name, thumbnail: g.iconURL(),
      fields: [
        { name: 'Owner', value: `<@${g.ownerId}>`, inline: true }, { name: 'Members', value: String(g.memberCount), inline: true },
        { name: 'Created', value: discordTime(g.createdTimestamp, 'R'), inline: true },
        { name: 'Channels', value: `${count(ChannelType.GuildText)} text • ${count(ChannelType.GuildVoice)} voice`, inline: true },
        { name: 'Roles', value: String(g.roles.cache.size), inline: true }, { name: 'Boosts', value: `${g.premiumSubscriptionCount ?? 0} (tier ${g.premiumTier})`, inline: true },
      ],
      footer: `Server ID: ${g.id}`,
    })] });
  },
};
