'use strict';
const config = require('../../services/guildConfig');
const help = require('../../services/help');
const { AppError } = require('../../utils/errors');
const { respond } = require('../../utils/reply');
const { newCommand } = require('../../utils/builder');

module.exports = {
  category: 'General',
  cooldown: 3,
  autocompletePermission: 0n,
  data: newCommand('help', 'Browse Aurora command modules')
    .addStringOption((o) => o.setName('context').setDescription('A module, command, or page number').setAutocomplete(true)),
  async execute(interaction) {
    const { prefix } = await config.get(interaction.guildId, 'general');
    const view = help.resolve(interaction.options.getString('context'), prefix, interaction.guild);
    if (!view) throw new AppError('No module or page with that name. Try `/help`.');
    return respond(interaction, view, { ephemeral: false });
  },
  async autocomplete(interaction) {
    const q = interaction.options.getFocused().toLowerCase();
    const names = [
      ...help.PAGES.map(([name]) => name),
      ...help.PAGES.flatMap(([, sections]) => sections.flatMap(([, commands]) => commands)),
    ];
    await interaction.respond(
      [...new Set(names)]
        .filter((n) => n.toLowerCase().includes(q))
        .slice(0, 25)
        .map((n) => ({ name: n, value: n })),
    );
  },
};
