'use strict';
const { newCommand } = require('../../utils/builder');
const { makeEmbed } = require('../../utils/embeds');
const { discordTime } = require('../../utils/duration');
const { respond } = require('../../utils/reply');
const moderation = require('../../services/moderation');

module.exports = {
  category: 'General',
  cooldown: 5,
  data: newCommand('userinfo', 'Show information about a member')
    .addUserOption((o) => o.setName('user').setDescription('Member (default: you)')),
  async execute(interaction) {
    const user = interaction.options.getUser('user') ?? interaction.user;
    const m = await interaction.guild.members.fetch(user.id).catch(() => null);
    const roles = m ? m.roles.cache.filter((r) => r.id !== interaction.guildId).sort((a, b) => b.position - a.position).map((r) => `<@&${r.id}>`).slice(0, 15).join(' ') : null;
    return respond(interaction, { embeds: [makeEmbed({
      title: user.username, thumbnail: user.displayAvatarURL(),
      fields: [
        { name: 'ID', value: user.id, inline: true }, { name: 'Bot', value: user.bot ? 'Yes' : 'No', inline: true },
        { name: 'Created', value: discordTime(user.createdTimestamp, 'R'), inline: true },
        m?.joinedTimestamp ? { name: 'Joined', value: discordTime(m.joinedTimestamp, 'R'), inline: true } : null,
        m && interaction.member.permissions.has('ModerateMembers') ? { name: 'Warnings', value: String(await moderation.countWarnings(interaction.guildId, user.id)), inline: true } : null,
        roles ? { name: 'Roles', value: roles } : null,
      ].filter(Boolean),
    })] });
  },
};
