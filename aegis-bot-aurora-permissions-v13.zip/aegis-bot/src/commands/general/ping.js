'use strict';
const { MessageFlags } = require('discord.js');
const { newCommand } = require('../../utils/builder');

module.exports = {
  category: 'General',
  cooldown: 5,
  data: newCommand('ping', 'Check the bot latency'),
  async execute(interaction) {
    const sent = await interaction.reply({ content: '🏓 Pinging…', flags: MessageFlags.Ephemeral, withResponse: true });
    const at = sent?.resource?.message?.createdTimestamp ?? Date.now();
    await interaction.editReply(`🏓 Pong! Round-trip **${at - interaction.createdTimestamp}ms** • API **${Math.round(interaction.client.ws.ping)}ms**`);
  },
};
