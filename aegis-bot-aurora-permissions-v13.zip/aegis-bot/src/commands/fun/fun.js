'use strict';
const crypto = require('node:crypto');
const { newCommand } = require('../../utils/builder');
const { dispatch } = require('../../utils/dispatch');
const { EIGHT_BALL } = require('../../utils/fun');
const { escapeText } = require('../../utils/embeds');
const { respond } = require('../../utils/reply');

const pick = (arr) => arr[crypto.randomInt(arr.length)];
const pub = (i, text) => respond(i, { content: text, allowedMentions: { parse: [] } }, { ephemeral: false });
const RPS = ['rock', 'paper', 'scissors'];
const EMOJI = { rock: '🪨', paper: '📄', scissors: '✂️' };

module.exports = {
  category: 'Fun Commands',
  cooldown: 3,
  data: newCommand('fun', 'Games and silly commands')
    .addSubcommand((s) => s.setName('8ball').setDescription('Ask the magic 8-ball').addStringOption((o) => o.setName('question').setDescription('Your question').setRequired(true).setMaxLength(200)))
    .addSubcommand((s) => s.setName('coinflip').setDescription('Flip a coin'))
    .addSubcommand((s) => s.setName('roll').setDescription('Roll dice').addIntegerOption((o) => o.setName('sides').setDescription('Sides (default 6)').setMinValue(2).setMaxValue(1000)).addIntegerOption((o) => o.setName('count').setDescription('How many dice (default 1)').setMinValue(1).setMaxValue(20)))
    .addSubcommand((s) => s.setName('rps').setDescription('Rock paper scissors vs the bot').addStringOption((o) => o.setName('choice').setDescription('Your move').setRequired(true).addChoices(...RPS.map((r) => ({ name: r, value: r })))))
    .addSubcommand((s) => s.setName('choose').setDescription('Let me choose').addStringOption((o) => o.setName('options').setDescription('Comma-separated options').setRequired(true).setMaxLength(500)))
    .addSubcommand((s) => s.setName('ship').setDescription('Ship two people').addUserOption((o) => o.setName('first').setDescription('First person').setRequired(true)).addUserOption((o) => o.setName('second').setDescription('Second person (default: you)')))
    .addSubcommand((s) => s.setName('rate').setDescription('Rate anything out of 10').addStringOption((o) => o.setName('thing').setDescription('What to rate').setRequired(true).setMaxLength(100)))
    .addSubcommand((s) => s.setName('reverse').setDescription('Reverse some text').addStringOption((o) => o.setName('text').setDescription('Text').setRequired(true).setMaxLength(300)))
    .addSubcommand((s) => s.setName('hug').setDescription('Give someone a hug').addUserOption((o) => o.setName('user').setDescription('Who to hug').setRequired(true))),
  execute: (i) => dispatch(i, {
    '8ball': (x) => pub(x, `🎱 **${escapeText(x.options.getString('question', true))}**\n${pick(EIGHT_BALL)}`),
    coinflip: (x) => pub(x, `🪙 **${crypto.randomInt(2) ? 'Heads' : 'Tails'}**`),
    roll(x) {
      const sides = x.options.getInteger('sides') ?? 6; const n = x.options.getInteger('count') ?? 1;
      const rolls = Array.from({ length: n }, () => crypto.randomInt(sides) + 1);
      return pub(x, `🎲 d${sides} × ${n}: **${rolls.join(', ')}**${n > 1 ? ` (total ${rolls.reduce((a, b) => a + b, 0)})` : ''}`);
    },
    rps(x) {
      const me = pick(RPS); const you = x.options.getString('choice', true);
      const win = { rock: 'scissors', paper: 'rock', scissors: 'paper' };
      const result = me === you ? "It's a tie!" : win[you] === me ? 'You win! 🎉' : 'I win! 😎';
      return pub(x, `${EMOJI[you]} vs ${EMOJI[me]} — ${result}`);
    },
    choose(x) {
      const options = x.options.getString('options', true).split(',').map((s) => s.trim()).filter(Boolean);
      return pub(x, options.length < 2 ? '❌ Give me at least two comma-separated options.' : `🤔 I choose: **${escapeText(pick(options))}**`);
    },
    ship(x) {
      const a = x.options.getUser('first', true); const b = x.options.getUser('second') ?? x.user;
      const seed = [a.id, b.id].sort().join(':'); const pct = crypto.createHash('sha256').update(seed).digest()[0] % 101;
      return pub(x, `💞 **${escapeText(a.username)}** × **${escapeText(b.username)}** — compatibility **${pct}%** ${'█'.repeat(Math.round(pct / 10))}${'░'.repeat(10 - Math.round(pct / 10))}`);
    },
    rate: (x) => pub(x, `⭐ I rate **${escapeText(x.options.getString('thing', true))}** a **${crypto.randomInt(11)}/10**`),
    reverse: (x) => pub(x, `🔁 ${escapeText([...x.options.getString('text', true)].reverse().join(''))}`),
    hug: (x) => pub(x, `🤗 **${escapeText(x.user.username)}** hugs **${escapeText(x.options.getUser('user', true).username)}**!`),
  }),
};
