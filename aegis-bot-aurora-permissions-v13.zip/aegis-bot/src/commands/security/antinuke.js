'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const DEFAULTS = require('../../config/defaults');
const antinuke = require('../../services/antinuke');
const permit = require('../../services/permit');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

const MODULES = [
  ['channel-create', 'channelCreate'], ['channel-delete', 'channelDelete'], ['channel-update', 'channelUpdate'],
  ['role-create', 'roleCreate'], ['role-delete', 'roleDelete'], ['role-update', 'roleUpdate'], ['role-position', 'rolePosition'],
  ['ban', 'ban'], ['kick', 'kick'], ['bot-add', 'botAdd'],
  ['webhook-create', 'webhookCreate'], ['webhook-delete', 'webhookDelete'], ['webhook-update', 'webhookUpdate'],
  ['guild-update', 'guildUpdate'], ['vanity-update', 'vanityUpdate'], ['onboarding-safeguard', 'onboardingSafeguard'], ['linkrole-protection', 'linkroleProtection'], ['invite-role-protection', 'inviteRoleProtection'], ['mainrole-protection', 'mainroleProtection'], ['integration', 'integration'], ['prune', 'prune'], ['emoji-delete', 'emojiDelete'], ['sticker-delete', 'stickerDelete'],
  ['member-role-update', 'memberRoleUpdate'], ['permission-escalation', 'permissionEscalation'], ['mention-spam', 'mentionSpam'],
];
const moduleChoices = MODULES.map(([name]) => ({ name, value: name }));
const ANTINUKE_ARROW = '<:whitearrow:1551669900622172161>';
const ANTINUKE_CHECK = '<:wccheckmark:1551675781527380011>';
const ANTINUKE_CROSS = '<:wccrossmar:1551676376313237504>';

async function ownerGuard(interaction, cfg) {
  if (!cfg.ownerOnly || interaction.user.id === interaction.guild.ownerId) return true;
  if (await permit.isPermitted(interaction.guildId, interaction.member, 'antinuke')) return true;
  throw new AppError('Anti-nuke settings are restricted to the server owner and Extra Owners.');
}

async function securityGuard(interaction, cfg) {
  if (await permit.isPermitted(interaction.guildId, interaction.member, 'antinuke')) return true;
  if (!interaction.memberPermissions?.has(P.ManageGuild)) throw new AppError('You need **Manage Server** to use this command.');
  return true;
}
function getBool(interaction, name) {
  const value = interaction.options.getBoolean(name);
  if (value === null) throw new AppError(`Choose whether **${name}** should be enabled or disabled.`);
  return value;
}

function requireEnabled(cfg) {
  if (!cfg.enabled) throw new AppError(`${ANTINUKE_CROSS} Antinuke is not enabled in this server. Use \`/antinuke enable\` to enable it.`);
}

function configEmbed(c) {
  const lines = Object.entries(c.modules ?? {}).map(([key, value]) => `${key}: **${value ? 'ON' : 'OFF'}**`).join('\n');
  return makeEmbed({ title: '🛡️ Anti-nuke configuration', color: 0x2c2c2c, fields: [
    { name: 'Status', value: c.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
    { name: 'Owner-only', value: c.ownerOnly ? 'On' : 'Off', inline: true },
    { name: 'Betrayal guard', value: c.betrayalGuard ? 'On' : 'Off', inline: true },
    { name: 'Window', value: `${c.windowSec}s`, inline: true },
    { name: 'Punishment', value: c.punishment, inline: true },
    { name: 'Auto-recovery', value: c.autoRecovery ? 'On' : 'Off', inline: true },
    { name: 'Normal limits', value: Object.entries(c.limits).map(([k, v]) => `• ${k}: **${v}**`).join('\n') },
    { name: 'Betrayal limits', value: Object.entries(c.betrayalLimits ?? {}).map(([k, v]) => `• ${k}: **${v}**`).join('\n') },
    { name: 'Modules', value: lines },
    { name: 'Whitelist', value: c.whitelist?.length ? c.whitelist.map((id) => `<@${id}>`).join(' ') : 'None' },
  ] });
}

module.exports = {
  category: 'Security',
  botPermissions: [P.ViewAuditLog],
  cooldown: 3,
  data: newCommand('antinuke', 'Protect the server from destructive mass actions', P.ManageGuild)
    .addSubcommand((s) => s.setName('wizard').setDescription('Apply a strong one-click anti-nuke setup'))
    .addSubcommand((s) => s.setName('owneronly').setDescription('Require the server owner to change anti-nuke settings').addBooleanOption((o) => o.setName('enabled').setDescription('Enable owner-only settings').setRequired(true)))
    .addSubcommand((s) => s.setName('betrayalguard').setDescription('Protect against dangerous actions by whitelisted users').addBooleanOption((o) => o.setName('enabled').setDescription('Enable betrayal guard').setRequired(true)))
    .addSubcommand((s) => s.setName('enable').setDescription('Enable and configure anti-nuke'))
    .addSubcommand((s) => s.setName('disable').setDescription('Disable and reset anti-nuke'))
    .addSubcommand((s) => s.setName('limit').setDescription('Set a module threshold').addStringOption((o) => o.setName('module').setDescription('Protected action key').setRequired(true)).addIntegerOption((o) => o.setName('amount').setDescription('Actions in the detection window').setMinValue(1).setMaxValue(50).setRequired(true)))
    .addSubcommand((s) => s.setName('whitelisted').setDescription('Show the anti-nuke whitelist'))
    .addSubcommand((s) => s.setName('manage').setDescription('Show the complete anti-nuke configuration'))
    .addSubcommand((s) => s.setName('logging').setDescription('Set or clear the anti-nuke log channel').addChannelOption((o) => o.setName('channel').setDescription('Security log channel')))
    .addSubcommand((s) => s.setName('whitelist').setDescription('Add or remove a trusted user').addStringOption((o) => o.setName('action').setDescription('Action').setRequired(true).addChoices({ name: 'Add', value: 'add' }, { name: 'Remove', value: 'remove' }, { name: 'Clear', value: 'clear' })).addUserOption((o) => o.setName('user').setDescription('User to trust')))
    .addSubcommand((s) => s.setName('config').setDescription('Configure core anti-nuke settings').addIntegerOption((o) => o.setName('window').setDescription('Detection window in seconds').setMinValue(5).setMaxValue(300)).addStringOption((o) => o.setName('punishment').setDescription('Action on trigger').addChoices({ name: 'Strip privileged roles', value: 'strip' }, { name: 'Kick', value: 'kick' }, { name: 'Ban', value: 'ban' })))
    .addSubcommand((s) => s.setName('autorecovery').setDescription('Automatically restore deleted channels and roles').addBooleanOption((o) => o.setName('enabled').setDescription('Enable recovery').setRequired(true)))
    .addSubcommand((s) => s.setName('module').setDescription('Enable or disable a protection module').addStringOption((o) => o.setName('name').setDescription('Module key').setRequired(true)).addBooleanOption((o) => o.setName('enabled').setDescription('Enable the module').setRequired(true)))
    .addSubcommand((s) => s.setName('status').setDescription('Show anti-nuke status')),

  execute: async (i) => {
    const cfg = await config.get(i.guildId, 'antinuke');
    if (i.options.getSubcommand() !== 'status') await securityGuard(i, cfg);
    return dispatch(i, {
    async wizard(interaction) {
      const c = await config.get(interaction.guildId, 'antinuke'); await ownerGuard(interaction, c);
      if (!interaction.guild.members.me.permissions.has([P.ViewAuditLog, P.ManageChannels, P.ManageRoles, P.BanMembers, P.KickMembers, P.ModerateMembers, P.ManageWebhooks])) throw new AppError('I need the anti-nuke permissions first: View Audit Log, Manage Channels/Roles/Webhooks, Ban Members, Kick Members and Moderate Members.');
      const d = DEFAULTS.antinuke();
      await config.update(interaction.guildId, 'antinuke', (x) => { x.enabled = true; x.windowSec = 30; x.limits = structuredClone(d.limits); x.betrayalLimits = structuredClone(d.betrayalLimits); x.modules = structuredClone(d.modules); x.betrayalGuard = true; x.autoRecovery = true; x.recovery = structuredClone(d.recovery); x.punishment = 'strip'; }, { actorId: interaction.user.id, summary: 'Anti-nuke wizard completed' });
      return ok(interaction, '🛡️ Anti-nuke wizard complete: protection enabled, all modules enabled, betrayal guard enabled, auto-recovery enabled, and thresholds reset to the safe baseline.');
    },
    async owneronly(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); const enabled = getBool(interaction, 'enabled'); if (interaction.user.id !== interaction.guild.ownerId) throw new AppError('Only the server owner can change Owner Only mode.'); await config.update(interaction.guildId, 'antinuke', (c) => { c.ownerOnly = enabled; }, { actorId: interaction.user.id, summary: `Anti-nuke owner-only: ${enabled}` }); return ok(interaction, `${enabled ? '<:wccheckmark:1551675781527380011>  **Owner Only Enabled**\n<:whitearrow:1551669900622172161> Security commands are now accessible to Extra Owners as well.' : '<:wccrossmar:1551676376313237504>  **Owner Only Disabled**\n<:whitearrow:1551669900622172161> Security commands are now accessible to Extra Owners as well.'}`); },
    async betrayalguard(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); const enabled = getBool(interaction, 'enabled'); await ownerGuard(interaction, c); await config.update(interaction.guildId, 'antinuke', (d) => { d.betrayalGuard = enabled; }, { actorId: interaction.user.id, summary: `Anti-nuke betrayal guard: ${enabled}` }); return ok(interaction, `Betrayal guard is now **${enabled ? 'enabled' : 'disabled'}**.`); },
    async enable(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); await ownerGuard(interaction, c); if (!interaction.guild.members.me.permissions.has([P.ViewAuditLog])) throw new AppError('I need **View Audit Log** to run anti-nuke.'); await config.update(interaction.guildId, 'antinuke', (d) => { d.enabled = true; }, { actorId: interaction.user.id, summary: 'Anti-nuke enabled' }); await antinuke.primeSnapshots(interaction.guild).catch(() => {}); return ok(interaction, '🛡️ Anti-nuke is now **enabled**.'); },
    async disable(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); await ownerGuard(interaction, c); if (!c.enabled) throw new AppError('Antinuke is not enabled in this server.'); await config.update(interaction.guildId, 'antinuke', () => structuredClone(DEFAULTS.antinuke()), { actorId: interaction.user.id, summary: 'Anti-nuke disabled and reset' }); await antinuke.clearData(interaction.guildId); return ok(interaction, '🛡️ Anti-nuke is now **disabled and reset**.'); },
    async limit(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); await ownerGuard(interaction, c); const module = interaction.options.getString('module', true); const key = MODULES.find(([n]) => n === module)?.[1]; const amount = interaction.options.getInteger('amount', true); await config.update(interaction.guildId, 'antinuke', (d) => { d.limits[key] = amount; }, { actorId: interaction.user.id, summary: `Anti-nuke limit ${module}: ${amount}` }); return ok(interaction, `**${module}** threshold set to **${amount}** actions per detection window.`); },
    async whitelisted(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); const users = c.whitelist ?? []; return respond(interaction, { embeds: [makeEmbed({ title: '🛡️ Anti-nuke whitelist', timestamp: false, description: users.length ? users.map((id) => `<@${id}> — ${id}`).join('\n') : 'No extra users are whitelisted. The server owner and this bot are always exempt.' })] }); },
    async manage(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); return respond(interaction, { embeds: [configEmbed(c)] }); },
    async logging(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); await ownerGuard(interaction, c); const channel = interaction.options.getChannel('channel'); if (channel && !channel.isTextBased()) throw new AppError('Choose a text-based channel.'); await config.update(interaction.guildId, 'antinuke', (d) => { d.loggingChannelId = channel?.id ?? null; }, { actorId: interaction.user.id, summary: `Anti-nuke logging channel: ${channel?.id ?? 'cleared'}` }); return ok(interaction, channel ? `Anti-nuke logs will also be sent to <#${channel.id}>.` : 'Anti-nuke dedicated logging channel cleared.'); },
    async whitelist(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); await ownerGuard(interaction, c); const action = interaction.options.getString('action', true); const user = interaction.options.getUser('user'); if (action !== 'clear' && !user) throw new AppError('Choose a user for add/remove.'); if (action === 'clear') { await config.update(interaction.guildId, 'antinuke', (d) => { d.whitelist = []; }, { actorId: interaction.user.id, summary: 'Anti-nuke whitelist cleared' }); return ok(interaction, 'Anti-nuke whitelist cleared.'); } if (user.id === interaction.guild.ownerId || user.id === interaction.client.user.id) throw new AppError('That account is already exempt.'); await config.update(interaction.guildId, 'antinuke', (d) => { d.whitelist ??= []; if (action === 'add' && !d.whitelist.includes(user.id)) d.whitelist.push(user.id); if (action === 'remove') d.whitelist = d.whitelist.filter((id) => id !== user.id); }, { actorId: interaction.user.id, summary: `Anti-nuke whitelist ${action}: ${user.id}` }); return ok(interaction, `${action === 'add' ? 'Added' : 'Removed'} ${user} ${action === 'add' ? 'to' : 'from'} the anti-nuke whitelist.`); },
    async config(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); await ownerGuard(interaction, c); const window = interaction.options.getInteger('window'); const punishment = interaction.options.getString('punishment'); if (window === null && !punishment) throw new AppError('Provide at least one setting to change.'); await config.update(interaction.guildId, 'antinuke', (d) => { if (window !== null) d.windowSec = window; if (punishment) d.punishment = punishment; }, { actorId: interaction.user.id, summary: 'Anti-nuke core configuration updated' }); return ok(interaction, 'Anti-nuke configuration updated.'); },
    async autorecovery(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); const enabled = getBool(interaction, 'enabled'); await ownerGuard(interaction, c); if (enabled && !interaction.guild.members.me.permissions.has([P.ManageChannels, P.ManageRoles])) throw new AppError('Auto-recovery needs **Manage Channels** and **Manage Roles**.'); await config.update(interaction.guildId, 'antinuke', (d) => { d.autoRecovery = enabled; }, { actorId: interaction.user.id, summary: `Anti-nuke auto-recovery: ${enabled}` }); return ok(interaction, `Auto-recovery is now **${enabled ? 'enabled' : 'disabled'}**.`); },
    async module(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); requireEnabled(c); await ownerGuard(interaction, c); const name = interaction.options.getString('name', true); const enabled = interaction.options.getBoolean('enabled', true); const key = MODULES.find(([n]) => n === name)?.[1]; await config.update(interaction.guildId, 'antinuke', (d) => { d.modules[key] = enabled; }, { actorId: interaction.user.id, summary: `Anti-nuke module ${name}: ${enabled}` }); return ok(interaction, `**${name}** is now **${enabled ? 'enabled' : 'disabled'}**.`); },
    async status(interaction) { const c = await config.get(interaction.guildId, 'antinuke'); return respond(interaction, { embeds: [makeEmbed({ title: '🛡️ Anti-nuke status', color: 0x2c2c2c, fields: [{ name: 'Status', value: c.enabled ? '✅ Enabled' : '❌ Disabled', inline: true }, { name: 'Window', value: `${c.windowSec}s`, inline: true }, { name: 'Punishment', value: c.punishment, inline: true }, { name: 'Betrayal guard', value: c.betrayalGuard ? 'On' : 'Off', inline: true }, { name: 'Auto-recovery', value: c.autoRecovery ? 'On' : 'Off', inline: true }, { name: 'Whitelist', value: c.whitelist?.length ? String(c.whitelist.length) : 'None', inline: true }] })] }); },
  });
  },
};
