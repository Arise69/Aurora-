'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { patchConfig, toggleInList } = require('../../utils/optionsPatch');
const { makeEmbed } = require('../../utils/embeds');
const { formatDuration } = require('../../utils/duration');
const { ok, respond } = require('../../utils/reply');

const SPEC = [
  { name: 'enabled', type: 'boolean', path: 'enabled' },
  { name: 'message-limit', type: 'integer', path: 'messageLimit', label: 'Message limit' },
  { name: 'interval', type: 'integer', path: 'intervalSec', label: 'Interval (s)' },
  { name: 'duplicate-limit', type: 'integer', path: 'duplicateLimit', label: 'Duplicate limit' },
  { name: 'duplicate-window', type: 'integer', path: 'duplicateWindowSec', label: 'Duplicate window (s)' },
  { name: 'delete-messages', type: 'boolean', path: 'deleteMessages', label: 'Delete spam' },
  { name: 'record-warning', type: 'boolean', path: 'recordWarning', label: 'Record first strike as warning' },
  { name: 'cooldown', type: 'integer', path: 'cooldownSec', label: 'Punishment cooldown (s)' },
  { name: 'strike-reset', type: 'integer', path: 'strikeResetMin', label: 'Strike reset (min)' },
  { name: 'exempt-staff', type: 'boolean', path: 'exemptStaff', label: 'Exempt staff' },
];

module.exports = {
  category: 'Security',
  userPermissions: [P.ManageGuild],
  data: newCommand('antispam', 'Configure the anti-spam system', P.ManageGuild)
    .addSubcommand((s) => s.setName('status').setDescription('Show current anti-spam settings'))
    .addSubcommand((s) => s.setName('config').setDescription('Change anti-spam settings')
      .addBooleanOption((o) => o.setName('enabled').setDescription('Enable or disable anti-spam'))
      .addIntegerOption((o) => o.setName('message-limit').setDescription('Messages within the interval that count as flooding').setMinValue(3).setMaxValue(30))
      .addIntegerOption((o) => o.setName('interval').setDescription('Flood interval in seconds').setMinValue(2).setMaxValue(60))
      .addIntegerOption((o) => o.setName('duplicate-limit').setDescription('Identical messages that count as spam').setMinValue(2).setMaxValue(20))
      .addIntegerOption((o) => o.setName('duplicate-window').setDescription('Window for duplicate detection in seconds').setMinValue(5).setMaxValue(300))
      .addBooleanOption((o) => o.setName('delete-messages').setDescription('Delete detected spam messages'))
      .addBooleanOption((o) => o.setName('record-warning').setDescription('Store the first strike as a real warning'))
      .addIntegerOption((o) => o.setName('cooldown').setDescription('Seconds after a punishment before escalating again').setMinValue(0).setMaxValue(120))
      .addIntegerOption((o) => o.setName('strike-reset').setDescription('Minutes without spam before strikes reset').setMinValue(1).setMaxValue(1440))
      .addBooleanOption((o) => o.setName('exempt-staff').setDescription('Ignore members with Manage Messages / Manage Server / Admin')))
    .addSubcommand((s) => s.setName('timeouts').setDescription('Set the escalation timeouts (strike 2 and strike 3+)')
      .addStringOption((o) => o.setName('strike-2').setDescription('e.g. 5m').setRequired(true))
      .addStringOption((o) => o.setName('strike-3').setDescription('e.g. 1h').setRequired(true)))
    .addSubcommand((s) => s.setName('ignore').setDescription('Exempt or un-exempt a channel, role or user')
      .addStringOption((o) => o.setName('action').setDescription('Add or remove').setRequired(true).addChoices({ name: 'Add', value: 'add' }, { name: 'Remove', value: 'remove' }))
      .addChannelOption((o) => o.setName('channel').setDescription('Channel'))
      .addRoleOption((o) => o.setName('role').setDescription('Role'))
      .addUserOption((o) => o.setName('user').setDescription('User'))),
  execute: (i) => dispatch(i, {
    async status(interaction) {
      const c = await config.get(interaction.guildId, 'antispam');
      const list = (a, f) => (a.length ? a.map(f).join(' ') : 'None');
      return respond(interaction, { embeds: [makeEmbed({
        title: '🚨 Anti-spam', timestamp: false,
        fields: [
          { name: 'Status', value: c.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
          { name: 'Flood', value: `${c.messageLimit} msgs / ${c.intervalSec}s`, inline: true },
          { name: 'Duplicates', value: `${c.duplicateLimit}× / ${c.duplicateWindowSec}s`, inline: true },
          { name: 'Escalation', value: `1: warning • 2: timeout ${formatDuration(c.timeoutSteps[0] * 1000)} • 3+: timeout ${formatDuration(c.timeoutSteps[1] * 1000)}` },
          { name: 'Cooldown / reset', value: `${c.cooldownSec}s / ${c.strikeResetMin}m`, inline: true },
          { name: 'Ignored', value: `Channels: ${list(c.ignoredChannels, (x) => `<#${x}>`)}\nRoles: ${list(c.ignoredRoles, (x) => `<@&${x}>`)}\nUsers: ${list(c.ignoredUsers, (x) => `<@${x}>`)}` },
        ],
      })] });
    },
    async config(interaction) { return ok(interaction, `Anti-spam updated:\n${await patchConfig(interaction, 'antispam', SPEC)}`); },
    async timeouts(interaction) {
      const { parseDuration } = require('../../utils/duration');
      const a = parseDuration(interaction.options.getString('strike-2', true));
      const b = parseDuration(interaction.options.getString('strike-3', true));
      if (!a || !b || a > 28 * 86_400_000 || b > 28 * 86_400_000) throw new AppError('Use durations like `5m` or `1h` (max 28 days).');
      await config.update(interaction.guildId, 'antispam', (c) => { c.timeoutSteps = [Math.round(a / 1000), Math.round(b / 1000)]; }, { actorId: interaction.user.id, summary: `Anti-spam timeouts: ${formatDuration(a)}, ${formatDuration(b)}` });
      return ok(interaction, `Escalation set: strike 2 → ${formatDuration(a)}, strike 3+ → ${formatDuration(b)}.`);
    },
    async ignore(interaction) {
      const add = interaction.options.getString('action', true) === 'add';
      const targets = [['channel', 'ignoredChannels'], ['role', 'ignoredRoles'], ['user', 'ignoredUsers']]
        .map(([opt, path]) => [interaction.options.get(opt)?.value, path]).filter(([v]) => v);
      if (!targets.length) throw new AppError('Choose a channel, role or user.');
      for (const [id, path] of targets) await toggleInList(interaction.guildId, 'antispam', path, id, add, { actorId: interaction.user.id, summary: `Anti-spam ignore ${add ? 'added' : 'removed'}: ${id}` });
      return ok(interaction, `${add ? 'Added to' : 'Removed from'} the anti-spam ignore list.`);
    },
  }),
};
