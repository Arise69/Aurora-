'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

module.exports = {
  category: 'Security',
  userPermissions: [P.ManageGuild],
  data: newCommand('mainrole', 'Manage the security main role', P.ManageGuild)
    .addSubcommand((s) => s.setName('show').setDescription('Show the configured main role'))
    .addSubcommand((s) => s.setName('add').setDescription('Set the main role')
      .addRoleOption((o) => o.setName('role').setDescription('Role to use as the main role').setRequired(true)))
    .addSubcommand((s) => s.setName('remove').setDescription('Remove the configured main role'))
    .addSubcommand((s) => s.setName('reset').setDescription('Reset the main role configuration')),
  execute: (i) => dispatch(i, {
    async show(interaction) {
      const c = await config.get(interaction.guildId, 'security');
      return respond(interaction, { embeds: [makeEmbed({ title: '🛡️ Mainrole', description: c.mainroleId ? `Current main role: <@&${c.mainroleId}>` : 'No main role is configured.' })] });
    },
    async add(interaction) {
      const role = interaction.options.getRole('role', true);
      if (role.id === interaction.guildId || role.managed) throw new AppError('Choose a normal, non-managed role.');
      if (role.position >= interaction.guild.members.me.roles.highest.position) throw new AppError('That role is at or above my highest role. Move my bot role above it first.');
      await config.update(interaction.guildId, 'security', (d) => { d.mainroleId = role.id; }, { actorId: interaction.user.id, summary: `Main role set to ${role.id}` });
      return ok(interaction, `Main role set to <@&${role.id}>.`);
    },
    async remove(interaction) {
      await config.update(interaction.guildId, 'security', (d) => { d.mainroleId = null; }, { actorId: interaction.user.id, summary: 'Main role removed' });
      return ok(interaction, 'Main role removed.');
    },
    async reset(interaction) {
      await config.update(interaction.guildId, 'security', (d) => { d.mainroleId = null; }, { actorId: interaction.user.id, summary: 'Main role reset' });
      return ok(interaction, 'Main role configuration reset.');
    },
  }),
};
