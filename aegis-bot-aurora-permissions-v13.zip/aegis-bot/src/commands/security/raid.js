'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const antiraid = require('../../services/antiraid');
const { AppError } = require('../../utils/errors');
const { parseDuration, formatDuration, discordTime } = require('../../utils/duration');
const { dispatch } = require('../../utils/dispatch');
const { patchConfig } = require('../../utils/optionsPatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');
const { COLORS } = require('../../config/constants');

const SPEC = [
  { name: 'enabled', type: 'boolean', path: 'enabled' },
  { name: 'join-threshold', type: 'integer', path: 'joinThreshold', label: 'Join threshold' },
  { name: 'join-window', type: 'integer', path: 'joinWindowSec', label: 'Join window (s)' },
  { name: 'auto-lockdown', type: 'boolean', path: 'autoLockdown', label: 'Auto lockdown' },
  { name: 'lockdown-minutes', type: 'integer', path: 'lockdownDurationMin', label: 'Lockdown minutes' },
  { name: 'new-account-hours', type: 'integer', path: 'newAccountAgeHours', label: 'New-account age (h)' },
  { name: 'new-account-action', type: 'string', path: 'newAccountAction', label: 'New-account action' },
  { name: 'lock-channels', type: 'boolean', path: 'lockChannels', label: 'Lock channels' },
  { name: 'alert-role', type: 'role', path: 'alertRoleId', label: 'Alert role' },
];

module.exports = {
  category: 'Security',
  userPermissions: [P.ManageGuild],
  cooldown: 5,
  data: newCommand('raid', 'Anti-raid protection and lockdown controls', P.ManageGuild)
    .addSubcommand((s) => s.setName('status').setDescription('Show anti-raid status and current lockdown'))
    .addSubcommand((s) => s.setName('lockdown').setDescription('Enable lockdown mode now')
      .addStringOption((o) => o.setName('duration').setDescription('e.g. 15m, 2h (1 minute – 24 hours; default from config)'))
      .addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(200)))
    .addSubcommand((s) => s.setName('unlock').setDescription('End lockdown and restore everything'))
    .addSubcommand((s) => s.setName('config').setDescription('Change anti-raid settings')
      .addBooleanOption((o) => o.setName('enabled').setDescription('Enable join-rate detection'))
      .addIntegerOption((o) => o.setName('join-threshold').setDescription('Joins that count as a raid').setMinValue(3).setMaxValue(100))
      .addIntegerOption((o) => o.setName('join-window').setDescription('Detection window in seconds').setMinValue(3).setMaxValue(300))
      .addBooleanOption((o) => o.setName('auto-lockdown').setDescription('Automatically lock down when a raid is detected'))
      .addIntegerOption((o) => o.setName('lockdown-minutes').setDescription('Default lockdown length in minutes').setMinValue(1).setMaxValue(1440))
      .addIntegerOption((o) => o.setName('new-account-hours').setDescription('Accounts younger than this are restricted in lockdown').setMinValue(0).setMaxValue(720))
      .addStringOption((o) => o.setName('new-account-action').setDescription('What to do with suspicious new joiners').addChoices(
        { name: 'Timeout until lockdown ends', value: 'timeout' }, { name: 'Kick', value: 'kick' }, { name: 'Nothing', value: 'none' }))
      .addBooleanOption((o) => o.setName('lock-channels').setDescription('Also deny @everyone from sending messages during lockdown'))
      .addRoleOption((o) => o.setName('alert-role').setDescription('Role to ping on raid detection'))),
  execute: (i) => dispatch(i, {
    async status(interaction) {
      const { cfg, recentJoins, lockdown } = await antiraid.status(interaction.guild);
      return respond(interaction, { embeds: [makeEmbed({
        title: '🛡️ Anti-raid status', color: lockdown ? COLORS.security : COLORS.success,
        fields: [
          { name: 'Detection', value: cfg.enabled ? `On — ${cfg.joinThreshold} joins / ${cfg.joinWindowSec}s` : 'Off', inline: true },
          { name: 'Recent joins', value: String(recentJoins), inline: true },
          { name: 'Auto lockdown', value: cfg.autoLockdown ? `On (${cfg.lockdownDurationMin} min)` : 'Off', inline: true },
          { name: 'Lockdown', value: lockdown ? `🔒 Active — ends ${discordTime(Number(lockdown.ends_at), 'R')}\nReason: ${lockdown.reason ?? 'n/a'}` : '🔓 Not active' },
          { name: 'New-account rule', value: `${cfg.newAccountAction} (< ${cfg.newAccountAgeHours}h old)`, inline: true },
          { name: 'Channel locking', value: cfg.lockChannels ? 'On' : 'Off', inline: true },
        ],
      })] });
    },
    async lockdown(interaction) {
      const raw = interaction.options.getString('duration');
      const ms = raw ? parseDuration(raw) : undefined;
      if (raw && !ms) throw new AppError('Invalid duration. Examples: `15m`, `2h`.');
      await interaction.deferReply({ flags: 64 });
      const res = await antiraid.startLockdown(interaction.guild, { durationMs: ms, reason: interaction.options.getString('reason') ?? 'Manual lockdown', startedBy: interaction.user.id });
      return ok(interaction, `${res.extended ? 'Lockdown extended' : 'Lockdown enabled'} — ends ${discordTime(res.endsAt, 'R')} (${formatDuration(res.endsAt - Date.now())}). Use \`/raid unlock\` to end it early.`);
    },
    async unlock(interaction) {
      await interaction.deferReply({ flags: 64 });
      const r = await antiraid.endLockdown(interaction.guild, { by: interaction.user.id, reason: 'Manually unlocked' });
      return ok(interaction, `Lockdown ended. ${r.released} restricted user(s) released${r.failedChannels ? `; ⚠️ ${r.failedChannels} channel(s) could not be restored` : ''}.`);
    },
    async config(interaction) {
      const summary = await patchConfig(interaction, 'antiraid', SPEC, {
        validate: async (changes) => {
          const role = changes.find((c) => c.name === 'alert-role');
          if (role) { const r = interaction.guild.roles.cache.get(role.value); if (r?.id === interaction.guildId) throw new AppError('Choose a real role.'); }
          if (changes.some((c) => c.name === 'lock-channels' && c.value)) assertLockPerms(interaction);
        },
      });
      return ok(interaction, `Anti-raid updated:\n${summary}`);
    },
  }),
};

function assertLockPerms(interaction) {
  if (!interaction.guild.members.me.permissions.has([P.ManageChannels, P.ManageRoles])) {
    throw new AppError('To lock channels I need **Manage Channels** and **Manage Roles**. Grant them first.');
  }
}
