'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const tickets = require('../../services/tickets');
const { AppError } = require('../../utils/errors');
const { dispatch, parseList } = require('../../utils/dispatch');
const { assertBotPermissions } = require('../../utils/permissions');
const { ok, defer, respond } = require('../../utils/reply');

/** Runs a handler only inside an open ticket and only for support staff. */
async function inTicket(interaction) {
  const ticket = await tickets.getByChannel(interaction.channelId);
  if (!ticket || ticket.status !== 'open') throw new AppError('Use this inside an open ticket channel.');
  const cfg = await config.get(interaction.guildId, 'tickets');
  if (!tickets.isSupport(interaction.member, cfg)) throw new AppError('Only support staff can do that.');
  return ticket;
}

module.exports = {
  category: 'Tickets',
  cooldown: 3,
  data: newCommand('ticket', 'Support ticket system')
    .addSubcommand((s) => s.setName('setup').setDescription('Configure tickets and post the panel (Manage Server)')
      .addChannelOption((o) => o.setName('panel-channel').setDescription('Where to post the ticket panel').setRequired(true).addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
      .addChannelOption((o) => o.setName('category').setDescription('Category for ticket channels').addChannelTypes(ChannelType.GuildCategory))
      .addRoleOption((o) => o.setName('support-role').setDescription('Role that can see and handle tickets'))
      .addChannelOption((o) => o.setName('log-channel').setDescription('Transcripts and ticket logs go here').addChannelTypes(ChannelType.GuildText))
      .addStringOption((o) => o.setName('types').setDescription('Comma-separated ticket types (max 5), e.g. Support,Report,Purchase'))
      .addIntegerOption((o) => o.setName('max-open').setDescription('Open tickets allowed per user').setMinValue(1).setMaxValue(10))
      .addBooleanOption((o) => o.setName('dm-transcript').setDescription('DM the transcript to the opener when closed')))
    .addSubcommand((s) => s.setName('disable').setDescription('Disable new tickets (Manage Server)'))
    .addSubcommand((s) => s.setName('close').setDescription('Close this ticket').addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(300)))
    .addSubcommand((s) => s.setName('claim').setDescription('Claim this ticket (support staff)'))
    .addSubcommand((s) => s.setName('add').setDescription('Add a user to this ticket (support staff)').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand((s) => s.setName('remove').setDescription('Remove a user from this ticket (support staff)').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand((s) => s.setName('transcript').setDescription('Save a transcript of this ticket now (support staff)')),
  execute: (i) => dispatch(i, {
    async setup(interaction) {
      if (!interaction.memberPermissions.has(P.ManageGuild)) throw new AppError('You need **Manage Server** to set up tickets.');
      assertBotPermissions(interaction.guild, [P.ManageChannels, P.ManageRoles]);
      await defer(interaction);
      const o = interaction.options;
      const panelChannel = interaction.guild.channels.cache.get(o.getChannel('panel-channel', true).id);
      const types = o.getString('types') ? parseList(o.getString('types'), { max: 5, maxLength: 40, lower: false }) : null;
      if (types && !types.length) throw new AppError('Provide at least one ticket type.');
      const support = o.getRole('support-role');
      const next = await config.update(interaction.guildId, 'tickets', (c) => {
        c.enabled = true; c.panelChannelId = panelChannel.id;
        if (o.getChannel('category')) c.categoryId = o.getChannel('category').id;
        if (support) { c.supportRoleIds = [support.id]; }
        if (o.getChannel('log-channel')) c.logChannelId = o.getChannel('log-channel').id;
        if (types) c.types = types;
        if (o.getInteger('max-open')) c.maxOpenPerUser = o.getInteger('max-open');
        if (o.getBoolean('dm-transcript') !== null) c.dmTranscript = o.getBoolean('dm-transcript');
      }, { actorId: interaction.user.id, summary: 'Ticket system configured' });
      await tickets.postPanel(interaction.guild, panelChannel, next);
      return ok(interaction, `Tickets are live. Panel posted in <#${panelChannel.id}>.${next.supportRoleIds.length ? '' : '\n⚠️ No support role set — only members with **Manage Channels** can handle tickets.'}`);
    },
    async disable(interaction) {
      if (!interaction.memberPermissions.has(P.ManageGuild)) throw new AppError('You need **Manage Server**.');
      await config.update(interaction.guildId, 'tickets', (c) => { c.enabled = false; }, { actorId: interaction.user.id, summary: 'Tickets disabled' });
      return ok(interaction, 'New tickets are disabled. Existing tickets keep working.');
    },
    close: (x) => tickets.close(x, { reason: x.options.getString('reason') }),
    claim: (x) => tickets.claimTicket(x),
    async add(x) {
      await inTicket(x);
      const user = x.options.getUser('user', true);
      await x.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
      return respond(x, { content: `➕ <@${user.id}> was added to the ticket.`, allowedMentions: { users: [user.id] } }, { ephemeral: false });
    },
    async remove(x) {
      const ticket = await inTicket(x);
      const user = x.options.getUser('user', true);
      if (user.id === ticket.opener_id) throw new AppError('You cannot remove the ticket opener.');
      await x.channel.permissionOverwrites.delete(user.id);
      return ok(x, `Removed <@${user.id}> from the ticket.`);
    },
    async transcript(x) {
      const ticket = await inTicket(x);
      await defer(x);
      const { AttachmentBuilder } = require('discord.js');
      const file = new AttachmentBuilder(await tickets.buildTranscript(x.channel, ticket), { name: `transcript-${String(ticket.number).padStart(4, '0')}.txt` });
      return respond(x, { content: '📄 Transcript saved:', files: [file] });
    },
  }),
};
