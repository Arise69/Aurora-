'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const logging = require('../../services/logging');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');
const { LOG_CATEGORIES, COLORS } = require('../../config/constants');

const TEXT = [ChannelType.GuildText, ChannelType.GuildAnnouncement];
const choices = Object.keys(LOG_CATEGORIES).map((k) => ({ name: k, value: k }));

function assertWritable(guild, channel) {
  const ch = guild.channels.cache.get(channel.id);
  if (!ch?.permissionsFor(guild.members.me)?.has([P.ViewChannel, P.SendMessages, P.EmbedLinks])) {
    throw new AppError(`I need **View Channel, Send Messages and Embed Links** in <#${channel.id}>.`);
  }
}

module.exports = {
  category: 'Logging',
  userPermissions: [P.ManageGuild],
  data: newCommand('logging', 'Configure server logs', P.ManageGuild)
    .addSubcommand((s) => s.setName('setup').setDescription('Send every log category to one channel')
      .addChannelOption((o) => o.setName('channel').setDescription('Log channel').setRequired(true).addChannelTypes(...TEXT)))
    .addSubcommand((s) => s.setName('config').setDescription('Route or toggle a single log category')
      .addStringOption((o) => o.setName('category').setDescription('Log category').setRequired(true).addChoices(...choices))
      .addChannelOption((o) => o.setName('channel').setDescription('Send this category to a different channel').addChannelTypes(...TEXT))
      .addBooleanOption((o) => o.setName('enabled').setDescription('Turn this category on or off'))
      .addBooleanOption((o) => o.setName('reset').setDescription('Remove the override and use the default channel')))
    .addSubcommand((s) => s.setName('view').setDescription('Show the current logging configuration'))
    .addSubcommand((s) => s.setName('test').setDescription('Send a test entry to every configured log channel'))
    .addSubcommand((s) => s.setName('disable').setDescription('Turn logging off completely')),
  execute: (i) => dispatch(i, {
    async setup(interaction) {
      const channel = interaction.options.getChannel('channel', true);
      assertWritable(interaction.guild, channel);
      await config.update(interaction.guildId, 'logging', (c) => { c.enabled = true; c.defaultChannelId = channel.id; }, { actorId: interaction.user.id, summary: `Default log channel → <#${channel.id}>` });
      return ok(interaction, `Logging enabled. All categories now go to <#${channel.id}>. Use \`/logging config\` to route categories elsewhere.`);
    },
    async config(interaction) {
      const category = interaction.options.getString('category', true);
      const channel = interaction.options.getChannel('channel');
      const enabled = interaction.options.getBoolean('enabled');
      const reset = interaction.options.getBoolean('reset');
      if (!channel && enabled === null && !reset) throw new AppError('Provide a channel, `enabled` or `reset`.');
      if (channel) assertWritable(interaction.guild, channel);
      await config.update(interaction.guildId, 'logging', (c) => {
        if (channel) c.channels[category] = channel.id;
        if (reset) delete c.channels[category];
        if (enabled === true) c.disabled = c.disabled.filter((x) => x !== category);
        if (enabled === false && !c.disabled.includes(category)) c.disabled.push(category);
      }, { actorId: interaction.user.id, summary: `Log category ${category} updated` });
      return ok(interaction, `Log category **${category}** updated.`);
    },
    async view(interaction) {
      const c = await config.get(interaction.guildId, 'logging');
      const lines = Object.entries(LOG_CATEGORIES).map(([k, d]) => {
        const ch = c.channels[k] ?? c.defaultChannelId;
        return `${c.disabled.includes(k) ? '⛔' : ch ? '✅' : '⚪'} **${k}** → ${ch ? `<#${ch}>` : 'not set'} — ${d}`;
      });
      return respond(interaction, { embeds: [makeEmbed({ title: `📜 Logging ${c.enabled ? '(on)' : '(off)'}`, description: lines.join('\n'), timestamp: false })] });
    },
    async test(interaction) {
      const embed = makeEmbed({ title: '🧪 Log test', description: `Triggered by <@${interaction.user.id}>`, color: COLORS.info });
      for (const category of Object.keys(LOG_CATEGORIES)) await logging.send(interaction.guild, category, embed);
      return ok(interaction, 'Test entries sent (categories with no channel are skipped).');
    },
    async disable(interaction) {
      await config.update(interaction.guildId, 'logging', (c) => { c.enabled = false; }, { actorId: interaction.user.id, summary: 'Logging disabled' });
      return ok(interaction, 'Logging disabled. Your channel settings are kept; re-enable with `/logging setup`.');
    },
  }),
};
