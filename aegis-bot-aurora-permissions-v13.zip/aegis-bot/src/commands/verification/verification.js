'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const verification = require('../../services/verification');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { assertAssignableRole } = require('../../utils/permissions');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond, defer } = require('../../utils/reply');

module.exports = {
  category: 'Verification',
  userPermissions: [P.ManageGuild],
  botPermissions: [P.ManageRoles],
  data: newCommand('verification', 'Button / code verification for new members', P.ManageGuild)
    .addSubcommand((s) => s.setName('setup').setDescription('Post the verification panel and enable verification')
      .addChannelOption((o) => o.setName('channel').setDescription('Where to post the panel').setRequired(true).addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
      .addRoleOption((o) => o.setName('role').setDescription('Role granted after verifying').setRequired(true))
      .addRoleOption((o) => o.setName('unverified-role').setDescription('Optional role given on join and removed on verification'))
      .addStringOption((o) => o.setName('mode').setDescription('Verification method').addChoices({ name: 'Button', value: 'button' }, { name: 'Code (type a short code)', value: 'code' }))
      .addIntegerOption((o) => o.setName('min-account-age').setDescription('Minimum account age in hours (0 = none)').setMinValue(0).setMaxValue(8760))
      .addIntegerOption((o) => o.setName('max-attempts').setDescription('Failed attempts before a lockout').setMinValue(1).setMaxValue(20))
      .addStringOption((o) => o.setName('title').setDescription('Panel title').setMaxLength(80))
      .addStringOption((o) => o.setName('description').setDescription('Panel text').setMaxLength(500)))
    .addSubcommand((s) => s.setName('status').setDescription('Show verification settings'))
    .addSubcommand((s) => s.setName('disable').setDescription('Disable verification and remove the panel')),
  execute: (i) => dispatch(i, {
    async setup(interaction) {
      await defer(interaction);
      const { guild } = interaction;
      const channel = guild.channels.cache.get(interaction.options.getChannel('channel', true).id);
      const role = interaction.options.getRole('role', true);
      const unverified = interaction.options.getRole('unverified-role');
      assertAssignableRole(guild, guild.roles.cache.get(role.id), interaction.member);
      if (unverified) assertAssignableRole(guild, guild.roles.cache.get(unverified.id), interaction.member);
      if (unverified && unverified.id === role.id) throw new AppError('The verified and unverified roles must be different.');

      const old = await config.get(guild.id, 'verification');
      const next = await config.update(guild.id, 'verification', (c) => {
        c.enabled = true; c.channelId = channel.id; c.roleId = role.id; c.unverifiedRoleId = unverified?.id ?? null;
        c.mode = interaction.options.getString('mode') ?? c.mode;
        c.minAccountAgeHours = interaction.options.getInteger('min-account-age') ?? c.minAccountAgeHours;
        c.maxAttempts = interaction.options.getInteger('max-attempts') ?? c.maxAttempts;
        c.title = interaction.options.getString('title') ?? c.title;
        c.description = interaction.options.getString('description') ?? c.description;
      }, { actorId: interaction.user.id, summary: `Verification set up in <#${channel.id}> (role <@&${role.id}>)` });

      const msg = await verification.postPanel(guild, channel, next);
      if (old.channelId && old.messageId) await guild.channels.cache.get(old.channelId)?.messages.delete(old.messageId).catch(() => {});
      await config.update(guild.id, 'verification', (c) => { c.messageId = msg.id; });
      return ok(interaction, `Verification is live in <#${channel.id}>. Mode: **${next.mode}**. Members receive <@&${role.id}>.\nTip: hide your other channels from @everyone and show them to <@&${role.id}>.`);
    },
    async status(interaction) {
      const c = await config.get(interaction.guildId, 'verification');
      return respond(interaction, { embeds: [makeEmbed({
        title: `✅ Verification ${c.enabled ? '(on)' : '(off)'}`, timestamp: false,
        fields: [
          { name: 'Channel', value: c.channelId ? `<#${c.channelId}>` : 'Not set', inline: true }, { name: 'Role', value: c.roleId ? `<@&${c.roleId}>` : 'Not set', inline: true },
          { name: 'Unverified role', value: c.unverifiedRoleId ? `<@&${c.unverifiedRoleId}>` : 'None', inline: true }, { name: 'Mode', value: c.mode, inline: true },
          { name: 'Min account age', value: `${c.minAccountAgeHours}h`, inline: true }, { name: 'Lockout', value: `${c.maxAttempts} fails → ${c.lockoutMin} min`, inline: true },
        ],
      })] });
    },
    async disable(interaction) {
      const c = await config.get(interaction.guildId, 'verification');
      if (c.channelId && c.messageId) await interaction.guild.channels.cache.get(c.channelId)?.messages.delete(c.messageId).catch(() => {});
      await config.update(interaction.guildId, 'verification', (x) => { x.enabled = false; x.messageId = null; }, { actorId: interaction.user.id, summary: 'Verification disabled' });
      return ok(interaction, 'Verification disabled and the panel removed.');
    },
  }),
};
