'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const customroles = require('../../services/customroles');
const { AppError } = require('../../utils/errors');
const { dispatch, parseList } = require('../../utils/dispatch');
const { patchConfig } = require('../../utils/optionsPatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond, defer } = require('../../utils/reply');

const needAdmin = (i) => { if (!i.memberPermissions.has(P.ManageGuild)) throw new AppError('You need **Manage Server** to change custom-role settings.'); };

module.exports = {
  category: 'CustomRole',
  botPermissions: [P.ManageRoles],
  cooldown: 5,
  data: newCommand('customrole', 'Your own personal role (name and color)')
    .addSubcommand((s) => s.setName('create').setDescription('Create your custom role')
      .addStringOption((o) => o.setName('name').setDescription('Role name').setRequired(true).setMaxLength(32))
      .addStringOption((o) => o.setName('color').setDescription('Hex color, e.g. #ff66aa')))
    .addSubcommand((s) => s.setName('edit').setDescription('Change your role name or color')
      .addStringOption((o) => o.setName('name').setDescription('New name').setMaxLength(32))
      .addStringOption((o) => o.setName('color').setDescription('New hex color')))
    .addSubcommand((s) => s.setName('delete').setDescription('Delete your custom role'))
    .addSubcommand((s) => s.setName('info').setDescription('Show your custom role'))
    .addSubcommand((s) => s.setName('config').setDescription('Server settings (Manage Server)')
      .addBooleanOption((o) => o.setName('enabled').setDescription('Enable custom roles'))
      .addRoleOption((o) => o.setName('required-role').setDescription('Members need this role'))
      .addBooleanOption((o) => o.setName('boosters-only').setDescription('Only server boosters'))
      .addRoleOption((o) => o.setName('base-role').setDescription('New roles are placed just below this role'))
      .addIntegerOption((o) => o.setName('max-name-length').setDescription('Maximum role name length').setMinValue(3).setMaxValue(100))
      .addStringOption((o) => o.setName('blocked-names').setDescription('Comma-separated words that may not appear in role names').setMaxLength(300))),
  execute: (i) => dispatch(i, {
    async create(interaction) {
      await defer(interaction);
      const role = await customroles.create(interaction.member, interaction.options.getString('name', true), interaction.options.getString('color'));
      return ok(interaction, `Your role <@&${role.id}> has been created and assigned to you!`);
    },
    async edit(interaction) {
      const role = await customroles.edit(interaction.member, { name: interaction.options.getString('name'), color: interaction.options.getString('color') });
      return ok(interaction, `Updated <@&${role.id}>.`);
    },
    async delete(interaction) { await customroles.remove(interaction.member); return ok(interaction, 'Your custom role was deleted.'); },
    async info(interaction) {
      const role = await customroles.ownedRole(interaction.member);
      return respond(interaction, { embeds: [makeEmbed({ title: 'Your custom role', color: role.color || undefined, timestamp: false, description: `<@&${role.id}>\nColor: \`${role.hexColor}\` • Members: ${role.members.size}` })] });
    },
    async config(interaction) {
      needAdmin(interaction);
      const guild = interaction.guild;
      const blocked = interaction.options.getString('blocked-names');
      const summary = await patchConfig(interaction, 'customroles', [
        { name: 'enabled', type: 'boolean', path: 'enabled' },
        { name: 'required-role', type: 'role', path: 'requiredRoleId', label: 'Required role' },
        { name: 'boosters-only', type: 'boolean', path: 'boostersOnly', label: 'Boosters only' },
        { name: 'base-role', type: 'role', path: 'baseRoleId', label: 'Base role' },
        { name: 'max-name-length', type: 'integer', path: 'maxNameLength', label: 'Max name length' },
        ...(blocked ? [{ name: 'blocked-names', type: 'string', path: 'blockedNames', label: 'Blocked names', map: (v) => parseList(v, { max: 30, maxLength: 30 }) }] : []),
      ], {
        validate: async (changes) => {
          const base = changes.find((c) => c.name === 'base-role');
          if (base) {
            const r = guild.roles.cache.get(base.value);
            if (r.id === guild.id) throw new AppError('Choose a real role.');
            if (guild.members.me.roles.highest.comparePositionTo(r) <= 0) throw new AppError('The base role must be below my highest role.');
          }
        },
      });
      return ok(interaction, `Custom-role settings updated:\n${summary}`);
    },
  }),
};
