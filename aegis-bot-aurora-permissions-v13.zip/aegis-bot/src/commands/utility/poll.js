'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const { AppError } = require('../../utils/errors');
const { makeEmbed, escapeText } = require('../../utils/embeds');
const { ok, defer } = require('../../utils/reply');

const NUMS = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

module.exports = {
  category: 'Utility',
  botPermissions: [P.SendMessages, P.EmbedLinks, P.AddReactions],
  cooldown: 10,
  data: (() => {
    const b = newCommand('poll', 'Create a reaction poll')
      .addStringOption((o) => o.setName('question').setDescription('The question').setRequired(true).setMaxLength(250));
    for (let n = 1; n <= 10; n++) b.addStringOption((o) => o.setName(`option${n}`).setDescription(`Option ${n}${n <= 2 ? '' : ' (optional)'}`).setRequired(n <= 2).setMaxLength(100));
    return b;
  })(),
  async execute(interaction) {
    const options = [];
    for (let n = 1; n <= 10; n++) { const v = interaction.options.getString(`option${n}`); if (v) options.push(v); }
    if (options.length < 2) throw new AppError('A poll needs at least two options.');
    await defer(interaction);
    const msg = await interaction.channel.send({
      embeds: [makeEmbed({ title: `📊 ${escapeText(interaction.options.getString('question', true))}`, description: options.map((o, i) => `${NUMS[i]} ${escapeText(o)}`).join('\n'), footer: `Poll by ${interaction.user.username}` })],
      allowedMentions: { parse: [] },
    });
    for (let i = 0; i < options.length; i++) await msg.react(NUMS[i]).catch(() => {});
    return ok(interaction, 'Poll created.');
  },
};
