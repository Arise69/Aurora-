'use strict';
const { newCommand } = require('../../utils/builder');
const utility = require('../../services/utility');
const { AppError } = require('../../utils/errors');
const { parseDuration, formatDuration, discordTime } = require('../../utils/duration');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed, clip, escapeText } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

module.exports = {
  category: 'Utility',
  data: newCommand('remind', 'Personal reminders (delivered by DM)')
    .addSubcommand((s) => s.setName('set').setDescription('Create a reminder')
      .addStringOption((o) => o.setName('in').setDescription('When, e.g. 30m, 2h, 1d12h').setRequired(true))
      .addStringOption((o) => o.setName('message').setDescription('What to remind you about').setRequired(true).setMaxLength(500)))
    .addSubcommand((s) => s.setName('list').setDescription('Show your pending reminders'))
    .addSubcommand((s) => s.setName('cancel').setDescription('Cancel a reminder').addStringOption((o) => o.setName('id').setDescription('Reminder ID').setRequired(true))),
  execute: (i) => dispatch(i, {
    async set(interaction) {
      const ms = parseDuration(interaction.options.getString('in', true));
      if (!ms || ms < 10_000 || ms > 365 * 86_400_000) throw new AppError('Choose a time between 10 seconds and 1 year, e.g. `45m` or `2d`.');
      const id = await utility.addReminder({ userId: interaction.user.id, guildId: interaction.guildId, channelId: interaction.channelId, message: interaction.options.getString('message', true), remindAt: Date.now() + ms });
      return ok(interaction, `I'll remind you in **${formatDuration(ms)}** (${discordTime(Date.now() + ms, 'R')}). ID \`${id}\`.`);
    },
    async list(interaction) {
      const rows = await utility.listReminders(interaction.user.id);
      return respond(interaction, { embeds: [makeEmbed({ title: '⏰ Your reminders', timestamp: false, description: rows.length ? rows.map((r) => `\`${r.id}\` ${discordTime(Number(r.remind_at), 'R')} — ${escapeText(clip(r.message, 100))}`).join('\n') : 'You have no pending reminders.' })] });
    },
    async cancel(interaction) {
      if (!(await utility.cancelReminder(interaction.user.id, interaction.options.getString('id', true).trim()))) throw new AppError('No reminder with that ID.');
      return ok(interaction, 'Reminder cancelled.');
    },
  }),
};
