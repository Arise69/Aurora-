'use strict';
const { newCommand } = require('../../utils/builder');
const utility = require('../../services/utility');
const { ok } = require('../../utils/reply');

module.exports = {
  category: 'Utility',
  data: newCommand('afk', 'Set your AFK status; people who mention you are told')
    .addStringOption((o) => o.setName('reason').setDescription('Why you are away').setMaxLength(200)),
  async execute(interaction) {
    await utility.setAfk(interaction.guildId, interaction.user.id, interaction.options.getString('reason'));
    return ok(interaction, "You're now AFK. I'll remove it when you next send a message.");
  },
};
