'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const { AppError } = require('../../utils/errors');
const { makeEmbed } = require('../../utils/embeds');
const { ok } = require('../../utils/reply');

module.exports = {
  category: 'Utility',
  userPermissions: [P.ManageMessages],
  botPermissions: [P.SendMessages],
  data: newCommand('say', 'Make the bot post a message or embed (no mass pings)', P.ManageMessages)
    .addStringOption((o) => o.setName('message').setDescription('Text to send').setRequired(true).setMaxLength(1900))
    .addChannelOption((o) => o.setName('channel').setDescription('Channel (default: here)').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
    .addBooleanOption((o) => o.setName('embed').setDescription('Send as an embed'))
    .addStringOption((o) => o.setName('title').setDescription('Embed title').setMaxLength(200)),
  async execute(interaction) {
    const channel = interaction.guild.channels.cache.get(interaction.options.getChannel('channel')?.id ?? interaction.channelId);
    if (!channel?.isTextBased()) throw new AppError('Choose a text channel.');
    if (!channel.permissionsFor(interaction.member)?.has(P.SendMessages)) throw new AppError("You can't send messages in that channel.");
    const text = interaction.options.getString('message', true);
    const payload = interaction.options.getBoolean('embed')
      ? { embeds: [makeEmbed({ title: interaction.options.getString('title') ?? undefined, description: text, timestamp: false })] }
      : { content: text };
    await channel.send({ ...payload, allowedMentions: { parse: [] } }); // never pings @everyone/roles/users
    return ok(interaction, `Sent in <#${channel.id}>.`);
  },
};
