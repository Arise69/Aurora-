'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const giveaways = require('../../services/giveaways');
const { AppError } = require('../../utils/errors');
const { parseDuration, formatDuration, discordTime } = require('../../utils/duration');
const { dispatch, parseRoles } = require('../../utils/dispatch');
const { patchConfig } = require('../../utils/optionsPatch');
const { makeEmbed, clip } = require('../../utils/embeds');
const { ok, respond, defer } = require('../../utils/reply');
const { COLORS } = require('../../config/constants');

const idOpt = (o, desc = 'Giveaway ID') => o.setName('id').setDescription(desc).setRequired(true).setAutocomplete(true).setMaxLength(12);
const dur = (raw, label, { required = false } = {}) => {
  if (!raw) { if (required) throw new AppError(`${label} is required.`); return 0; }
  const ms = parseDuration(raw);
  if (!ms) throw new AppError(`Invalid ${label.toLowerCase()}. Examples: \`30m\`, \`24h\`, \`1d12h\`, \`1w\`.`);
  return ms;
};

module.exports = {
  category: 'Giveaways',
  userPermissions: [P.ManageGuild],
  botPermissions: [P.SendMessages, P.EmbedLinks],
  cooldown: 3,
  data: newCommand('giveaway', 'Create and manage giveaways', P.ManageGuild)
    .addSubcommand((s) => s.setName('start').setDescription('Start (or schedule) a giveaway')
      .addStringOption((o) => o.setName('prize').setDescription('What is being given away').setRequired(true).setMaxLength(200))
      .addStringOption((o) => o.setName('duration').setDescription('How long it runs, e.g. 24h, 3d, 1w').setRequired(true))
      .addIntegerOption((o) => o.setName('winners').setDescription('Number of winners (default 1)').setMinValue(1).setMaxValue(20))
      .addStringOption((o) => o.setName('description').setDescription('Extra text shown on the giveaway').setMaxLength(1000))
      .addRoleOption((o) => o.setName('role').setDescription('Role required to enter'))
      .addStringOption((o) => o.setName('excluded-roles').setDescription('Roles that cannot enter (mention up to 5)').setMaxLength(200))
      .addStringOption((o) => o.setName('min-account-age').setDescription('Minimum Discord account age, e.g. 30d'))
      .addStringOption((o) => o.setName('min-server-age').setDescription('Minimum time in this server, e.g. 7d'))
      .addUserOption((o) => o.setName('host').setDescription('Host shown on the giveaway (default: you)'))
      .addChannelOption((o) => o.setName('channel').setDescription('Channel to post in (default: configured or current)').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
      .addStringOption((o) => o.setName('start-in').setDescription('Schedule it: start after this long, e.g. 2h')))
    .addSubcommand((s) => s.setName('end').setDescription('End a giveaway now and pick winners').addStringOption((o) => idOpt(o)))
    .addSubcommand((s) => s.setName('reroll').setDescription('Pick new winner(s) for an ended giveaway')
      .addStringOption((o) => idOpt(o))
      .addIntegerOption((o) => o.setName('count').setDescription('How many new winners (default: original count)').setMinValue(1).setMaxValue(20)))
    .addSubcommand((s) => s.setName('cancel').setDescription('Cancel an active or scheduled giveaway').addStringOption((o) => idOpt(o)))
    .addSubcommand((s) => s.setName('list').setDescription('List active and scheduled giveaways'))
    .addSubcommand((s) => s.setName('config').setDescription('Giveaway defaults for this server')
      .addChannelOption((o) => o.setName('default-channel').setDescription('Default channel for new giveaways').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
      .addRoleOption((o) => o.setName('ping-role').setDescription('Role to ping when a giveaway starts'))
      .addBooleanOption((o) => o.setName('dm-winners').setDescription('DM winners when they win'))
      .addIntegerOption((o) => o.setName('max-active').setDescription('Maximum simultaneous giveaways').setMinValue(1).setMaxValue(100))),

  async autocomplete(interaction) {
    const sub = interaction.options.getSubcommand();
    const statuses = sub === 'reroll' ? ['ended'] : ['active', 'scheduled'];
    const rows = await giveaways.listGiveaways(interaction.guildId, statuses, interaction.options.getFocused(), 25);
    await interaction.respond(rows.map((g) => ({ name: clip(`${g.prize} (${g.id})`, 100), value: g.id })));
  },

  execute: (i) => dispatch(i, {
    async start(interaction) {
      const { guild, options } = interaction;
      const durationMs = dur(options.getString('duration'), 'Duration', { required: true });
      const startInMs = dur(options.getString('start-in'), 'Start delay');
      const cfg = await config.get(guild.id, 'giveaways');
      const picked = options.getChannel('channel');
      const channel = guild.channels.cache.get(picked?.id ?? cfg.defaultChannelId ?? interaction.channelId);
      if (!channel?.isTextBased() || channel.isThread()) throw new AppError('Choose a normal text or announcement channel for the giveaway.');
      const role = options.getRole('role');
      if (role?.id === guild.id) throw new AppError('The required role cannot be @everyone.');
      await defer(interaction);

      const gw = await giveaways.create({
        guild, channel, hostId: (options.getUser('host') ?? interaction.user).id, prize: options.getString('prize', true),
        durationMs, startInMs, winners: options.getInteger('winners') ?? 1, description: options.getString('description'),
        requiredRoleId: role?.id ?? null, excludedRoleIds: parseRoles(options.getString('excluded-roles'), guild),
        minAccountAgeMs: dur(options.getString('min-account-age'), 'Minimum account age'), minMemberAgeMs: dur(options.getString('min-server-age'), 'Minimum server age'),
      });
      return ok(interaction, gw.status === 'scheduled'
        ? `Giveaway **${clip(gw.prize, 80)}** scheduled for ${discordTime(gw.starts_at, 'R')} in <#${channel.id}> (ID \`${gw.id}\`).`
        : `Giveaway **${clip(gw.prize, 80)}** started in <#${channel.id}> — ends ${discordTime(gw.ends_at, 'R')} (ID \`${gw.id}\`).`);
    },
    async end(interaction) {
      const id = interaction.options.getString('id', true);
      const gw = await giveaways.getGiveaway(id);
      if (!gw || gw.guild_id !== interaction.guildId) throw new AppError('No giveaway with that ID in this server.');
      await defer(interaction);
      const res = await giveaways.endGiveaway(gw.id, { endedBy: interaction.user.id });
      return ok(interaction, res?.winners.length ? `Giveaway ended. Winner(s): ${res.winners.map((w) => `<@${w}>`).join(', ')}` : 'Giveaway ended — there were no valid entries.');
    },
    async reroll(interaction) {
      await defer(interaction);
      const winners = await giveaways.reroll(interaction.guildId, interaction.options.getString('id', true), interaction.options.getInteger('count'), interaction.user.id);
      return ok(interaction, `Rerolled. New winner(s): ${winners.map((w) => `<@${w}>`).join(', ')}`);
    },
    async cancel(interaction) {
      await defer(interaction);
      const gw = await giveaways.cancel(interaction.guildId, interaction.options.getString('id', true), interaction.user.id);
      return ok(interaction, `Cancelled giveaway **${clip(gw.prize, 80)}**.`);
    },
    async list(interaction) {
      const rows = await giveaways.listGiveaways(interaction.guildId);
      if (!rows.length) return respond(interaction, 'ℹ️ There are no active or scheduled giveaways.');
      const lines = await Promise.all(rows.slice(0, 15).map(async (g) => {
        const n = await giveaways.countEntries(g.id);
        const when = g.status === 'scheduled' ? `starts ${discordTime(g.starts_at, 'R')}` : `ends ${discordTime(g.ends_at, 'R')}`;
        return `**${clip(g.prize, 60)}** — \`${g.id}\` • ${g.status} • ${when} • ${g.winner_count} winner(s) • ${n} entr${n === 1 ? 'y' : 'ies'} • <#${g.channel_id}>`;
      }));
      return respond(interaction, { embeds: [makeEmbed({ title: '🎉 Giveaways', color: COLORS.gold, description: lines.join('\n'), footer: `${rows.length} giveaway(s)` })] });
    },
    async config(interaction) {
      const summary = await patchConfig(interaction, 'giveaways', [
        { name: 'default-channel', type: 'channel', path: 'defaultChannelId', label: 'Default channel' },
        { name: 'ping-role', type: 'role', path: 'pingRoleId', label: 'Ping role' },
        { name: 'dm-winners', type: 'boolean', path: 'dmWinners', label: 'DM winners' },
        { name: 'max-active', type: 'integer', path: 'maxActive', label: 'Max active' },
      ]);
      return ok(interaction, `Giveaway defaults updated:\n${summary}`);
    },
  }),
};
