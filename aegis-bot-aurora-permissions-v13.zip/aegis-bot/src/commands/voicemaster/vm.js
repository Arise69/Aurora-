'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const vm = require('../../services/voicemaster');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { assertBotPermissions } = require('../../utils/permissions');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

const needAdmin = (i) => { if (!i.memberPermissions.has(P.ManageGuild)) throw new AppError('You need **Manage Server** to configure Voice Master.'); };
const userOpt = (s) => s.addUserOption((o) => o.setName('user').setDescription('Member').setRequired(true));

async function setEveryone(interaction, patch, text) {
  const { channel } = await vm.requireOwned(interaction);
  await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, patch, { reason: `Voice Master: ${interaction.user.username}` });
  return ok(interaction, text);
}

module.exports = {
  category: 'Voice Master',
  botPermissions: [P.ManageChannels],
  cooldown: 3,
  data: newCommand('vm', 'Join-to-create voice channels and owner controls')
    .addSubcommand((s) => s.setName('setup').setDescription('Enable Voice Master (Manage Server)')
      .addChannelOption((o) => o.setName('creator').setDescription('Existing "join to create" voice channel (default: create one)').addChannelTypes(ChannelType.GuildVoice))
      .addChannelOption((o) => o.setName('category').setDescription('Category for the temporary channels').addChannelTypes(ChannelType.GuildCategory))
      .addStringOption((o) => o.setName('name-template').setDescription("Channel name, e.g. {user}'s room").setMaxLength(80))
      .addIntegerOption((o) => o.setName('default-limit').setDescription('Default user limit (0 = unlimited)').setMinValue(0).setMaxValue(99)))
    .addSubcommand((s) => s.setName('disable').setDescription('Disable Voice Master (Manage Server)'))
    .addSubcommand((s) => s.setName('lock').setDescription('Lock your channel so nobody new can join'))
    .addSubcommand((s) => s.setName('unlock').setDescription('Unlock your channel'))
    .addSubcommand((s) => s.setName('hide').setDescription('Hide your channel from everyone else'))
    .addSubcommand((s) => s.setName('unhide').setDescription('Make your channel visible again'))
    .addSubcommand((s) => s.setName('name').setDescription('Rename your channel').addStringOption((o) => o.setName('name').setDescription('New name').setRequired(true).setMaxLength(100)))
    .addSubcommand((s) => s.setName('limit').setDescription('Set your channel user limit').addIntegerOption((o) => o.setName('users').setDescription('0 = unlimited').setRequired(true).setMinValue(0).setMaxValue(99)))
    .addSubcommand((s) => userOpt(s.setName('permit').setDescription('Let a member join even if locked/hidden')))
    .addSubcommand((s) => userOpt(s.setName('reject').setDescription('Kick a member out and block them from your channel')))
    .addSubcommand((s) => s.setName('claim').setDescription('Claim the channel if the owner left'))
    .addSubcommand((s) => userOpt(s.setName('transfer').setDescription('Give ownership to another member in your channel')))
    .addSubcommand((s) => s.setName('info').setDescription('Show info about your current channel')),
  execute: (i) => dispatch(i, {
    async setup(interaction) {
      needAdmin(interaction);
      assertBotPermissions(interaction.guild, [P.ManageChannels, P.MoveMembers]);
      const { guild, options } = interaction;
      let creator = options.getChannel('creator');
      let category = options.getChannel('category');
      if (!creator) {
        category ??= await guild.channels.create({ name: 'Voice Master', type: ChannelType.GuildCategory, reason: 'Voice Master setup' });
        creator = await guild.channels.create({ name: '➕ Join to create', type: ChannelType.GuildVoice, parent: category.id, reason: 'Voice Master setup' });
      }
      await config.update(guild.id, 'voicemaster', (c) => {
        c.enabled = true; c.creatorChannelId = creator.id; c.categoryId = category?.id ?? c.categoryId;
        c.nameTemplate = options.getString('name-template') ?? c.nameTemplate; c.defaultLimit = options.getInteger('default-limit') ?? c.defaultLimit;
      }, { actorId: interaction.user.id, summary: `Voice Master enabled (creator <#${creator.id}>)` });
      return ok(interaction, `Voice Master enabled. Members who join <#${creator.id}> get their own channel.`);
    },
    async disable(interaction) {
      needAdmin(interaction);
      await config.update(interaction.guildId, 'voicemaster', (c) => { c.enabled = false; }, { actorId: interaction.user.id, summary: 'Voice Master disabled' });
      return ok(interaction, 'Voice Master disabled. Existing temporary channels are cleaned up when empty.');
    },
    lock: (x) => setEveryone(x, { Connect: false }, '🔒 Channel locked.'),
    unlock: (x) => setEveryone(x, { Connect: null }, '🔓 Channel unlocked.'),
    hide: (x) => setEveryone(x, { ViewChannel: false }, '🙈 Channel hidden.'),
    unhide: (x) => setEveryone(x, { ViewChannel: null }, '👀 Channel visible.'),
    async name(x) {
      const { channel } = await vm.requireOwned(x);
      vm.checkRenameLimit(channel.id);
      const name = vm.sanitizeName(x.options.getString('name', true));
      await channel.setName(name, `Voice Master: ${x.user.username}`);
      return ok(x, `Channel renamed to **${name}**.`);
    },
    async limit(x) {
      const { channel } = await vm.requireOwned(x);
      const n = x.options.getInteger('users', true);
      await channel.setUserLimit(n);
      return ok(x, n ? `User limit set to **${n}**.` : 'User limit removed.');
    },
    async permit(x) {
      const { channel } = await vm.requireOwned(x);
      const user = x.options.getUser('user', true);
      await channel.permissionOverwrites.edit(user.id, { Connect: true, ViewChannel: true });
      return ok(x, `<@${user.id}> can now join your channel.`);
    },
    async reject(x) {
      const { channel } = await vm.requireOwned(x);
      const user = x.options.getUser('user', true);
      if (user.id === x.user.id) throw new AppError("You can't reject yourself.");
      await channel.permissionOverwrites.edit(user.id, { Connect: false });
      const m = channel.members.get(user.id);
      if (m) await m.voice.disconnect('Rejected by channel owner').catch(() => {});
      return ok(x, `<@${user.id}> can no longer join your channel.`);
    },
    async claim(x) {
      const { channel, row } = await vm.requireOwned(x, { allowUnowned: true });
      if (row.owner_id === x.user.id) throw new AppError('You already own this channel.');
      if (channel.members.has(row.owner_id)) throw new AppError('The owner is still in the channel.');
      await vm.setOwner(channel.id, x.user.id);
      await channel.permissionOverwrites.edit(x.user.id, { ViewChannel: true, Connect: true, Speak: true });
      return ok(x, 'You are now the owner of this channel.');
    },
    async transfer(x) {
      const { channel } = await vm.requireOwned(x);
      const user = x.options.getUser('user', true);
      if (!channel.members.has(user.id) || user.bot) throw new AppError('That member must be in your channel.');
      await vm.setOwner(channel.id, user.id);
      await channel.permissionOverwrites.edit(user.id, { ViewChannel: true, Connect: true, Speak: true });
      return ok(x, `Ownership transferred to <@${user.id}>.`);
    },
    async info(x) {
      const { channel, row } = await vm.requireOwned(x, { allowUnowned: true });
      return respond(x, { embeds: [makeEmbed({ title: `🎙️ ${channel.name}`, timestamp: false, fields: [
        { name: 'Owner', value: `<@${row.owner_id}>`, inline: true }, { name: 'Members', value: `${channel.members.size}${channel.userLimit ? `/${channel.userLimit}` : ''}`, inline: true },
      ] })] });
    },
  }),
};
