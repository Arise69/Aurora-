'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const music = require('../../services/music');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { patchConfig } = require('../../utils/optionsPatch');
const { makeEmbed, clip, escapeText } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

const ctl = (i) => music.assertController(i.guild, i.member);

module.exports = {
  category: 'Music',
  data: newCommand('music', 'Music playback controls')
    .addSubcommand((s) => s.setName('skip').setDescription('Skip the current track'))
    .addSubcommand((s) => s.setName('stop').setDescription('Stop playback, clear the queue and leave'))
    .addSubcommand((s) => s.setName('pause').setDescription('Pause playback'))
    .addSubcommand((s) => s.setName('resume').setDescription('Resume playback'))
    .addSubcommand((s) => s.setName('queue').setDescription('Show the queue'))
    .addSubcommand((s) => s.setName('nowplaying').setDescription('Show the current track'))
    .addSubcommand((s) => s.setName('loop').setDescription('Set loop mode').addStringOption((o) => o.setName('mode').setDescription('Loop mode').setRequired(true).addChoices({ name: 'Off', value: 'off' }, { name: 'Track', value: 'track' }, { name: 'Queue', value: 'queue' })))
    .addSubcommand((s) => s.setName('shuffle').setDescription('Shuffle the queue'))
    .addSubcommand((s) => s.setName('remove').setDescription('Remove a track from the queue').addIntegerOption((o) => o.setName('position').setDescription('Queue position').setRequired(true).setMinValue(1)))
    .addSubcommand((s) => s.setName('config').setDescription('Music settings (Manage Server)')
      .addRoleOption((o) => o.setName('dj-role').setDescription('Only this role (and admins) may control playback'))
      .addIntegerOption((o) => o.setName('max-queue').setDescription('Maximum queue length').setMinValue(1).setMaxValue(500))
      .addIntegerOption((o) => o.setName('max-track-minutes').setDescription('Maximum track length').setMinValue(1).setMaxValue(180))),
  execute: (i) => dispatch(i, {
    async skip(interaction) { (await ctl(interaction)).player.stop(); return ok(interaction, 'Skipped.', { ephemeral: false }); },
    async stop(interaction) { (await ctl(interaction)).destroy(); return ok(interaction, 'Stopped and left the channel.', { ephemeral: false }); },
    async pause(interaction) { (await ctl(interaction)).player.pause(); return ok(interaction, 'Paused.'); },
    async resume(interaction) { (await ctl(interaction)).player.unpause(); return ok(interaction, 'Resumed.'); },
    async queue(interaction) {
      const s = music.sessionFor(interaction.guildId);
      if (!s) throw new AppError('Nothing is playing.');
      return respond(interaction, { embeds: [music.queueEmbed(s)] });
    },
    async nowplaying(interaction) {
      const s = music.sessionFor(interaction.guildId);
      if (!s?.current) throw new AppError('Nothing is playing.');
      return respond(interaction, { embeds: [makeEmbed({ title: '🎶 Now playing', description: `**${escapeText(clip(s.current.title, 200))}** \`${music.fmt(s.current.seconds)}\`\nRequested by <@${s.current.requestedBy}>`, timestamp: false })] });
    },
    async loop(interaction) { const s = await ctl(interaction); s.loop = interaction.options.getString('mode', true); return ok(interaction, `Loop mode: **${s.loop}**.`); },
    async shuffle(interaction) {
      const s = await ctl(interaction);
      s.queue = require('../../services/giveaways').shuffle(s.queue);
      return ok(interaction, 'Queue shuffled.');
    },
    async remove(interaction) {
      const s = await ctl(interaction);
      const idx = interaction.options.getInteger('position', true) - 1;
      if (!s.queue[idx]) throw new AppError('There is no track at that position.');
      const [t] = s.queue.splice(idx, 1);
      return ok(interaction, `Removed **${escapeText(clip(t.title, 80))}**.`);
    },
    async config(interaction) {
      if (!interaction.memberPermissions.has(P.ManageGuild)) throw new AppError('You need **Manage Server** to change music settings.');
      const summary = await patchConfig(interaction, 'music', [
        { name: 'dj-role', type: 'role', path: 'djRoleId', label: 'DJ role' },
        { name: 'max-queue', type: 'integer', path: 'maxQueue', label: 'Max queue' },
        { name: 'max-track-minutes', type: 'integer', path: 'maxTrackMinutes', label: 'Max track minutes' },
      ]);
      return ok(interaction, `Music settings updated:\n${summary}`);
    },
  }),
};
