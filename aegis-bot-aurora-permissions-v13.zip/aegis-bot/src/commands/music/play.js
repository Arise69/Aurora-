'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const music = require('../../services/music');
const { makeEmbed, escapeText, clip } = require('../../utils/embeds');
const { respond, defer } = require('../../utils/reply');

module.exports = {
  category: 'Music',
  botPermissions: [P.Connect, P.Speak],
  cooldown: 3,
  data: newCommand('play', 'Play a song (search, YouTube link or direct audio URL)')
    .addStringOption((o) => o.setName('query').setDescription('Song name or URL').setRequired(true).setMaxLength(300)),
  async execute(interaction) {
    await defer(interaction, false);
    const { track, position } = await music.play({ guild: interaction.guild, member: interaction.member, textChannel: interaction.channel, query: interaction.options.getString('query', true) });
    return respond(interaction, { embeds: [makeEmbed({
      title: position === 0 ? '🎶 Now playing' : '➕ Added to queue', description: `**${escapeText(clip(track.title, 200))}**`,
      footer: `Requested by ${interaction.user.username}${position ? ` • position ${position}` : ''}`,
    })] }, { ephemeral: false });
  },
};
