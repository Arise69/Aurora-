'use strict';

const { newCommand } = require('../utils/builder');
const { makeEmbed } = require('../utils/embeds');
const { reply } = require('../prefix/helpers');
const { respond, ok, fail } = require('../utils/reply');
const { AppError } = require('../utils/errors');
const owners = require('../services/botOwner');
const { formatDuration } = require('../utils/duration');
const { version: djsVersion } = require('discord.js');

const OWNER_COLOR = 0x2c2c2c;

function memory() {
  const m = process.memoryUsage();
  return `RSS: **${(m.rss / 1048576).toFixed(1)} MB**\nHeap: **${(m.heapUsed / 1048576).toFixed(1)} / ${(m.heapTotal / 1048576).toFixed(1)} MB**`;
}

function statsEmbed(client) {
  const members = client.guilds.cache.reduce((n, g) => n + (g.memberCount || 0), 0);
  return makeEmbed({
    title: 'Aurora Owner Panel',
    description: 'Bot statistics visible to Aurora owners only.',
    color: OWNER_COLOR,
    thumbnail: client.user.displayAvatarURL({ size: 256 }),
    fields: [
      { name: 'Guilds', value: String(client.guilds.cache.size), inline: true },
      { name: 'Users', value: String(members), inline: true },
      { name: 'Uptime', value: formatDuration(client.uptime || 0), inline: true },
      { name: 'Memory', value: memory(), inline: true },
      { name: 'Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true },
      { name: 'Node.js', value: process.version, inline: true },
      { name: 'discord.js', value: `v${djsVersion}`, inline: true },
      { name: 'Commands', value: String(client.commands?.size || 0), inline: true },
    ],
  });
}

async function ownerOnly(userId) {
  if (!(await owners.isOwner(userId))) throw new AppError('This command is restricted to Aurora bot owners.');
}

function targetIdFromInteraction(i) {
  return i.options.getUser('user', true).id;
}

module.exports = {
  category: 'Bot Settings',
  data: newCommand('owner', 'Aurora bot owner controls'),
  async execute(i) {
    await ownerOnly(i.user.id);
    const sub = i.options.getSubcommand();
    const user = i.options.getUser('user');
    if (sub === 'stats') return respond(i, { embeds: [statsEmbed(i.client)] });
    if (sub === 'list') {
      const d = await owners.get();
      const envOwners = require('../config/env').ownerIds;
      const all = [...new Set([...envOwners, ...d.owners])];
      return respond(i, { embeds: [makeEmbed({ title: 'Aurora Owners', color: OWNER_COLOR, description: all.length ? all.map((id, n) => `**[\`${String(n + 1).padStart(2, '0')}\`]** <@${id}>`).join('\n') : 'No owners are configured.' })] });
    }
    if (sub === 'add') {
      await owners.addOwner(targetIdFromInteraction(i));
      return ok(i, `Added <@${user.id}> as an Aurora bot owner.`);
    }
    if (sub === 'remove') {
      if (require('../config/env').ownerIds.includes(user.id)) throw new AppError('That owner is defined in OWNER_IDS and must be removed from the .env file.');
      const current = await owners.get();
      const allOwners = new Set([...require('../config/env').ownerIds, ...current.owners]);
      if (allOwners.size <= 1 && allOwners.has(user.id)) throw new AppError('You cannot remove the last Aurora bot owner.');
      await owners.removeOwner(user.id);
      return ok(i, `Removed <@${user.id}> from Aurora bot owners.`);
    }
    if (sub === 'noprefix-add') {
      await owners.grantNoPrefix(user.id);
      return ok(i, `Granted no-prefix access to <@${user.id}>. They can now use commands without the \`.\` prefix.`);
    }
    if (sub === 'noprefix-remove') {
      await owners.revokeNoPrefix(user.id);
      return ok(i, `Removed no-prefix access from <@${user.id}>.`);
    }
    if (sub === 'noprefix-list') {
      const d = await owners.get();
      return respond(i, { embeds: [makeEmbed({ title: 'Aurora No-Prefix Users', color: OWNER_COLOR, description: d.noPrefix.length ? d.noPrefix.map((id, n) => `**[\`${String(n + 1).padStart(2, '0')}\`]** <@${id}>`).join('\n') : 'No users have no-prefix access.' })] });
    }
    throw new AppError('Unknown owner action.');
  },
};

module.exports.data = newCommand('owner', 'Aurora bot owner controls')
  .addSubcommand((s) => s.setName('stats').setDescription('Show Aurora guild, user, uptime and memory statistics'))
  .addSubcommand((s) => s.setName('list').setDescription('List Aurora bot owners'))
  .addSubcommand((s) => s.setName('add').setDescription('Add an Aurora bot owner').addUserOption((o) => o.setName('user').setDescription('User to add').setRequired(true)))
  .addSubcommand((s) => s.setName('remove').setDescription('Remove an Aurora bot owner').addUserOption((o) => o.setName('user').setDescription('User to remove').setRequired(true)))
  .addSubcommand((s) => s.setName('noprefix-add').setDescription('Grant no-prefix command access').addUserOption((o) => o.setName('user').setDescription('User to grant').setRequired(true)))
  .addSubcommand((s) => s.setName('noprefix-remove').setDescription('Remove no-prefix command access').addUserOption((o) => o.setName('user').setDescription('User to remove').setRequired(true)))
  .addSubcommand((s) => s.setName('noprefix-list').setDescription('List users with no-prefix access'));
