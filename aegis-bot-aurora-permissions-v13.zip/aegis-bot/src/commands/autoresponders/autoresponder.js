'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const responders = require('../../services/autoresponder');
const logging = require('../../services/logging');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed, clip, escapeText } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

module.exports = {
  category: 'Autoresponders',
  userPermissions: [P.ManageGuild],
  data: newCommand('autoresponder', 'Reply automatically to trigger phrases', P.ManageGuild)
    .addSubcommand((s) => s.setName('add').setDescription('Create an autoresponder (variables: {user} {user.name} {server} {count})')
      .addStringOption((o) => o.setName('trigger').setDescription('Trigger text (case-insensitive)').setRequired(true).setMaxLength(100))
      .addStringOption((o) => o.setName('response').setDescription('What I should reply').setRequired(true).setMaxLength(1500))
      .addStringOption((o) => o.setName('match').setDescription('How to match (default: contains)').addChoices(
        { name: 'Whole message equals', value: 'exact' }, { name: 'Contains', value: 'contains' }, { name: 'Starts with', value: 'starts' }, { name: 'Ends with', value: 'ends' }))
      .addIntegerOption((o) => o.setName('cooldown').setDescription('Seconds between replies per channel (default 5)').setMinValue(1).setMaxValue(3600)))
    .addSubcommand((s) => s.setName('remove').setDescription('Delete an autoresponder').addStringOption((o) => o.setName('id-or-trigger').setDescription('ID or trigger text').setRequired(true)))
    .addSubcommand((s) => s.setName('list').setDescription('Show autoresponders')),
  execute: (i) => dispatch(i, {
    async add(interaction) {
      const id = await responders.add(interaction.guildId, {
        trigger: interaction.options.getString('trigger', true), response: interaction.options.getString('response', true),
        matchType: interaction.options.getString('match') ?? 'contains', cooldownSec: interaction.options.getInteger('cooldown') ?? 5, by: interaction.user.id,
      });
      await logging.logConfigChange(interaction.guildId, 'autoresponders', interaction.user.id, `Autoresponder \`${id}\` created`);
      return ok(interaction, `Autoresponder created (ID \`${id}\`).`);
    },
    async remove(interaction) {
      if (!(await responders.remove(interaction.guildId, interaction.options.getString('id-or-trigger', true).trim()))) throw new AppError('No autoresponder with that ID or trigger.');
      return ok(interaction, 'Autoresponder removed.');
    },
    async list(interaction) {
      const rows = await responders.list(interaction.guildId);
      return respond(interaction, { embeds: [makeEmbed({
        title: '💬 Autoresponders', timestamp: false,
        description: rows.length ? rows.slice(0, 20).map((r) => `\`${r.id}\` **${escapeText(clip(r.trigger_text, 40))}** (${r.match_type}) → ${escapeText(clip(r.response, 60))}`).join('\n') : 'None yet. Create one with `/autoresponder add`.',
        footer: `${rows.length}/100`,
      })] });
    },
  }),
};
