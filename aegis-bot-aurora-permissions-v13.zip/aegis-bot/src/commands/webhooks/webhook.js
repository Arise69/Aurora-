'use strict';
const { PermissionFlagsBits: P, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, MessageFlags } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const webhooks = require('../../services/webhooks');
const logging = require('../../services/logging');
const env = require('../../config/env');
const cipher = require('../../utils/crypto');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

const pending = new Map(); // `${guild}:${user}` -> { name, kind, events, at }

function requireEncryption() {
  if (!cipher.isConfigured()) throw new AppError('Webhooks are disabled: `ENCRYPTION_KEY` is not configured on this bot.');
}

module.exports = {
  category: 'Webhooks',
  userPermissions: [P.Administrator],
  data: newCommand('webhook', 'Send moderation, raid and giveaway alerts to webhooks', P.Administrator)
    .addSubcommand((s) => s.setName('add').setDescription('Register a webhook (the URL is entered privately in a pop-up)')
      .addStringOption((o) => o.setName('name').setDescription('A name for this webhook').setRequired(true).setMaxLength(32))
      .addStringOption((o) => o.setName('type').setDescription('Where it sends').addChoices({ name: 'Discord webhook', value: 'discord' }, { name: 'External HTTPS endpoint', value: 'external' }))
      .addStringOption((o) => o.setName('events').setDescription(`Comma-separated: ${webhooks.EVENT_NAMES.join(', ')}`.slice(0, 100))))
    .addSubcommand((s) => s.setName('list').setDescription('List webhooks (URLs are never shown)'))
    .addSubcommand((s) => s.setName('remove').setDescription('Delete a webhook').addStringOption((o) => o.setName('name').setDescription('Webhook name or ID').setRequired(true)))
    .addSubcommand((s) => s.setName('test').setDescription('Send a test notification').addStringOption((o) => o.setName('name').setDescription('Webhook name or ID').setRequired(true))),
  components: {
    async wh(interaction) {
      if (!interaction.isModalSubmit() || interaction.customId !== 'wh:add') return;
      const key = `${interaction.guildId}:${interaction.user.id}`;
      const p = pending.get(key);
      pending.delete(key);
      if (!p || Date.now() - p.at > 600_000) throw new AppError('That form expired. Run `/webhook add` again.');
      if (!interaction.memberPermissions?.has(P.Administrator)) throw new AppError("You don't have permission to do that.");
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const url = interaction.fields.getTextInputValue('url').trim();
      const secret = interaction.fields.getTextInputValue('secret').trim() || null;
      const id = await webhooks.add({ guildId: interaction.guildId, name: p.name, kind: p.kind, url, secret, events: p.events, createdBy: interaction.user.id });
      await logging.logConfigChange(interaction.guildId, 'webhooks', interaction.user.id, `Webhook "${p.name}" (${id}) added — events: ${p.events.join(', ')}`);
      return ok(interaction, `Webhook **${p.name}** saved (ID \`${id}\`, encrypted). Use \`/webhook test\` to verify it.`);
    },
  },
  execute: (i) => dispatch(i, {
    async add(interaction) {
      requireEncryption();
      const kind = interaction.options.getString('type') ?? 'discord';
      if (kind === 'external' && !env.allowExternalWebhooks) throw new AppError('External endpoints are disabled on this bot (`ALLOW_EXTERNAL_WEBHOOKS=false`).');
      const events = webhooks.parseEvents(interaction.options.getString('events'));
      pending.set(`${interaction.guildId}:${interaction.user.id}`, { name: interaction.options.getString('name', true).trim(), kind, events, at: Date.now() });
      const modal = new ModalBuilder().setCustomId('wh:add').setTitle('Webhook URL (kept private)').addComponents(
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('url').setLabel('Webhook URL').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(400)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('secret').setLabel('Signing secret (external only, optional)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100)),
      );
      return interaction.showModal(modal);
    },
    async list(interaction) {
      const rows = await webhooks.list(interaction.guildId);
      return respond(interaction, { embeds: [makeEmbed({
        title: '🪝 Webhooks', timestamp: false,
        description: rows.length ? rows.map((r) => `${r.enabled ? '✅' : '⛔'} **${r.name}** (\`${r.id}\`, ${r.kind}) — ${r.events.join(', ')}${r.failures ? ` — ⚠️ ${r.failures} recent failure(s)` : ''}`).join('\n') : 'No webhooks configured.',
        footer: 'Webhooks that fail 10 times in a row are disabled automatically.',
      })] });
    },
    async remove(interaction) {
      const name = interaction.options.getString('name', true);
      if (!(await webhooks.remove(interaction.guildId, name))) throw new AppError('No webhook with that name or ID.');
      await logging.logConfigChange(interaction.guildId, 'webhooks', interaction.user.id, `Webhook "${name}" removed`);
      return ok(interaction, 'Webhook removed.');
    },
    async test(interaction) {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const success = await webhooks.test(interaction.guildId, interaction.options.getString('name', true));
      return respond(interaction, success ? '✅ Test notification delivered.' : '❌ Delivery failed. Check that the URL is still valid.');
    },
  }),
};
