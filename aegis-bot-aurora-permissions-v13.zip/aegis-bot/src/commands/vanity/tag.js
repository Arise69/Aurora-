'use strict';
const { newCommand } = require('../../utils/builder');
const tags = require('../../services/tags');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed, escapeText } = require('../../utils/embeds');
const { discordTime } = require('../../utils/duration');
const { ok, respond } = require('../../utils/reply');

const nameOpt = (o, auto = true) => o.setName('name').setDescription('Tag name').setRequired(true).setMaxLength(32).setAutocomplete(auto);

module.exports = {
  category: 'Vanity & Tags',
  autocompletePermission: 0n,
  data: newCommand('tag', 'Saved snippets for your server')
    .addSubcommand((s) => s.setName('show').setDescription('Post a tag').addStringOption((o) => nameOpt(o)))
    .addSubcommand((s) => s.setName('create').setDescription('Create a tag')
      .addStringOption((o) => nameOpt(o, false)).addStringOption((o) => o.setName('content').setDescription('Tag content').setRequired(true).setMaxLength(1800)))
    .addSubcommand((s) => s.setName('edit').setDescription('Edit your tag')
      .addStringOption((o) => nameOpt(o)).addStringOption((o) => o.setName('content').setDescription('New content').setRequired(true).setMaxLength(1800)))
    .addSubcommand((s) => s.setName('delete').setDescription('Delete your tag').addStringOption((o) => nameOpt(o)))
    .addSubcommand((s) => s.setName('info').setDescription('Show tag details').addStringOption((o) => nameOpt(o)))
    .addSubcommand((s) => s.setName('list').setDescription('List all tags')),
  async autocomplete(interaction) {
    const rows = await tags.search(interaction.guildId, interaction.options.getFocused());
    await interaction.respond(rows.map((r) => ({ name: r.name, value: r.name })));
  },
  execute: (i) => dispatch(i, {
    async show(interaction) {
      const tag = await tags.use(interaction.guildId, interaction.options.getString('name', true));
      return respond(interaction, { content: tag.content, allowedMentions: { parse: [] } }, { ephemeral: false });
    },
    async create(interaction) {
      await tags.create(interaction.guildId, interaction.options.getString('name', true), interaction.options.getString('content', true), interaction.user.id);
      return ok(interaction, 'Tag created.');
    },
    async edit(interaction) {
      await tags.edit(interaction.guildId, interaction.options.getString('name', true), interaction.options.getString('content', true), interaction.member);
      return ok(interaction, 'Tag updated.');
    },
    async delete(interaction) {
      await tags.remove(interaction.guildId, interaction.options.getString('name', true), interaction.member);
      return ok(interaction, 'Tag deleted.');
    },
    async info(interaction) {
      const tag = await tags.getTag(interaction.guildId, interaction.options.getString('name', true));
      if (!tag) return respond(interaction, '❌ No tag with that name.');
      return respond(interaction, { embeds: [makeEmbed({ title: `Tag: ${escapeText(tag.name)}`, timestamp: false, fields: [
        { name: 'Owner', value: `<@${tag.owner_id}>`, inline: true }, { name: 'Uses', value: String(tag.uses), inline: true }, { name: 'Created', value: discordTime(Number(tag.created_at), 'R'), inline: true },
      ] })] });
    },
    async list(interaction) {
      const rows = await tags.list(interaction.guildId);
      return respond(interaction, { embeds: [makeEmbed({ title: `🏷️ Tags (${rows.length})`, timestamp: false, description: rows.length ? rows.map((r) => `\`${r.name}\``).join(' ').slice(0, 3900) : 'No tags yet.' })] });
    },
  }),
};
