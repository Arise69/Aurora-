'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const env = require('../../config/env');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { assertAssignableRole } = require('../../utils/permissions');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

module.exports = {
  category: 'Vanity & Tags',
  userPermissions: [P.ManageGuild],
  botPermissions: [P.ManageRoles],
  data: newCommand('vanity', 'Give a role to members who show your keyword/vanity in their status', P.ManageGuild)
    .addSubcommand((s) => s.setName('set').setDescription('Enable the vanity role')
      .addStringOption((o) => o.setName('keyword').setDescription('Text to look for in custom status, e.g. /myserver').setRequired(true).setMinLength(2).setMaxLength(50))
      .addRoleOption((o) => o.setName('role').setDescription('Role to give').setRequired(true))
      .addChannelOption((o) => o.setName('channel').setDescription('Announce new supporters here').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
      .addStringOption((o) => o.setName('message').setDescription('Announcement text ({user} {keyword} {server})').setMaxLength(300)))
    .addSubcommand((s) => s.setName('disable').setDescription('Disable the vanity role'))
    .addSubcommand((s) => s.setName('status').setDescription('Show vanity settings')),
  execute: (i) => dispatch(i, {
    async set(interaction) {
      const role = interaction.guild.roles.cache.get(interaction.options.getRole('role', true).id);
      assertAssignableRole(interaction.guild, role, interaction.member);
      const channel = interaction.options.getChannel('channel');
      await config.update(interaction.guildId, 'vanity', (c) => {
        c.enabled = true; c.keyword = interaction.options.getString('keyword', true).trim(); c.roleId = role.id;
        c.channelId = channel?.id ?? c.channelId; c.message = interaction.options.getString('message') ?? c.message;
      }, { actorId: interaction.user.id, summary: `Vanity role set to <@&${role.id}>` });
      const warn = env.intents.presences ? '' : '\n⚠️ The bot owner has not enabled `ENABLE_PRESENCES=true`, so presence updates cannot be received yet.';
      return ok(interaction, `Members with the keyword in their custom status will get <@&${role.id}>.${warn}`);
    },
    async disable(interaction) {
      await config.update(interaction.guildId, 'vanity', (c) => { c.enabled = false; }, { actorId: interaction.user.id, summary: 'Vanity role disabled' });
      return ok(interaction, 'Vanity role disabled.');
    },
    async status(interaction) {
      const c = await config.get(interaction.guildId, 'vanity');
      return respond(interaction, { embeds: [makeEmbed({ title: `🏷️ Vanity ${c.enabled ? '(on)' : '(off)'}`, timestamp: false, fields: [
        { name: 'Keyword', value: c.keyword ? `\`${c.keyword}\`` : 'Not set', inline: true }, { name: 'Role', value: c.roleId ? `<@&${c.roleId}>` : 'Not set', inline: true },
        { name: 'Announce in', value: c.channelId ? `<#${c.channelId}>` : 'Nowhere', inline: true }, { name: 'Presence intent', value: env.intents.presences ? 'Enabled' : 'Disabled', inline: true },
      ] })] });
    },
  }),
};
