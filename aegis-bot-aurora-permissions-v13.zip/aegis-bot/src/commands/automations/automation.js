'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const utility = require('../../services/utility');
const db = require('../../database');
const { AppError } = require('../../utils/errors');
const { parseDuration, formatDuration, discordTime } = require('../../utils/duration');
const { dispatch } = require('../../utils/dispatch');
const { assertAssignableRole } = require('../../utils/permissions');
const { toggleInList } = require('../../utils/optionsPatch');
const { makeEmbed, clip } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

const TEXTCH = [ChannelType.GuildText, ChannelType.GuildAnnouncement];

module.exports = {
  category: 'Automations',
  userPermissions: [P.ManageGuild],
  data: newCommand('automation', 'Autoroles, scheduled messages, sticky messages and auto-publish', P.ManageGuild)
    .addSubcommandGroup((g) => g.setName('autorole').setDescription('Roles given automatically on join')
      .addSubcommand((s) => s.setName('add').setDescription('Add an autorole')
        .addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true))
        .addStringOption((o) => o.setName('for').setDescription('Who gets it').addChoices({ name: 'Humans (default)', value: 'human' }, { name: 'Bots', value: 'bot' })))
      .addSubcommand((s) => s.setName('remove').setDescription('Remove an autorole').addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true)))
      .addSubcommand((s) => s.setName('list').setDescription('Show autoroles')))
    .addSubcommandGroup((g) => g.setName('schedule').setDescription('Recurring messages')
      .addSubcommand((s) => s.setName('add').setDescription('Post a message on a repeating interval')
        .addChannelOption((o) => o.setName('channel').setDescription('Channel').setRequired(true).addChannelTypes(...TEXTCH))
        .addStringOption((o) => o.setName('every').setDescription('Interval, e.g. 6h, 1d (min 5m)').setRequired(true))
        .addStringOption((o) => o.setName('message').setDescription('Message text').setRequired(true).setMaxLength(1900)))
      .addSubcommand((s) => s.setName('remove').setDescription('Delete a scheduled message').addStringOption((o) => o.setName('id').setDescription('Schedule ID').setRequired(true)))
      .addSubcommand((s) => s.setName('list').setDescription('Show scheduled messages')))
    .addSubcommandGroup((g) => g.setName('sticky').setDescription('A message that stays at the bottom of a channel')
      .addSubcommand((s) => s.setName('set').setDescription('Set the sticky message')
        .addChannelOption((o) => o.setName('channel').setDescription('Channel').setRequired(true).addChannelTypes(...TEXTCH))
        .addStringOption((o) => o.setName('message').setDescription('Sticky text').setRequired(true).setMaxLength(1500)))
      .addSubcommand((s) => s.setName('clear').setDescription('Remove the sticky message').addChannelOption((o) => o.setName('channel').setDescription('Channel').setRequired(true).addChannelTypes(...TEXTCH))))
    .addSubcommandGroup((g) => g.setName('autopublish').setDescription('Auto-publish announcement channel posts')
      .addSubcommand((s) => s.setName('enable').setDescription('Publish every message in an announcement channel').addChannelOption((o) => o.setName('channel').setDescription('Announcement channel').setRequired(true).addChannelTypes(ChannelType.GuildAnnouncement)))
      .addSubcommand((s) => s.setName('disable').setDescription('Stop auto-publishing').addChannelOption((o) => o.setName('channel').setDescription('Channel').setRequired(true).addChannelTypes(ChannelType.GuildAnnouncement)))),
  execute: (i) => dispatch(i, {
    async 'autorole.add'(interaction) {
      const role = interaction.guild.roles.cache.get(interaction.options.getRole('role', true).id);
      assertAssignableRole(interaction.guild, role, interaction.member);
      const key = interaction.options.getString('for') === 'bot' ? 'botRoleIds' : 'humanRoleIds';
      if (!(await toggleInList(interaction.guildId, 'autorole', key, role.id, true, { actorId: interaction.user.id, summary: `Autorole added: <@&${role.id}>` }))) throw new AppError('That role is already an autorole.');
      return ok(interaction, `<@&${role.id}> will be given to new ${key === 'botRoleIds' ? 'bots' : 'members'}.`);
    },
    async 'autorole.remove'(interaction) {
      const id = interaction.options.getRole('role', true).id;
      const a = await toggleInList(interaction.guildId, 'autorole', 'humanRoleIds', id, false, { actorId: interaction.user.id, summary: `Autorole removed: <@&${id}>` });
      const b = await toggleInList(interaction.guildId, 'autorole', 'botRoleIds', id, false, null);
      if (!a && !b) throw new AppError('That role is not an autorole.');
      return ok(interaction, 'Autorole removed.');
    },
    async 'autorole.list'(interaction) {
      const c = await config.get(interaction.guildId, 'autorole');
      const f = (a) => (a.length ? a.map((r) => `<@&${r}>`).join(' ') : 'None');
      return respond(interaction, { embeds: [makeEmbed({ title: 'Autoroles', timestamp: false, description: `**Members:** ${f(c.humanRoleIds)}\n**Bots:** ${f(c.botRoleIds)}` })] });
    },
    async 'schedule.add'(interaction) {
      const ms = parseDuration(interaction.options.getString('every', true));
      if (!ms) throw new AppError('Invalid interval. Examples: `6h`, `1d`.');
      const channel = interaction.options.getChannel('channel', true);
      const id = await utility.addScheduled({ guildId: interaction.guildId, channelId: channel.id, content: interaction.options.getString('message', true), intervalMs: ms, by: interaction.user.id });
      return ok(interaction, `Scheduled message \`${id}\` will post in <#${channel.id}> every **${formatDuration(ms)}**, first ${discordTime(Date.now() + ms, 'R')}.`);
    },
    async 'schedule.remove'(interaction) {
      if (!(await utility.removeScheduled(interaction.guildId, interaction.options.getString('id', true).trim()))) throw new AppError('No scheduled message with that ID.');
      return ok(interaction, 'Scheduled message removed.');
    },
    async 'schedule.list'(interaction) {
      const rows = await utility.listScheduled(interaction.guildId);
      return respond(interaction, { embeds: [makeEmbed({ title: 'Scheduled messages', timestamp: false, description: rows.length ? rows.map((r) => `\`${r.id}\` <#${r.channel_id}> every ${formatDuration(Number(r.interval_ms))} (next ${discordTime(Number(r.next_run_at), 'R')}) — ${clip(r.content, 60)}`).join('\n') : 'None.' })] });
    },
    async 'sticky.set'(interaction) {
      const channel = interaction.options.getChannel('channel', true);
      await db.run(`INSERT INTO sticky_messages (guild_id, channel_id, content, last_message_id) VALUES (?, ?, ?, NULL)
        ON CONFLICT (guild_id, channel_id) DO UPDATE SET content = excluded.content`, [interaction.guildId, channel.id, interaction.options.getString('message', true)]);
      return ok(interaction, `Sticky message set for <#${channel.id}>. It will appear after the next message there.`);
    },
    async 'sticky.clear'(interaction) {
      const channel = interaction.options.getChannel('channel', true);
      const row = await db.get('SELECT last_message_id FROM sticky_messages WHERE guild_id = ? AND channel_id = ?', [interaction.guildId, channel.id]);
      if (!row) throw new AppError('That channel has no sticky message.');
      await db.run('DELETE FROM sticky_messages WHERE guild_id = ? AND channel_id = ?', [interaction.guildId, channel.id]);
      if (row.last_message_id) await interaction.guild.channels.cache.get(channel.id)?.messages.delete(row.last_message_id).catch(() => {});
      return ok(interaction, 'Sticky message removed.');
    },
    async 'autopublish.enable'(interaction) {
      const ch = interaction.options.getChannel('channel', true);
      if (!interaction.guild.members.me.permissionsIn(ch.id).has(P.ManageMessages)) throw new AppError(`I need **Manage Messages** in <#${ch.id}> to publish messages.`);
      await toggleInList(interaction.guildId, 'automation', 'autopublishChannelIds', ch.id, true, { actorId: interaction.user.id, summary: `Auto-publish enabled in <#${ch.id}>` });
      return ok(interaction, `Messages in <#${ch.id}> will be published automatically.`);
    },
    async 'autopublish.disable'(interaction) {
      const ch = interaction.options.getChannel('channel', true);
      await toggleInList(interaction.guildId, 'automation', 'autopublishChannelIds', ch.id, false, { actorId: interaction.user.id, summary: `Auto-publish disabled in <#${ch.id}>` });
      return ok(interaction, 'Auto-publish disabled.');
    },
  }),
};
