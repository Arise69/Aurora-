'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

module.exports = {
  category: 'Bot Settings',
  userPermissions: [P.ManageGuild],
  data: newCommand('settings', 'Bot settings for this server', P.ManageGuild)
    .addSubcommand((s) => s.setName('prefix').setDescription('Change the prefix for text commands')
      .addStringOption((o) => o.setName('prefix').setDescription('1-3 characters, e.g. ! or .').setRequired(true).setMinLength(1).setMaxLength(3)))
    .addSubcommand((s) => s.setName('dm-notify').setDescription('DM members when they are warned, timed out, kicked or banned')
      .addBooleanOption((o) => o.setName('enabled').setDescription('Send DMs').setRequired(true)))
    .addSubcommand((s) => s.setName('view').setDescription('Show this server\'s bot settings')),
  execute: (i) => dispatch(i, {
    async prefix(interaction) {
      const prefix = interaction.options.getString('prefix', true).trim();
      if (!prefix || /[\s\\`@#*_~|>]/.test(prefix) || /^\/$/.test(prefix)) throw new AppError('That prefix is not allowed (no spaces or markdown/mention characters).');
      await config.update(interaction.guildId, 'general', (c) => { c.prefix = prefix; }, { actorId: interaction.user.id, summary: `Prefix → ${prefix}` });
      return ok(interaction, `Prefix changed to \`${prefix}\`. Slash commands always work.`);
    },
    async 'dm-notify'(interaction) {
      const enabled = interaction.options.getBoolean('enabled', true);
      await config.update(interaction.guildId, 'general', (c) => { c.dmNotify = enabled; }, { actorId: interaction.user.id, summary: `DM notifications → ${enabled}` });
      return ok(interaction, `Punishment DMs ${enabled ? 'enabled' : 'disabled'}.`);
    },
    async view(interaction) {
      const g = await config.get(interaction.guildId, 'general');
      const me = interaction.guild.members.me;
      const perms = [['Manage Roles', P.ManageRoles], ['Manage Channels', P.ManageChannels], ['Moderate Members', P.ModerateMembers], ['Kick', P.KickMembers], ['Ban', P.BanMembers], ['View Audit Log', P.ViewAuditLog], ['Manage Messages', P.ManageMessages]];
      return respond(interaction, { embeds: [makeEmbed({
        title: '🔧 Bot settings', timestamp: false,
        fields: [
          { name: 'Prefix', value: `\`${g.prefix}\``, inline: true }, { name: 'DM notifications', value: g.dmNotify ? 'On' : 'Off', inline: true },
          { name: 'My permissions', value: perms.map(([n, p]) => `${me.permissions.has(p) ? '✅' : '❌'} ${n}`).join('\n') },
        ],
      })] });
    },
  }),
};
