'use strict';
const { PermissionFlagsBits: P } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const permit = require('../../services/permit');
const logging = require('../../services/logging');
const { AppError } = require('../../utils/errors');
const { dispatch } = require('../../utils/dispatch');
const { makeEmbed } = require('../../utils/embeds');
const { discordTime } = require('../../utils/duration');
const { ok, respond } = require('../../utils/reply');

const scopeOpt = (o, required) => o.setName('scope').setDescription('Which system to exempt from').setRequired(required)
  .addChoices(...permit.SCOPES.map((s) => ({ name: s === 'all' ? 'All security systems' : s, value: s })));

function target(interaction) {
  const user = interaction.options.getUser('user');
  const role = interaction.options.getRole('role');
  if ((user && role) || (!user && !role)) throw new AppError('Choose either a user **or** a role.');
  return user ? { id: user.id, type: 'user', label: `<@${user.id}>` } : { id: role.id, type: 'role', label: `<@&${role.id}>` };
}
const withTarget = (s) => s.addUserOption((o) => o.setName('user').setDescription('User')).addRoleOption((o) => o.setName('role').setDescription('Role'));

module.exports = {
  category: 'Permit Commands',
  userPermissions: [P.Administrator],
  data: newCommand('permit', 'Exempt trusted users/roles from anti-spam, AutoMod, anti-raid and anti-nuke', P.Administrator)
    .addSubcommand((s) => withTarget(s.setName('add').setDescription('Permit a user or role').addStringOption((o) => scopeOpt(o, true))))
    .addSubcommand((s) => withTarget(s.setName('remove').setDescription('Remove a permit').addStringOption((o) => scopeOpt(o, false))))
    .addSubcommand((s) => s.setName('list').setDescription('Show everyone who is permitted')),
  execute: (i) => dispatch(i, {
    async add(interaction) {
      const t = target(interaction);
      if (t.type === 'role' && t.id === interaction.guildId) throw new AppError('You cannot permit @everyone.');
      const scope = interaction.options.getString('scope', true);
      const added = await permit.add(interaction.guildId, t.id, t.type, scope, interaction.user.id);
      if (!added) throw new AppError('That permit already exists.');
      await logging.logConfigChange(interaction.guildId, 'permit', interaction.user.id, `Permitted ${t.label} for **${scope}**`);
      return ok(interaction, `${t.label} is now permitted for **${scope}**.`);
    },
    async remove(interaction) {
      const t = target(interaction);
      const n = await permit.remove(interaction.guildId, t.id, interaction.options.getString('scope'));
      if (!n) throw new AppError('No matching permit found.');
      await logging.logConfigChange(interaction.guildId, 'permit', interaction.user.id, `Removed permit for ${t.label}`);
      return ok(interaction, `Removed ${n} permit(s) for ${t.label}.`);
    },
    async list(interaction) {
      const rows = await permit.list(interaction.guildId);
      return respond(interaction, { embeds: [makeEmbed({
        title: '🔑 Permits', timestamp: false,
        description: rows.length ? rows.slice(0, 40).map((r) => `${r.target_type === 'user' ? `<@${r.target_id}>` : `<@&${r.target_id}>`} → **${r.scope}** (${discordTime(Number(r.created_at), 'd')})`).join('\n') : 'Nobody is permitted.',
      })] });
    },
  }),
};
