'use strict';
const { PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { newCommand } = require('../../utils/builder');
const config = require('../../services/guildConfig');
const { AppError } = require('../../utils/errors');
const { dispatch, parseList } = require('../../utils/dispatch');
const { patchConfig, toggleInList } = require('../../utils/optionsPatch');
const { makeEmbed } = require('../../utils/embeds');
const { ok, respond } = require('../../utils/reply');

const RULES = ['words', 'mentions', 'links', 'invites', 'repeated', 'caps'];
const LIMIT_PATH = { mentions: 'limit', links: 'limit', repeated: 'maxChars', caps: 'percent' };
const ACTIONS = [
  { name: 'Delete message', value: 'delete' }, { name: 'Warn user', value: 'warn' }, { name: 'Timeout user', value: 'timeout' },
  { name: 'Delete + warn', value: 'delete+warn' }, { name: 'Delete + timeout', value: 'delete+timeout' },
];
const targetOpts = (s) => s
  .addChannelOption((o) => o.setName('channel').setDescription('Channel').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildVoice, ChannelType.GuildForum, ChannelType.GuildCategory))
  .addRoleOption((o) => o.setName('role').setDescription('Role'))
  .addUserOption((o) => o.setName('user').setDescription('User'));

module.exports = {
  category: 'Automod',
  userPermissions: [P.ManageGuild],
  data: newCommand('automod', 'Configure AutoMod (banned words, links, invites, mentions…)', P.ManageGuild)
    .addSubcommand((s) => s.setName('setup').setDescription('Enable AutoMod with a sensible starter configuration')
      .addChannelOption((o) => o.setName('log-channel').setDescription('Send AutoMod logs here').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)))
    .addSubcommand((s) => s.setName('status').setDescription('Show AutoMod settings'))
    .addSubcommand((s) => s.setName('disable').setDescription('Turn AutoMod off'))
    .addSubcommand((s) => s.setName('config').setDescription('General AutoMod settings')
      .addIntegerOption((o) => o.setName('timeout-seconds').setDescription('Timeout length for timeout actions').setMinValue(10).setMaxValue(2_419_200))
      .addBooleanOption((o) => o.setName('exempt-staff').setDescription('Ignore Admin / Manage Server / Manage Messages members')))
    .addSubcommand((s) => s.setName('rule').setDescription('Enable/disable a rule or change its action and limit')
      .addStringOption((o) => o.setName('rule').setDescription('Rule').setRequired(true).addChoices(...RULES.map((r) => ({ name: r, value: r }))))
      .addBooleanOption((o) => o.setName('enabled').setDescription('Turn the rule on or off'))
      .addStringOption((o) => o.setName('action').setDescription('What to do on a violation').addChoices(...ACTIONS))
      .addIntegerOption((o) => o.setName('limit').setDescription('Mentions/links allowed, repeated chars, or caps percent').setMinValue(1).setMaxValue(100)))
    .addSubcommandGroup((g) => g.setName('words').setDescription('Manage banned words and phrases')
      .addSubcommand((s) => s.setName('add').setDescription('Add banned words').addStringOption((o) => o.setName('words').setDescription('Comma-separated words/phrases').setRequired(true).setMaxLength(500)))
      .addSubcommand((s) => s.setName('remove').setDescription('Remove banned words').addStringOption((o) => o.setName('words').setDescription('Comma-separated words/phrases').setRequired(true).setMaxLength(500)))
      .addSubcommand((s) => s.setName('list').setDescription('Show the banned words (privately)')))
    .addSubcommandGroup((g) => g.setName('whitelist').setDescription('Exempt channels, roles and users')
      .addSubcommand((s) => targetOpts(s.setName('add').setDescription('Add to the whitelist')))
      .addSubcommand((s) => targetOpts(s.setName('remove').setDescription('Remove from the whitelist')))
      .addSubcommand((s) => s.setName('list').setDescription('Show the whitelist')))
    .addSubcommandGroup((g) => g.setName('domains').setDescription('Allowed link domains')
      .addSubcommand((s) => s.setName('add').setDescription('Allow links to a domain').addStringOption((o) => o.setName('domain').setDescription('e.g. youtube.com').setRequired(true).setMaxLength(100)))
      .addSubcommand((s) => s.setName('remove').setDescription('Stop allowing a domain').addStringOption((o) => o.setName('domain').setDescription('Domain').setRequired(true).setMaxLength(100)))),
  execute: (i) => dispatch(i, {
    async setup(interaction) {
      const log = interaction.options.getChannel('log-channel');
      await config.update(interaction.guildId, 'automod', (c) => {
        c.enabled = true;
        for (const r of ['invites', 'mentions', 'links', 'repeated']) c.rules[r].enabled = true;
      }, { actorId: interaction.user.id, summary: 'AutoMod enabled (starter rules: invites, mentions, links, repeated)' });
      if (log) await config.update(interaction.guildId, 'logging', (c) => { c.enabled = true; c.channels.automod = log.id; });
      return ok(interaction, `AutoMod is **on** with starter rules (invites, excessive mentions, excessive links, repeated characters).${log ? ` Logs → <#${log.id}>.` : ' Set a log channel with `/logging config category:automod`.'}\nAdd banned words with \`/automod words add\` and tune rules with \`/automod rule\`.`);
    },
    async status(interaction) {
      const c = await config.get(interaction.guildId, 'automod');
      const lines = RULES.map((r) => { const x = c.rules[r]; return `${x.enabled ? '✅' : '⚪'} **${r}** — ${x.action}${LIMIT_PATH[r] ? ` (limit ${x[LIMIT_PATH[r]]})` : ''}${r === 'words' ? ` — ${x.list.length} word(s)` : ''}`; });
      return respond(interaction, { embeds: [makeEmbed({
        title: `🤖 AutoMod ${c.enabled ? '(on)' : '(off)'}`, timestamp: false, description: lines.join('\n'),
        fields: [{ name: 'Timeout length', value: `${c.timeoutSec}s`, inline: true }, { name: 'Exempt staff', value: c.exemptStaff ? 'Yes' : 'No', inline: true }],
      })] });
    },
    async disable(interaction) {
      await config.update(interaction.guildId, 'automod', (c) => { c.enabled = false; }, { actorId: interaction.user.id, summary: 'AutoMod disabled' });
      return ok(interaction, 'AutoMod disabled. Your rules are kept.');
    },
    async config(interaction) {
      const s = await patchConfig(interaction, 'automod', [
        { name: 'timeout-seconds', type: 'integer', path: 'timeoutSec', label: 'Timeout (s)' },
        { name: 'exempt-staff', type: 'boolean', path: 'exemptStaff', label: 'Exempt staff' },
      ]);
      return ok(interaction, `AutoMod updated:\n${s}`);
    },
    async rule(interaction) {
      const rule = interaction.options.getString('rule', true);
      const enabled = interaction.options.getBoolean('enabled');
      const action = interaction.options.getString('action');
      const limit = interaction.options.getInteger('limit');
      if (enabled === null && !action && limit === null) throw new AppError('Provide `enabled`, `action` or `limit`.');
      if (limit !== null && !LIMIT_PATH[rule]) throw new AppError(`The **${rule}** rule has no numeric limit.`);
      await config.update(interaction.guildId, 'automod', (c) => {
        const r = c.rules[rule];
        if (enabled !== null) r.enabled = enabled;
        if (action) r.action = action;
        if (limit !== null) r[LIMIT_PATH[rule]] = limit;
      }, { actorId: interaction.user.id, summary: `AutoMod rule "${rule}" updated` });
      return ok(interaction, `Rule **${rule}** updated.`);
    },
    async 'words.add'(interaction) {
      const words = parseList(interaction.options.getString('words', true), { max: 50, maxLength: 50 });
      if (!words.length) throw new AppError('No valid words supplied.');
      let added = 0;
      await config.update(interaction.guildId, 'automod', (c) => {
        for (const w of words) if (!c.rules.words.list.includes(w)) { if (c.rules.words.list.length >= 200) throw new AppError('The banned word list is full (200).'); c.rules.words.list.push(w); added += 1; }
        c.rules.words.enabled = true;
      }, { actorId: interaction.user.id, summary: `${words.length} banned word(s) added (list hidden)` });
      return ok(interaction, `Added **${added}** banned word(s) and enabled the word filter.`);
    },
    async 'words.remove'(interaction) {
      const words = new Set(parseList(interaction.options.getString('words', true), { max: 50, maxLength: 50 }));
      let removed = 0;
      await config.update(interaction.guildId, 'automod', (c) => { const before = c.rules.words.list.length; c.rules.words.list = c.rules.words.list.filter((w) => !words.has(w)); removed = before - c.rules.words.list.length; }, { actorId: interaction.user.id, summary: 'Banned words removed (list hidden)' });
      return ok(interaction, `Removed **${removed}** word(s).`);
    },
    async 'words.list'(interaction) {
      const c = await config.get(interaction.guildId, 'automod');
      return respond(interaction, c.rules.words.list.length ? `🤐 Banned words (${c.rules.words.list.length}):\n||${c.rules.words.list.join(', ').slice(0, 1800)}||` : 'ℹ️ No banned words configured.');
    },
    async 'whitelist.add'(interaction) { return editWhitelist(interaction, true); },
    async 'whitelist.remove'(interaction) { return editWhitelist(interaction, false); },
    async 'whitelist.list'(interaction) {
      const c = await config.get(interaction.guildId, 'automod');
      const f = (a, fn) => (a.length ? a.map(fn).join(' ') : 'None');
      return respond(interaction, { embeds: [makeEmbed({ title: 'AutoMod whitelist', timestamp: false, description: `**Channels:** ${f(c.ignoredChannels, (x) => `<#${x}>`)}\n**Roles:** ${f(c.ignoredRoles, (x) => `<@&${x}>`)}\n**Users:** ${f(c.ignoredUsers, (x) => `<@${x}>`)}` })] });
    },
    async 'domains.add'(interaction) {
      const domain = cleanDomain(interaction.options.getString('domain', true));
      await config.update(interaction.guildId, 'automod', (c) => { if (!c.rules.links.allowedDomains.includes(domain)) { if (c.rules.links.allowedDomains.length >= 50) throw new AppError('Domain list is full.'); c.rules.links.allowedDomains.push(domain); } }, { actorId: interaction.user.id, summary: `Allowed domain ${domain}` });
      return ok(interaction, `Links to **${domain}** are now allowed.`);
    },
    async 'domains.remove'(interaction) {
      const domain = cleanDomain(interaction.options.getString('domain', true));
      await config.update(interaction.guildId, 'automod', (c) => { c.rules.links.allowedDomains = c.rules.links.allowedDomains.filter((d) => d !== domain); }, { actorId: interaction.user.id, summary: `Removed allowed domain ${domain}` });
      return ok(interaction, `**${domain}** removed from the allowed list.`);
    },
  }),
};

function cleanDomain(input) {
  const d = input.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
  if (!/^[a-z0-9.-]{3,100}$/.test(d) || !d.includes('.')) throw new AppError('Enter a domain like `example.com`.');
  return d;
}

async function editWhitelist(interaction, add) {
  const pairs = [['channel', 'ignoredChannels'], ['role', 'ignoredRoles'], ['user', 'ignoredUsers']]
    .map(([opt, path]) => [interaction.options.get(opt)?.value, path]).filter(([v]) => v);
  if (!pairs.length) throw new AppError('Choose a channel, role or user.');
  for (const [id, path] of pairs) await toggleInList(interaction.guildId, 'automod', path, id, add, { actorId: interaction.user.id, summary: `AutoMod whitelist ${add ? 'add' : 'remove'}: ${id}` });
  return ok(interaction, `${add ? 'Added to' : 'Removed from'} the AutoMod whitelist.`);
}
