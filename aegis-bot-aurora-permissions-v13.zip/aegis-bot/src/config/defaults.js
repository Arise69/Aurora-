'use strict';
/**
 * Default per-guild configuration. Each top-level key is a "module" stored as one JSON document
 * in guild_settings (guild_id, module). Stored values are deep-merged over these defaults, so new
 * options can be added later without a database migration.
 */
const env = require('./env');

module.exports = {
  general: () => ({ prefix: env.defaultPrefix, dmNotify: true }),

  logging: () => ({
    enabled: true,
    defaultChannelId: null,
    channels: {},          // category -> channelId (overrides default)
    disabled: [],          // categories switched off
  }),

  antispam: () => ({
    enabled: true,
    messageLimit: 6,        // messages within intervalSec => flood
    intervalSec: 5,
    duplicateLimit: 4,      // identical messages within duplicateWindowSec
    duplicateWindowSec: 30,
    strikeResetMin: 10,     // strikes decay after this long without a violation
    timeoutSteps: [300, 3600], // seconds: strike 2, strike 3+ (strike 1 = warning)
    cooldownSec: 10,        // after a punishment, extra spam is only deleted (no re-escalation)
    deleteMessages: true,
    recordWarning: true,    // strike 1 is stored as a real warning
    exemptStaff: true,      // Administrator / Manage Messages / Manage Server bypass
    ignoredChannels: [], ignoredRoles: [], ignoredUsers: [], ignoredCommands: [], ignoredBypassUsers: [],
  }),

  antiraid: () => ({
    enabled: true,
    joinThreshold: 10,
    joinWindowSec: 10,
    autoLockdown: false,
    lockdownDurationMin: 15, // 1..1440
    newAccountAgeHours: 72,  // accounts younger than this are "suspicious" during lockdown
    newAccountAction: 'timeout', // timeout | kick | none
    lockChannels: false,     // also deny @everyone SendMessages while locked
    excludedChannels: [],
    alertRoleId: null,
  }),

  antinuke: () => ({
    enabled: false,
    windowSec: 30,
    limits: {
      channelCreate: 3, channelDelete: 3, channelUpdate: 3,
      roleCreate: 3, roleDelete: 3, roleUpdate: 2, rolePosition: 1,
      ban: 3, kick: 3, botAdd: 1,
      webhookCreate: 2, webhookDelete: 2, webhookUpdate: 2,
      guildUpdate: 1, integration: 1, prune: 1, vanityUpdate: 1, onboardingSafeguard: 1, linkroleProtection: 1, inviteRoleProtection: 1, mainroleProtection: 1, emojiDelete: 3, stickerDelete: 3,
      memberRoleUpdate: 2, permissionEscalation: 1,
    },
    // Separate thresholds used when betrayal guard monitors a normally trusted/whitelisted actor.
    betrayalLimits: {
      channelCreate: 4, channelDelete: 2, channelUpdate: 4,
      roleCreate: 3, roleDelete: 2, roleUpdate: 2, rolePosition: 1,
      ban: 2, kick: 2, botAdd: 1,
      webhookCreate: 2, webhookDelete: 2, webhookUpdate: 2,
      guildUpdate: 1, integration: 1, prune: 1, vanityUpdate: 1, onboardingSafeguard: 1, linkroleProtection: 1, inviteRoleProtection: 1, mainroleProtection: 1, emojiDelete: 2, stickerDelete: 2,
      memberRoleUpdate: 1, permissionEscalation: 1,
    },
    modules: {
      channelCreate: true, channelDelete: true, channelUpdate: true,
      roleCreate: true, roleDelete: true, roleUpdate: true, rolePosition: true,
      ban: true, kick: true, botAdd: true,
      webhookCreate: true, webhookDelete: true, webhookUpdate: true,
      guildUpdate: true, integration: true, prune: true, vanityUpdate: true, onboardingSafeguard: true, linkroleProtection: true, inviteRoleProtection: true, mainroleProtection: true, emojiDelete: true, stickerDelete: true,
      memberRoleUpdate: true, permissionEscalation: true, mentionSpam: true,
    },
    punishment: 'strip',
    ownerOnly: false,
    betrayalGuard: true,
    autoRecovery: false,
    recovery: { channels: true, roles: true },
    loggingChannelId: null,
    // Per-user, per-filter whitelist. Legacy string-array entries are still accepted as all-filter trust.
    whitelist: {},
  }),

  security: () => ({
    mainroleId: null,
    quarantineRoleId: null,
    barrierRoleId: null,
  }),

  profile: () => ({
    bios: {},
    badges: {},
    branding: {},
  }),

  automod: () => ({
    enabled: false,
    exemptStaff: true,
    ignoredChannels: [], ignoredRoles: [], ignoredUsers: [], ignoredCommands: [], ignoredBypassUsers: [],
    timeoutSec: 600,                 // length of the "Auto Mute"
    heatDecayPerSec: 1,              // a user's heat cools down by this much every second
    whitelist: {},                   // ruleKey -> { users: [], roles: [], channels: [] }  (managed with `.automod whitelist`)
    // Every violation deletes the message and adds `heat` (x the units: mentions, emojis, ...) to the user's heat meter;
    // reaching 100 triggers the Auto Mute.
    rules: {
      words:    { enabled: false, list: [], action: 'delete', heat: 100 },
      mentions: { enabled: false, limit: 5, action: 'delete', heat: 20 },
      links:    { enabled: false, limit: 3, allowedDomains: [], action: 'delete', heat: 100 },
      invites:  { enabled: false, allowOwnServer: true, action: 'delete', heat: 100 },
      repeated: { enabled: false, maxChars: 12, maxWords: 8, action: 'delete', heat: 20 },
      caps:     { enabled: false, percent: 75, minLength: 20, action: 'delete', heat: 0.12 },   // per capital letter
      spam:        { enabled: false, limit: 6, intervalSec: 5, action: 'delete', heat: 15 },   // messages from one user within the interval
      emojis:      { enabled: false, limit: 10, action: 'delete', heat: 12 },                  // per emoji
      nsfw:        { enabled: false, extraDomains: [], action: 'delete', heat: 100 },          // + built-in adult-site list (fixed at 100)
      attachments: { enabled: false, limit: 4, action: 'delete', heat: 20 },                   // per attachment
      zalgo:       { enabled: false, maxStack: 5, action: 'delete', heat: 1.5 },               // per combining mark
      similar:     { enabled: false, limit: 3, windowSec: 30, similarity: 0.85, action: 'delete', heat: 22 },
      charlimit:   { enabled: false, maxChars: 1200, action: 'delete', heat: 0.08 },           // per character
      newlines:    { enabled: false, limit: 10, action: 'delete', heat: 5 },                   // per line break
    },
  }),

  warnings: () => ({
    thresholds: [
      { count: 3, action: 'timeout', durationSec: 3600 },
      { count: 5, action: 'kick', durationSec: 0 },
    ],
  }),

  verification: () => ({
    enabled: false,
    channelId: null,
    messageId: null,
    roleId: null,            // granted on success
    unverifiedRoleId: null,  // optional: given on join, removed on success
    mode: 'button',          // button | code
    minAccountAgeHours: 0,
    maxAttempts: 5,
    lockoutMin: 10,
    title: 'Verification',
    description: 'Press the button below to verify and gain access to the server.',
  }),

  giveaways: () => ({ defaultChannelId: null, pingRoleId: null, dmWinners: true, maxActive: 25 }),

  tickets: () => ({
    enabled: false, categoryId: null, logChannelId: null, supportRoleIds: [],
    maxOpenPerUser: 1, types: ['Support'], panelChannelId: null, dmTranscript: true,
  }),

  greetings: () => ({
    welcome: { enabled: false, channelId: null, message: 'Welcome {user} to **{server}**! You are member #{count}.', embed: true, deleteAfterSec: 0, dm: false },
    leave:   { enabled: false, channelId: null, message: '**{user.name}** has left **{server}**.', embed: true, deleteAfterSec: 0, dm: false },
    boost:   { enabled: false, channelId: null, message: '💜 Thank you {user} for boosting **{server}**!', embed: true, deleteAfterSec: 0, dm: false },
  }),

  autorole: () => ({ humanRoleIds: [], botRoleIds: [] }),
  automation: () => ({ autopublishChannelIds: [] }),

  vanity: () => ({ enabled: false, keyword: null, roleId: null, channelId: null, message: '{user} is repping **{keyword}** — thanks for the support! 💖' }),

  customroles: () => ({
    enabled: false, requiredRoleId: null, boostersOnly: false, baseRoleId: null,
    maxNameLength: 32, blockedNames: ['admin', 'administrator', 'moderator', 'mod', 'staff', 'owner', 'everyone', 'here'],
  }),

  voicemaster: () => ({ enabled: false, creatorChannelId: null, categoryId: null, nameTemplate: "{user}'s channel", defaultLimit: 0 }),

  permissions: () => ({
    roles: {}, // roleId -> { permissions: [fake permission names], createdBy, updatedAt }
  }),

  music: () => ({ djRoleId: null, maxQueue: 100, maxTrackMinutes: 30 }),
};
