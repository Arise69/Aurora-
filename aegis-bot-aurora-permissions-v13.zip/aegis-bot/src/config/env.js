'use strict';
require('dotenv').config({ quiet: true });

const bool = (v, d = false) =>
  v === undefined || v === null || v === '' ? d : ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());
const list = (v) => (v ? String(v).split(',').map((s) => s.trim()).filter(Boolean) : []);

const env = {
  get nodeEnv() { return process.env.NODE_ENV || 'production'; },
  get token() { return (process.env.DISCORD_TOKEN || '').trim(); },
  get clientId() { return (process.env.CLIENT_ID || '').trim(); },
  get devGuildId() { return (process.env.DEV_GUILD_ID || '').trim() || null; },
  get databaseUrl() { return (process.env.DATABASE_URL || 'sqlite:./data/aegis.db').trim(); },
  get encryptionKey() { return (process.env.ENCRYPTION_KEY || '').trim(); },
  get allowExternalWebhooks() { return bool(process.env.ALLOW_EXTERNAL_WEBHOOKS, false); },
  get defaultPrefix() { const raw = String(process.env.DEFAULT_PREFIX ?? '').trim(); return (!raw || raw === ',') ? '.' : raw.slice(0, 5); },
  get ownerIds() { return list(process.env.OWNER_IDS); },
  get intents() {
    return {
      members: bool(process.env.ENABLE_GUILD_MEMBERS, true),
      messageContent: bool(process.env.ENABLE_MESSAGE_CONTENT, true),
      presences: bool(process.env.ENABLE_PRESENCES, false),
    };
  },
  get autoDeploy() { return bool(process.env.AUTO_DEPLOY_COMMANDS, false); },
  get musicEnabled() { return bool(process.env.ENABLE_MUSIC, true); },

  /** Throws a readable error if required variables are missing. */
  validate({ needToken = true, needClientId = false } = {}) {
    const missing = [];
    if (needToken && !this.token) missing.push('DISCORD_TOKEN');
    if (needClientId && !this.clientId) missing.push('CLIENT_ID');
    if (missing.length) {
      throw new Error(`Missing required environment variable(s): ${missing.join(', ')}. Copy .env.example to .env and fill them in.`);
    }
  },
};

module.exports = env;
