'use strict';
const { PermissionFlagsBits: P } = require('discord.js');

const COLORS = {
  primary: 0x5865f2, success: 0x57f287, error: 0xed4245, warning: 0xfee75c,
  info: 0x3498db, mod: 0xe67e22, security: 0xe74c3c, neutral: 0x2b2d31, gold: 0xf1c40f,
};

const LOG_CATEGORIES = {
  messages: 'Message deletes, edits & bulk deletes',
  members: 'Member joins & leaves',
  moderation: 'Bans, kicks, timeouts & warnings',
  roles: 'Role creation, changes & member role updates',
  channels: 'Channel creation, changes & deletion',
  server: 'Server & bot setting changes',
  giveaways: 'Giveaway creation, completion & rerolls',
  security: 'Anti-spam, anti-raid & anti-nuke events',
  automod: 'AutoMod actions',
  verification: 'Verification events',
  tickets: 'Ticket events & transcripts',
  voice: 'Voice channel activity',
};

// Roles carrying any of these are never handed out automatically (autorole, vanity, verification, custom roles).
const DANGEROUS_PERMISSIONS = [
  P.Administrator, P.ManageGuild, P.ManageRoles, P.ManageChannels, P.BanMembers, P.KickMembers,
  P.ModerateMembers, P.ManageWebhooks, P.ManageMessages, P.MentionEveryone, P.ManageNicknames,
];

const LIMITS = {
  maxTimeoutMs: 28 * 24 * 60 * 60 * 1000,
  reasonLength: 500,
  maxGiveawayMs: 60 * 24 * 60 * 60 * 1000,
  minGiveawayMs: 10 * 1000,
};

module.exports = { COLORS, LOG_CATEGORIES, DANGEROUS_PERMISSIONS, LIMITS };
