# Aegis — moderation, security, verification, logging, webhooks, giveaways & community bot

A modular, production-oriented Discord bot built on **Node.js ≥ 20** and **discord.js v14** (slash commands + an optional prefix layer).
It covers every category of the reference help menu — *Security, Permit, AutoMod, Moderation, General, Verification, Utility, Automations,
Autoresponders, Vanity & Tags, Greetings, Music, Fun, CustomRole, Voice Commands, Tickets, Logging, Voice Master, Bot Settings* — plus
**Giveaways** and **Webhooks**. All configuration is stored **per server** in a database; nothing is hard-coded.

```
46 top-level slash commands · 133 subcommands · 21 help categories · SQLite by default, PostgreSQL-ready
```

---

## 1. Quick start

```bash
# 1. Install (Node 20+; Node 22.5+ needs no native build tools)
npm install

# 2. Configure
cp .env.example .env        # then fill DISCORD_TOKEN, CLIENT_ID, ENCRYPTION_KEY
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"   # -> ENCRYPTION_KEY

# 3. Register slash commands (DEV_GUILD_ID in .env = instant, single server; empty = global, up to ~1 h)
npm run deploy

# 4. Run
npm start                   # or: npm run pm2:start
```

### Discord Developer Portal checklist
1. **New Application** → copy the **Application ID** into `CLIENT_ID`.
2. **Bot** tab → **Reset Token** → copy into `DISCORD_TOKEN` (never share/commit it).
3. **Bot → Privileged Gateway Intents** — enable what you use (must match `.env`):
   | Intent | Needed for | `.env` switch |
   |---|---|---|
   | **Server Members** | joins/leaves, anti-raid, autorole, greetings, member logs | `ENABLE_GUILD_MEMBERS` |
   | **Message Content** | anti-spam, AutoMod, autoresponders, prefix commands | `ENABLE_MESSAGE_CONTENT` |
   | **Presence** | *only* the Vanity-role feature | `ENABLE_PRESENCES` (default off) |

   Non-privileged intents used automatically: Guilds, Guild Moderation (audit-log events), Guild Messages, Guild Voice States.
   If you disable an intent in `.env` the related features degrade gracefully (a warning is logged at startup).
4. Turn **Public Bot** off if the bot is private.
5. **Invite URL** (scopes `bot applications.commands`, permissions `1099812695254`):
   ```
   https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot%20applications.commands&permissions=1099812695254
   ```
   That integer = View Channel, Send Messages, Embed Links, Attach Files, Read History, Add Reactions, Manage Messages, Manage Channels, Manage Roles,
   Kick, Ban, Moderate Members (timeouts), View Audit Log, Connect, Speak, Mute/Deafen/Move Members. **Do not grant Administrator.**
6. **Role position matters:** drag the bot's role *above* every role it must manage (verified role, autoroles, custom-role base role, members it moderates).

---

## 2. Architecture

```
src/
├── index.js                 # client, intents, cache limits, graceful shutdown, global error hooks
├── config/    env.js · constants.js · defaults.js        # env vars, colors/limits, per-guild default config
├── database/  index.js · schema.js · drivers/{sqlite,postgres}.js   # async get/all/run/exec + versioned migrations
├── middleware/guard.js      # rate-limits, permission checks (user + bot), unified error handling
├── events/    ready · interactionCreate · messageCreate · members · voice · logging · client
├── services/  (all business logic)
│   guildConfig · logging · webhooks · moderation · exemptions · permit
│   antispam · automod · antiraid · antinuke
│   verification · giveaways · tickets · voicemaster · customroles · greetings
│   autoresponder · tags · vanity · utility · music · channelTools · help · scheduler
├── commands/  <category>/<command>.js     # thin slash-command layer (validation + reply)
├── prefix/    index.js + general/moderation/music/utility/fun     # optional text-prefix layer
└── utils/     embeds · reply · permissions · duration · crypto · netsafe · template · ids · errors · logger · …
scripts/       deploy-commands.js · migrate.js       tests/   node:test suite       ecosystem.config.js   PM2
```

**Design rules**
* *Commands are thin, services are thick.* Slash commands and prefix commands call the same service (`moderation.warn`, `antiraid.startLockdown`, …), so behaviour and logging are identical everywhere.
* *Event order is explicit.* `messageCreate` runs anti-spam → AutoMod → AFK/auto-publish → prefix commands → autoresponders → sticky; a message that was punished stops the chain.
* *One scheduler.* A single 5-second loop handles giveaways (start/end), reminders, scheduled posts, temp-bans and lockdown expiry — all **DB-driven**, so nothing is lost on restart and overdue items are processed immediately after downtime.
* *Errors:* `AppError` = safe user-facing message; Discord API codes are mapped to friendly text; anything else is logged with a reference id (`ref: 7K2M9Q`) and the user only sees the reference. Every event handler is wrapped, so one failure never kills the process.
* *Config:* each module is one JSON document per guild (`guild_settings`), deep-merged over `config/defaults.js`, cached in memory, updated through a serialised read-modify-write, and every change is audit-logged to the `server` log category.

## 3. Database schema (`src/database/schema.js`)

Portable SQL (TEXT snowflake IDs, BIGINT epoch-ms timestamps, no AUTOINCREMENT, `ON CONFLICT` upserts) so the same migrations run on SQLite and PostgreSQL.

| Table | Purpose |
|---|---|
| `guild_settings (guild_id, module, data JSON)` | **All per-guild config**: general/prefix, logging, antispam, antiraid, antinuke, automod, warning thresholds, verification, giveaways defaults, tickets, greetings, autorole, vanity, customroles, voicemaster, music |
| `warnings (id, guild_id, user_id, moderator_id, reason, created_at)` | Warning records with unique short IDs |
| `giveaways` / `giveaway_entries` | Giveaway definition + status (`scheduled/active/ended/cancelled`) / one row per (giveaway,user) — PK prevents duplicate entries |
| `verification_attempts` | Failure counts + lockouts (abuse prevention) |
| `webhooks` | Webhook targets — **URL and secret AES-256-GCM encrypted** |
| `permits` | Users/roles exempt from anti-spam / AutoMod / anti-raid / anti-nuke |
| `autoresponders`, `tags`, `afk`, `reminders`, `scheduled_messages`, `sticky_messages` | Community features |
| `tickets`, `counters` | Ticket records; atomic per-guild ticket numbers |
| `voice_channels`, `custom_roles` | Voice Master temp channels; member → custom-role mapping |
| `lockdowns` | Active lockdown incl. **previous channel-overwrite state** and restricted users (crash-safe recovery) |
| `temp_bans`, `schema_migrations` | Timed unbans; applied migrations |

**Upgrade to PostgreSQL:** `npm i pg`, set `DATABASE_URL=postgres://user:pass@host:5432/db`, `npm run migrate`. (To move existing SQLite data, export/import per table; schema is identical.)
SQLite driver: uses `better-sqlite3` when it installs, otherwise falls back to Node's built-in `node:sqlite` (Node ≥ 22.5), so cheap hosts without compilers still work.

## 4. Security model

| Concern | Control |
|---|---|
| Secrets | Only via environment variables. Logger **redacts** bot tokens, webhook URLs and env secrets from every line, including stack traces. No command ever prints config values. |
| Webhook URLs | Entered through a **private modal** (not a slash option), validated (`discord.com/api/webhooks/…` only; external HTTPS endpoints are opt-in and SSRF-checked), encrypted at rest, never displayed or logged, auto-disabled after 10 consecutive failures, external payloads HMAC-signed (`X-Aegis-Signature`). |
| Command authorisation | Default member permissions **and** runtime checks (`userPermissions`) **and** bot-permission checks before every action. Sensitive config (webhooks, anti-nuke, permit) requires **Administrator**. |
| Hierarchy | `hierarchyProblem()` blocks self-moderation, moderating the owner/bot, equal-or-higher roles (for the moderator **and** the bot). Automated actions apply the bot-side check. Role assignment refuses roles with dangerous permissions (`assertAssignableRole`). |
| Abuse / spam of commands | Per-command cooldown + global burst limit (8 actions/10 s); component (button) rate limit; verification cooldown, attempt limit and lockout; ticket creation cooldown + per-user cap. |
| Input safety | Length/regex validation on every option; parameterised SQL only; user text never interpolated into SQL/regex (banned words are escaped literals → no ReDoS); `allowedMentions` defaults to *none* so users cannot make the bot ping `@everyone`; reasons are stripped of control characters; `escapeText` on echoed user content. |
| Data minimisation | Stores only Discord IDs and moderation content. No passwords, tokens, e-mails or other personal data are requested. |
| Anti-nuke | Audit-log driven, off by default, owner/bot/permitted users exempt. |

## 5. How the major features work

* **Anti-spam** — sliding-window flood detection (default 6 msgs/5 s) + identical-message detection (4× in 30 s, ignores messages < 4 chars so "lol" isn't spam). Escalation per user: strike 1 warning (recorded), strike 2 timeout 5 m, strike 3+ timeout 1 h; strikes decay after 10 min; a post-punishment cooldown only *deletes* burst leftovers instead of re-escalating. Staff (Manage Messages/Server/Admin), ignored channels/roles/users and permitted users bypass. Every detection is logged (`security`).
* **Anti-raid** — join-rate threshold (default 10 joins/10 s). Optional auto-lockdown; during lockdown accounts younger than N hours are timed out (released when lockdown ends) or kicked; optional `@everyone` send-lock on channels. **Lock-out protection:** only `@everyone`'s Send Messages is touched (never View/Use Commands), staff roles with explicit allows and Admins are unaffected, previous overwrites are stored and restored exactly, lockdowns always expire (1 min – 24 h), expired ones are reconciled at startup, `/raid unlock` always works, and the DB row is removed *before* restoring so a partial failure can never leave the server "stuck".
* **AutoMod** — banned words/phrases (whole-word match), mentions, links (with allowed domains), invites (own-server invites optionally allowed), repeated characters/words, caps. Actions per rule: delete, warn, timeout, delete+warn, delete+timeout. Whitelists for channels/roles/users. Logged to `automod`.
* **Warnings** — `/warn /warnings /clearwarnings /removewarning`, unique IDs, exact-count thresholds (`/warnsettings`, default 3 → 1 h timeout, 5 → kick). All actions logged; all require Moderate Members.
* **Verification** — button or short-code (modal) mode, optional unverified role, account-age gate, attempt limit + lockout, panel re-posting, full audit trail (`verification` logs).
* **Giveaways** — start/end/reroll/cancel/list/config with autocomplete; required role, excluded roles, min account age, min server time, host, multiple winners, scheduled start (`start-in`), live entry count (debounced to 1 edit/7 s), duplicate-proof entry (DB primary key), leave button, **winners are re-validated at draw time** (left the server / lost the role ⇒ skipped and replaced), atomic end (a giveaway can never finish twice), reroll excludes previous winners, DM winners, restart-safe.
* **Logging** — 12 categories, each routable to its own channel or disabled: messages, members, moderation, roles, channels, server (Discord *and* bot setting changes), giveaways, security, automod, verification, tickets, voice. Bans/kicks/timeouts/role changes come from the **audit-log event stream** (so manual Discord actions are captured with the executor and reason; the bot's own actions are logged once by the service).
* **Webhooks** — subscribe a webhook to any log category (`moderation`, `security` = spam/raid/nuke alerts, `giveaways`, …).
* **Tickets** — panel buttons per type, private channels, support roles, claim/add/remove, close-with-confirm, `.txt` transcript to the log channel (+ optional DM), atomic ticket numbers.
* **Voice Master** — join-to-create channels with owner commands (lock/hide/limit/rename/permit/reject/claim/transfer), auto-deleted when empty, reconciled on startup, rename rate-limit guard.
* **Music** *(optional)* — direct audio URLs (SSRF-checked) and, if `play-dl` is installed, YouTube search/links; queue, loop, shuffle, DJ role, auto-leave. See the caveat below.

### ZEON-style category → command map
| Category | Commands |
|---|---|
| Security | `/antispam` `/raid` `/antinuke` |
| Permit Commands | `/permit add\|remove\|list` |
| Automod | `/automod setup\|status\|disable\|config\|rule\|words\|whitelist\|domains` |
| Moderation | `/warn /warnings /clearwarnings /removewarning /warnsettings /kick /ban /unban /timeout /untimeout /purge /slowmode /lock /unlock` |
| General | `/help /ping /botinfo /serverinfo /userinfo /avatar` |
| Verification | `/verification setup\|status\|disable` |
| Utility | `/remind /afk /poll /say` |
| Automations | `/automation autorole\|schedule\|sticky\|autopublish` |
| Autoresponders | `/autoresponder add\|remove\|list` |
| Vanity & Tags | `/vanity …` `/tag show\|create\|edit\|delete\|info\|list` |
| Greetings | `/greetings welcome\|leave\|boost\|test\|variables\|status` |
| Music | `/play` `/music skip\|stop\|pause\|resume\|queue\|nowplaying\|loop\|shuffle\|remove\|config` |
| Fun Commands | `/fun 8ball\|coinflip\|roll\|rps\|choose\|ship\|rate\|reverse\|hug` |
| CustomRole | `/customrole create\|edit\|delete\|info\|config` |
| Voice Commands | `/voice mute\|unmute\|deafen\|undeafen\|disconnect\|move\|moveall\|disconnectall` |
| Tickets | `/ticket setup\|disable\|close\|claim\|add\|remove\|transcript` |
| Logging | `/logging setup\|config\|view\|test\|disable` |
| Voice Master | `/vm setup\|disable\|lock\|unlock\|hide\|unhide\|name\|limit\|permit\|reject\|claim\|transfer\|info` |
| Bot Settings | `/settings prefix\|dm-notify\|view` |
| Giveaways · Webhooks | `/giveaway start\|end\|reroll\|cancel\|list\|config` · `/webhook add\|list\|remove\|test` |

Prefix layer (default `.`, change with `/settings prefix`): `.help [context]`, `.ping`, `.avatar`, `.userinfo`, `.warn`, `.warnings`, `.kick`, `.ban`, `.unban`, `.mute`, `.unmute`, `.purge`, `.lock`, `.unlock`, `.play/.skip/.stop/.pause/.resume/.queue/.loop`, `.afk`, `.tag`, `.8ball`, `.coinflip`, `.roll`. Same permission/hierarchy rules apply.

## 6. Discord API limitations & edge cases (handled or documented)
* **Timeouts** max 28 days; admins cannot be timed out; bot needs a role above the target.
* **Bulk delete** ignores messages older than 14 days; 1–100 per call.
* **Channel renames** are limited to 2 per 10 minutes per channel (Voice Master guards this).
* **Slash-command propagation:** global registration can take up to ~1 hour; use `DEV_GUILD_ID` while developing. Max 100 top-level commands (46 used) and ~8000 characters per command definition (validated in tests).
* **Interaction deadline:** replies must start within 3 s — long work is deferred first.
* **Audit-log events** arrive after gateway events (~1 s); channel/role logs briefly wait to name the executor. Requires *View Audit Log*.
* **Message content** of messages sent while the bot was offline or uncached cannot be shown in delete logs.
* **DMs** to users with closed DMs silently fail (never blocks the action).
* **Presence intent** is required for Vanity roles and is privileged (verification needed above 100 servers).
* **Bots in >100 servers** must be verified for privileged intents; **>2,500 guilds** requires sharding (`ShardingManager`) — current design targets a single shard, in-memory trackers (spam/raid windows) are per-process.
* **Music:** streaming from YouTube may violate YouTube's Terms of Service and `play-dl` can break when YouTube changes; direct audio URLs are the safe default. Requires FFmpeg (`ffmpeg-static` is optional-installed), an Opus encoder and libsodium. Disable with `ENABLE_MUSIC=false`.
* **Presence/Guild data retention:** when the bot is removed from a server its rows are kept (in case of re-invite). To purge: `DELETE FROM <table> WHERE guild_id = '<id>'` for the tables above.

## 7. Production deployment (Linux VPS / Node hosting)

```bash
# Ubuntu example
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash - && sudo apt-get install -y nodejs
sudo npm i -g pm2
git clone <your repo> aegis && cd aegis
npm ci --omit=dev          # optional deps (music/pg/better-sqlite3) install best-effort
cp .env.example .env && nano .env && chmod 600 .env
npm run deploy             # register slash commands
npm run pm2:start          # start under PM2 (production env)
pm2 save && pm2 startup    # survive reboots (run the printed command)
```

**Operations**
| Task | Command |
|---|---|
| Logs | `npm run pm2:logs` (or `pm2 logs aegis-bot`) |
| Restart / reload after update | `git pull && npm ci --omit=dev && npm run deploy && npm run pm2:restart` |
| Apply DB migrations only | `npm run migrate` (also runs automatically on start) |
| Run tests | `npm test` |
| Backup (SQLite) | `sqlite3 data/aegis.db ".backup 'backup-$(date +%F).db'"` (safe while running, WAL mode) |
| Remove all slash commands | `npm run deploy:clear` |

**Restart / recovery behaviour**
* PM2 restarts crashes automatically (`min_uptime`, exponential back-off, memory cap 450 MB); `SIGINT/SIGTERM` trigger a graceful shutdown (scheduler stopped, voice sessions closed, Discord client destroyed, DB closed; 12 s hard timeout).
* `uncaughtException` logs and exits so PM2 restarts from a clean state; `unhandledRejection` is logged and the bot continues.
* On start the bot reconnects, then the scheduler immediately: ends giveaways whose time passed while offline, starts overdue scheduled giveaways, delivers overdue reminders, lifts expired lockdowns/temp-bans, and Voice Master removes orphaned channels.
* **Locked out by a lockdown?** Any Administrator can run `/raid unlock`; if the bot is down, lockdowns expire on their own after at most 24 h and are restored on next start. Manual fallback: remove the `@everyone` "Send Messages ✗" override on the affected channels.
* **Lost `ENCRYPTION_KEY`:** stored webhooks become unreadable — delete them (`DELETE FROM webhooks;`) and re-add; nothing else depends on the key.

## 8. What was verified (and what was not)
The sandbox this was built in had **no internet access**, so `npm install` and a live Discord connection were impossible. Therefore:
* ✅ `npm test` (23 tests): duration/template/SSRF/crypto utils, spam & AutoMod detection logic (including false-positive cases), migrations, per-guild config persistence & concurrency, permits, tags, autoresponders, encrypted webhook storage, portable-SQL checks, and the **full giveaway lifecycle** (create → enter → end with invalid-winner replacement → reroll → cancel → scheduled start → overdue-after-restart) against a real SQLite database with fake Discord objects.
* ✅ Every command definition is validated against Discord's documented limits (names, descriptions ≤ 100, ≤ 25 options, required-before-optional, definition size) and every subcommand is checked to have a handler — using a builder mock when discord.js isn't installed, and the real builders when it is.
* ⚠️ **Not exercised against the live Discord API.** Run `npm install && npm test && npm run deploy` first (tests use the real discord.js automatically once installed), then try each feature in a test server with `DEV_GUILD_ID` set. Dependency versions in `package.json` were chosen from memory and could not be resolved offline — if `npm install` complains, relax the version range.

## 9. Troubleshooting
| Symptom | Fix |
|---|---|
| `Used disallowed intents` on start | Enable the matching privileged intents in the Portal or set `ENABLE_*=false` |
| Slash commands missing | Run `npm run deploy`; set `DEV_GUILD_ID` for instant updates; re-invite with `applications.commands` |
| "I can't assign that role" | Move the bot's role above the target role |
| Logs empty | `/logging setup`; bot needs View/Send/Embed Links in the log channel |
| Webhooks disabled | Set a valid 32-byte `ENCRYPTION_KEY` |
| Music silent | Install optional deps (`@discordjs/voice opusscript libsodium-wrappers ffmpeg-static`) and give Connect/Speak |
