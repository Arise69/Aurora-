// PM2 process file. Start with:  pm2 start ecosystem.config.js --env production
module.exports = {
  apps: [
    {
      name: 'aegis-bot',
      script: 'src/index.js',
      instances: 1,              // Gateway bots must run a single instance per shard
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 20,
      min_uptime: '20s',         // crash-looping faster than this counts as a failed start
      restart_delay: 5000,
      exp_backoff_restart_delay: 200,
      max_memory_restart: '450M',
      kill_timeout: 15000,       // give graceful shutdown time to finish
      listen_timeout: 10000,
      time: true,
      merge_logs: true,
      out_file: './logs/out.log',
      error_file: './logs/error.log',
      env: { NODE_ENV: 'development' },
      env_production: { NODE_ENV: 'production' },
    },
  ],
};
