'use strict';
require('./helpers/setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseDuration, formatDuration } = require('../src/utils/duration');
const { render } = require('../src/utils/template');
const { isPrivateIp, isDiscordWebhookUrl, assertPublicUrl } = require('../src/utils/netsafe');
const { SpamTracker, contentHash } = require('../src/services/antispam');
const automod = require('../src/services/automod');
const { shortId } = require('../src/utils/ids');
const { redact } = require('../src/utils/logger');
const { chunkLines } = require('../src/utils/pagination');

test('parseDuration', () => {
  assert.equal(parseDuration('30m'), 1_800_000);
  assert.equal(parseDuration('1d12h'), 129_600_000);
  assert.equal(parseDuration('1w'), 604_800_000);
  assert.equal(parseDuration(' 2H 30M '), 9_000_000);
  for (const bad of ['', 'abc', '10', '-5m', '5x', '1d 2', '0s', 'm5', '9'.repeat(40) + 'm']) assert.equal(parseDuration(bad), null, bad);
});
test('formatDuration', () => {
  assert.equal(formatDuration(90_000), '1m 30s');
  assert.equal(formatDuration(86_400_000 + 3_600_000), '1d 1h');
  assert.equal(formatDuration(0), '0s');
});
test('render only substitutes known variables', () => {
  assert.equal(render('Hi {user} {nope}', { user: '<@1>' }), 'Hi <@1> {nope}');
  assert.equal(render('{constructor} {__proto__}', {}), '{constructor} {__proto__}');
});
test('isPrivateIp', () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.0.5', '172.16.9.9', '169.254.169.254', '100.64.0.1', '0.0.0.0', '::1', 'fd00::1', 'fe80::1', '::ffff:10.0.0.1', '224.0.0.1']) assert.equal(isPrivateIp(ip), true, ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '172.32.0.1', '2606:4700:4700::1111']) assert.equal(isPrivateIp(ip), false, ip);
});
test('webhook URL validation', async () => {
  assert.equal(isDiscordWebhookUrl('https://discord.com/api/webhooks/123456789/abc-DEF_1'), true);
  assert.equal(isDiscordWebhookUrl('https://evil.com/api/webhooks/123/abc'), false);
  assert.equal(isDiscordWebhookUrl('http://discord.com/api/webhooks/123/abc'), false);
  assert.equal(isDiscordWebhookUrl('https://discord.com.evil.com/api/webhooks/123/abc'), false);
  await assert.rejects(assertPublicUrl('https://127.0.0.1/x'));
  await assert.rejects(assertPublicUrl('http://example.com/x'));
  await assert.rejects(assertPublicUrl('https://user:pw@example.com/'));
  await assert.rejects(assertPublicUrl('https://localhost/'));
});
test('SpamTracker flood + duplicate + no false positives', () => {
  const opts = { messageLimit: 6, intervalMs: 5000, duplicateLimit: 4, duplicateWindowMs: 30_000 };
  let t = new SpamTracker(); let r = null;
  for (let i = 0; i < 6; i++) r = t.check('u', { ts: 1000 + i * 100, hash: `h${i}`, channelId: 'c', messageId: `m${i}` }, opts);
  assert.equal(r.type, 'flood'); assert.equal(r.messages.length, 6);
  t = new SpamTracker(); r = null;
  for (let i = 0; i < 4; i++) r = t.check('u', { ts: 1000 + i * 4000, hash: 'same', channelId: 'c', messageId: `m${i}` }, opts);
  assert.equal(r.type, 'duplicate');
  t = new SpamTracker(); r = null; // normal conversation: 1 msg / 2s
  for (let i = 0; i < 30; i++) r = t.check('u', { ts: i * 2000, hash: `h${i}`, channelId: 'c', messageId: `m${i}` }, opts) ?? r;
  assert.equal(r, null);
  t = new SpamTracker(); r = null; // short repeats ("lol") are never hashed
  for (let i = 0; i < 4; i++) r = t.check('u', { ts: i * 3000, hash: contentHash('lol'), channelId: 'c', messageId: `m${i}` }, opts);
  assert.equal(r, null);
});
test('contentHash', () => {
  assert.equal(contentHash('Hello, World!!'), contentHash('hello world'));
  assert.equal(contentHash('ok'), null);
});
test('automod helpers', () => {
  const re = automod.wordRegex('g1', ['bad word', 'spam']);
  assert.ok(re.test('this is a BAD   word here'));
  assert.ok(re.test('SPAM!'));
  assert.ok(!re.test('spammer')); // no substring false positives
  assert.ok(!re.test('classic'));
  assert.equal(automod.wordRegex('g2', []), null);
  assert.deepEqual(automod.extractDomains('see https://www.Example.com/a and http://sub.foo.org?x=1'), ['example.com', 'sub.foo.org']);
  assert.equal(automod.longestRun('heyyyyyyyy'), 8);
  assert.equal(automod.longestRun('a b  c'), 1);
  assert.equal(automod.longestWordRun('lol lol lol lol x'), 4);
  assert.equal(automod.normalizeText('sp\u200bam'), 'spam');
});
test('shortId / redact / chunkLines', () => {
  const ids = new Set(Array.from({ length: 500 }, () => shortId(8)));
  assert.equal(ids.size, 500);
  assert.match(shortId(8), /^[0-9A-HJKMNP-TV-Z]{8}$/);
  const fake = 'https://discord.com/api/webhooks/123456789012345678/AbCdEf_ghIJkl-mnOPqrSTuvWXyz0123';
  assert.ok(!redact(`failed ${fake}`).includes('AbCdEf'));
  assert.ok(chunkLines(Array(200).fill('x'.repeat(50)), 1000).every((p) => p.length <= 1050));
});
