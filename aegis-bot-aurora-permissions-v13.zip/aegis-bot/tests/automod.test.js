'use strict';
const setup = require('./helpers/setup');
const test = require('node:test');
const assert = require('node:assert/strict');
process.env.LOG_LEVEL = 'error';

const db = require('../src/database');
const config = require('../src/services/guildConfig');
const automod = require('../src/services/automod');
const DEFAULTS = require('../src/config/defaults');
const cmdModule = require('../src/prefix/automod');
const cmd = cmdModule[0];

test.before(async () => { await db.init(':memory:'); });
test.after(async () => { await db.close(); });

// ───── engine ─────
const rulesWith = (patch) => {
  const cfg = DEFAULTS.automod();
  for (const [k, v] of Object.entries(patch)) Object.assign(cfg.rules[k], { enabled: true }, v);
  return cfg;
};
let seq = 0;
const msg = (content, extra = {}) => ({
  content, guild: { id: `eg${extra.guild ?? 1}` }, author: { id: extra.user ?? `u${++seq}` },
  mentions: { users: new Map(), roles: new Map() }, attachments: { size: extra.attachments ?? 0 },
  createdTimestamp: extra.ts ?? 1_000_000,
});

test('pure helpers', () => {
  assert.equal(automod.countEmojis('hi 😀😀 <:ab:123456789012345678> <a:cd:223456789012345678>'), 4);
  assert.equal(automod.countEmojis('plain text'), 0);
  assert.ok(automod.maxMarkStack('h̷̢̡̛͍̩e̶l') >= 5);          // zalgo
  assert.ok(automod.maxMarkStack('नमस्ते café') <= 2);          // Hindi / accents are fine
  assert.equal(automod.countNewlines('a\nb\n\nc'), 3);
  assert.ok(automod.similarity('hellothere', 'hellothere!') > 0.85);
  assert.ok(automod.similarity('hellothere', 'goodbyeall') < 0.4);
  assert.equal(automod.domainMatches('cdn.pornhub.com', ['pornhub.com']), true);
  assert.equal(automod.domainMatches('notpornhub.com', ['pornhub.com']), false);
});

test('new filters are all off by default and each one triggers its own rule', async () => {
  const off = DEFAULTS.automod();
  for (const f of cmdModule.FILTERS) assert.equal(off.rules[f.key].enabled, false, f.key);

  const check = async (patch, message) => (await automod.evaluate(message, rulesWith(patch)))?.rule ?? null;
  assert.equal(await check({ emojis: { limit: 3 } }, msg('😀😀😀')), 'emojis');
  assert.equal(await check({ emojis: { limit: 3 } }, msg('😀😀')), null);
  assert.equal(await check({ nsfw: {} }, msg('look https://www.pornhub.com/x')), 'nsfw');
  assert.equal(await check({ nsfw: { extraDomains: ['bad.example'] } }, msg('see https://sub.bad.example/y')), 'nsfw');
  assert.equal(await check({ nsfw: {} }, msg('https://example.com')), null);
  assert.equal(await check({ attachments: { limit: 3 } }, msg('', { attachments: 3 })), 'attachments'); // works without any text
  assert.equal(await check({ attachments: { limit: 3 } }, msg('hi', { attachments: 2 })), null);
  assert.equal(await check({ zalgo: {} }, msg('h̷̢̡̛͍̩e̶l̷l̶o')), 'zalgo');
  assert.equal(await check({ zalgo: {} }, msg('नमस्ते दुनिया café')), null);
  assert.equal(await check({ charlimit: { maxChars: 20 } }, msg('x'.repeat(21))), 'charlimit');
  assert.equal(await check({ charlimit: { maxChars: 20 } }, msg('x'.repeat(20))), null);
  assert.equal(await check({ newlines: { limit: 4 } }, msg('a\nb\nc\nd\ne')), 'newlines');
  assert.equal(await check({ newlines: { limit: 4 } }, msg('a\nb\nc')), null);
  assert.equal(await check({}, msg('anything at all')), null); // nothing enabled -> never fires
});

test('spam: N messages from one user inside the interval; other users and slow senders are fine', async () => {
  const cfg = rulesWith({ spam: { limit: 4, intervalSec: 5 } });
  const user = 'spammer';
  const results = [];
  for (let i = 0; i < 4; i += 1) results.push((await automod.evaluate(msg(`m${i}`, { user, guild: 2, ts: 10_000 + i * 500 }), cfg))?.rule ?? null);
  assert.deepEqual(results, [null, null, null, 'spam']);
  assert.equal((await automod.evaluate(msg('hi', { user: 'someone-else', guild: 2, ts: 12_000 }), cfg)), null);
  const slow = [];
  for (let i = 0; i < 6; i += 1) slow.push(await automod.evaluate(msg(`s${i}`, { user: 'slow', guild: 2, ts: 100_000 + i * 6_000 }), cfg));
  assert.ok(slow.every((v) => v === null));
});

test('similar: near-identical messages repeated within the window', async () => {
  const cfg = rulesWith({ similar: { limit: 3, windowSec: 30, similarity: 0.85 } });
  const user = 'copycat';
  const out = [];
  for (const [i, t] of ['buy cheap gold now!!', 'buy cheap gold now!', 'buy cheap gold now!!!'].entries()) {
    out.push((await automod.evaluate(msg(t, { user, guild: 3, ts: 50_000 + i * 2_000 }), cfg))?.rule ?? null);
  }
  assert.deepEqual(out, [null, null, 'similar']);
  const different = [];
  for (const [i, t] of ['hello everyone here', 'what a lovely day today', 'anyone want to play later'].entries()) {
    different.push(await automod.evaluate(msg(t, { user: 'normal', guild: 3, ts: 60_000 + i * 2_000 }), cfg));
  }
  assert.ok(different.every((v) => v === null));
  const old = await automod.evaluate(msg('buy cheap gold now!!', { user, guild: 3, ts: 50_000 + 200_000 }), cfg); // far outside the window
  assert.equal(old, null);
});

// ───── command ─────
const text = (p) => p.embeds[0].data?.description ?? p.embeds[0].description ?? '';
const color = (p) => p.embeds[0].data?.color;
const { PermissionFlagsBits: P } = require('discord.js');
const manager = { has: () => true };

function run(guildId, args, { perms = manager, userId = 'u1' } = {}) {
  const sent = [];
  const message = {
    author: { id: userId, username: 'tester' },
    member: { displayName: 'Tester', permissions: perms },
    guild: { id: guildId, ownerId: 'owner', channels: { cache: new Map([['333333333333333333', {}]]) } },
    mentions: { users: { first: () => undefined }, channels: { first: () => undefined }, roles: { first: () => undefined } },
    reply: async (p) => { sent.push(p); },
  };
  return cmd.execute(message, [...args], { prefix: '.' }).then(() => sent[0]);
}
const cfgOf = (g) => config.get(g, 'automod');

test('.automod: help page 1 (7 entries), buttons, page 2 via the pager', async () => {
  const first = await run('a1', []);
  assert.equal(first.components?.length, 1);
  const calls = {};
  await cmdModule.handleComponent({
    customId: 'am:next:u1:1', user: { id: 'u1', username: 'tester' }, member: { displayName: 'Tester' },
    inGuild: () => true, guild: { id: 'a1' }, update: async (p) => { calls.update = p; },
  });
  assert.ok(calls.update);
  if (setup.mocked) return;
  const t = text(first);
  assert.ok(t.startsWith('### Aurora automod [8]\n```yml\n<..> <required> | [..] [optional]\n```\n\n> **`.automod disable`**'));
  assert.deepEqual([...t.matchAll(/> \*\*`(\.automod \w+)`\*\*/g)].map((m) => m[1]),
    ['.automod disable', '.automod enable', '.automod logging', '.automod manage', '.automod reset', '.automod settings', '.automod whitelist']);
  assert.ok(t.includes('<a:space:1551669674213908510> <:whitearrow:1551669900622172161>  Manage per-filter whitelists for a specific target.'));
  assert.ok(t.endsWith('-# Page 1/2 | Requested by Tester'));
  assert.equal(color(first), 0x2c2c2c);
  const p2 = text(calls.update);
  assert.ok(p2.startsWith('### Aurora automod [8]'));
  assert.deepEqual([...p2.matchAll(/> \*\*`(\.automod \w+)`\*\*/g)].map((m) => m[1]), ['.automod wlshow']);
  assert.ok(p2.endsWith('-# Page 2/2 | Requested by Tester'));
});

test('.automod enable: enables + shows the filter panel; enabling again is denied', async () => {
  const first = await run('a2', ['enable']);
  assert.equal((await cfgOf('a2')).enabled, true);
  assert.ok(first.components?.length === 1);
  const again = await run('a2', ['enable']);
  assert.ok(!again.components);
  if (setup.mocked) return;
  const t = text(first);
  assert.ok(t.startsWith('### Setup Automod !\n<:arrow:1556670011232227368> **Anti spam** → <:wccrossmar:1551676376313237504>'));
  assert.equal(t.split('\n').length, 14); // heading + 13 filters
  assert.ok(t.endsWith('**Blacklist word** → <:wccrossmar:1551676376313237504>'));
  assert.equal(color(first), 0x2c2c2c);
  assert.equal(text(again), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  Automod is already enabled. Use `/automod manage` to configure filters.');
  assert.equal(color(again), 0xed4245);
});

test('.automod disable: disables; already disabled is denied', async () => {
  const denied = await run('a3', ['disable']);
  await run('a3', ['enable']);
  const ok = await run('a3', ['disable']);
  assert.equal((await cfgOf('a3')).enabled, false);
  if (setup.mocked) return;
  assert.equal(text(denied), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  The automod system is already disabled.');
  assert.equal(color(denied), 0xed4245);
  assert.equal(text(ok), '**<:wccheckmark:1551675781527380011>  Automod Disabled**\n<:whitearrow:1551669900622172161>  The automod system has been disabled.');
  assert.equal(color(ok), 0x2c2c2c);
});

test('.automod logging: usage without a channel, sets the logging channel with one', async () => {
  const usage = await run('a4', ['logging']);
  assert.equal((await config.get('a4', 'logging')).channels.automod, undefined);
  const ok = await run('a4', ['logging', '333333333333333333']);
  assert.equal((await config.get('a4', 'logging')).channels.automod, '333333333333333333');
  await assert.rejects(run('a4', ['logging', '999999999999999999']), /could not find that channel/);
  if (setup.mocked) return;
  assert.equal(text(usage), '```yml\n<..> <required> | [..] [optional]\n```\n> **`.automod logging <channel>`**\n\n<:whitearrow:1551669900622172161>  Sets the logging channel for automod events.');
  assert.equal(text(ok), '**<:wccheckmark:1551675781527380011>  Automod Logging**\n<:whitearrow:1551669900622172161>  Automod logging channel has been set to <#333333333333333333>.');
});

test('.automod manage: same panel as enable (does not change enabled)', async () => {
  const shown = await run('a5', ['manage']);
  assert.ok(shown.components?.length === 1);
  assert.equal((await cfgOf('a5')).enabled, false);
});

test('panel select sets exactly the chosen filters (and refuses other users / non-managers)', async () => {
  const click = async (values, { userId = 'u1', real = true, id = 'am:sel:u1:0' } = {}) => {
    const c = {};
    await cmdModule.handleComponent({
      customId: id, values, user: { id: userId, username: 'tester' }, inGuild: () => true,
      memberPermissions: { has: () => real },
      guild: { id: 'a6', ownerId: 'owner' },
      update: async (p) => { c.update = p; }, reply: async (p) => { c.replied = p; },
    });
    return c;
  };
  let c = await click(['spam', 'words', 'bogus']);
  assert.ok(c.update);
  let rules = (await cfgOf('a6')).rules;
  assert.equal(rules.spam.enabled, true); assert.equal(rules.words.enabled, true); assert.equal(rules.caps.enabled, false);
  if (!setup.mocked) {
    assert.ok(text(c.update).includes('**Anti spam** → <:wccheckmark:1551675781527380011>'));
    assert.ok(text(c.update).includes('**Anti caps** → <:wccrossmar:1551676376313237504>'));
  }
  c = await click(['words', 'caps']);                                    // spam deselected, caps selected
  rules = (await cfgOf('a6')).rules;
  assert.deepEqual([rules.spam.enabled, rules.words.enabled, rules.caps.enabled], [false, true, true]);
  c = await click([]);                                                   // everything deselected
  assert.ok(Object.values((await cfgOf('a6')).rules).every((r) => r.enabled === false));
  c = await click(['caps'], { userId: 'u2' });                           // someone else's panel
  assert.ok(!c.update); assert.match(c.replied.content, /Only the person/);
  c = await click(['caps'], { real: false });                            // lost Manage Server
  assert.ok(!c.update); assert.match(c.replied.content, /Manage Server/);
  assert.equal((await cfgOf('a6')).rules.caps.enabled, false);
});

test('.automod reset: defaults + switched off, keeps the ignore lists, clears the logging override', async () => {
  await run('a7', ['enable']);
  await run('a7', ['logging', '333333333333333333']);
  await config.update('a7', 'automod', (d) => { d.rules.caps.enabled = true; d.rules.words.list = ['x']; d.ignoredChannels = ['1']; d.ignoredBypassUsers = ['2']; d.ignoredCommands = ['ban']; d.ignoredUsers = ['3']; });
  const ok = await run('a7', ['reset']);
  const c = await cfgOf('a7');
  assert.equal(c.enabled, false);
  assert.equal(c.rules.caps.enabled, false);
  assert.deepEqual(c.rules.words.list, []);
  assert.deepEqual(c.ignoredUsers, []);
  assert.deepEqual([c.ignoredChannels, c.ignoredBypassUsers, c.ignoredCommands], [['1'], ['2'], ['ban']]);
  assert.equal((await config.get('a7', 'logging')).channels.automod, undefined);
  if (setup.mocked) return;
  assert.equal(text(ok), '**<:wccheckmark:1551675781527380011>  Automod Reset**\n<:whitearrow:1551669900622172161> The automod configuration has been successfully reset.');
  assert.equal(color(ok), 0x2c2c2c);
});

test('needs real Manage Server (or the owner)', async () => {
  await assert.rejects(run('a8', ['enable'], { perms: { has: () => false } }), /Manage Server/);
  assert.equal((await cfgOf('a8')).enabled, false);
  await run('a8', ['enable'], { perms: { has: () => false }, userId: 'owner' });
  assert.equal((await cfgOf('a8')).enabled, true);
});

// ───── settings (heat) ─────
test('.automod settings: master settings text matches the requested defaults', async () => {
  const shown = await run('s1', ['settings']);
  assert.ok(shown.components?.length === 1);
  const t = cmdModule.settingsText(DEFAULTS.automod().rules);
  const A = '<:arrow:1556670011232227368>';
  assert.equal(t, [
    '### Automod Master Settings',
    `${A} **Anti spam** → Punishment: \`Auto Mute\` | Heat: \`15\``,
    `${A} **Anti caps** → Punishment: \`Auto Mute\` | Heat: \`0.12\``,
    `${A} **Anti link** → Punishment: \`Auto Mute\` | Heat: \`100\``,
    `${A} **Anti invites** → Punishment: \`Auto Mute\` | Heat: \`100\``,
    `${A} **Anti mass mention** → Punishment: \`Auto Mute\` | Heat: \`20\``,
    `${A} **Anti emoji spam** → Punishment: \`Auto Mute\` | Heat: \`12\``,
    `${A} **Anti NSFW link** → Punishment: \`Auto Mute\` | Heat: \`100 (Max)\``,
    `${A} **Anti attachment spam** → Punishment: \`Auto Mute\` | Heat: \`20\``,
    `${A} **Anti zalgo spam** → Punishment: \`Auto Mute\` | Heat: \`1.5\``,
    `${A} **Similar message spam** → Punishment: \`Auto Mute\` | Heat: \`22\``,
    `${A} **Character limit spam** → Punishment: \`Auto Mute\` | Heat: \`0.08\``,
    `${A} **New line spam** → Punishment: \`Auto Mute\` | Heat: \`5\``,
    `${A} **Blacklist word** → Punishment: \`Auto Mute\` | Heat: \`100 (Max)\``,
  ].join('\n'));
  if (!setup.mocked) { assert.equal(text(shown), t); assert.equal(color(shown), 0x2c2c2c); }
});

const guildFor = (id) => ({ id, ownerId: 'owner' });
test('heat: selecting a filter opens the modal; the modal saves a validated value', async () => {
  const base = { user: { id: 'u1', username: 't' }, inGuild: () => true, memberPermissions: { has: () => true }, guild: guildFor('s2') };
  const shown = {};
  await cmdModule.handleComponent({ ...base, customId: 'am:heat:u1:0', values: ['caps'], showModal: async (m) => { shown.modal = m; } });
  assert.ok(shown.modal);
  const noModal = {};
  await cmdModule.handleComponent({ ...base, customId: 'am:heat:u1:0', values: ['words'], showModal: async () => { noModal.opened = true; }, reply: async () => {} });
  assert.equal(noModal.opened, undefined);            // words / nsfw are fixed at 100

  const submit = async (value, extra = {}) => {
    const c = {};
    await cmdModule.handleHeatModal({
      ...base, customId: 'amh:u1:caps', fields: { getTextInputValue: () => value }, isFromMessage: () => true,
      update: async (p) => { c.update = p; }, reply: async (p) => { c.replied = p; }, ...extra,
    });
    return c;
  };
  let c = await submit('0,25');
  assert.equal((await cfgOf('s2')).rules.caps.heat, 0.25);
  assert.ok(c.update);
  if (!setup.mocked) assert.ok(text(c.update).includes('**Anti caps** → Punishment: `Auto Mute` | Heat: `0.25`'));
  for (const bad of ['abc', '-1', '101', '']) {
    c = await submit(bad);
    assert.match(c.replied.content, /between 0 and 100/);
  }
  assert.equal((await cfgOf('s2')).rules.caps.heat, 0.25);
  c = await submit('50', { customId: 'amh:u1:words' });
  assert.match(c.replied.content, /fixed heat/);
  c = await submit('50', { user: { id: 'u2' } });
  assert.match(c.replied.content, /Only the person/);
  c = await submit('50', { memberPermissions: { has: () => false } });
  assert.match(c.replied.content, /Manage Server/);
  assert.equal((await cfgOf('s2')).rules.caps.heat, 0.25);
});

test('HeatTracker: adds up, cools down, resets', () => {
  const h = new automod.HeatTracker();
  assert.equal(h.add('k', 40, 0, 1), 40);
  assert.equal(h.add('k', 40, 10_000, 1), 70);          // 40 cooled to 30, +40
  assert.equal(h.add('k', 40, 10_000, 1), 110);          // reaches the limit
  h.clear('k');
  assert.equal(h.add('k', 5, 10_000, 1), 5);
  assert.equal(h.add('k', 0, 1_000_000, 1), 0);          // fully cooled
  assert.equal(h.add('other', 15, 0, 1), 15);
});

// ───── whitelist ─────
const U1 = '111111111111111111';
const ROLE = '666666666666666666';
const CHAN = '333333333333333333';
function runWl(guildId, args, { user = undefined, role = undefined, channel = undefined, client = true } = {}) {
  const sent = [];
  const message = {
    author: { id: 'u1', username: 'tester' }, member: { displayName: 'Tester', permissions: manager },
    guild: { id: guildId, ownerId: 'owner', channels: { cache: new Map([[CHAN, {}]]) }, roles: { cache: new Map([[ROLE, {}]]) } },
    client: client ? { users: { fetch: async (id) => (id === U1 ? { id } : Promise.reject(new Error('unknown'))) } } : undefined,
    mentions: { users: { first: () => user }, roles: { first: () => role }, channels: { first: () => channel } },
    reply: async (p) => { sent.push(p); },
  };
  return cmd.execute(message, ['whitelist', ...args], { prefix: '.' }).then(() => sent[0]);
}

test('.automod whitelist: no target is denied; targets resolve to user / role / channel', async () => {
  const denied = await runWl('w1', []);
  assert.ok(!denied.components);
  if (!setup.mocked) {
    assert.equal(text(denied), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  You must provide a User, Role, or Channel to whitelist.');
    assert.equal(color(denied), 0xed4245);
  }
  const user = await runWl('w1', [], { user: { id: U1 } });
  const role = await runWl('w1', [], { role: { id: ROLE } });
  const channel = await runWl('w1', [], { channel: { id: CHAN } });
  const byId = await runWl('w1', [ROLE]);                         // raw ids are resolved against the server
  for (const p of [user, role, channel, byId]) assert.equal(p.components?.length, 1);
  await assert.rejects(runWl('w1', ['999999999999999999']), /could not find/);
  if (setup.mocked) return;
  assert.ok(text(user).startsWith(`### Automod Whitelist - <@${U1}>\n<:arrow:1556670011232227368>  **Anti spam** → <:wccrossmar:1551676376313237504>`));
  assert.ok(text(role).startsWith(`### Automod Whitelist - <@&${ROLE}>`));
  assert.ok(text(channel).startsWith(`### Automod Whitelist - <#${CHAN}>`));
  assert.equal(text(user).split('\n').length, 13);               // heading + 12 filters (no NSFW)
  assert.ok(!text(user).includes('NSFW'));
  assert.equal(color(user), 0x2c2c2c);
});

test('whitelist select: whitelists the target for exactly the chosen filters, panel shows ✅, overview lists them', async () => {
  const pick = async (values, { type = 'u', id = U1, userId = 'u1', real = true } = {}) => {
    const c = {};
    await cmdModule.handleWhitelistComponent({
      customId: `amw:sel:${userId}:${type}${id}`, values, user: { id: 'u1', username: 't' }, inGuild: () => true,
      memberPermissions: { has: () => real }, guild: guildFor('w2'),
      update: async (p) => { c.update = p; }, reply: async (p) => { c.replied = p; },
    });
    return c;
  };
  let c = await pick(['spam', 'caps', 'nsfw', 'bogus']);                  // nsfw can't be whitelisted
  assert.ok(c.update);
  let wl = (await cfgOf('w2')).whitelist;
  assert.deepEqual(Object.keys(wl).sort(), ['caps', 'spam']);
  assert.deepEqual(wl.spam.users, [U1]);
  if (!setup.mocked) {
    assert.ok(text(c.update).includes('**Anti spam** → <:wccheckmark:1551675781527380011>'));
    assert.ok(text(c.update).includes('**Anti link** → <:wccrossmar:1551676376313237504>'));
  }
  await pick(['spam'], { type: 'r', id: ROLE });
  await pick(['spam'], { type: 'c', id: CHAN });
  wl = (await cfgOf('w2')).whitelist;
  assert.deepEqual([wl.spam.users, wl.spam.roles, wl.spam.channels], [[U1], [ROLE], [CHAN]]);

  const t = cmdModule.overviewText(await cfgOf('w2'));
  assert.equal(t, [
    '### Automod Whitelist Overview',
    `**Anti spam**\n<:arrow:1556670011232227368>  **Users:** <@${U1}>\n<:arrow:1556670011232227368>  **Roles:** <@&${ROLE}>\n<:arrow:1556670011232227368>  **Channels:** <#${CHAN}>`,
    `**Anti caps**\n<:arrow:1556670011232227368>  **Users:** <@${U1}>`,
  ].join('\n'));
  const overview = await run('w2', ['wlshow']);
  if (!setup.mocked) { assert.equal(text(overview), t); assert.equal(color(overview), 0x2c2c2c); }

  await pick(['caps'], { type: 'u' });                                    // spam removed for the user, caps kept
  wl = (await cfgOf('w2')).whitelist;
  assert.deepEqual([wl.spam.users, wl.caps.users], [[], [U1]]);
  await pick([], { type: 'u' });                                          // nothing selected removes the user everywhere
  wl = (await cfgOf('w2')).whitelist;
  assert.deepEqual(Object.keys(wl), ['spam']);                            // still has the role + channel entries
  assert.deepEqual(wl.spam.users, []);

  c = await pick(['caps'], { userId: 'u9' });                             // someone else's panel
  assert.ok(!c.update); assert.match(c.replied.content, /Only the person/);
  c = await pick(['caps'], { real: false });
  assert.ok(!c.update); assert.match(c.replied.content, /Manage Server/);
});

test('.automod wlshow: nothing whitelisted -> denied', async () => {
  const empty = await run('w3', ['wlshow']);
  assert.ok(!empty.components);
  if (!setup.mocked) { assert.equal(text(empty), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  There is nothing whitelisted in this server.'); assert.equal(color(empty), 0xed4245); }
});

test('engine: a whitelisted user / role / channel is skipped for that filter only', async () => {
  const cfg = rulesWith({ emojis: { limit: 3 }, newlines: { limit: 3 } });
  cfg.whitelist = { emojis: { users: ['vip'], roles: ['r-ok'], channels: ['c-ok'] } };
  const mk = (extra) => ({ ...msg('😀😀😀', { user: 'plain' }), channelId: 'c-1', member: { id: 'plain', roles: { cache: new Map() } }, ...extra });
  assert.equal((await automod.evaluate(mk({}), cfg))?.rule, 'emojis');
  assert.equal(await automod.evaluate(mk({ author: { id: 'vip' } }), cfg), null);
  assert.equal(await automod.evaluate(mk({ member: { id: 'plain', roles: { cache: new Map([['r-ok', {}]]) } } }), cfg), null);
  assert.equal(await automod.evaluate(mk({ channelId: 'c-ok' }), cfg), null);
  assert.equal(await automod.evaluate(mk({ channel: { parentId: 'c-ok' } }), cfg), null);               // category whitelist
  assert.equal((await automod.evaluate(mk({ author: { id: 'vip' }, content: 'a\nb\nc\nd' }), cfg))?.rule, 'newlines'); // other filters still apply
  const v = await automod.evaluate(mk({ content: '😀😀😀😀' }), cfg);
  assert.equal(v.units, 4);                                                                               // heat is charged per emoji
});

test('.automod reset also clears the per-filter whitelists and heat values', async () => {
  await config.update('w4', 'automod', (d) => { d.whitelist = { spam: { users: [U1], roles: [], channels: [] } }; d.rules.caps.heat = 9; });
  await run('w4', ['reset']);
  const c = await cfgOf('w4');
  assert.deepEqual(c.whitelist, {});
  assert.equal(c.rules.caps.heat, 0.12);
});
