'use strict';
const setup = require('./helpers/setup');
const Module = require('node:module');
const test = require('node:test');
const assert = require('node:assert/strict');
process.env.LOG_LEVEL = 'error';

// Offline sandbox: give this file a faithful minimal permission implementation (the generic discord.js mock has none).
if (setup.mocked) {
  const bits = ['CreateInstantInvite', 'KickMembers', 'BanMembers', 'Administrator', 'ManageChannels', 'ManageGuild', 'ManageMessages', 'ModerateMembers'];
  const flags = Object.fromEntries(bits.map((n, i) => [n, 1n << BigInt(i)]));
  const bit = (x) => (typeof x === 'string' ? flags[x] : BigInt(x));
  class PermissionsBitField {
    constructor(v = 0n) { this.bitfield = [].concat(v).reduce((a, x) => a | (x instanceof PermissionsBitField ? x.bitfield : bit(x)), 0n); }
    has(p) { return [].concat(p).every((x) => (this.bitfield & bit(x)) === bit(x)); }
    remove(v) { this.bitfield &= ~(v instanceof PermissionsBitField ? v.bitfield : BigInt(v)); return this; }
    toArray() { return bits.filter((n) => this.bitfield & flags[n]); }
  }
  const real = Module._load;
  Module._load = function stub(request, ...rest) {
    const mod = real.call(this, request, ...rest);
    return request === 'discord.js' ? new Proxy(mod, { get: (t, k) => (k === 'PermissionsBitField' ? PermissionsBitField : k === 'PermissionFlagsBits' ? flags : t[k]) }) : mod;
  };
}

const { PermissionsBitField, PermissionFlagsBits: P } = require('discord.js');
const db = require('../src/database');
const moderation = require('../src/services/moderation');
const commands = require('../src/prefix/modbasic');
const { setClient } = require('../src/utils/context');
const [ban, softban] = commands;

test.before(async () => { await db.init(':memory:'); setClient({ user: { id: 'bot' } }); });
test.after(async () => { await db.close(); });

const text = (p) => p.embeds[0].data?.description ?? p.embeds[0].description ?? '';
const color = (p) => p.embeds[0].data?.color;

// ───── fixtures ─────
const role = (position) => ({ position, comparePositionTo(o) { return this.position - o.position; } });
function makeWorld({ botPos = 10, modPos = 20, banned = [], members = {}, dmFails = false, bannable = true } = {}) {
  const calls = { created: [], removed: [], dms: [] };
  const mk = (id, position, extra = {}) => ({
    id, displayName: `nick-${id}`, roles: { highest: role(position) }, bannable,
    user: { id, username: `user-${id}`, send: async (p) => { if (dmFails) throw new Error('closed'); calls.dms.push(p); } }, ...extra,
  });
  const people = { target: mk('222222222222222222', 5), high: mk('333333333333333333', 15), equal: mk('444444444444444444', 10), ...members };
  const guild = {
    id: 'g1', name: 'Test', ownerId: 'owner',
    members: {
      me: { id: 'bot', roles: { highest: role(botPos) }, permissions: new PermissionsBitField([P.BanMembers]) },
      fetch: async (id) => people[Object.keys(people).find((k) => people[k].id === id)] ?? Promise.reject(new Error('Unknown Member')),
    },
    bans: {
      create: async (id, opts) => { calls.created.push({ id, ...opts }); },
      remove: async (id, reason) => { calls.removed.push({ id, reason }); },
      fetch: async ({ user }) => (banned.includes(user) ? { user: { id: user } } : Promise.reject(new Error('Unknown Ban'))),
    },
  };
  const users = { '555555555555555555': { id: '555555555555555555', username: 'outsider', send: async (p) => { calls.dms.push(p); } } };
  for (const p of Object.values(people)) users[p.id] = p.user;
  const moderator = { id: 'mod', displayName: 'Mod', roles: { highest: role(modPos) }, user: { id: 'mod', username: 'radientsoul' }, permissions: new PermissionsBitField([P.BanMembers]) };
  return { calls, guild, people, users, moderator };
}

/** Runs a command; `script` = what happens on the confirmation message: an array of fake component interactions or 'timeout'. */
async function run(cmd, world, args, script = []) {
  const sent = [];
  const prompt = {
    edits: [], deleted: false,
    awaitMessageComponent: async () => {
      if (script === 'timeout' || !script.length) throw new Error('time');
      return script.shift();
    },
    edit: async (p) => { prompt.edits.push(p); return prompt; },
    delete: async () => { prompt.deleted = true; },
  };
  const message = {
    author: { id: 'mod', username: 'radientsoul' }, member: world.moderator, guild: world.guild,
    client: { users: { fetch: async (id) => world.users[id] ?? Promise.reject(new Error('Unknown User')) } },
    reply: async (p) => { sent.push(p); return prompt; },
  };
  try { await cmd.execute(message, [...args], { prefix: '.' }); } catch (err) { err.prompt = prompt; throw err; }
  return { sent, prompt };
}
const click = (customId, userId = 'mod') => {
  const i = { customId, user: { id: userId }, deferred: false, replies: [] };
  i.deferUpdate = async () => { i.deferred = true; };
  i.reply = async (p) => { i.replies.push(p); };
  return i;
};
const YES = () => click('modc:yes');
const NO = () => click('modc:no');

test.beforeEach(() => { require('../src/prefix/ui'); });

// stub the permission assertion (needs real discord.js permission math otherwise)
const permsUtil = require('../src/utils/permissions');
const realAssert = permsUtil.assertBotPermissions;
permsUtil.assertBotPermissions = () => {};

test('arg parsing: reason + optional delete_messages flag', () => {
  const p = commands.parseBanArgs;
  assert.deepEqual(p([]), { reason: '', deleteMessages: false });
  assert.deepEqual(p(['spamming', 'links']), { reason: 'spamming links', deleteMessages: false });
  assert.deepEqual(p(['spamming', 'true']), { reason: 'spamming', deleteMessages: true });
  assert.deepEqual(p(['spamming', 'delete_messages=true']), { reason: 'spamming', deleteMessages: true });
  assert.deepEqual(p(['delete_messages=false']), { reason: '', deleteMessages: false });
  assert.deepEqual(p(['raid', 'delete=yes']), { reason: 'raid', deleteMessages: true });
  assert.deepEqual(p(['rule', '1']), { reason: 'rule 1', deleteMessages: false }); // a bare number is part of the reason
});

test('usage embeds', async () => {
  const b = await run(ban, makeWorld(), []);
  const s = await run(softban, makeWorld(), []);
  if (setup.mocked) return assert.ok(b.sent[0].embeds && s.sent[0].embeds);
  assert.equal(text(b.sent[0]), '```yml\n<..> <required> | [..] [optional]\n```\n> **`.ban <user> [reason] [delete_messages=False]`**\n\n<:whitearrow:1551669900622172161>  **Aliases :** `hackban`\n<:whitearrow:1551669900622172161>  Ban a user from the server.');
  assert.equal(text(s.sent[0]), '```yml\n<..> <required> | [..] [optional]\n```\n> **`.softban <member> [reason]`**\n\n<:whitearrow:1551669900622172161>  Ban and unban a member to purge messages.');
  assert.equal(color(b.sent[0]), 0x2c2c2c);
  assert.deepEqual(ban.aliases, ['hackban']);
});

test('refusals are red "Process Denied !" embeds and never reach the confirmation', async () => {
  const cases = [
    ['<@333333333333333333>', makeWorld(), BOT_MSG()],                       // higher than the bot
    ['444444444444444444', makeWorld(), BOT_MSG()],                          // equal to the bot
    ['222222222222222222', makeWorld({ bannable: false }), BOT_MSG()],       // Discord says it is not bannable
    ['222222222222222222', makeWorld({ modPos: 5 }), 'You cannot moderate someone with an equal or higher role than yours.'],
    ['mod', makeWorld(), null],
    ['999999999999999999', makeWorld(), 'I could not find that user.'],
    ['555555555555555555', makeWorld({ banned: ['555555555555555555'] }), 'That user is already banned.'],
  ];
  function BOT_MSG() { return 'I cannot ban someone with a higher or equal role to me!'; }
  for (const [arg, world, expected] of cases) {
    if (arg === 'mod') { world.people.mod = world.moderator; world.users.mod = world.moderator.user; }
    const { sent, prompt } = await run(ban, world, [arg, 'reason'], [YES()]);
    assert.equal(sent.length, 1, arg);                                       // only the denial, no confirmation message
    assert.deepEqual(world.calls.created, [], arg);
    if (setup.mocked || expected === null) continue;
    assert.equal(text(sent[0]), `**Process Denied !**\n<:wccrossmar:1551676376313237504>  ${expected}`, arg);
    assert.equal(color(sent[0]), 0xed4245);
    assert.equal(prompt.deleted, false);
  }
  assert.equal(commands.BOT_HIERARCHY, 'I cannot ban someone with a higher or equal role to me!');
});

test('confirmation screen: text, buttons; timeout and Remove take no action and delete the message', async () => {
  const w = makeWorld();
  const shown = await run(ban, w, ['222222222222222222', 'spam'], 'timeout');
  assert.equal(shown.sent.length, 1);
  assert.equal(shown.prompt.deleted, true);
  assert.deepEqual(w.calls.created, []);
  assert.ok(shown.sent[0].components?.length === 1);
  if (!setup.mocked) {
    assert.equal(text(shown.sent[0]), '### Do you want to continue? <:reason:1556690309768024185>\n<:whitearrow:1551669900622172161>  Are you sure **radientsoul** ? You have `10s` to decide.');
    assert.equal(color(shown.sent[0]), 0x2c2c2c);
  }
  const w2 = makeWorld();
  const removed = await run(ban, w2, ['222222222222222222', 'spam'], [NO()]);
  assert.equal(removed.prompt.deleted, true);
  assert.deepEqual(w2.calls.created, []);
  assert.deepEqual(removed.prompt.edits, []);
});

test('Confirm bans, shows the result embed; Dm Done flips to a check when the DM arrived', async () => {
  const w = makeWorld();
  const yes = YES();
  const { prompt } = await run(ban, w, ['222222222222222222', 'being', 'rude'], [yes]);
  assert.equal(yes.deferred, true);
  assert.equal(w.calls.created.length, 1);
  assert.equal(w.calls.created[0].id, '222222222222222222');
  assert.equal(w.calls.created[0].deleteMessageSeconds, 0);
  assert.match(w.calls.created[0].reason, /being rude/);
  assert.equal(w.calls.dms.length, 1);                                          // the member was told before the ban
  assert.equal(prompt.deleted, false);
  assert.deepEqual(prompt.edits[0].components, []);
  if (setup.mocked) return;
  assert.equal(text(prompt.edits[0]), [
    '**<:wccheckmark:1551675781527380011>  User have been banned!**',
    '<:members:1543490027777036381>  `nick-222222222222222222`',
    '<:whitecheck:1556694996835508294> **Moderator :** `radientsoul`',
    '',
    '<:reason:1556690309768024185>',
    '<:wickarrow:1556694640634241087> Dm Done ? <:wccheckmark:1551675781527380011> ',
    '<:wickarrow:1556694640634241087> **Reason :** `being rude`',
  ].join('\n'));
  assert.equal(color(prompt.edits[0]), 0x2c2c2c);
});

test('no reason -> "Reason not provided"; closed DMs -> cross; delete_messages=true removes 7 days', async () => {
  const w = makeWorld({ dmFails: true });
  const { prompt } = await run(ban, w, ['222222222222222222', 'delete_messages=true'], [YES()]);
  assert.equal(w.calls.created[0].deleteMessageSeconds, 7 * 86400);
  assert.equal(w.calls.dms.length, 0);
  if (setup.mocked) return;
  const t = text(prompt.edits[0]);
  assert.ok(t.includes('Dm Done ? <:wccrossmar:1551676376313237504> \n'));
  assert.ok(t.endsWith('**Reason :** `Reason not provided`'));
});

test('hackban: a user who is not in the server can be banned by ID (no DM possible)', async () => {
  const w = makeWorld();
  const { prompt } = await run(ban, w, ['555555555555555555', 'raider'], [YES()]);
  assert.equal(w.calls.created[0].id, '555555555555555555');
  assert.equal(w.calls.dms.length, 0);
  if (!setup.mocked) {
    assert.ok(text(prompt.edits[0]).includes('`outsider`'));
    assert.ok(text(prompt.edits[0]).includes('Dm Done ? <:wccrossmar:1551676376313237504>'));
  }
});

test('only the moderator can press the buttons; other people get a private notice and the wait continues', async () => {
  const w = makeWorld();
  const intruder = click('modc:yes', 'someone-else');
  const { prompt } = await run(ban, w, ['222222222222222222'], [intruder, YES()]);
  assert.equal(intruder.replies.length, 1);
  assert.match(intruder.replies[0].content, /Only the person/);
  assert.equal(w.calls.created.length, 1);                                       // the real moderator's click still worked
  assert.equal(prompt.edits.length, 1);
});

test('softban: bans with 7 days of messages deleted, unbans right away, says "soft banned"', async () => {
  const w = makeWorld();
  const { prompt, sent } = await run(softban, w, ['222222222222222222', 'cleanup'], [YES()]);
  assert.equal(sent.length, 1);
  assert.equal(w.calls.created.length, 1);
  assert.equal(w.calls.created[0].deleteMessageSeconds, 7 * 86400);
  assert.match(w.calls.created[0].reason, /cleanup \(softban\)/);
  assert.equal(w.calls.removed.length, 1);
  assert.equal(w.calls.removed[0].id, '222222222222222222');
  assert.equal(w.calls.dms.length, 1);
  if (setup.mocked) return;
  assert.ok(text(prompt.edits[0]).startsWith('**<:wccheckmark:1551675781527380011>  User have been soft banned!**'));
  // a banned user can never be "softbanned" (that would unban them)
  const w2 = makeWorld({ banned: ['555555555555555555'] });
  const again = await run(softban, w2, ['555555555555555555'], [YES()]);
  assert.deepEqual(w2.calls.removed, []);
  assert.match(text(again.sent[0]), /already banned/);
});

test('unexpected Discord errors during the ban: the confirmation is replaced by a denied embed (then re-thrown)', async () => {
  const w = makeWorld();
  w.guild.bans.create = async () => { throw new Error('Missing Permissions'); };
  const err = await run(ban, w, ['222222222222222222'], [YES()]).then(() => null, (e) => e);
  assert.ok(err, 'the error is re-thrown so the dispatcher can log it');
  assert.equal(err.prompt.edits.length, 1);
  assert.deepEqual(err.prompt.edits[0].components, []);
  if (!setup.mocked) {
    assert.match(text(err.prompt.edits[0]), /^\*\*Process Denied !\*\*\n<:wccrossmar:1551676376313237504>  Discord refused the request/);
    assert.equal(color(err.prompt.edits[0]), 0xed4245);
  }
});

test('result text helper', () => {
  const t = commands.resultText({ title: 'X', nickname: 'a`b', moderatorName: 'm', dmSent: false, reason: '' });
  assert.ok(t.includes('`a\'b`') && t.includes('Reason not provided') && t.includes('Dm Done ? <:wccrossmar:1551676376313237504> '));
});
