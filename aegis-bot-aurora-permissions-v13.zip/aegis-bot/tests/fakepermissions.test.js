'use strict';
const setup = require('./helpers/setup');
const Module = require('node:module');
const test = require('node:test');
const assert = require('node:assert/strict');
process.env.LOG_LEVEL = 'error';

// Offline sandbox: the generic discord.js mock has no real permission bits, so give this file a faithful minimal one.
if (setup.mocked) {
  const bits = ['CreateInstantInvite', 'KickMembers', 'BanMembers', 'Administrator', 'ManageChannels', 'ManageGuild', 'ManageMessages', 'ModerateMembers',
    'ManageRoles', 'ManageWebhooks', 'MoveMembers', 'MuteMembers', 'DeafenMembers', 'ManageNicknames', 'ManageGuildExpressions', 'ViewAuditLog'];
  const flags = Object.fromEntries(bits.map((n, i) => [n, 1n << BigInt(i)]));
  const bit = (x) => {
    if (typeof x === 'string') { if (!(x in flags)) throw new RangeError(`invalid permission ${x}`); return flags[x]; }
    return BigInt(x);
  };
  class PermissionsBitField {
    constructor(v = 0n) { this.bitfield = [].concat(v).reduce((a, x) => a | (x instanceof PermissionsBitField ? x.bitfield : bit(x)), 0n); }
    has(p) { return [].concat(p).every((x) => (this.bitfield & bit(x)) === bit(x)); }
    toArray() { return bits.filter((n) => this.bitfield & flags[n]); }
  }
  const real = Module._load;
  Module._load = function stub(request, ...rest) {
    const mod = real.call(this, request, ...rest);
    return request === 'discord.js' ? new Proxy(mod, { get: (t, k) => (k === 'PermissionsBitField' ? PermissionsBitField : k === 'PermissionFlagsBits' ? flags : t[k]) }) : mod;
  };
}

const { PermissionsBitField, PermissionFlagsBits: P } = require('discord.js');
const db = require('../src/database');
const config = require('../src/services/guildConfig');
const fake = require('../src/services/fakePermissions');
const panel = require('../src/prefix/permissions');
const { setClient } = require('../src/utils/context');

const member = (roles, real = []) => ({
  guild: { id: 'g1' },
  roles: { cache: new Map(roles.map((r) => [r, {}])) },
  permissions: new PermissionsBitField(real),
});

test.before(async () => {
  await db.init(':memory:');
  setClient({ user: { id: 'bot', displayAvatarURL: () => 'https://example.com/a.png' } });
  await config.update('g1', 'permissions', (d) => {
    d.roles.rMod = { permissions: ['timeout', 'messages'] };
    d.roles.rVoice = { permissions: ['voice'] };
    d.roles.rQuar = { permissions: ['quarantine'] };
    d.roles.rAll = { permissions: fake.KEYS.slice() };
    d.roles.rLegacy = { permissions: ['Administrator'] };       // stored by the first version of the feature
    d.roles.rLegacy2 = { permissions: ['ManageMessages', 'BanMembers'] };
  });
});
test.after(async () => { await db.close(); });

test('category parsing: keys, labels, aliases, legacy names, "all"', () => {
  assert.equal(fake.parseCategory('ban'), 'ban');
  assert.equal(fake.parseCategory('Kick Users'), 'kick');
  assert.equal(fake.parseCategory('Purge / Manage Messages'), 'messages');
  assert.equal(fake.parseCategory('manage-emojis'), 'emojis');
  assert.equal(fake.parseCategory('BanMembers'), 'ban');
  assert.equal(fake.parseCategory('nonsense'), null);
  assert.equal(fake.isAllWord('All Perms'), true);
  assert.deepEqual(fake.normalizeKeys(['Administrator']), fake.KEYS);
  assert.deepEqual(fake.normalizeKeys(['voice', 'ban', 'ban', 'junk']), ['ban', 'voice']); // panel order, deduped, junk dropped
});

test('categories grant exactly the permissions their commands check', async () => {
  const m = member(['rMod']);
  assert.equal(await fake.satisfies(m, [P.ModerateMembers]), true);
  assert.equal(await fake.satisfies(m, [P.ManageMessages]), true);
  assert.equal(await fake.satisfies(m, [P.ModerateMembers, P.ManageMessages]), true);
  assert.equal(await fake.satisfies(m, [P.BanMembers]), false);
  assert.equal(await fake.satisfies(m, [P.ManageMessages, P.BanMembers]), false);
  assert.equal(await fake.satisfies(m, [P.ManageChannels]), false);
});

test('Voice Moderation covers move / mute / deafen but not channel management', async () => {
  const m = member(['rVoice']);
  for (const p of [P.MoveMembers, P.MuteMembers, P.DeafenMembers]) assert.equal(await fake.satisfies(m, [p]), true);
  assert.equal(await fake.satisfies(m, [P.ManageChannels]), false);
});

test('Quarantine pseudo-permission: fake category OR real Manage Roles', async () => {
  assert.equal(await fake.satisfies(member(['rQuar']), ['Quarantine']), true);
  assert.equal(await fake.satisfies(member([], [P.ManageRoles]), ['Quarantine']), true);
  assert.equal(await fake.satisfies(member(['rMod']), ['Quarantine']), false);
  assert.equal(await fake.satisfies(member(['rQuar']), [P.ManageRoles]), false); // quarantine does not imply role management
});

test('real and fake permissions can be mixed per permission', async () => {
  assert.equal(await fake.satisfies(member(['rMod'], [P.BanMembers]), [P.BanMembers, P.ManageMessages]), true);
});

test('no roles / unconfigured roles get nothing', async () => {
  assert.equal(await fake.satisfies(member([]), [P.ManageMessages]), false);
  assert.equal(await fake.satisfies(member(['other']), [P.ManageMessages]), false);
});

test('All Perms never reaches real Administrator or Manage Server', async () => {
  const m = member(['rAll']);
  for (const p of [P.BanMembers, P.KickMembers, P.ModerateMembers, P.ManageMessages, P.ManageChannels, P.ManageRoles, P.ManageNicknames, P.ManageGuildExpressions, P.MoveMembers]) {
    assert.equal(await fake.satisfies(m, [p]), true);
  }
  assert.equal(await fake.satisfies(m, [P.Administrator]), false);
  assert.equal(await fake.satisfies(m, [P.ManageGuild]), false);
  assert.equal(await fake.satisfies(m, [P.ViewAuditLog]), false);
});

test('legacy stored values keep working', async () => {
  assert.equal(await fake.satisfies(member(['rLegacy']), [P.KickMembers]), true);
  assert.equal(await fake.satisfies(member(['rLegacy']), [P.Administrator]), false);
  assert.equal(await fake.satisfies(member(['rLegacy2']), [P.BanMembers, P.ManageMessages]), true);
  assert.equal(await fake.satisfies(member(['rLegacy2']), [P.KickMembers]), false);
});

test('real Administrator always passes; fakeable:false ignores fake grants', async () => {
  assert.equal(await fake.satisfies(member([], [P.Administrator]), [P.Administrator]), true);
  assert.equal(await fake.satisfies(member(['rAll']), [P.ManageRoles], { fakeable: false }), false);
  assert.equal(await fake.satisfies(member([], [P.ManageRoles]), [P.ManageRoles], { fakeable: false }), true);
});

test('slash-style member: role ids as a plain array + explicit realPermissions', async () => {
  const m = { guild: { id: 'g1' }, roles: ['rMod'], permissions: '0' };
  const none = new PermissionsBitField(0n);
  assert.equal(await fake.satisfies(m, [P.ManageMessages], { realPermissions: none }), true);
  assert.equal(await fake.satisfies(m, [P.KickMembers], { realPermissions: none }), false);
});

test('unknown permission names are never satisfiable; empty requirement always is', async () => {
  assert.equal(await fake.satisfies(member(['rAll']), ['TotallyMadeUp']), false);
  assert.equal(await fake.satisfies(member([]), []), true);
});

test('updateRole: toggle / all / reset persist, empty removes the entry', async () => {
  const toggle = (picked) => fake.updateRole('g2', 'r1', (cur) => { for (const k of picked) { if (cur.has(k)) cur.delete(k); else cur.add(k); } return cur; });
  assert.deepEqual(await toggle(['kick', 'ban']), ['ban', 'kick']);
  assert.deepEqual(await toggle(['ban']), ['kick']);
  assert.deepEqual(await fake.keysOfRole('g2', 'r1'), ['kick']);
  assert.deepEqual(await fake.updateRole('g2', 'r1', () => fake.KEYS), fake.KEYS);
  assert.deepEqual(await fake.updateRole('g2', 'r1', () => []), []);
  assert.equal((await config.get('g2', 'permissions')).roles.r1, undefined);
});

test('panel text: 10 rows in order, on/off state, role and requester lines', () => {
  const t = panel.panelText(['ban', 'voice'], '<@&5>', { id: '9', username: 'da`rki' });
  const rows = t.head.split('\n').filter((l) => l.startsWith('> '));
  assert.equal(rows.length, 10);
  assert.match(rows[0], /Quarantine Users/);
  assert.match(rows[9], /Voice Moderation/);
  assert.ok(rows[1].includes('<:on:1551833384131498014>') && !rows[1].includes('<:off:')); // Ban is ON
  assert.ok(rows[0].includes('1551693996059787356')); // Quarantine is OFF
  assert.ok(t.head.startsWith('### Permissions Setup'));
  assert.equal(t.role, '<:whitearrow:1551669900622172161> **Role** » <@&5>');
  assert.equal(t.foot, '-# Requested by <@9> (`darki`)');
});

// ───── panel button / select handler ─────
function click({ customId, userId = 'u1', real = [P.ManageGuild], values, roles = { r1: { id: 'r1', name: 'yo', managed: false } }, owner = 'owner' }) {
  const calls = { updated: null, replied: null };
  return {
    calls,
    interaction: {
      customId, values,
      user: { id: userId, username: 'tester' },
      memberPermissions: new PermissionsBitField(real),
      inGuild: () => true,
      guild: { id: 'g3', ownerId: owner, roles: { cache: new Map(Object.entries(roles)) } },
      update: async (p) => { calls.updated = p; },
      reply: async (p) => { calls.replied = p; },
    },
  };
}

test('panel handler: toggle, All Perms, Reset', async () => {
  let c = click({ customId: 'fp:sel:u1:r1', values: ['ban', 'kick'] });
  await panel.handleComponent(c.interaction);
  assert.ok(c.calls.updated);
  assert.deepEqual(await fake.keysOfRole('g3', 'r1'), ['ban', 'kick']);

  c = click({ customId: 'fp:sel:u1:r1', values: ['kick', 'voice'] });
  await panel.handleComponent(c.interaction);
  assert.deepEqual(await fake.keysOfRole('g3', 'r1'), ['ban', 'voice']);

  c = click({ customId: 'fp:all:u1:r1' });
  await panel.handleComponent(c.interaction);
  assert.deepEqual(await fake.keysOfRole('g3', 'r1'), fake.KEYS);

  c = click({ customId: 'fp:reset:u1:r1' });
  await panel.handleComponent(c.interaction);
  assert.deepEqual(await fake.keysOfRole('g3', 'r1'), []);
});

test('panel handler refuses other users, people without Manage Server, and bad roles', async () => {
  let c = click({ customId: 'fp:all:someoneelse:r1' });
  await panel.handleComponent(c.interaction);
  assert.equal(c.calls.updated, null);
  assert.match(c.calls.replied.content, /Only the person who opened/);

  c = click({ customId: 'fp:all:u1:r1', real: [P.ManageMessages] });
  await panel.handleComponent(c.interaction);
  assert.equal(c.calls.updated, null);
  assert.match(c.calls.replied.content, /Manage Server/);
  assert.deepEqual(await fake.keysOfRole('g3', 'r1'), []);

  c = click({ customId: 'fp:all:u1:r1', roles: { r1: { id: 'r1', name: 'bot', managed: true } } });
  await panel.handleComponent(c.interaction);
  assert.equal(c.calls.updated, null);

  c = click({ customId: 'fp:all:u1:gone' });
  await panel.handleComponent(c.interaction);
  assert.equal(c.calls.updated, null);

  // the server owner may always use it
  c = click({ customId: 'fp:all:owner:r1', userId: 'owner', real: [] });
  await panel.handleComponent(c.interaction);
  assert.ok(c.calls.updated);
});

test('list page text matches the requested layout', () => {
  const txt = panel.listPageText({ keys: ['ban'], roleMention: '<@&5>', page: 0, total: 3, nickname: 'Darki' });
  const lines = txt.split('\n');
  assert.equal(lines[0], '### Fake Permission Roles [3]');
  assert.equal(lines.filter((l) => l.startsWith('> ')).length, 10);
  assert.ok(lines[2].includes('<:on:1551833384131498014>')); // Ban / Unban
  assert.ok(lines[1].includes('<:off:1551693996059787356>'));
  assert.equal(lines.at(-2), '<:whitearrow:1551669900622172161> **Role :** <@&5>');
  assert.equal(lines.at(-1), '-# Page 1/3 | Requested by Darki');
});

test('list pagination: next/prev/last/first clamp, delete, and role removal', async () => {
  await config.update('g4', 'permissions', (d) => { d.roles = { a: { permissions: ['ban'] }, b: { permissions: ['kick'] }, c: { permissions: ['voice'] } }; });
  const mk = (id, position) => [id, { id, name: id, position }];
  const roles = new Map([mk('a', 3), mk('b', 2), mk('c', 1)]);
  const run = async (action, page, extra = {}) => {
    const calls = {};
    await panel.handleListClick({
      user: { id: 'u1', username: 'tester' }, member: { displayName: 'Tester' },
      guild: { id: 'g4', roles: { cache: roles } },
      message: { delete: async () => { calls.deleted = true; } },
      update: async (p) => { calls.update = p; },
      ...extra,
    }, action, page);
    return calls;
  };
  const pageOf = (c) => /Page (\d+)\/(\d+)/.exec(c.update.embeds[0].data?.description ?? c.update.embeds[0].description ?? '')?.slice(1, 3).join('/');
  if (!setup.mocked) {
    assert.equal(pageOf(await run('next', 1)), '2/3');
    assert.equal(pageOf(await run('next', 9)), '3/3');
    assert.equal(pageOf(await run('prev', -4)), '1/3');
    assert.equal(pageOf(await run('last', 2)), '3/3');
  } else {
    assert.ok((await run('next', 1)).update); // EmbedBuilder is a mock here; page text is covered by the test above
  }
  assert.equal((await run('del', 0)).deleted, true);
  // all roles removed while the message was open -> falls back to the red "Process Denied" embed, no buttons
  await config.update('g4', 'permissions', (d) => { d.roles = {}; });
  const c = await run('next', 1);
  assert.deepEqual(c.update.components, []);
});

test('.permissions revoke / remove: usage, revoke, and denied when nothing is configured', async () => {
  await config.update('g5', 'permissions', (d) => { d.roles = { r9: { permissions: ['ban', 'kick'] } }; });
  const role = { id: 'r9', name: 'yo', managed: false, toString: () => '<@&r9>' };
  const run = async (action, withRole) => {
    const sent = [];
    const message = {
      author: { id: 'u1', username: 'tester' },
      member: { displayName: 'Tester', permissions: new PermissionsBitField([P.ManageGuild]) },
      guild: { id: 'g5', ownerId: 'owner', roles: { cache: new Map([['r9', role]]) } },
      mentions: { roles: { first: () => (withRole ? role : undefined) } },
      reply: async (p) => { sent.push(p); },
    };
    await panel.command.execute(message, withRole ? [action, '<@&r9>'] : [action], { prefix: '.' });
    return sent[0];
  };
  const text = (p) => p.embeds[0].data?.description ?? p.embeds[0].description ?? '';

  const usage = await run('revoke', false);
  assert.equal((await fake.keysOfRole('g5', 'r9')).length, 2); // usage must not revoke anything
  const ok = await run('remove', true);                          // `remove` is an alias of `revoke`
  assert.deepEqual(await fake.keysOfRole('g5', 'r9'), []);
  const denied = await run('revoke', true);                      // nothing left to revoke
  if (!setup.mocked) {
    assert.ok(text(usage).includes('.permissions revoke <role>') && text(usage).includes('**Aliases :** `remove`'));
    assert.equal(text(ok), '**<:wccheckmark:1551675781527380011> Permissions Revoked**\n<:whitearrow:1551669900622172161>  Successfully revoked all fake permissions for <@&r9>.');
    assert.equal(ok.embeds[0].data.color, 0x2c2c2c);
    assert.equal(text(denied), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  <@&r9> does not have any fake permissions configured.');
    assert.equal(denied.embeds[0].data.color, 0xed4245);
  } else {
    assert.ok(usage.embeds && ok.embeds && denied.embeds);
  }
});

test('.permissions manage: usage, denied when nothing is configured, otherwise the grant panel', async () => {
  const role = { id: 'r8', name: 'yo', managed: false, position: 1, toString: () => '<@&r8>' };
  const run = async (guildId, withRole) => {
    const sent = [];
    await panel.command.execute({
      author: { id: 'u1', username: 'tester' },
      member: { displayName: 'Tester', permissions: new PermissionsBitField([P.ManageGuild]) },
      guild: { id: guildId, ownerId: 'owner', roles: { cache: new Map([['r8', role]]) } },
      mentions: { roles: { first: () => (withRole ? role : undefined) } },
      reply: async (p) => { sent.push(p); },
    }, withRole ? ['manage', '<@&r8>'] : ['manage'], { prefix: '.' });
    return sent[0];
  };
  const text = (p) => p.embeds[0].data?.description ?? p.embeds[0].description ?? '';

  const usage = await run('g6', false);
  const denied = await run('g6', true);                       // nothing configured anywhere
  await config.update('g6', 'permissions', (d) => { d.roles = { r8: { permissions: ['ban'] } }; });
  const shown = await run('g6', true);                        // configured -> same panel as grant

  assert.ok(usage.embeds && denied.embeds);
  assert.ok(shown.components && !shown.embeds);
  assert.equal(shown.flags, require('discord.js').MessageFlags.IsComponentsV2);
  if (!setup.mocked) {
    assert.ok(text(usage).includes('.permissions manage <role>'));
    assert.ok(!text(usage).includes('Aliases'));
    assert.ok(text(usage).endsWith('<:whitearrow:1551669900622172161>  Manage already configured fake permission roles.'));
    assert.equal(text(denied), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  There are no fake permission roles configured to manage.');
    assert.equal(denied.embeds[0].data.color, 0xed4245);
  }
});
