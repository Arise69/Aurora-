'use strict';
require('./helpers/setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
process.env.ENCRYPTION_KEY = crypto.randomBytes(32).toString('base64');
process.env.LOG_LEVEL = 'error';

const db = require('../src/database');
const config = require('../src/services/guildConfig');
const permit = require('../src/services/permit');
const tags = require('../src/services/tags');
const responders = require('../src/services/autoresponder');
const webhooks = require('../src/services/webhooks');
const { setClient } = require('../src/utils/context');
const { AppError } = require('../src/utils/errors');

test.before(async () => { await db.init(':memory:'); });
test.after(async () => { await db.close(); });

test('migrations are idempotent and versioned', async () => {
  const rows = await db.all('SELECT id FROM schema_migrations');
  assert.deepEqual(rows.map((r) => Number(r.id)), [1, 2, 3]);
  const tables = (await db.all("SELECT name FROM sqlite_master WHERE type='table'")).map((r) => r.name);
  for (const t of ['guild_settings', 'warnings', 'giveaways', 'giveaway_entries', 'webhooks', 'tickets', 'lockdowns', 'voice_channels', 'custom_roles', 'antinuke_snapshots', 'bot_settings']) assert.ok(tables.includes(t), t);
});

test('guild config: defaults, merge, per-guild isolation, persistence, frozen', async () => {
  const a = await config.get('g1', 'antispam');
  assert.equal(a.messageLimit, 6);
  assert.throws(() => { a.messageLimit = 1; }, TypeError); // frozen
  await config.update('g1', 'antispam', (c) => { c.messageLimit = 9; c.ignoredChannels.push('c1'); });
  assert.equal((await config.get('g1', 'antispam')).messageLimit, 9);
  assert.equal((await config.get('g2', 'antispam')).messageLimit, 6); // other guild untouched
  config.clearCache(); // simulate restart
  const again = await config.get('g1', 'antispam');
  assert.equal(again.messageLimit, 9);
  assert.deepEqual(again.ignoredChannels, ['c1']);
  assert.equal(again.duplicateLimit, 4); // new defaults still merged
  // serialised concurrent updates never lose writes
  await Promise.all(Array.from({ length: 20 }, (_, i) => config.update('g1', 'automod', (c) => { c.ignoredUsers.push(`u${i}`); })));
  assert.equal((await config.get('g1', 'automod')).ignoredUsers.length, 20);
  await assert.rejects(config.get('g1', 'nope'));
});

test('permit scopes', async () => {
  assert.equal(await permit.add('g1', 'u1', 'user', 'automod', 'admin'), true);
  assert.equal(await permit.add('g1', 'u1', 'user', 'automod', 'admin'), false);
  await permit.add('g1', 'r1', 'role', 'all', 'admin');
  const member = (id, roles = []) => ({ id, roles: { cache: { has: (r) => roles.includes(r) } } });
  assert.equal(await permit.isPermitted('g1', member('u1'), 'automod'), true);
  assert.equal(await permit.isPermitted('g1', member('u1'), 'antispam'), false);
  assert.equal(await permit.isPermitted('g1', member('u9', ['r1']), 'antinuke'), true);
  assert.equal(await permit.isPermitted('g2', member('u1'), 'automod'), false);
  assert.equal(await permit.remove('g1', 'u1', 'automod'), 1);
});

test('tags', async () => {
  await tags.create('g1', 'Rules', 'be nice', 'u1');
  await assert.rejects(tags.create('g1', 'rules', 'dup', 'u1'), AppError);
  await assert.rejects(tags.create('g1', 'bad name', 'x', 'u1'), AppError);
  assert.equal((await tags.use('g1', 'RULES')).content, 'be nice');
  assert.equal((await tags.getTag('g1', 'rules')).uses, 1);
  const owner = { id: 'u1', permissions: { has: () => false } }; const other = { id: 'u2', permissions: { has: () => false } };
  await assert.rejects(tags.edit('g1', 'rules', 'hax', other), AppError);
  await tags.edit('g1', 'rules', 'be kind', owner);
  assert.equal((await tags.search('g1', 'ru')).length, 1);
  await tags.remove('g1', 'rules', owner);
  await assert.rejects(tags.use('g1', 'rules'), AppError);
});

test('autoresponders match modes + limits', async () => {
  const id = await responders.add('g1', { trigger: 'Hello', response: 'hi {user.name}', matchType: 'exact', cooldownSec: 5, by: 'u1' });
  await assert.rejects(responders.add('g1', { trigger: 'hello', response: 'x', matchType: 'exact', cooldownSec: 5, by: 'u1' }), AppError);
  await assert.rejects(responders.add('g1', { trigger: 'x', response: 'y', matchType: 'regex', cooldownSec: 5, by: 'u1' }), AppError);
  const replies = [];
  const msg = (content) => ({ guild: { id: 'g1', members: { me: {} } }, channelId: 'c1', content, member: { user: { id: 'u', username: 'Bob' }, guild: { id: 'g1', name: 'S', memberCount: 3 } }, channel: { permissionsFor: () => ({ has: () => true }) }, reply: async (o) => replies.push(o.content) });
  assert.equal(await responders.process(msg('hello there')), false);       // exact only
  assert.equal(await responders.process(msg('HELLO')), true);
  assert.equal(replies[0], 'hi Bob');
  assert.equal(await responders.process(msg('hello')), false);              // cooldown
  assert.equal(await responders.remove('g1', id), true);
});

test('webhooks: encrypted at rest, validated, never listed with URL', async () => {
  const url = 'https://discord.com/api/webhooks/123456789012345678/SuperSecretToken_abc';
  const id = await webhooks.add({ guildId: 'g1', name: 'alerts', kind: 'discord', url, secret: null, events: webhooks.parseEvents('moderation,security'), createdBy: 'u1' });
  const raw = await db.get('SELECT * FROM webhooks WHERE id = ?', [id]);
  assert.ok(!raw.url_enc.includes('SuperSecretToken') && !raw.url_enc.includes('discord.com'));
  const listed = JSON.stringify(await webhooks.list('g1'));
  assert.ok(!listed.includes('SuperSecretToken') && !listed.includes('url'));
  await assert.rejects(webhooks.add({ guildId: 'g1', name: 'bad', kind: 'discord', url: 'https://evil.example/api/webhooks/1/x', events: ['all'], createdBy: 'u' }), AppError);
  await assert.rejects(webhooks.add({ guildId: 'g1', name: 'ext', kind: 'external', url: 'https://example.com/hook', events: ['all'], createdBy: 'u' }), AppError); // disabled by default
  assert.throws(() => webhooks.parseEvents('moderation,nonsense'), AppError);
  assert.equal(await webhooks.remove('g1', 'alerts'), true);
});

test('SQL portability spot-checks: RETURNING counter, ON CONFLICT DO NOTHING, atomic status claim', async () => {
  const next = async () => Number((await db.get(`INSERT INTO counters (guild_id, name, value) VALUES (?, 'ticket', 1) ON CONFLICT (guild_id, name) DO UPDATE SET value = counters.value + 1 RETURNING value`, ['g1'])).value);
  assert.deepEqual([await next(), await next(), await next()], [1, 2, 3]);
  const ins = () => db.run('INSERT INTO giveaway_entries (giveaway_id, user_id, entered_at) VALUES (?, ?, ?) ON CONFLICT DO NOTHING', ['G', 'U', 1]);
  assert.equal((await ins()).changes, 1); assert.equal((await ins()).changes, 0);
});

// ───────── Giveaway lifecycle with fake Discord objects ─────────
test('giveaway lifecycle: create → enter → end (invalid winners skipped) → reroll → cancel; scheduled start; restart safety', async () => {
  const sent = []; const edits = [];
  const channel = {
    id: 'ch1', isTextBased: () => true, isThread: () => false, permissionsFor: () => ({ has: () => true }),
    send: async (o) => { sent.push(o); return { id: `m${sent.length}` }; }, messages: { edit: async (id, p) => { edits.push([id, p]); } },
  };
  const members = new Map();
  const mk = (id, { roles = [], bot = false } = {}) => ({ id, user: { id, bot, createdTimestamp: Date.now() - 400 * 86_400_000 }, joinedTimestamp: Date.now() - 100 * 86_400_000, roles: { cache: { has: (r) => roles.includes(r) } } });
  for (let n = 1; n <= 6; n++) members.set(`u${n}`, mk(`u${n}`, { roles: ['vip'] }));
  members.set('u7', mk('u7')); // no required role any more
  const guild = { id: 'gg', name: 'Guild', members: { me: { id: 'bot' }, fetch: async (id) => { if (!members.has(id)) throw Object.assign(new Error('Unknown Member'), { code: 10007 }); return members.get(id); } }, channels: { cache: { get: () => undefined } } };
  setClient({ user: { id: 'bot' }, guilds: { cache: { get: () => guild } }, channels: { cache: { get: () => channel }, fetch: async () => channel }, users: { fetch: async () => ({ send: async () => {} }) } });
  const giveaways = require('../src/services/giveaways');

  const gw = await giveaways.create({ guild, channel, hostId: 'host', prize: 'Nitro', durationMs: 60_000, winners: 2, requiredRoleId: 'vip', excludedRoleIds: ['banned'] });
  assert.equal(gw.status, 'active'); assert.equal(sent.length, 1);
  assert.equal((await db.get('SELECT message_id FROM giveaways WHERE id = ?', [gw.id])).message_id, 'm1');

  for (const u of ['u1', 'u2', 'u3', 'u4', 'u5', 'u7', 'ghost']) await db.run('INSERT INTO giveaway_entries (giveaway_id, user_id, entered_at) VALUES (?, ?, ?)', [gw.id, u, Date.now()]);
  assert.equal(await giveaways.countEntries(gw.id), 7);
  assert.equal(giveaways.eligibility(members.get('u7'), await giveaways.getGiveaway(gw.id)) !== null, true);  // lost the role
  assert.equal(giveaways.eligibility(members.get('u1'), await giveaways.getGiveaway(gw.id)), null);

  const ended = await giveaways.endGiveaway(gw.id);
  assert.equal(ended.winners.length, 2);
  assert.ok(ended.winners.every((w) => ['u1', 'u2', 'u3', 'u4', 'u5'].includes(w)), 'ghost / ineligible users never win');
  await assert.rejects(giveaways.endGiveaway(gw.id), AppError); // cannot end twice (atomic claim)
  assert.ok(sent.at(-1).content.includes('Congratulations'));

  const rerolled = await giveaways.reroll('gg', gw.id, 2);
  assert.equal(rerolled.length, 2);
  assert.ok(rerolled.every((w) => !ended.winners.includes(w)), 'reroll excludes previous winners');
  assert.equal((await giveaways.reroll('gg', gw.id, 5)).length, 1); // only one eligible entrant left
  await assert.rejects(giveaways.reroll('gg', gw.id, 5), AppError); // pool exhausted
});

test('giveaway reroll pool exhaustion + cancel + scheduled start', async () => {
  const sent = [];
  const channel = { id: 'ch1', isTextBased: () => true, isThread: () => false, permissionsFor: () => ({ has: () => true }), send: async (o) => { sent.push(o); return { id: `s${sent.length}` }; }, messages: { edit: async () => {} } };
  const guild = { id: 'gg', name: 'Guild', members: { me: { id: 'bot' }, fetch: async () => { throw new Error('x'); } } };
  setClient({ user: { id: 'bot' }, guilds: { cache: { get: () => guild } }, channels: { cache: { get: () => channel } }, users: { fetch: async () => null } });
  const giveaways = require('../src/services/giveaways');

  const sched = await giveaways.create({ guild, channel, hostId: 'h', prize: 'Later', durationMs: 60_000, startInMs: 3_600_000 });
  assert.equal(sched.status, 'scheduled'); assert.equal(sent.length, 0);
  await giveaways.tick();
  assert.equal(sent.length, 0); // not due yet
  await db.run('UPDATE giveaways SET starts_at = ?, ends_at = ? WHERE id = ?', [Date.now() - 1, Date.now() + 60_000, sched.id]);
  await giveaways.tick();
  assert.equal(sent.length, 1);
  assert.equal((await giveaways.getGiveaway(sched.id)).status, 'active');

  // Simulated downtime: end time already passed when the scheduler wakes up → still ends, no entries → "nobody won"
  await db.run('UPDATE giveaways SET ends_at = ? WHERE id = ?', [Date.now() - 5000, sched.id]);
  await giveaways.tick();
  const done = await giveaways.getGiveaway(sched.id);
  assert.equal(done.status, 'ended'); assert.deepEqual(done.winner_ids, []);
  await assert.rejects(giveaways.reroll('gg', sched.id), AppError); // nobody to draw

  const c = await giveaways.create({ guild, channel, hostId: 'h', prize: 'Cancel me', durationMs: 60_000 });
  await giveaways.cancel('gg', c.id, 'admin');
  assert.equal((await giveaways.getGiveaway(c.id)).status, 'cancelled');
  await assert.rejects(giveaways.cancel('gg', c.id, 'admin'), AppError);
  await assert.rejects(giveaways.create({ guild, channel, hostId: 'h', prize: 'x', durationMs: 5 }), AppError);
  await assert.rejects(giveaways.create({ guild, channel, hostId: 'h', prize: 'x', durationMs: 60_000, winners: 99 }), AppError);
});
