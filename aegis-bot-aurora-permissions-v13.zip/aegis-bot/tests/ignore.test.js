'use strict';
const setup = require('./helpers/setup');
const test = require('node:test');
const assert = require('node:assert/strict');
process.env.LOG_LEVEL = 'error';

const db = require('../src/database');
const config = require('../src/services/guildConfig');
const ignore = require('../src/prefix/ignore');
const { setClient } = require('../src/utils/context');
const cmd = ignore[0];

const manager = { has: () => true };
const text = (p) => p.embeds[0].data?.description ?? p.embeds[0].description ?? '';
const color = (p) => p.embeds[0].data?.color;

test.before(async () => { await db.init(':memory:'); setClient({ user: { id: 'bot', displayAvatarURL: () => '' } }); });
test.after(async () => { await db.close(); });

const users = { '111111111111111111': 'radientsoul', '222222222222222222': 'other' };
function run(guildId, args, { perms = manager, userId = 'u1', pages = null } = {}) {
  const sent = [];
  const message = {
    author: { id: userId, username: 'tester' },
    member: { displayName: 'Tester', permissions: perms },
    guild: { id: guildId, ownerId: 'owner', channels: { cache: new Map([['333333333333333333', {}], ['444444444444444444', {}], ['555555555555555555', {}]]) }, roles: { cache: new Map([['666666666666666666', {}], ['777777777777777777', {}], [guildId, {}]]) } },
    client: { users: { cache: new Map(), fetch: async (id) => (users[id] ? { id, username: users[id] } : Promise.reject(new Error('unknown'))) } },
    mentions: { users: { first: () => undefined }, channels: { first: () => undefined }, roles: { first: () => undefined } },
    reply: async (p) => { sent.push(p); },
  };
  return cmd.execute(message, [...args], { prefix: '.' }).then(() => sent[0]);
}
const bypassList = async (g) => (await config.get(g, 'automod')).ignoredBypassUsers;

test('.ignore and .ignore bypass show the help pages', async () => {
  const root = await run('g1', []);
  const byp = await run('g1', ['bypass']);
  if (setup.mocked) return assert.ok(root.embeds && byp.embeds);
  assert.equal(color(root), 0x2c2c2c);
  const t = text(root);
  assert.ok(t.startsWith('### Aurora ignore [4]\n```yml\n<..> <required> | [..] [optional]\n```\n\n> **`.ignore bypass`**'));
  assert.ok(t.includes('<a:space:1551669674213908510> <:whitearrow:1551669900622172161>  Manage users that can bypass the ignore list for this server.'));
  assert.deepEqual([...t.matchAll(/> \*\*`(\.ignore \w+)`\*\*/g)].map((m) => m[1]), ['.ignore bypass', '.ignore channel', '.ignore command', '.ignore role']);
  assert.ok(t.endsWith('-# Page 1/1 | Requested by Tester'));
  const b = text(byp);
  assert.ok(b.startsWith('### Aurora bypass [4]'));
  assert.deepEqual([...b.matchAll(/> \*\*`(\.ignore bypass \w+)`\*\*/g)].map((m) => m[1]), ['.ignore bypass add', '.ignore bypass remove', '.ignore bypass reset', '.ignore bypass show']);
});

test('bypass add / remove usage embeds', async () => {
  const add = await run('g2', ['bypass', 'add']);
  const rem = await run('g2', ['bypass', 'remove']);
  assert.deepEqual(await bypassList('g2'), []);
  if (setup.mocked) return;
  assert.equal(text(add), '```yml\n<..> <required> | [..] [optional]\n```\n> **`.ignore bypass add <user>`**\n\n<a:space:1551669674213908510> <:whitearrow:1551669900622172161>  Add a bypass user for this server.');
  assert.ok(text(rem).includes('> **`.ignore bypass remove <user>`**') && text(rem).endsWith('Remove a bypass user for this server.'));
  assert.equal(color(add), 0x2c2c2c);
});

test('bypass add: adds, then refuses duplicates; unknown ids are rejected', async () => {
  const ok = await run('g3', ['bypass', 'add', '111111111111111111']);
  assert.deepEqual(await bypassList('g3'), ['111111111111111111']);
  const dup = await run('g3', ['bypass', 'add', '111111111111111111']);
  assert.deepEqual(await bypassList('g3'), ['111111111111111111']);
  await assert.rejects(run('g3', ['bypass', 'add', '999999999999999999']), /could not find that user/);
  assert.deepEqual(await bypassList('g3'), ['111111111111111111']);
  if (setup.mocked) return;
  assert.equal(text(ok), '<:wccheckmark:1551675781527380011> **Bypass User Added**\n<:whitearrow:1551669900622172161> User <@111111111111111111> can now bypass the ignore list.');
  assert.equal(color(ok), 0x2c2c2c);
  assert.equal(text(dup), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  User <@111111111111111111> is already in the bypass list.');
  assert.equal(color(dup), 0xed4245);
});

test('bypass remove: removes listed users (setListConfig bug fixed too), message for unlisted users', async () => {
  await run('g4', ['bypass', 'add', '111111111111111111']);
  await run('g4', ['bypass', 'add', '222222222222222222']);
  const ok = await run('g4', ['bypass', 'remove', '111111111111111111']);
  assert.deepEqual(await bypassList('g4'), ['222222222222222222']);
  const missing = await run('g4', ['bypass', 'remove', '111111111111111111']);
  assert.deepEqual(await bypassList('g4'), ['222222222222222222']);
  if (!setup.mocked) {
    assert.equal(text(ok), '**<:wccheckmark:1551675781527380011>  Bypass User Removed**\n<:whitearrow:1551669900622172161>  User <@111111111111111111> can no longer bypass the ignore list.');
    assert.equal(text(missing), '**<:wccrossmar:1551676376313237504>  Bypass User Removed**\n<:whitearrow:1551669900622172161>  User <@111111111111111111> can no longer bypass the ignore list.');
    assert.equal(color(missing), 0xed4245);
  }
  // the old catalog implementation (`.ignore channel remove`) never removed anything because of a dangling else
  await config.update('g4', 'automod', (d) => { d.ignoredRoles = ['333333333333333333', '444444444444444444']; });
  await run('g4', ['role', 'remove', '333333333333333333']);
  assert.deepEqual((await config.get('g4', 'automod')).ignoredRoles, ['444444444444444444']);
});

test('bypass reset', async () => {
  await run('g5', ['bypass', 'add', '111111111111111111']);
  const r = await run('g5', ['bypass', 'reset']);
  assert.deepEqual(await bypassList('g5'), []);
  if (!setup.mocked) {
    assert.equal(text(r), '**<:wccheckmark:1551675781527380011>  Bypass User Reset**\n<:whitearrow:1551669900622172161>  The bypass users list has been reset.');
    assert.equal(color(r), 0x2c2c2c);
  }
});

test('bypass show: empty -> denied, otherwise the numbered list', async () => {
  const empty = await run('g6', ['bypass', 'show']);
  await run('g6', ['bypass', 'add', '111111111111111111']);
  const shown = await run('g6', ['bypass', 'show']);
  assert.ok(!shown.components); // a single page has no buttons
  if (setup.mocked) return assert.ok(empty.embeds && shown.embeds);
  assert.equal(color(empty), 0xed4245);
  assert.equal(text(shown), '### Ignored Bypass users [1]\n**[`01`]** <@111111111111111111> → [`radientsoul`](https://discord.com/users/111111111111111111)\n-# Page 1/1 | Requested by Tester');
  assert.equal(color(shown), 0x2c2c2c);
});

test('bypass show paginates at 10 per page, numbering continues, buttons only when needed', async () => {
  const ids = Array.from({ length: 12 }, (_, i) => String(100000000000000000n + BigInt(i)));
  await config.update('g7', 'automod', (d) => { d.ignoredBypassUsers = ids; });
  for (const id of ids) users[id] = `u${id.slice(-2)}`;
  const first = await run('g7', ['bypass', 'show']);
  assert.ok(first.components?.length === 1);
  const click = async (action, page) => {
    const calls = {};
    await ignore.handleComponent({
      customId: `ig:${action}:u1:${page}`, user: { id: 'u1', username: 'tester' }, member: { displayName: 'Tester' },
      inGuild: () => true, guild: { id: 'g7' },
      client: { users: { cache: new Map(), fetch: async (id) => ({ id, username: users[id] }) } },
      message: { delete: async () => { calls.deleted = true; } },
      update: async (p) => { calls.update = p; }, reply: async (p) => { calls.replied = p; },
    });
    return calls;
  };
  const next = await click('next', 1);
  assert.ok(next.update);
  if (!setup.mocked) {
    assert.ok(text(next.update).includes('**[`11`]**') && text(next.update).includes('**[`12`]**'));
    assert.ok(text(next.update).endsWith('-# Page 2/2 | Requested by Tester'));
  }
  assert.equal((await click('del', 1)).deleted, true);
  const other = await (async () => { const c = {}; await ignore.handleComponent({ customId: 'ig:next:someoneelse:1', user: { id: 'u1' }, inGuild: () => true, guild: { id: 'g7' }, reply: async (p) => { c.replied = p; } }); return c; })();
  assert.match(other.replied.content, /Only the person who ran/);
  // everybody removed while the message was open -> falls back to the red embed without buttons
  await config.update('g7', 'automod', (d) => { d.ignoredBypassUsers = []; });
  assert.deepEqual((await click('next', 1)).update.components, []);
});

test('pure page text: numbering offset and username sanitising', () => {
  const t = ignore.bypassPageText({ rows: [{ id: '1', username: 'a`b' }], offset: 9, totalUsers: 12, page: 1, pages: 2, nickname: 'N' });
  assert.equal(t, '### Ignored Bypass users [12]\n**[`10`]** <@1> → [`ab`](https://discord.com/users/1)\n-# Page 2/2 | Requested by N');
});

test('needs real Manage Server (or the owner)', async () => {
  await assert.rejects(run('g8', ['bypass', 'add', '111111111111111111'], { perms: { has: () => false } }), /Manage Server/);
  assert.deepEqual(await bypassList('g8'), []);
  await run('g8', ['bypass', 'add', '111111111111111111'], { perms: { has: () => false }, userId: 'owner' });
  assert.deepEqual(await bypassList('g8'), ['111111111111111111']);
});

const chans = async (g) => (await config.get(g, 'automod')).ignoredChannels;
const CH = '333333333333333333';

test('.ignore channel help + usage embeds', async () => {
  const help = await run('c1', ['channel']);
  const add = await run('c1', ['channel', 'add']);
  const rem = await run('c1', ['channel', 'remove']);
  assert.deepEqual(await chans('c1'), []);
  if (setup.mocked) return assert.ok(help.embeds && add.embeds && rem.embeds);
  const t = text(help);
  assert.ok(t.startsWith('### Aurora channel [4]\n```yml\n<..> <required> | [..] [optional]\n```\n\n> **`.ignore channel add`**'));
  assert.ok(t.includes("<:whitearrow:1551669900622172161>  Add a channel to the server's ignore list."));
  assert.deepEqual([...t.matchAll(/> \*\*`(\.ignore channel \w+)`\*\*/g)].map((m) => m[1]), ['.ignore channel add', '.ignore channel remove', '.ignore channel reset', '.ignore channel show']);
  assert.ok(t.endsWith('-# Page 1/1 | Requested by Tester'));
  assert.equal(text(add), "```yml\n<..> <required> | [..] [optional]\n```\n> **`.ignore channel add <channel>`**\n\n<a:space:1551669674213908510> <:whitearrow:1551669900622172161>  Add a channel to the server's ignore list.");
  assert.ok(text(rem).includes('> **`.ignore channel remove <channel>`**'));
});

test('.ignore channel add: adds, refuses duplicates and channels outside the server', async () => {
  const ok = await run('c2', ['channel', 'add', CH]);
  assert.deepEqual(await chans('c2'), [CH]);
  const dup = await run('c2', ['channel', 'add', CH]);
  assert.deepEqual(await chans('c2'), [CH]);
  await assert.rejects(run('c2', ['channel', 'add', '999999999999999999']), /could not find that channel/);
  if (setup.mocked) return;
  assert.equal(text(ok), `**<:wccheckmark:1551675781527380011>  Ignore Channel Added**\n<:whitearrow:1551669900622172161>  Channel <#${CH}> has been added to the ignore list.`);
  assert.equal(color(ok), 0x2c2c2c);
  assert.equal(text(dup), `**Process Denied !**\n<:whitearrow:1551669900622172161>  Channel <#${CH}> is already in the ignore list.`);
  assert.equal(color(dup), 0xed4245);
});

test('.ignore channel remove / reset', async () => {
  await run('c3', ['channel', 'add', CH]);
  await run('c3', ['channel', 'add', '444444444444444444']);
  const missing = await run('c3', ['channel', 'remove', '555555555555555555']);
  assert.equal((await chans('c3')).length, 2);
  const ok = await run('c3', ['channel', 'remove', CH]);
  assert.deepEqual(await chans('c3'), ['444444444444444444']);
  const reset = await run('c3', ['channel', 'reset']);
  assert.deepEqual(await chans('c3'), []);
  if (setup.mocked) return;
  assert.equal(text(missing), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  Channel <#555555555555555555> is not in the ignore list.');
  assert.equal(color(missing), 0xed4245);
  assert.equal(text(ok), `**<:wccheckmark:1551675781527380011>  Ignore Channel Removed**\n<:whitearrow:1551669900622172161>  Channel <#${CH}> has been removed from the ignore list.`);
  assert.equal(text(reset), '**<:wccheckmark:1551675781527380011>  Ignore Channel Reset**\n<:whitearrow:1551669900622172161>  The ignored channels list has been reset.');
  assert.equal(color(reset), 0x2c2c2c);
});

test('.ignore channel show: empty -> denied; list; pagination via the igc buttons', async () => {
  const empty = await run('c4', ['channel', 'show']);
  await run('c4', ['channel', 'add', CH]);
  const one = await run('c4', ['channel', 'show']);
  assert.ok(!one.components);
  if (!setup.mocked) {
    assert.equal(text(empty), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  There are no ignored channels in this server.');
    assert.equal(color(empty), 0xed4245);
    assert.equal(text(one), `### Ignored Channels [1]\n**[\`01\`]** <#${CH}>\n-# Page 1/1 | Requested by Tester`);
    assert.equal(color(one), 0x2c2c2c);
  }
  const ids = Array.from({ length: 11 }, (_, i) => String(200000000000000000n + BigInt(i)));
  await config.update('c4', 'automod', (d) => { d.ignoredChannels = ids; });
  const first = await run('c4', ['channel', 'show']);
  assert.equal(first.components?.length, 1);
  const calls = {};
  await ignore.handleChannelComponent({
    customId: 'igc:next:u1:1', user: { id: 'u1', username: 'tester' }, member: { displayName: 'Tester' }, inGuild: () => true, guild: { id: 'c4' },
    update: async (p) => { calls.update = p; }, reply: async (p) => { calls.replied = p; },
  });
  assert.ok(calls.update);
  if (!setup.mocked) assert.equal(text(calls.update), `### Ignored Channels [11]\n**[\`11\`]** <#${ids[10]}>\n-# Page 2/2 | Requested by Tester`);
  const other = {};
  await ignore.handleChannelComponent({ customId: 'igc:next:someoneelse:1', user: { id: 'u1' }, inGuild: () => true, guild: { id: 'c4' }, reply: async (p) => { other.replied = p; } });
  assert.match(other.replied.content, /Only the person who ran/);
});

// ───────────── .ignore command ─────────────
const cmds = async (g) => (await config.get(g, 'automod')).ignoredCommands;

test('.ignore command help + usage embeds', async () => {
  const help = await run('m1', ['command']);
  const add = await run('m1', ['command', 'add']);
  const rem = await run('m1', ['command', 'remove']);
  assert.deepEqual(await cmds('m1'), []);
  if (setup.mocked) return assert.ok(help.embeds && add.embeds && rem.embeds);
  const t = text(help);
  assert.ok(t.startsWith('### Aurora command [4]\n```yml\n<..> <required> | [..] [optional]\n```\n\n> **`.ignore command add`**'));
  assert.ok(t.includes("<a:space:1551669674213908510> <:whitearrow:1551669900622172161>  Add a command to the server's ignore list."));
  assert.ok(t.endsWith('-# Page 1/1 | Requested by Tester'));
  assert.equal(text(add), "```yml\n<..> <required> | [..] [optional]\n```\n> **`.ignore command add <command>`**\n\n<:whitearrow:1551669900622172161>  Add a command to the server's ignore list.");
  assert.equal(text(rem), "```yml\n<..> <required> | [..] [optional]\n```\n> **`.ignore command remove <command>`**\n\n<:whitearrow:1551669900622172161>  Remove a command from the server's ignore list.");
  assert.equal(color(add), 0x2c2c2c);
});

test('.ignore command add: only real commands, aliases resolve, no duplicates, `ignore` is protected', async () => {
  const ok = await run('m2', ['command', 'add', 'antinuke']);
  assert.deepEqual(await cmds('m2'), ['antinuke']);
  const dup = await run('m2', ['command', 'add', 'antinuke']);
  const fakeCmd = await run('m2', ['command', 'add', 'notarealcommand']);
  const self = await run('m2', ['command', 'add', 'ignore']);
  const selfSub = await run('m2', ['command', 'add', 'ignore', 'bypass', 'add']);
  assert.deepEqual(await cmds('m2'), ['antinuke']);
  const alias = await run('m2', ['command', 'add', 'CLEAR']);      // alias of purge
  assert.deepEqual(await cmds('m2'), ['antinuke', 'purge']);
  if (setup.mocked) return;
  assert.equal(text(ok), '**<:wccheckmark:1551675781527380011>  Ignore Command Added**\n<:whitearrow:1551669900622172161>  Command `antinuke` has been added to the ignore list.');
  assert.equal(color(ok), 0x2c2c2c);
  assert.equal(text(dup), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  Command `antinuke` is already in the ignore list.');
  assert.equal(color(dup), 0xed4245);
  assert.match(text(fakeCmd), /Process Denied !/);
  assert.match(text(self), /cannot be ignored/);
  assert.match(text(selfSub), /cannot be ignored/);
  assert.match(text(alias), /Command `purge` has been added/);
});

test('.ignore command remove / reset', async () => {
  await run('m3', ['command', 'add', 'antinuke']);
  await run('m3', ['command', 'add', 'ban']);
  const missing = await run('m3', ['command', 'remove', 'kick']);
  assert.equal((await cmds('m3')).length, 2);
  const ok = await run('m3', ['command', 'remove', 'antinuke']);
  assert.deepEqual(await cmds('m3'), ['ban']);
  const reset = await run('m3', ['command', 'reset']);
  assert.deepEqual(await cmds('m3'), []);
  if (setup.mocked) return;
  assert.equal(text(missing), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  Command `kick` is not in the ignore list.');
  assert.equal(color(missing), 0xed4245);
  assert.equal(text(ok), '**<:wccheckmark:1551675781527380011>  Ignore Command Removed**\n<:whitearrow:1551669900622172161>  Command `antinuke` has been removed from the ignore list.');
  assert.equal(text(reset), '**<:wccheckmark:1551675781527380011>  Ignore Command Reset**\n<:whitearrow:1551669900622172161>  The ignored commands list has been reset.');
  assert.equal(color(reset), 0x2c2c2c);
});

test('.ignore command show: empty -> denied, list, pagination via igm buttons', async () => {
  const empty = await run('m4', ['command', 'show']);
  await run('m4', ['command', 'add', 'antinuke']);
  const one = await run('m4', ['command', 'show']);
  assert.ok(!one.components);
  if (!setup.mocked) {
    assert.equal(text(empty), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  There are no ignored commands in this server.');
    assert.equal(color(empty), 0xed4245);
    assert.equal(text(one), '### Ignored Commands [1]\n**[`01`]** `antinuke`\n-# Page 1/1 | Requested by Tester');
  }
  const names = Array.from({ length: 12 }, (_, i) => `cmd${i}`);
  await config.update('m4', 'automod', (d) => { d.ignoredCommands = names; });
  const first = await run('m4', ['command', 'show']);
  assert.equal(first.components?.length, 1);
  const calls = {};
  await ignore.handleCommandComponent({
    customId: 'igm:next:u1:1', user: { id: 'u1', username: 'tester' }, member: { displayName: 'Tester' }, inGuild: () => true, guild: { id: 'm4' },
    update: async (p) => { calls.update = p; },
  });
  if (!setup.mocked) assert.equal(text(calls.update), '### Ignored Commands [12]\n**[`11`]** `cmd10`\n**[`12`]** `cmd11`\n-# Page 2/2 | Requested by Tester');
  assert.ok(calls.update);
});

// ───────────── enforcement ─────────────
test('ignored commands are skipped for everyone except bypass users; subcommands and aliases are covered', async () => {
  const { isCommandIgnored } = require('../src/services/ignoreList');
  const { resolve } = require('../src/prefix');
  await config.update('e1', 'automod', (d) => { d.ignoredCommands = ['purge', 'role']; d.ignoredBypassUsers = ['vip']; });
  const purge = resolve('clear');                       // alias -> same command object
  assert.equal(purge.name, 'purge');
  assert.equal(await isCommandIgnored('e1', 'someone', purge), true);
  assert.equal(await isCommandIgnored('e1', 'vip', purge), false);        // bypass user
  assert.equal(await isCommandIgnored('e1', 'someone', resolve('role add')), true); // "role" covers "role add"
  assert.equal(await isCommandIgnored('e1', 'someone', resolve('ping')), false);
  assert.equal(await isCommandIgnored('other-guild', 'someone', purge), false);     // per server
  // never ignorable: the ignore command and its subcommands
  await config.update('e1', 'automod', (d) => { d.ignoredCommands = ['ignore', 'ignore bypass']; });
  assert.equal(await isCommandIgnored('e1', 'someone', resolve('ignore')), false);
  assert.equal(await isCommandIgnored('e1', 'someone', resolve('ignore bypass add')), false);
});

test('prefix dispatcher: an ignored command produces no reply, bypass users and other commands still work', async () => {
  const { handle } = require('../src/prefix');
  await config.update('e2', 'automod', (d) => { d.ignoredCommands = ['ping']; d.ignoredBypassUsers = ['vip']; });
  const attempt = async (userId, content) => {
    const sent = [];
    const message = {
      content, author: { id: userId, username: 'x' }, guild: { id: 'e2', members: { me: {} } }, createdTimestamp: 0,
      channel: { permissionsFor: () => ({ has: () => true }) },
      member: { permissions: { has: () => true } },
      client: { ws: { ping: 1 } },
      reply: async (p) => { sent.push(p); return { createdTimestamp: 0, edit: async () => {} }; },
    };
    const handled = await handle(message);
    return { handled, replies: sent.length };
  };
  const blocked = await attempt('someone', '.ping');
  assert.deepEqual(blocked, { handled: true, replies: 0 });
  const bypassed = await attempt('vip', '.ping');
  assert.equal(bypassed.handled, true);
  assert.ok(bypassed.replies >= 1);
});

// ───────────── .ignore role ─────────────
const rolesOf = async (g) => (await config.get(g, 'automod')).ignoredRoles;
const R1 = '666666666666666666';

test('.ignore role help + usage embeds', async () => {
  const help = await run('r1', ['role']);
  const add = await run('r1', ['role', 'add']);
  const rem = await run('r1', ['role', 'remove']);
  assert.deepEqual(await rolesOf('r1'), []);
  if (setup.mocked) return assert.ok(help.embeds && add.embeds && rem.embeds);
  const t = text(help);
  assert.ok(t.startsWith('### Aurora role [4]\n```yml\n<..> <required> | [..] [optional]\n```\n\n> **`.ignore role add`**'));
  assert.ok(t.includes("<a:space:1551669674213908510> <:whitearrow:1551669900622172161>  Add a role to the server's ignore list."));
  assert.ok(t.endsWith('-# Page 1/1 | Requested by Tester'));
  assert.equal(text(add), "```yml\n<..> <required> | [..] [optional]\n```\n> **`.ignore role add <role>`**\n\n<:whitearrow:1551669900622172161>  Add a role to the server's ignore list.");
  assert.equal(text(rem), "```yml\n<..> <required> | [..] [optional]\n```\n> **`.ignore role remove <role>`**\n\n<:whitearrow:1551669900622172161>  Remove a role from the server's ignore list.");
  assert.equal(color(add), 0x2c2c2c);
});

test('.ignore role add: adds, refuses duplicates, unknown roles and @everyone', async () => {
  const ok = await run('r2', ['role', 'add', R1]);
  assert.deepEqual(await rolesOf('r2'), [R1]);
  const dup = await run('r2', ['role', 'add', R1]);
  const everyone = await run('r2', ['role', 'add', 'r2']);            // the @everyone role id equals the guild id
  await assert.rejects(run('r2', ['role', 'add', '999999999999999999']), /could not find that role/);
  assert.deepEqual(await rolesOf('r2'), [R1]);
  if (setup.mocked) return assert.ok(everyone.embeds);
  assert.equal(text(ok), `**<:wccheckmark:1551675781527380011>  Ignore Role Added**\n<:whitearrow:1551669900622172161>  Role <@&${R1}> has been added to the ignore list.`);
  assert.equal(color(ok), 0x2c2c2c);
  assert.equal(text(dup), `**Process Denied !**\n<:wccrossmar:1551676376313237504>  Role <@&${R1}> is already in the ignore list.`);
  assert.equal(color(dup), 0xed4245);
  assert.match(text(everyone), /@everyone/);
});

test('.ignore role remove / reset', async () => {
  await run('r3', ['role', 'add', R1]);
  await run('r3', ['role', 'add', '777777777777777777']);
  const missing = await run('r3', ['role', 'remove', '888888888888888888']);
  assert.equal((await rolesOf('r3')).length, 2);
  const ok = await run('r3', ['role', 'remove', R1]);
  assert.deepEqual(await rolesOf('r3'), ['777777777777777777']);
  const reset = await run('r3', ['role', 'reset']);
  assert.deepEqual(await rolesOf('r3'), []);
  if (setup.mocked) return;
  assert.equal(text(missing), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  Role <@&888888888888888888> is not in the ignore list.');
  assert.equal(color(missing), 0xed4245);
  assert.equal(text(ok), `**<:wccheckmark:1551675781527380011>  Ignore Role Removed**\n<:whitearrow:1551669900622172161>  Role <@&${R1}> has been removed from the ignore list.`);
  assert.equal(text(reset), '**<:wccheckmark:1551675781527380011>  Ignore Role Reset**\n<:whitearrow:1551669900622172161>  The ignored roles list has been reset.');
  assert.equal(color(reset), 0x2c2c2c);
});

test('.ignore role show: empty (normal colour, as requested), list, pagination via igr buttons', async () => {
  const empty = await run('r4', ['role', 'show']);
  await run('r4', ['role', 'add', R1]);
  const one = await run('r4', ['role', 'show']);
  assert.ok(!one.components);
  if (!setup.mocked) {
    assert.equal(text(empty), '**Process Denied !**\n<:wccrossmar:1551676376313237504>  There are no ignored roles in this server.');
    assert.equal(color(empty), 0x2c2c2c);
    assert.equal(text(one), `### Ignored Roles [1]\n**[\`01\`]** <@&${R1}>\n-# Page 1/1 | Requested by Tester`);
    assert.equal(color(one), 0x2c2c2c);
  }
  const ids = Array.from({ length: 11 }, (_, i) => String(300000000000000000n + BigInt(i)));
  await config.update('r4', 'automod', (d) => { d.ignoredRoles = ids; });
  const first = await run('r4', ['role', 'show']);
  assert.equal(first.components?.length, 1);
  const calls = {};
  await ignore.handleRoleComponent({
    customId: 'igr:next:u1:1', user: { id: 'u1', username: 'tester' }, member: { displayName: 'Tester' }, inGuild: () => true, guild: { id: 'r4' },
    update: async (p) => { calls.update = p; },
  });
  assert.ok(calls.update);
  if (!setup.mocked) assert.equal(text(calls.update), `### Ignored Roles [11]\n**[\`11\`]** <@&${ids[10]}>\n-# Page 2/2 | Requested by Tester`);
  // all roles removed while the message was open -> same empty embed, no buttons
  await config.update('r4', 'automod', (d) => { d.ignoredRoles = []; });
  const gone = {};
  await ignore.handleRoleComponent({ customId: 'igr:next:u1:1', user: { id: 'u1' }, inGuild: () => true, guild: { id: 'r4' }, update: async (p) => { gone.update = p; } });
  assert.deepEqual(gone.update.components, []);
});
