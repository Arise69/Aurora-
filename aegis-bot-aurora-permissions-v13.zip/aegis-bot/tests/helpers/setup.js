'use strict';
/**
 * Test bootstrap. If discord.js is installed, the real library is used. Otherwise (e.g. an offline CI sandbox)
 * a small faithful mock of the slash-command builders + enums is registered so the whole project can still be
 * loaded and every command definition validated against Discord's documented limits.
 */
const Module = require('node:module');

// dotenv is a trivial dependency; stub it when the sandbox has no node_modules.
try { require.resolve('dotenv'); } catch {
  const origLoadEnv = Module._load;
  Module._load = function patchedEnv(request, ...rest) { return request === 'dotenv' ? { config() {} } : origLoadEnv.call(this, request, ...rest); };
}

try { require.resolve('discord.js'); module.exports = { mocked: false }; } catch {
  const enumProxy = (start = 0) => { const map = new Map(); return new Proxy({}, { get: (_, k) => (typeof k === 'string' ? (map.has(k) ? map.get(k) : (map.set(k, map.size + start), map.get(k))) : undefined) }); };
  const bigEnum = () => { const map = new Map(); return new Proxy({}, { get: (_, k) => (typeof k === 'string' ? (map.has(k) ? map.get(k) : (map.set(k, 1n << BigInt(map.size)), map.get(k))) : undefined) }); };
  const stringEnum = () => new Proxy({}, { get: (_, k) => (typeof k === 'string' ? k : undefined) });

  const OPT = { String: 3, Integer: 4, Boolean: 5, User: 6, Channel: 7, Role: 8, Mentionable: 9, Number: 10 };
  class Option {
    constructor(type) { this.type = type; }
    setName(v) { this.name = v; return this; } setDescription(v) { this.description = v; return this; }
    setRequired(v = true) { this.required = v; return this; } setAutocomplete(v = true) { this.autocomplete = v; return this; }
    setMinValue(v) { this.min_value = v; return this; } setMaxValue(v) { this.max_value = v; return this; }
    setMinLength(v) { this.min_length = v; return this; } setMaxLength(v) { this.max_length = v; return this; }
    addChoices(...c) { this.choices = [...(this.choices ?? []), ...c.flat()]; return this; }
    addChannelTypes(...t) { this.channel_types = t.flat(); return this; }
    toJSON() { const { ...o } = this; if (!o.required) delete o.required; return o; }
  }
  class Container {
    constructor() { this.options = []; }
    setName(v) { this.name = v; return this; } setDescription(v) { this.description = v; return this; }
    toJSON() { return { ...this, options: this.options.map((o) => o.toJSON()) }; }
  }
  for (const [k, t] of Object.entries(OPT)) {
    Container.prototype[`add${k}Option`] = function add(fn) { const o = new Option(t); fn(o); this.options.push(o); return this; };
  }
  class Sub extends Container { constructor() { super(); this.type = 1; } }
  class Group extends Container {
    constructor() { super(); this.type = 2; }
    addSubcommand(fn) { const s = new Sub(); fn(s); this.options.push(s); return this; }
  }
  class SlashCommandBuilder extends Container {
    setContexts(...c) { this.contexts = c.flat(); return this; }
    setDefaultMemberPermissions(p) { this.default_member_permissions = String(p); return this; }
    addSubcommand(fn) { const s = new Sub(); fn(s); this.options.push(s); return this; }
    addSubcommandGroup(fn) { const g = new Group(); fn(g); this.options.push(g); return this; }
  }
  const generic = () => { const f = function noop() {}; return new Proxy(f, { get: (t, p) => (p === Symbol.toPrimitive ? () => 'mock' : p === 'then' ? undefined : generic()), apply: () => generic(), construct: () => generic() }); };
  const known = {
    SlashCommandBuilder, PermissionFlagsBits: bigEnum(), ChannelType: enumProxy(), InteractionContextType: { Guild: 0 },
    MessageFlags: { Ephemeral: 64 }, Events: stringEnum(), AuditLogEvent: enumProxy(100), MessageType: enumProxy(200), ActivityType: { Custom: 4 },
    ButtonStyle: enumProxy(1), TextInputStyle: enumProxy(1), version: '0.0.0-mock',
  };
  const mock = new Proxy(known, { get: (t, k) => (k in t ? t[k] : typeof k === 'string' ? generic() : undefined) });
  const origLoad = Module._load;
  Module._load = function patched(request, ...rest) { return request === 'discord.js' ? mock : origLoad.call(this, request, ...rest); };
  module.exports = { mocked: true };
}
