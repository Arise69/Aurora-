'use strict';
require('./helpers/setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

test('AES-256-GCM round trip, tamper detection', () => {
  process.env.ENCRYPTION_KEY = crypto.randomBytes(32).toString('base64');
  const c = require('../src/utils/crypto');
  assert.equal(c.isConfigured(), true);
  const url = 'https://discord.com/api/webhooks/1/secret-token';
  const enc = c.encrypt(url);
  assert.ok(!enc.includes('secret-token'));
  assert.notEqual(enc, c.encrypt(url)); // random IV
  assert.equal(c.decrypt(enc), url);
  const parts = enc.split(':'); parts[3] = Buffer.from('tampered').toString('base64');
  assert.throws(() => c.decrypt(parts.join(':')));
  process.env.ENCRYPTION_KEY = 'short';
  assert.equal(c.isConfigured(), false);
  assert.throws(() => c.encrypt('x'));
});
