'use strict';
require('./helpers/setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCommands } = require('../src/utils/loaders');
const { CATEGORIES } = require('../src/services/help');

const commands = loadCommands();
const NAME_RE = /^[\p{Ll}\p{Lm}\p{Lo}\p{N}_-]{1,32}$/u;

function measure(node) {
  let n = (node.name?.length ?? 0) + (node.description?.length ?? 0);
  for (const c of node.choices ?? []) n += String(c.name).length + String(c.value).length;
  for (const o of node.options ?? []) n += measure(o);
  return n;
}

function checkOptions(path, options = []) {
  assert.ok(options.length <= 25, `${path}: more than 25 options`);
  let seenOptional = false;
  const names = new Set();
  for (const o of options) {
    const here = `${path} ${o.name}`;
    assert.match(o.name, NAME_RE, `${here}: invalid name`);
    assert.ok(o.description && o.description.length <= 100, `${here}: description missing or > 100 chars (${o.description?.length})`);
    assert.ok(!names.has(o.name), `${here}: duplicate option name`);
    names.add(o.name);
    if (o.type === 1 || o.type === 2) {
      if (o.type === 2) assert.ok(o.options.every((s) => s.type === 1), `${here}: groups may only contain subcommands`);
      checkOptions(here, o.options);
    } else {
      if (o.required) assert.ok(!seenOptional, `${here}: required option after optional option`);
      else seenOptional = true;
      if (o.choices) assert.ok(o.choices.length <= 25, `${here}: > 25 choices`);
      for (const c of o.choices ?? []) assert.ok(String(c.name).length <= 100, `${here}: choice name too long`);
    }
  }
}

test('command registry is valid for Discord', () => {
  assert.ok(commands.size <= 100, `top-level commands: ${commands.size}`);
  const known = new Set(CATEGORIES.map(([n]) => n));
  for (const [name, cmd] of commands) {
    const json = cmd.data.toJSON();
    assert.equal(json.name, name);
    assert.match(json.name, NAME_RE);
    assert.ok(json.description && json.description.length <= 100, `/${name}: bad description`);
    assert.ok(known.has(cmd.category), `/${name}: unknown help category "${cmd.category}"`);
    const kinds = new Set((json.options ?? []).map((o) => (o.type === 1 || o.type === 2 ? 'sub' : 'opt')));
    assert.ok(kinds.size <= 1, `/${name}: mixes subcommands and plain options`);
    checkOptions(`/${name}`, json.options);
    assert.ok(measure(json) < 6000, `/${name}: definition too large (${measure(json)} chars, limit 6000-8000)`);
    if (cmd.autocomplete) assert.equal(typeof cmd.autocomplete, 'function');
  }
  console.log(`  ${commands.size} top-level commands validated`);
});

test('every subcommand has a handler (dispatch keys match the definition)', async () => {
  let checked = 0;
  for (const [name, cmd] of commands) {
    const json = cmd.data.toJSON();
    const pairs = [];
    for (const o of json.options ?? []) {
      if (o.type === 1) pairs.push([null, o.name]);
      else if (o.type === 2) for (const s of o.options) pairs.push([o.name, s.name]);
    }
    for (const [group, sub] of pairs) {
      const fake = { options: { getSubcommandGroup: () => group, getSubcommand: () => sub }, inGuild: () => true };
      try { await cmd.execute(fake); } catch (err) {
        assert.ok(!/No handler for subcommand/.test(String(err.message)), `/${name} ${group ?? ''} ${sub}: ${err.message}`);
      }
      checked += 1;
    }
  }
  console.log(`  ${checked} subcommands have handlers`);
});

test('help coverage: every category has commands', () => {
  const used = new Set([...commands.values()].map((c) => c.category));
  for (const [n] of CATEGORIES) assert.ok(used.has(n), `help category "${n}" has no commands`);
});

test('all event modules load', () => {
  const fs = require('node:fs'); const path = require('node:path');
  const dir = path.join(__dirname, '..', 'src', 'events');
  for (const f of fs.readdirSync(dir)) {
    const mod = require(path.join(dir, f));
    for (const h of Array.isArray(mod) ? mod : [mod]) assert.equal(typeof h.execute, 'function', `${f}: handler without execute`);
  }
  require('../src/prefix');
  require('../src/services/scheduler');
});
